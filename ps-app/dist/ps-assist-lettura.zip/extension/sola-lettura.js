// Build «Stampa Infermeria»: solo la stazione di stampa (e sola lettura). Generato da tools (dist/ext-mini).
self.PSA_SOLA_LETTURA = true;
self.PSA_SOLO_STAZIONE = true;
