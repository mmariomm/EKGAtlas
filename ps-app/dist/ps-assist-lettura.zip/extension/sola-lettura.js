// Build mini «Lettura e stampa»: sola lettura. Generato da tools (dist/ext-mini).
self.PSA_SOLA_LETTURA = true;
