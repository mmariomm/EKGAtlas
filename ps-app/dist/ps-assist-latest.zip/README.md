# PS Assist — richieste Pronto Soccorso in un click (SA4PSO)

Ricostruito **da zero** (agosto 2026) dopo un re-audit completo delle pagine reali salvate di SA4PSO.
Sostituisce il vecchio script v0.6 ("un esame per ricaricamento di pagina") con un motore molto più
semplice e robusto: guida il server con le **stesse identiche richieste dei click manuali**, tutto da una
sola pagina, verificando ogni passaggio prima del successivo.

> **In sintesi per il medico**: dalla pagina del paziente scrivi il quesito, tocchi i profili
> e gli esami, premi un bottone. La richiesta viene creata, gli esami aggiunti e
> verificati uno a uno nel carrello, e atterri sulla pagina esami reale per premere **Conferma**
> (o lasci che la prema lui, subito: il tuo click su «+ Conferma» è la decisione). Dopo la conferma parte da
> solo il **wizard di stampa**: PDF etichette con la finestra di stampa già aperta
> (etichettatrice), poi PDF lista esami (stampante normale).

---

## Installazione (Chrome / Edge, PC ospedale)

Il modo più semplice nel 2026 è l'**estensione dedicata** (niente Tampermonkey: da Chrome 138+ i
gestori di userscript richiedono anche il toggle "Consenti script utente" per estensione — un
passaggio in più che qui non serve).

1. Scarica il progetto da https://github.com/mmariomm/EKGAtlas (**Code → Download ZIP**, branch
   `main`), estrai: ti serve solo `ps-app/extension`.
2. Apri `chrome://extensions` (o `edge://extensions`).
3. Attiva **Modalità sviluppatore** (interruttore in alto a destra).
4. Premi **Carica estensione non pacchettizzata** e seleziona la cartella `ps-app/extension`.
5. Apri SA4PSO: il pannello blu appare in alto a destra sulle pagine di paziente, Nuova
   Richiesta ed esami, **intestato col nome del paziente** su cui stai lavorando (anche da
   minimizzato, così sai sempre per chi stai ordinando). Sulla **lista del pronto soccorso**,
   dove non c'è un paziente aperto, il pannello non mostra alcun esame: lì non si può ordinare.
   Si **trascina** dall'intestazione e si **ridimensiona** dall'angolo in basso a sinistra
   (posizione e misura restano memorizzate; doppio click sull'intestazione o sull'angolo per
   tornare a com'era).

**Perché "si aggiorna" a ogni pagina?** Il gestionale è un'app anni 2000: OGNI click ricarica
l'intera pagina — nessuna estensione può impedirlo. Il pannello però **si ricostruisce identico**:
quesito, esami selezionati, sezioni aperte e posizione tornano come li hai lasciati (per lo
stesso paziente, nella stessa scheda), quindi in pratica non te ne accorgi.

**Aggiornare a una nuova versione**: sostituisci i file nella STESSA cartella dell'estensione e
premi **"⟳ ricarica estensione"** nel piè di pagina del pannello (o ⟳ in `chrome://extensions`).
Un'estensione non pacchettizzata non può scaricarsi gli aggiornamenti da sola, e PS Assist non
contatterà mai server esterni per controllare le versioni — sarebbe contro la regola «nessun dato
lascia l'ospedale». Le nuove versioni arrivano come zip: sostituisci, ricarica, fatto.

### E se non posso? (PC bloccato dall'IT, niente admin)

- La **Modalità sviluppatore NON richiede i permessi di amministratore di Windows**: è
  un'impostazione del profilo browser, normalmente disponibile a qualunque utente. Se però
  l'interruttore è grigio o assente, è una **policy aziendale** del browser (si vede in
  `chrome://policy`, voci tipo `ExtensionSettings` / `ExtensionDeveloperModeSettings`) — e lì
  nessun trucco locale la scavalca.
- **Piano B che funziona sempre, zero installazione: il bookmarklet.**
  1. Apri il file `ps-app/bookmarklet/ps-assist.bookmarklet.txt` e copia **tutto** il contenuto
     (inizia con `javascript:`).
  2. Crea un preferito qualsiasi nella barra dei preferiti → tasto destro → **Modifica** →
     incolla il testo copiato nel campo **URL** → nominalo `PS Assist`.
  3. Su ogni pagina SA4PSO, **un click sul preferito** fa comparire il pannello. Unica
     differenza dall'estensione: dopo un cambio pagina (es. dopo la Conferma) va ricliccato —
     conferma, ripresa del giro e wizard di stampa ripartono al click, perché i passaggi di
     consegna vivono nella scheda. Per lo stesso motivo qui il browser continua ad avvisare
     prima di lasciare una pagina mentre il giro sta mandando: senza un click nessuno lo
     riprenderebbe.
- A regime, la strada pulita è chiedere all'IT di consentire l'estensione (cartella locale o
  allowlist aziendale).

---

## Uso quotidiano

**Due forme, un tocco per passare dall'una all'altra.** Aperto, il pannello è una **finestra al
centro che prende l'85% dello schermo**: intestazione e schede restano ferme, scorre solo il
contenuto, che sta su una colonna comoda da leggere (valori e stanza usano tutta la larghezza).
La sposti dall'intestazione, la ridimensioni da **qualsiasi bordo o angolo**; **doppio clic**
sull'intestazione o sull'angolo la rimette al centro, all'85%. **—** la riduce alla **pill**, che
resta dove la trascini; un tocco sulla pill riapre la finestra dove l'avevi lasciata. Per usare il
gestionale sotto, si riduce alla pill: la finestra lo copre quasi tutto, apposta.

**Si apre da solo solo quando serve.** Una pagina raggiunta cliccando nel gestionale mostra la
pill: lì stai lavorando tu. La finestra si apre da sola quando la pagina l'ha aperta il pannello
(un paziente scelto dall'elenco, Richieste…) o quando ha qualcosa da dirti (un giro finito, un
avviso). **Esc** o un clic fuori la riducono; dopo **Copia** si riduce da sola e la pill dice
«✓ Copiato · incolla». Nel menu **⋯**: **Al centro** e **Affianca a destra** (una colonna, col
gestionale accanto), poi Registro e versione.

Il pannello ha cinque schermate, in **una fila di schede** sempre in cima e nell'ordine in cui si
lavora: **Richieste · Esiti · EO · Consensi · Dimissioni** (sulla lista del pronto soccorso, dove
non c'è un paziente: **Pazienti · EO · Consensi · Dimissioni**). Il paziente + episodio stanno nell'intestazione (anche da minimizzato). Sulla pagina «Storico dati clinici»
del portale clinico non c'è pannello: solo una striscia che dice cosa ha letto.

### Pazienti (‹ in alto a sinistra)

Aprire un paziente **dal gestionale** porta ai suoi **Esiti**, perché è quasi sempre quello che si
va a fare; ordinare è un tocco più in là — **Richieste** è sempre in cima. Dal pannello, sceglierne
un altro **carica la sua pagina**: il pannello non mostra mai i dati di un paziente diverso da
quello che hai davanti. Il pannello parte da qui solo sulla lista del pronto soccorso, dove non c'è
un paziente aperto; sulla scheda di un paziente parte dagli **Esiti**.

La stessa gente in due viste, **Lista | Stanza**: l'interruttore sta in fondo alla fila delle
schede e si ricorda l'ultima scelta.

**Lista** — i pazienti su cui hai lavorato nel turno, **una riga per paziente**: la striscia del
**triage**, il nome (un tocco sulla riga apre gli Esiti), la nota in grigio, **visto 20 min fa** —
in ambra dopo 3 ore —, oppure **questa pagina** per quello aperto, che è il primo; poi **dove sta**
nella stanza («Box 3 ▾», o «—»: un tocco e lo sposti), **Richieste** (in azzurro sulla riga sotto il
mouse), e passandoci sopra la **✕** per toglierlo dall'elenco. Il nome non si taglia mai per primo:
nella colonna stretta la nota scende sotto il nome e «visto…» si toglie. In fondo, chiusi, gli
**Archiviati** e **Svuota l'elenco**.

**Stanza** — una mappa minima della stanza, per vedere a colpo d'occhio **dove sta ogni paziente**:
i **letti** (uno per paziente) e le **aree** senza letto — corridoio, attesa, poltrone — dove ne
stanno quanti servono. A sinistra **Da sistemare**: chi non ha ancora un posto. Un paziente nuovo
arriva lì da solo, e nessuno sparisce: se il suo letto viene tolto, torna lì. Nella finestra
stretta «Da sistemare» scende in fondo, su una riga che scorre.

La stanza è una **griglia di celle uguali** (40 × 24; un letto ne prende 5 × 4): allargando o
stringendo la finestra cresce o cala tutta insieme, in scala, e **niente si sovrappone** — nemmeno
affiancata o alla misura minima, dove semmai la mappa scorre (sotto i 20 px una cella non porta più
un nome leggibile). Fuori da Modifica si vede solo il
pezzo disegnato, così anche una stanza piccola riempie la mappa. Il testo non cambia misura: in un
letto piccolo sparisce prima la nota, poi tutto tranne il nome del paziente (quello del letto resta
nel passaggio del mouse). Un letto vuoto è solo il suo nome e un letto disegnato appena.

- **Portare un paziente**: lo prendi e lo lasci su un letto, su un'area o in «Da sistemare»
  (col dito: soglia di 10 px); ti segue il suo nome, accanto al puntatore, mai sopra il letto che
  miri. Su un letto occupato **il nuovo prende il letto e chi c'era va in «Da sistemare»** —
  passandoci sopra lo dice: «ROSSI M. → Da sistemare». Premuto e lasciato senza trascinare, per
  quanto a lungo, **apre il paziente**, come le righe dell'elenco.
- **Sposta in…**, senza trascinare: tasto destro sul paziente, dito tenuto premuto, Maiusc+F10 (o
  il tasto menu), oppure il «posto» della Lista. Prima i letti vuoti, poi quelli occupati («al posto
  di ROSSI M.»), le aree, «Da sistemare» e, a parte, **Togli dall'elenco** (come la ✕); frecce,
  Invio, Esc.
- **Niente conferme: si annulla.** Ogni spostamento, un letto o un'area eliminati, «Togli
  dall'elenco», «svuota» e la ✕ mostrano per 8 secondi, in fondo, «… · **Annulla**».
- **Modifica** serve a disegnare la stanza, di solito una volta sola. Ci entri da **Disegna la
  stanza** (a stanza vuota) o dal menu **⋯ → Modifica la stanza**; la fila delle schede diventa la
  sua barra: **+ Letto**, **+ Area** e **Fine**. Si vede la pianta intera, coi puntini, e letti e
  aree si trascinano di cella in cella; uno nuovo va nel primo posto libero (se non ce n'è, lo
  dice). Dove un oggetto finirebbe sopra un altro diventa **rosso**, e lasciato lì torna dov'era.
  Un tocco sul **nome** lo cambia (Invio salva, Esc lascia com'era); sull'oggetto scelto la **×** lo
  toglie; l'angolo in basso a destra allarga un'area. In Modifica i pazienti stanno fermi, in
  grigio; **Fine** (o Esc) e si torna a spostarli.

**Per non sbagliare paziente.** Due pazienti in elenco con lo **stesso cognome** portano **⚠** e il
nome intero; con lo **stesso nome e cognome**, anche le ultime cifre dell'episodio: «ROSSI MARIO ·
…9001». Passando col mouse su un paziente: nome intero, episodio, quando l'hai aperto, da quando sta
nel suo posto, il triage, la nota. Lo **stesso paziente** (stesso codice fiscale) con due episodi:
il più vecchio è **episodio precedente**, in grigio, fuori dalla stanza. Il posto **non scade**:
resta finché non sposti il paziente, non lo togli dall'elenco o dall'elenco non esce; se non lo apri
da **12 ore** diventa grigio, dov'è.

**Il triage** è il colore che l'intestazione della scheda mostra quando la apri (ROSSO, ARANCIONE,
AZZURRO, VERDE, BIANCO): una striscia a sinistra del nome, la stessa in Lista e in Stanza (nel letto
la porta il letto), e basta — nella Stanza il colore vuol dire solo triage.

Tutto resta **solo in questo browser** (`localStorage`), niente va in rete; un altro PC o un altro
profilo Chrome ha la sua stanza. La **stanza disegnata** (`stanza.v1`: celle intere della griglia,
così a ogni misura è la stessa) resta come i fogli di dimissione: è un modello, non contiene
pazienti. **Chi sta dove** (`stanza.posti.v1`) sono solo numeri di episodio, mai nomi. La pagina di
login **non** li cancella: chi viene riaperto dopo una sessione scaduta ritrova il suo letto (il
posto aspetta al massimo un giorno). «Svuota l'elenco» toglie anche i posti; eliminare un paziente
(🗑) toglie anche il suo.

### Richieste
1. **Quesito diagnostico** — casella su una riga, suggerimenti a fianco; l'ultimo resta scritto.
   La **radiologia ha il suo**: casella «Quesito RX» nel gruppo RX. Se è vuota, la richiesta di
   radiologia prende quello sopra; se è scritta, il laboratorio usa quello sopra e la radiologia
   il suo.
2. Gli esami stanno in **gruppi per laboratorio** — **POC**, **Lab centrale** (le «Urgenze» e il
   laboratorio centrale: per chi ordina sono lo stesso posto), **RX** — e ogni gruppo ha **in
   testa i suoi profili rapidi**: Base PS e Coag POC sotto POC, Epatico e Coag sotto Lab
   centrale. Poi gli **esami singoli** — fra questi
   **EGA VENOSA NEW** / **EGA ARTERIOSA NEW** (il laboratorio ha rifatto gli emogas: sono i
   codici nuovi, e la vecchia versione resta in elenco solo in «altri esami…»), gli **epatici
   uno per uno** (GPT, GOT, GAMMA GT, BILIRUBINA, LIPASI: il profilo li ordina insieme, ma
   quasi sempre se ne vuole uno solo) e **SARSCOV**
   (tampone antigenico SARS-CoV-2, laboratorio centrale), griglia compatta a
   due colonne per laboratorio (POC / Lab centrale / RX). Per tutto il resto: **«altri esami…»** con
   menu a tendina su tutti i laboratori. I selezionati restano in alto, una riga per laboratorio,
   con la ✕ al passaggio del mouse.
   In una sede che la versione **- NEW** non ce l'ha ancora, il pannello ordina **quella di
   sempre** e lo scrive nel Registro: un codice nuovo non deve far fallire un ordine.
   **La seconda sede (OSG)** non ha il laboratorio «Urgenze»: POC e un laboratorio unico. Gli
   esami della colonna Urgenze vanno nella risorsa di questa sede che ha **lo stesso esame** —
   stesso nome o stesso mnemonico LIS — e **mai** in un POC (un altro strumento, un'altra
   provetta): la PCR del bottone finisce nel laboratorio, non fra i POC. In «altri esami…» si
   vedono solo le risorse della sede in cui sei (prima ogni esame usciva due volte, una per
   sede), e i nomi di reparto funzionano: **PCR** trova «PROTEINA C REATTIVA» (prima trovava
   solo «PCR POC»), e così PCT, EGA, GGT, AST/ALT, BNP, tropo — il laboratorio prima del POC.
3. **Mentre manda, puoi fare altro.** Partito il giro il pannello si fa piccolo: una
   **striscia** in un angolo con il nome del paziente, a che punto è (3/6) e che cosa sta
   facendo in quel momento — *creo la richiesta*, *invio LIPASI*, *controllo il carrello 2/3*,
   *confermo*. Sotto ci lavori normalmente: il gestionale non è bloccato e non compare più
   «vuoi lasciare la pagina?».
   **Se navighi, il giro non muore: riprende.** Il motore vive nella pagina e la pagina muore a
   ogni click, quindi il giro è annotato passo per passo e riparte da solo sulla pagina dopo —
   rilegge il carrello dal server, salta quello che c'è già, manda il resto. L'esame che era
   **in volo** nell'istante del cambio pagina **non viene mai rimandato**: si cerca in
   carrello, e se non c'è il giro si ferma e te lo dice (una provetta in più al laboratorio non
   è un dettaglio). Finito, la pagina **non** te la porta via: il carrello lo apri col bottone,
   e le etichette partono quando torni sulla scheda di quel paziente.
   Un tocco sulla striscia apre il pannello intero (passi + Registro), il quadratino rosso
   ferma tutto. **Esc** ferma il giro solo col pannello aperto: da quando gira in sottofondo, un
   Esc dato al gestionale (una tendina, un campo) non deve fermare gli esami. Se intanto sei sulla scheda di un altro paziente la striscia diventa **ambra** e
   lo scrive: gli esami restano quelli di chi li hai ordinati.
4. **Crea e aggiungi N esami** → ricevuta + bottone **✓ CONFERMA → stampa**; oppure
   **+ Conferma 🖨** che fa tutto da solo e conferma **subito**: il click è la decisione, e la
   conferma parte solo se ogni controllo passa — episodio, richiesta, nome dell'ultimo esame, e
   **carrello identico alla ricevuta** (un avanzo di un tentativo precedente la **sospende** e
   la lascia a te).
   Selezionando laboratorio **e** radiologia il bottone diventa **Crea 2 richieste** e il pannello
   le costruisce e le porta entrambe a conferma, con **una sola** stampa finale. Questa è
   l'unica che **non** va in sottofondo: le due richieste vivono nella memoria del pannello, e
   a metà non si riprendono — lì il browser avvisa ancora prima di cambiare pagina.
5. **Stampa**: ogni richiesta con data, ora e la lista compatta degli esami.

### Esiti
Due sezioni, una sotto l'altra: **Valori** e **Referti**.

**Valori** è un'unica tabella: gli analiti in riga, raggruppati per sezione fissa (*Emocromo,
Coagulazione, Biochim, Organi, Elettroliti e metabolismo, Emogas, Urine e altri liquidi*, e in
fondo **Altri** — i dettagli più sotto), una colonna per prelievo, **il più recente a sinistra**
(marcato «ultimo»). In cima a ogni colonna: **solo l'ora** se il prelievo è di oggi, **la data**
(27/08) con l'ora sotto se è di un altro giorno; **passando il mouse** sull'intestazione si legge
data e ora per esteso e **gli esami** compresi in quella richiesta.

- I nomi sono in **sigla** (`Hb`, `GB`, `PLT`…), con l'**unità fra parentesi accanto al nome**
  (`GB (x10³/µL)`) e il **range nel tooltip del valore**.
- La **formula leucocitaria** è una riga per cellula: il valore **assoluto** e fra parentesi la
  **percentuale** — `Neu 4.0 (56%)`. Il laboratorio le manda in coppia («Granulociti» e
  «Granulociti %»), che prima erano due righe con lo stesso nome. Il fuori range è quello
  dell'assoluto; una percentuale che arriva da sola resta da sola. Un nome fuori elenco è scritto **per esteso** e sottolineato a puntini — lo stesso
  vale per un'abbreviazione ambigua — e una riga d'avviso in cima dice **quali**.
- La tabella è **larga quanto i suoi numeri**, non quanto il pannello: se allarghi la finestra i
  valori restano **accanto ai nomi** invece di allontanarsene, e sono allineati a sinistra
  (incolonnati dalle cifre tabulari).
- In rosso c'è **solo il valore**, con ↑ ↓: il nome resta a sinistra, sempre nella stessa colonna.
  Una cella **·** = quel prelievo non ha quell'analita; *in corsivo* = risultato ancora
  **parziale** (il laboratorio non ha finito — c'è una riga che lo ricorda sotto la tabella). Quando lo stesso
  analita arriva da esami diversi — l'emocromo del POC e quello del laboratorio, per dire — chi
  non è «il solito» porta un **asterisco o una croce**, spiegati nella legenda sotto la tabella.
- **⭳ Carica i valori** legge i prelievi non ancora letti; fatta la prima lettura diventa
  **↻ Aggiorna**, che rilegge **tutti** i prelievi ancora aperti, a passo lento e uno alla volta.
  Con l'estensione il bottone legge **lo storico del portale**, in una scheda di sottofondo che si
  chiude da sola (vedi *Da dove viene la tabella*): lì ci sono **tutti** i valori del laboratorio,
  refertati e no, con una pagina sola. Le finestre Risultati — una richiesta per prelievo — si
  leggono **solo se il portale non si può leggere** (niente estensione, niente link, o non ha
  risposto: il pannello dice perché).
  **solo alterati** / **tutti** filtra le righe; **↺ Reset** dimentica i valori letti e la scheda
  in archivio di questo paziente, e **⭳ Carica i valori** li rilegge da zero (i tuoi segni
  restano).
- Di un prelievo il gestionale può **non dare data e ora** (né nel campo nascosto della riga, né
  a video). Quei valori **non spariscono**: diventano la colonna **?**, in fondo a destra, con
  «ora ignota» sotto e il motivo nel tooltip. Una riga sotto i bottoni lo dice, e il Registro
  elenca ogni prelievo letto con la colonna in cui è finito.
- **Un tocco su un valore lo segna**: giallo; un secondo tocco arancio; un terzo lo spegne. I segni
  sono tuoi, restano col paziente (24 ore, come la nota) e sopravvivono al cambio di pagina.
- **Cosa è cambiato dall'ultima volta che hai guardato**: dopo un **↻ Aggiorna**, in quel prelievo
  un valore cambiato ha **sfondo azzurro**, e lo stesso vale per un analita comparso da zero. In
  cima compare **«N valori nuovi dall'ultima lettura»** con un bottone **Letto** che spegne i
  marchi. La prima lettura di un prelievo è sempre il riferimento: non è mai un muro di marchi.
- Un avviso dice quanti prelievi mancano ancora (**«N prelievi ancora da leggere»**: ⭳ Carica i
  valori) e quali non si sono lasciati leggere (il **Registro** dice perché; **↻ Aggiorna**
  riprova).
- La tabella mette insieme due cose: i prelievi letti **in questa scheda del browser** — sempre,
  anche col bookmarklet e senza estensione — e, quando è di questo paziente, la **scheda
  clinica** che l'estensione tiene in archivio (la tabella del portale, e i prelievi letti in
  altre schede). Un prelievo il cui referto è arrivato nel frattempo — e la cui finestra
  Risultati è quindi sparita — **resta in tabella** come colonna: non scompare mai.
- Il pannello **si allarga da solo** quanto serve alle colonne, fino all'**80%** dello schermo in
  larghezza e altezza — mai più stretto di come l'hai già ridimensionato a mano.
- Quando la scheda viene (anche) dal portale, sotto la tabella compare: *«Con lo storico del
  portale, letto per NOME · identità confermata dal paziente da cui l'hai aperta / dal codice fiscale / dal nome»*.

**Referti** è la lista dei documenti (ECG, RX, TC, visite…), una riga ciascuno, come sempre. I
referti di **laboratorio** stanno tutti insieme sotto una riga **Laboratorio**, **chiusa**: quello
che dicono è già nella tabella qui sopra, e in mezzo agli altri facevano perdere l'ECG e la
radiologia. Un tocco sulla riga li apre — restano documenti da aprire come prima, ognuno con
**data e ora della richiesta**; il gruppo chiuso dice quanti sono e di quando è l'ultimo. Aperto o
chiuso, resta com'era anche dopo che la pagina si ricarica.
- **RIS ›** — referti di **radiologia** (RX, TC, ecografia, RMN) ed **ECG**: si aprono **dentro il
  pannello, come testo**. Il testo lo legge **pdf.js** — il lettore PDF di Firefox, dentro
  l'estensione, caricato nella scheda solo quando apri un referto: legge quello che legge Firefox
  (PDF cifrati, oggetti compressi, font di ogni tipo). Senza estensione resta il lettore interno,
  più semplice. Leggi il referto senza cambiare scheda, lo copi per il diario con **⧉ Copia**, e
  il PDF resta a un tocco (**↗ PDF**). I referti sono **PDF di testo, mai immagini**: se il testo
  non esce è uno sbaglio del lettore, non del referto — il PDF **si tiene** lo stesso (pallino
  verde) e si apre, e **⧉ Copia diagnosi** dice com'è fatto quel PDF (versione, cifratura, font,
  filtri: **mai il contenuto**), per correggerlo. Se il pannello non lo legge, al tocco ci prova anche il **service
  worker** (che raggiunge il server del portale, dove la pagina del gestionale non arriva). Se
  neanche lui, il pallino è rosso col motivo — e il motivo dice **su quale server** il gestionale
  rimanda il referto (solo l'indirizzo del server, niente del paziente) — e il documento **si apre
  lo stesso, con lo stesso tocco**. **⧉ Copia diagnosi** ora c'è per **ogni** referto non letto,
  non solo per i visualizzatori HTML.
- **LIS/AMB ↗** — gli altri referti (PDF): si aprono in una scheda e, con l'estensione, il
  documento che apri **viene tenuto** (pallino verde) — la volta dopo si apre all'istante, senza
  toccare il server. **⬇ Salva referti** li prende tutti in una volta, **↻ Resetta** svuota.
  Un referto che non si lascia salvare (pallino rosso, il motivo al passaggio del mouse e nel
  Registro) resta apribile con un tocco; **⧉ Copia diagnosi** copia com'è fatto il visualizzatore
  che l'ha impedito — senza numeri né valori dei campi — da mandare a chi fa il pannello. Lo
  stesso bottone (**⧉ Diagnosi**) compare nella finestra di stampa quando un documento non si
  lascia catturare.

> Perché i referti restano fuori dalla tabella dei Valori: referto e prelievo sono due cose
> diverse per il gestionale (un referto per documento, un accesso per prelievo, senza una chiave
> comune) e un abbinamento "a occhio" per nome ed ora prima o poi metterebbe i valori di un
> prelievo sotto il documento di un altro. Meglio due sezioni distinte e oneste che una fusione
> plausibile ma sbagliata.

### Chi c'è, e chi è stato dimesso
Nell'elenco **Pazienti** ogni scheda ha **Dimesso ✓**: il paziente esce dall'elenco principale e
finisce fra gli **Archiviati** (in fondo, con il conteggio). Da lì lo si può **↩ riportare** fra gli
attivi, oppure **🗑 eliminare** — e eliminare vuol dire *tutto quello che il programma sa di lui*:
la scheda clinica, i referti tenuti, il testo dei referti letti, la nota, e i dati per episodio di
quella scheda del browser. Chiede conferma una volta e non si torna indietro. L'elenco tiene un
giorno e sessanta pazienti: un turno è di dodici ore.

### Nota sul paziente
Sotto il nome, una **nota** di due righe che cresce con quello che scrivi. Non c'è un tasto Salva:
**si salva mentre scrivi** (e comunque quando esci dal campo), e compare un «salvata» che scompare
da sé. È legata al paziente — codice fiscale quando il pannello lo conosce, altrimenti il nome —
resta cambiando pagina, e scade dopo 24 ore come i dati clinici. Vive nel browser di quel computer:
non esce da lì.

### Modificare i fogli in fretta: `dist/dimissioni.html`
Una **pagina sola**, senza server: si apre col doppio clic e dentro ci sono già gli otto fogli in
servizio. Clicchi un titolo o un testo e scrivi — nessun tasto «modifica», nessuna schermata.
**+ Nuovo foglio**, **↑ ↓** per riordinare, **🗑** per buttarne uno (chiede conferma).
**⬇ Salva** scarica `dimissioni.json` *e* lo copia negli appunti, nella forma esatta che il pannello
importa con **⤒ Importa**: si passa da lì e i fogli nuovi sono in servizio. Il lavoro a metà resta
nel browser, quindi chiudere la pagina non costa niente; **↺ Originali** rimette i testi spediti.
La pagina sta nello zip e si rigenera con `npm run editor`.

### EO
Un elenco di **esami obiettivi da incollare in cartella**, scritti dal medico e tenuti verbatim.

- **EO generale**: un tocco e l'esame obiettivo completo, tutto negativo, è negli appunti.
- **Aggiungi per caso**: una tendina con nove quadri (*dolore toracico, dispnea, dolore addominale,
  cefalea, trauma/caduta, sincope, lombalgia, vertigine, pediatrico*) e quattro **frasi pronte**
  (rettale rifiutata, neuro poco collaborante, NEXUS, segni d'allarme spiegati). **Sceglierne uno lo
  copia da sé**: nessun secondo passaggio.
- Il testo scelto **resta scritto sotto la tendina**, così si vede cosa è finito negli appunti, e
  **⧉ Copia di nuovo** lo ripete senza doverlo riscegliere. La scelta sopravvive al cambio schermata.
- Si usa in due incollate: prima l'EO generale, poi l'aggiunta del caso. I testi sono **uguali per
  tutti i pazienti** — quello che riguarda *questo* paziente si scrive in cartella. Nessun dato di
  paziente entra qui (è un controllo del collaudo).

I testi stanno in `src/eo.json` e sono compilati dentro l'estensione: **zero richieste al server**.
In questa versione **non si modificano dal pannello** — per cambiarli si modifica quel file e si
ricompila (`npm run build`).

### Consensi
Sei moduli da firmare, dentro l'estensione: **Emocolture**, **HIV Dipendente**, **Lesioni
Animali**, **Antitetano**, **TAC cmdc**, **Emotrasfusione** (il pacchetto trasfusionale:
consenso informato, richiesta emocomponenti, dichiarazione del medico in urgenza).
Le **deleghe per il ritiro** — **Ritiro esami**, **Ritiro referto RX**, **Ritiro cartella e CD**
— non sono consensi: si danno a chi va a casa, e stanno in cima alla schermata **Dimissioni**.
Un tocco apre il PDF e la finestra di stampa, come per la lista esami; un modulo di più pagine
dice **quanta carta esce** prima che tu prema Stampa.

I file stanno nella cartella `extension/consensi/`: **niente rete, niente server**. Si aprono anche
se il gestionale è lento o giù, e per stamparli non esce una singola richiesta dal computer (è un
controllo del collaudo). Col preferito (bookmarklet) la sezione c'è ma i PDF no: quelli vivono
nell'estensione.

### Nomi che il pannello non conosce
Le sigle (`Emoglobina` → `Hb`) sono un elenco scritto a mano: fuori da quell'elenco
un'abbreviazione sarebbe **un'ipotesi**, e un'ipotesi che sembra una sigla nota è il modo in cui
si legge l'analita sbagliato. Quindi:

- **due esami che si abbrevierebbero uguale** nello stesso prelievo (`PTT secondi` e `PTT Ratio`,
  `Granulociti` e `Granulociti %`) vengono **scritti per esteso tutti e due**: due righe con la
  stessa etichetta sono peggio di un nome sconosciuto;
- il **campione fa parte del nome**: siero, plasma e sangue non aggiungono niente (`S-ALT` → `ALT`),
  ma ogni altro campione resta scritto nella sigla (`U-Emoglobina` → **`U·Hb`**, `Lcr-Glucosio` →
  `LCR·Glu`). L'emoglobina delle urine non diventerà mai `Hb`;
- un nome fuori elenco è **scritto per esteso** e **sottolineato a puntini**, mai abbreviato a caso;
- in cima compare una riga ambra: *«2 nomi non in elenco: scritti per esteso · 1 riga non letta»*,
  e **quali** apre l'elenco esatto, con nome e valore di quello che non è stato letto;
- una riga che il lettore rifiuta (niente data, niente range, niente stato: di solito è
  un'intestazione) **non sparisce**: viene contata e mostrata lì dentro. Se è un esame vero lo vedi
  e apri la finestra nativa. Lo stesso vale nello Storico per una riga che non sta in colonna
  (meno celle dell'intestazione): non viene indovinata, viene dichiarata.

Vale sia per i valori di un prelievo sia per la tabella dello Storico.

### Da dove viene la tabella (scheda clinica e portale)
Il gestionale ha una pagina che mette **tutti i prelievi affiancati**: dal paziente, a sinistra,
**Storico dati clinici › Tabella**. Il pannello **la legge da lì** — non chiede niente al server,
nemmeno una richiesta in più: legge la tabella che hai già davanti.

- Aprendo quella pagina compare in basso una striscia: *«90 esami · 4 prelievi letti — COGNOME
  NOME»*. Se sposti le colonne o cambi il periodo, **↻ Rileggi** aggiunge i prelievi nuovi a
  quelli già letti (non li sostituisce).
- **Non serve aprirla a mano: ⭳ Carica i valori lo fa da sé.** Il pannello prende il link
  «Storico Dati Clinici» **di questa pagina** — mai un indirizzo costruito, mai una richiesta
  diretta al portale — e l'estensione lo apre in una **scheda di sottofondo**, accanto, senza
  toglierti la vista. Lì la tabella si legge come quando la apri tu; se il portale la tiene
  dietro la voce **Tabella**, la si apre con un clic nell'interfaccia, come faresti tu (solo nelle
  schede aperte così). Il portale disegna **solo le colonne in vista** (quattro prelievi alla
  volta): nella scheda di sottofondo la tabella si **scorre da un capo all'altro**, a passi, come
  faresti tu, e ogni passo aggiunge i prelievi nuovi — così arrivano tutti, non i primi quattro.
  Arrivata la tabella, la scheda **si chiude da sola** — se ci sei andato
  sopra, resta tua. Per chi è lo sa la scheda stessa: la apre il pannello di quel paziente.
  La scheda del portale che hai aperto tu non si tocca. Se in 30 secondi la tabella non arriva
  (il portale chiede di entrare, si apre altrove, mostra un altro paziente) il pannello **dice
  perché** e il link a mano resta. Nessun permesso nuovo per l'estensione.
- **La scheda clinica si fonde, non si sovrascrive.** Il portale, le finestre Risultati e i
  referti letti scrivono nella stessa scheda del paziente: ognuno rilegge quello che c'è, fonde e
  riscrive dicendo da quale revisione è partito — se nel frattempo un altro ha scritto, rilegge e
  rifonde. Prima l'ultimo a scrivere cancellava gli altri: la tabella del portale arrivata dopo i
  Risultati si portava via i prelievi letti e i referti salvati.
- **Lo stesso esame scritto in due modi è una riga sola.** Il portale scrive «S-Sodio», la
  finestra Risultati «Sodio»: erano due righe, e mezza chimica compariva due volte. Il prefisso del
  campione (S-, P-, B-) non fa l'identità quando il resto è un nome noto; U- (urine) resta a
  parte, «S-100» e «B-12» restano interi, pCO₂ = pCO2. Due nomi diversi che nello stesso prelievo
  si contraddicono (S-Sodio e P-Sodio) non si coprono mai. «PTT Ratio» ha una sigla sua (PTTr),
  e «cK+» dell'emogas è potassio, non CPK.
- **L'emogas resta diviso dal laboratorio.** Hb, Ht, K, Na, Cl, Ca++, glucosio e lattato fatti
  dall'**EGA** non sono quelli dell'emocromo o della chimica: stanno nella sezione **Emogas**, su
  righe loro, accanto a pH e gas — mai nella riga dell'Hb dell'emocromo o del K del laboratorio.
  Lo decide l'**esame** che li ha prodotti (EGA venosa/arteriosa, emogasanalisi), non il nome: anche
  quando il nome è identico («Emoglobina», «B-Potassio»). Nella finestra Risultati di una richiesta
  con emocromo **e** EGA insieme (il Base PS) lo dicono i nomi dell'emogasanalizzatore (cK+, cNa+,
  ctHb, Hctc, cGlu, cLac…). Una tabella salvata prima, con righe miste, si divide da sola alla
  prima lettura.
- Tornando sul paziente, quei prelievi entrano **da soli** nella tabella **Valori** di **Esiti**,
  uniti a quelli letti dalla finestra Risultati del gestionale — niente riga da aprire, niente
  schermata a parte (vedi sopra come si legge la tabella).
- Gli esami sono **divisi in sezioni** e dentro ogni sezione l'ordine è **fisso**: *Emocromo,
  Coagulazione, Biochim* (PCR, PCT, VES, troponina, NT-proBNP, CPK, CK-MB, mioglobina, LDH),
  *Organi, Elettroliti e metabolismo, Emogas, Urine e altri liquidi*, e in fondo **Altri**. Prima l'ordine era quello in cui il laboratorio aveva stampato
  la tabella, e **cambiava da un prelievo all'altro**: lo stesso esame andava cercato ogni volta.
  Un analita che il programma non conosce non si perde: finisce in **Altri**, scritto per esteso.
  Il campione decide per primo — **`U-Emoglobina` va in Urine, mai nell'emocromo**.
- Nella tabella del portale la colonna di sinistra è la **prestazione ordinata** (`ESAME URINE
  COMPLETO`) e quella accanto è l'**analita** (`U-Albumina`, `U-Corpi chetonici`): il pannello legge
  l'analita, altrimenti un pannello di urine diventerebbe diciotto righe con lo stesso nome. Il
  prefisso del campione resta: **`U-Emoglobina` non è l'emoglobina del sangue**, e non viene mai
  fusa con essa.
- **La tabella si vede solo sotto il paziente giusto**, e la prova migliore è la più semplice:
  **il portale lo apri da un link sulla pagina del paziente**. Quel clic dice per chi lo stai
  aprendo, quindi la tabella letta di là si attacca a quell'**episodio** — nessun confronto di
  nomi può essere più sicuro, e non costa una richiesta. Se sei arrivato al portale per un'altra
  strada (un preferito, un'altra scheda), si ricade sulle prove più deboli: SA4PSO scrive il nome
  come una stringa sola (`ROSSI MARIO`), il portale lo dà già separato (`Cognome` + `Nome`), da lì
  l'ordine delle due parole non si deduce, quindi entrambi gli ordini vanno accettati — e con nomi
  di due parole uno scambio resterebbe indistinguibile. Allora, quando c'è, decide il
  **codice fiscale**: il portale lo scrive nel titolo della pagina, il gestionale accanto al nome
  nella finestra Risultati che il pannello legge già per i valori. Ne viaggia solo l'**impronta**,
  mai il codice in chiaro. Le due prove non possono contraddirsi: un codice che combacia accanto a
  un nome che non ha niente in comune fa **rifiutare** la tabella. Se il codice manca da un lato si
  torna al confronto sui nomi. In fondo alla tabella c'è scritto **per chi è stata letta** e **su
  cosa è stata verificata**, così un dubbio si vede invece di restare nascosto. Le due metà della tabella del portale (nomi a sinistra, valori a destra) devono
  combaciare riga per riga: se non combaciano non legge niente, invece di rischiare di attribuire
  un valore all'esame sbagliato.
- Vale solo con l'**estensione** (è lei a portare la tabella da una pagina all'altra), i valori
  stanno **in memoria e non su disco**, scadono dopo 2 ore e spariscono chiudendo il browser.
  Il logout li cancella con tutto il resto.
- Sul portale l'estensione entra **solo nella sezione che contiene quella tabella**
  (`/clin-port/*`) e lì fa una cosa sola: leggerla. **Se l'indirizzo del portale
  è un altro** — un altro IP, un'altra sede — lo aggiungi tu: nel pannello, negli
  Esiti, «Aggiungi l'indirizzo del portale» apre una pagina di impostazioni dove
  incolli l'indirizzo e Chrome chiede il permesso **per quel sito soltanto**.
  Il permesso si chiede da lì e non dal pannello perché Chrome pretende un gesto
  dell'utente, e un gesto non sopravvive al passaggio verso il service worker. Il percorso era ristretto a
  `/clin-port/info-cliniche/*`, ma il portale è una single-page application e
  quel pezzo di indirizzo può stare **dopo il cancelletto**, dove le regole di
  Chrome non guardano: l'estensione non partiva affatto. Se la tabella non
  compare entro sei secondi ora te lo **dice** con una striscia, invece di
  restare muta — «non si vede niente» e «non sto girando» erano indistinguibili. Su qualsiasi altra pagina di
  quel portale — compresa la sua schermata di accesso — **non fa assolutamente niente**, perché
  è un'altra applicazione e le regole scritte per SA4PSO non le si applicano.
- **Una scheda per paziente, da tutt'e due le finestre.** Ogni tabella letta diventa la scheda
  clinica di quel paziente: se non c'era viene creata (la striscia lo dice: *«…— ROSSI MARIO, nuovo
  · 3 pazienti in memoria»*), se c'era i prelievi nuovi si aggiungono ai suoi. E non solo dal
  portale: **ogni prelievo che il pannello legge dalla finestra Risultati del gestionale entra
  nella stessa scheda**, parziali compresi — un valore che il laboratorio non ha finito è in
  *corsivo* e la tabella lo spiega. Lo stesso analita letto dalle due finestre resta **una riga
  sola**.
- Sul paziente aperto il pannello mostra **solo la sua** scheda. Prima di tutto vale il **clic**:
  la tabella letta sul portale aperto **dalla pagina di questo paziente** è sua — ma solo se di là
  c'è **lo stesso nome**, perché il portale cambia paziente senza ricaricare la pagina e la tabella
  di un altro non deve portarsi dietro l'episodio da cui si era partiti (la striscia lo dice:
  *«non è BIANCHI ANNA, da cui l'hai aperta»*). Poi il **codice fiscale** quando c'è: se in
  archivio esiste una scheda con quel codice fiscale è quella, sempre — si ripiega sul nome solo
  se nessuna scheda porta un codice, altrimenti un omonimo senza codice potrebbe vincere su una
  verificata. Le altre schede non attraversano nemmeno il ponte.
- Le schede stanno nella memoria dell'estensione (**su disco**), **sopravvivono alla chiusura del
  browser e al logout** — un turno è di dodici ore e i pazienti sono più di dodici — e **scadono da
  sole 24 ore** dopo l'ultima lettura. Su un PC condiviso: profilo Chrome tuo, e chiudi a fine turno.
- Il portale si apre in un'altra scheda: **non serve ricaricare** la pagina del paziente, basta
  tornarci sopra. Nel **banco di prova** il giro c'è tutto (link «Storico Dati Clinici» in basso a
  sinistra), su una tabella ricostruita con esami inventati.

### Dimissioni
In cima, i **moduli per il ritiro** da dare a chi va a casa — Ritiro esami, Ritiro referto RX,
Ritiro cartella e CD: un tocco e parte la stampa, come per i consensi.

Poi nove **fogli di dimissione** pronti — i **cinque rivisti dal medico** stanno in cima, poi una riga
(*«non ancora rivisti»*) e sotto gli altri: si vede a colpo d'occhio dove si è già messo mano.
Sono scritti per il paziente: dosi per esteso, tetto del paracetamolo, e in fondo a ogni
foglio i motivi per **tornare in Pronto Soccorso**.

- L'elenco mostra **solo la patologia**, mai il testo: al momento della dimissione sai già quale ti
  serve, e leggerlo qui costerebbe solo uno scroll.
- **Un tocco sulla riga copia tutto il foglio** negli appunti, pronto da incollare nel verbale. Il
  bersaglio è la riga intera, non un'icona da 13 px.
- **✎** apre il testo in grande e lo riscrive **per le volte successive**: le modifiche restano su
  quel computer (`localStorage`) — **sopravvivono al logout, alla chiusura del browser e agli
  aggiornamenti del programma**, perché sono tue e non dati di un paziente. Non finiscono nel
  repository e non escono dal computer. Il foglio modificato porta un
  **pallino azzurro** nell'elenco.
- Quello che scrivi è **salvato come bozza a ogni tasto**: se cambi schermata, se il gestionale
  ricarica la pagina o se ti chiamano, al ritorno il testo ti aspetta dov'era.
- Il **copia negli appunti** ha un ripiego (`execCommand`) per le pagine servite in `http://`,
  dove `navigator.clipboard` non esiste: vale per tutti i pulsanti «copia» del pannello.
- Per un foglio **su misura per questo paziente**: modifica e usa **⧉ Copia** *senza salvare*. Nei
  modelli non vanno dati del paziente — e infatti la pulizia al logout li lascia stare, perché sono
  modelli, non dati clinici.
- **↺ Originale** chiede conferma prima di buttare il tuo testo. Se una nuova versione del
  programma corregge un foglio che tu avevi modificato, quel foglio si marca **⟳** e l'editor te lo
  dice: una correzione di dosaggio non può restare invisibile a chi ha personalizzato il testo.
- **⬇ JSON** salva i tuoi testi in un file (e negli appunti); **⤒ Importa** li rimette da una
  schermata dove incolli il JSON — entrano **solo i testi diversi dagli originali**, così un
  ripristino non congela per sempre gli altri sette.

---

## Stampa etichette e lista esami

Dopo la **Conferma** (manuale o automatica) si apre da solo il wizard di stampa, in sequenza,
raggruppando per stampante:

1. **Tutte le etichette provette** — i PDF dell'icona col codice a barre
   (`RcsStampaEtichetteLISHMIMU.do`, che porta al PDF servito da
   `uploaddownloadservlet.rra2`), con la finestra di stampa già aperta → **etichettatrice**;
2. poi **tutte le liste esami** — i PDF di "Stampa Richiesta" (`jasperservlet`, URL sempre letto
   dalla pagina perché `BRANCA` cambia per riga) → **stampante normale**;
3. per la **radiologia**, la riga ha l'icona stampante "Stampa Prenotazione Esterna": il wizard
   stampa quel PDF → **stampante normale**.

**Non serve una mano libera**: quando la finestra di stampa del browser si chiude, il wizard
**passa da solo al documento dopo** — come se avessi premuto «→ Avanti» — e sull'ultimo si chiude.
Il browser dice soltanto che il dialogo si è chiuso, non se hai stampato o annullato: si va avanti
in tutt'e due i casi, e i bottoni restano lì se vuoi guidare a mano. Un dialogo che si chiude
all'istante (stampa non disponibile su quel PC) **non** fa saltare la coda.

**Righe multiple**: quando gli esami di una richiesta appartengono a laboratori diversi (POC +
Urgenze, ecc.) il LIS la divide in **più righe** — stessa `RICHIESTA_ID`, `RICHIESTA_PROG` 1, 2… —
ognuna col suo PDF etichette e il suo foglio. Il wizard le stampa **tutte** ("Etichette — riga 1",
"Etichette — riga 2", poi le liste), mai solo l'ultima.

Sul campo, dopo la Conferma il gestionale **torna alla pagina del paziente**: è lì che il wizard
parte da solo (e se un'installazione mostrasse una pagina intermedia, parte lì se ha i link,
altrimenti aspetta il ritorno sul paziente). Dalla pagina paziente puoi anche **ristampare
qualsiasi richiesta**
(sezione **Stampa**: ogni richiesta è elencata con **data e ora** e, sotto, la **lista compatta
degli esami** che contiene). Ogni passo ha: Riapri stampa · Salta · Apri in una scheda ·
Annulla (Esc).

**Laboratorio + radiologia insieme**: se confermi una richiesta di laboratorio e poi una di
radiologia prima di tornare alla pagina del paziente, la stampa parte **una volta sola** e in
sequenza: tutte le etichette → tutte le liste → la prenotazione RX.

### Si può scegliere la stampante?

No: nessuna pagina web può impostare la destinazione
di stampa — è una barriera del browser, non un permesso mancante. Quello che si può fare senza
essere amministratori:

- Chrome **ricorda l'ultima stampante usata**, quindi il wizard raggruppa i documenti per
  destinazione (tutte le etichette, poi tutte le liste): al massimo **due cambi per paziente**,
  non uno per foglio.
- **Collegamento con `--kiosk-printing`** (si crea senza admin: tasto destro sull'icona di Chrome
  → Proprietà → aggiungi `--kiosk-printing --user-data-dir="%LOCALAPPDATA%\\ChromeEtichette"`).
  Da quella finestra Chrome stampa **senza dialogo** sulla stampante predefinita di Windows di
  quel profilo. Ha senso solo se quella finestra la usi per le sole etichette — la lista la
  stamperesti da una finestra normale. Fragile, ma funziona.
- Se le liste su carta non ti servono, salta il secondo passo del wizard: resta **un solo**
  dialogo per paziente.

---

## Come vengono letti i valori (e cosa fa quando non capisce)

I valori arrivano dall'**HTML** della finestra «Visualizza Risultati», non dal PDF del referto:
la pagina è una tabella dell'applicazione e si legge riga per riga — esame, valore, unità, range,
stato, data — prendendo **solo le celle figlie dirette** della riga (l'intestazione del paziente
sta nella stessa tabella, dentro tabelle annidate, e altrimenti finirebbe tra i risultati). Una
riga è un risultato se lo dimostra: ha una **data di refertazione**, oppure un **range numerico**,
oppure uno **stato** di laboratorio. Il resto viene scartato.

Il giudizio «fuori range» capisce i modi in cui i laboratori scrivono i limiti: `13 - 17`,
`7,35 – 7,45`, `4 - 10 x10^3`, `-2 - +2`, `< 0.5`, `> 60`, `fino a 5`, `inf./sup. a`, e i valori
con modificatore (`<0.01`, `>1000`) o a parole (`NEGATIVO`, `Assente`). Quando **non** capisce —
un range che dipende dal sesso, un formato mai visto, due range nella stessa cella — non inventa:
**non segna nulla** e mostra il valore in nero. È una scelta: meglio un fuori range non evidenziato
che un rosso che non sappiamo giustificare.

Un esame sconosciuto non sparisce mai: se non ha una sigla nota viene scritto **per esteso**,
sottolineato a puntini — mai abbreviato a caso.

**Quando il laboratorio referta**, il gestionale toglie la finestra Risultati e quei valori
sparirebbero con lei. I prelievi già letti in quella scheda **restano nella tabella dei Valori**,
come una colonna in più: sono ciò che il pannello aveva realmente sotto gli occhi, e non vengono
mai attaccati a un referto (niente li collega). Il referto in PDF resta lì accanto, come sempre.

> Il PDF del referto **di laboratorio** non viene letto: quello disegna il testo un glifo alla volta
> con un font ridotto e **senza mappa dei caratteri**, quindi ricavarne «Emoglobina 8.0 g/dL»
> significherebbe indovinare. Gli stessi valori sono già in HTML nella finestra Risultati, ed è da lì
> che si leggono. I referti di **radiologia ed ECG** sono l'opposto — hanno font e mappa veri — e
> infatti quelli il pannello li legge e te li mostra come testo.

---

## Dove finiscono referti e valori

- **Valori** (i prelievi in tabella): letti da `RcsAccessiRisultatiElenco.do`, HTML sullo stesso
  server. Restano in memoria **per la scheda e per quell'episodio**, così la tabella si
  ricostruisce all'istante; **↻ Aggiorna** li rilegge tutti, uno alla volta, man mano che il
  laboratorio completa. Chiusa la scheda, spariscono.
- **Referti** (righe LIS/RIS/AMB): il visualizzatore **non è su SA4PSO** — gira su un altro host
  interno e mostra il PDF come `blob:` di quell'origine, quindi una pagina di SA4PSO non può
  leggerlo. È il **service worker** dell'estensione a seguire la catena (redirect → visualizzatore
  → suo endpoint PDF) e a salvare i byte nella memoria dell'estensione, su questa macchina.
  Solo con l'**estensione**: il bookmarklet non può farlo. Se un referto non è
  salvabile resta senza pallino e il **motivo** compare passandoci sopra col mouse (e nel Registro).
  Scadono in **8 ore**, massimo 25, e si azzerano alla chiusura del browser; **↻ Resetta** subito.

> **Da configurare una volta**: l'host del visualizzatore è dichiarato in
> `extension/manifest.json` → `host_permissions` (oggi `http://10.11.0.151:9080/*`). Se nella tua
> sede è un altro indirizzo, cambialo lì e ricarica l'estensione.

---

## Banco di prova (provare senza ospedale)

Una pagina sola con dentro **le schermate vere del gestionale** e sopra **il
pannello vero** — la stessa build dell'estensione. Serve per provare e far
crescere l'interfaccia da casa, senza accesso a SA4PSO.

- **Online**: il link del banco di prova (nel messaggio di consegna), da qualsiasi browser.
- **Offline**: `dist/demo.html` è dentro lo zip — doppio click, funziona senza rete.

### Cosa c'è dentro

Le pagine sono quelle salvate dal gestionale — struttura, classi, foglio di
stile e icone originali — con **tutto il contenuto sostituito da dati
inventati** (vedi `esempi-gestionale/README.md`: gli originali erano cartelle
cliniche complete e non stanno in questo repository). Si passa dall'una all'altra
come nel programma: lista PS → scheda paziente → nuova richiesta → catalogo
esami → conferma → stampa; e sulla seconda scheda, risultati e referti.

### Cosa funziona

Il flusso completo dell'ordine: quesito, profili, esami, «Crea e aggiungi» con
la verifica esame per esame, il carrello che compare **nella pagina vera**, la
Conferma nativa, il wizard di stampa. E gli **Esiti**: i valori letti dalla
finestra Risultati vera, i referti salvati e riaperti. Anche la tabella **Valori**:
«Storico Dati Clinici» ricostruisce, sull'altra scheda, una tabella multi-prelievo
dalla sua forma (`test/fixtures/storico.mjs`, esami inventati: di quella pagina non
esiste una copia salvata qui); tornando sul paziente il pannello la ritrova già
unita ai suoi Esiti.

Di proposito **non** funziona il resto: gli script del gestionale sono rimossi
(schede e menu interni non si aprono), le schermate mai salvate mostrano una
pagina di cortesia invece di un errore, la stampa mostra il PDF ma non apre il
dialogo, e i PDF sono fogli vuoti.

### Niente esce dalla pagina

Non è una promessa, è una barriera: le richieste allo stesso indirizzo le serve
il simulatore in memoria, **tutto il resto viene rifiutato** — qualsiasi host,
XHR, WebSocket, EventSource, beacon — e nel file offline lo impone anche una
`Content-Security-Policy` che vieta al browser di raggiungere qualunque host.
La suite conta le richieste di rete di un'intera sessione: **una sola, la pagina
stessa**.

### Perché non invecchia

`dist/demo.html` è **generato** da `extension/content.js` (il pannello che si
installa) e da `esempi-gestionale/` (le pagine): `npm run demo` e ogni
`npm run dist` lo riallineano da soli, e la barra nera stampa quale build stai
provando. Una suite dedicata (`node test/demo.mjs`) ripercorre nel banco gli
stessi flussi dei test di prodotto.

> Il pannello, fuori dall'host dell'ospedale, accetta i ganci del banco
> (navigazione, schede, stampa); **su `smarthealth.multimedica.it` quei ganci non
> esistono nemmeno**, quindi nulla servito dal gestionale può dirottarlo.

---

## Perché è robusto (regole di sicurezza nel codice)

1. **Mai doppi ordini**: l'URL di inserimento di un esame viene richiesto **al massimo una volta**.
   La verifica rilegge l'elenco "pulito" (senza parametri di inserimento); se dopo 3 verifiche
   l'esame non compare, il motore **si ferma** e ti dice esattamente cosa controllare.
   Vale anche **fra una corsa e l'altra**: partendo da una pagina esami il motore **rilegge
   l'elenco dal server** invece di fidarsi di quello che hai sullo schermo. Gli inserimenti
   viaggiano in background, quindi dopo una corsa interrotta la pagina mostra ancora il carrello
   di prima — fidarsene voleva dire leggere «non c'è» un esame che c'era già, e ordinarlo una
   seconda volta. Costa una richiesta, e da quella rilettura arrivano anche i controlli di
   sessione ed episodio che quella strada saltava. C'è un test che lo prova.
   **Il giro riprende, gli invii no.** Ogni passo è annotato nella scheda del browser: che cosa
   è già in carrello, che cosa era **in volo**, che cosa resta. Se la pagina cambia, il giro
   riparte da lì. Quello che era in volo si **cerca** — fino a 3 riletture, col proprio codice,
   col nome identico o con lo stesso mnemonico LIS, **mai** per somiglianza (o «POTASSIO» si
   riconoscerebbe in «POTASSIO URINARIO») — e non si rimanda: se non si trova, stop e messaggio.
   Resta «in volo» finché non lo si ritrova, anche attraverso più interruzioni di fila: non
   scivola mai fra i «già fatti», o un esame mai partito passerebbe per uno tolto a mano e
   sparirebbe in silenzio. Quello che era già entrato si ricontrolla, e se nel frattempo
   qualcuno l'ha tolto dal carrello **non** viene rimesso.
   L'appunto vale 10 minuti e al massimo 12 riprese (il conto si scrive prima di ripartire, così
   vale anche se la ripresa muore subito), muore con la scheda del browser e con il «fine
   turno», e non parte mai da solo dopo uno STOP o un errore che ha già fermato il giro.
   **Una sola scheda alla volta.** Duplicando la scheda, Chrome ne copia anche l'appunto: due
   motori sullo stesso carrello vorrebbe dire due volte lo stesso esame. C'è un **presidio** in
   memoria condivisa — chi ci sta lavorando, su quale richiesta, da quando — che si molla quando
   la pagina se ne va e scade da solo in 25 secondi: la seconda scheda non manda niente e lo
   dice. Il presidio si ricontrolla **prima di ogni invio**, non solo alla partenza.
   **Niente sparisce zitto.** Un giro che nessuno riprenderà — scheda chiusa, browser caduto,
   sessione scaduta — lascia un segno in memoria condivisa: la prima pagina utile dice «un giro
   su X è rimasto a metà: N esami non sono stati mandati». Sulla pagina di login, dove il
   pannello non nasce nemmeno, compare una striscia rossa che lo dice **senza il nome**, perché
   quella pagina la può avere davanti chiunque. Se la memoria del browser è piena e l'appunto
   non si riesce a scrivere, il pannello non promette una ripresa che non ci sarà: lo scrive nel
   Registro e il giro torna a comportarsi come prima.
   **Un esame può entrare in carrello con un numero diverso dal suo**: le prestazioni a
   riflesso (BILIRUBINA TOTALE REFLEX) ci mettono l'esame che ne deriva. Il motore fotografa il
   carrello *prima* dell'invio e guarda quale riga è comparsa *dopo*: vale solo se porta il
   **nome** di quello che hai scelto — stesso nome, stesso mnemonico LIS, o l'uno dentro
   l'altro parola per parola. Una riga estranea non conta e il motore si ferma lo stesso.
   E se il server risponde all'inserimento con **una pagina che non è l'elenco**, l'esame è
   entrato lo stesso: si rilegge il carrello (mai un secondo invio) invece di fermarsi al buio.
2. **Mai il paziente sbagliato**: l'EPISODIO_ID viene fissato all'avvio e ogni pagina ricevuta è
   verificata **dal contenuto che il server dichiara** (non dall'URL richiesto); se manca o non
   corrisponde, stop prima di qualunque invio.
3. **Ogni sede ha i suoi numeri, non i suoi nomi**: gli identificativi di risorsa
   (`LABORATORIO ANALISI POC` è `00660001P` in una sede e un altro numero altrove) e perfino i
   codici delle prestazioni cambiano da presidio a presidio. Il pannello **non si fida dei numeri
   salvati**: se la risorsa scelta non è tra quelle della richiesta la cerca per **nome** (senza
   il suffisso di sede) e usa quella; se il codice di un esame non c'è, lo ritrova per **nome
   esatto** o per il **mnemonico** che il LIS stampa tra parentesi — `(POCT1502)`. Ogni traduzione
   finisce nel Registro, e il controllo del nome vivo resta comunque l'ultimo cancello prima di
   ogni invio. Se il nome non corrisponde a nulla si ferma e **dice cosa offre quella richiesta**,
   invece di un rifiuto muto.
4. **Mai l'esame sbagliato**: prima di ogni invio il nome dell'esame sulla riga viva della pagina
   deve coincidere con quello selezionato — se l'ospedale rinumera un codice, il motore si ferma
   e lo dice, invece di ordinare un esame diverso con tutte le spie verdi.
5. **La Conferma è sempre un click reale** sulla pagina visibile (il flusso di stampa etichette
   resta quello nativo), è opt-in e **immediata**: nessun conto alla rovescia, perché il tuo
   click su «+ Conferma» è già la decisione — ma scatta **solo** se il carrello coincide con la
   ricevuta di ciò che è stato appena aggiunto; ogni differenza la sospende con un messaggio.
   **La pagina della Conferma può essere invisibile.** Viene caricata davvero —
   stessa sessione, stesso modulo, stesso bottone — dentro una cornice nascosta
   invece che davanti agli occhi, e il clic è quello vero sul bottone del
   gestionale: i byte che partono sono gli stessi, perché a serializzare il
   modulo è il browser, non noi. La cornice gira **senza script**
   (`allow-forms allow-same-origin`, mai `allow-scripts` né
   `allow-top-navigation`), così il codice della pagina non può portarsi via la
   scheda del medico. Se il server **vieta di essere incorniciato**, il
   documento non è leggibile: il programma se ne accorge e torna alla pagina
   visibile, come prima. Ogni intoppo — cornice rifiutata, controllo che dice
   di no, stato incerto — finisce sulla pagina vera col motivo scritto, e la
   conferma resta al medico. C'è un test che prova che in quel caso la
   richiesta viene confermata **una volta sola**.
   **Non poter controllare non è come aver controllato**: se la ricevuta manca o è di un'altra
   richiesta, la conferma automatica **si sospende** invece di partire lo stesso. (Fino alla
   3.20 quel caso saltava il controllo e confermava — la Conferma nativa invia la richiesta
   *intera*, quindi era la strada per confermare l'avanzo di un tentativo precedente.)
6. **Il quesito non viene mai sovrascritto**: se il triage l'ha già compilato, resta il suo.
7. **Sessione scaduta riconosciuta**: se compare la pagina di login, stop con messaggio chiaro
   (che dice anche se l'ultimo esame è in stato ambiguo).
8. **Un run non muore in silenzio**: chiudere o cambiare pagina durante un run fa scattare
   l'avviso del browser; i passaggi falliti diventano rossi, quelli mai partiti "non eseguito".
9. **Niente esce dall'ospedale**: ogni richiesta è bloccata a livello di codice se non è diretta
   a una delle **due origini dell'ospedale** — SA4PSO e il portale clinico interno da cui
   arrivano i referti e si legge la tabella multi-prelievo. Nessun altro indirizzo, nessuna
   telemetria; preferenze e catalogo appreso restano nel browser.
10. **Due schede, due pazienti, zero interferenze**: i passaggi di consegna tra pagina e pagina
   (ricevuta e conferma automatica) vivono nella singola scheda (sessionStorage).
11. Codifica **windows-1252 identica byte per byte** a quella del browser (verificato contro
    Chromium reale, accenti e simboli inclusi).
12. **Stampe solo dai link della pagina**: gli URL dei PDF non vengono mai costruiti a mano
    (`BRANCA` varia per richiesta) e passano gli stessi controlli di origine di tutto il resto.
    La caccia al PDF ha **un tetto solo, sei tentativi in tutto**: oltre quello il documento si
    apre in una scheda e lo stampi da lì. (Il contatore stava dentro la funzione ricorsiva, così
    ogni livello ripartiva da zero e il tetto vero era 6+6×6 = **43 richieste**. Lo stesso
    difetto era rimasto nel service worker, per i referti, ed è corretto anche lì. Ora è uno solo,
    passato ai livelli sotto.) Chiudere la finestra di stampa **ferma davvero** la caccia.
13. **Un paziente alla volta**: per ordinare devi essere sulla sua pagina, e ogni dato salvato
    (valori, referti, registro, code di conferma) è legato al suo episodio — letto sotto un altro
    episodio semplicemente non esiste.
14. **Dove finisce il contenuto clinico, detto con precisione.** Dei pazienti *conosciuti*
    restano solo nome, episodio, indirizzo della pagina e colore del triage, al massimo 60 e per 24 ore, con
    **svuota** a mano e **🗑** per cancellare tutto di uno. Ma valori e testi dei referti letti in un turno stanno nel
    `sessionStorage` della scheda: **Chrome lo tiene anche su disco**, nel profilo, per poter
    ripristinare le schede — muore chiudendo la scheda, non prima. I PDF salvati stanno nella
    memoria dell'estensione (su disco), scadono dopo 8 ore, massimo 25, e si azzerano alla
    chiusura del browser. Le **schede cliniche** (tabella multi-prelievo, testi dei referti letti)
    stanno nella memoria dell'estensione, quindi **su disco**: un turno dura dodici ore e non si
    può perdere tutto chiudendo il browser. Scadono da sole **24 ore** dopo l'ultima lettura, al
    massimo 200 pazienti, e **🗑** su un paziente archiviato le cancella subito — schede, referti
    tenuti e nota. La pagina di login cancella il resto — ma il `sessionStorage` è
    **per scheda**: pulisce la scheda in cui è comparso il login, non le altre schede aperte.
    Su un PC condiviso: usa un profilo Chrome tuo e chiudi il browser a fine turno.
15. **Niente parte da solo, e niente si inventa.** Aprire la pagina di un paziente non legge
    **nessun** valore: cliccare un paziente non è chiedere il laboratorio. I valori si leggono
    quando li chiedi — aprendo un prelievo, o con **⭳ Carica i valori** che li prende tutti, uno
    alla volta, insieme allo storico del portale aperto in sottofondo dal link della pagina —
    e un prelievo che ha già fallito non si ritenta da solo. Un referto che apri non
    viene riletto per tenerne una copia: per quello c'è **⬇ Salva referti**. E la tabella
    multi-prelievo viene **letta dalla pagina che hai davanti**, non chiesta all'API che la
    riempie — una chiamata diretta a quel servizio arriverebbe senza l'`Origin` della sua app,
    cioè come una cosa diversa da te che clicchi, e non è quello che questo programma fa.
16. **I fogli di dimissione sono modelli, non cartelle**: sono l'unica cosa che sopravvive alla
    pulizia del logout, proprio perché non contengono il paziente. Per questo l'editor offre
    **⧉ Copia senza salvare** — chi vuole un foglio su misura non è mai costretto a salvarlo — e
    un salvataggio rifiutato dal browser (memoria piena o bloccata) viene **detto**, mai spacciato
    per riuscito.

> **Postazione condivisa**: `localStorage` e la memoria dell'estensione sono legati al **profilo
> Chrome**, non al login dell'ospedale. Usa l'estensione in un profilo tuo. Se il profilo è
> davvero condiviso, non usare **⬇ Salva referti** (i PDF resterebbero su disco fino a 8 ore).

---

## Collaudo guidato (prima volta su pazienti reali)

Precondizioni: profilo browser personale (non condiviso), una sola scheda SA4PSO, e per tutta la
prima fase usa **solo** "Crea richiesta e aggiungi" — mai il bottone con conferma.

**In ordine, senza saltare passi:**

1. **Verifica identità.** Apri il paziente in UNA sola scheda. Il pannello deve mostrare nome ed
   episodio identici alla testata SA4PSO. Se l'episodio manca, il pannello si rifiuta da solo:
   non insistere, usa la pagina nativa.
2. **Primo run minimo.** Un solo esame economico e comunque indicato (es. glucosio POC) su un
   paziente che ha già bisogno del prelievo. Quesito reale. **Non toccare il browser** finché non
   compare il banner verde (5–20 secondi; se provi a chiudere la scheda durante il run, il
   browser ti avvisa).
3. **Verifica il nome, non il conteggio.** Sulla pagina esami leggi la riga nel carrello: il
   **nome** deve corrispondere esattamente al chip scelto. (Il motore fa già questo controllo da
   solo prima di ogni invio e si ferma se un codice ha cambiato nome.)
5. **Conferma manuale nativa.** Premi tu Conferma: si apre il wizard di stampa — verifica che il
   PDF etichette sia della **richiesta giusta** e che le etichette riportino il **paziente
   giusto**, scegli l'etichettatrice, poi "Stampata — avanti" e stampa la lista sulla stampante
   normale. (Il wizard si può sempre chiudere con Esc e rifare dalla sezione "Stampa".)
6. **Controllo incrociato in EHR.** Riapri l'episodio: esattamente UNA richiesta nuova, 1 esame,
   quesito/medico/urgenza corretti, nessuna bozza doppia.
7. **Run multiplo con cambio risorsa.** Profilo con POC + Urgenze (es. Base PS + Epatico):
   ripeti i punti 3–5 riga per riga.
8. **Esercitazione di interruzione.** Lancia un run e premi INTERROMPI (o Esc) a metà; leggi il
   messaggio e controlla il carrello col bottone "Apri il carrello e controlla". Regola
   permanente: **dopo qualsiasi banner rosso mai rilanciare** — si apre il carrello, si sistema a
   mano, si controllano le bozze sull'episodio.
9. **Radiologia (solo dopo qualche giorno di laboratorio pulito).** Prima apertura nativa di
   "Richieste Radiologia" (apprendimento del catalogo), poi un solo RX torace dal pannello, con
   verifica in radiologia che la richiesta sia arrivata unica e con il quesito giusto.
10. **Auto-conferma (ultima fase, opzionale; solo laboratorio — la radiologia richiede sempre
    il tuo click, per codice oltre che per regola).** È **immediata**: primo uso con 1 esame
    restando davanti allo schermo, e ricontrolla etichette e richiesta appena confermata. Per
    provare il blocco di sicurezza: lascia un esame nel carrello da un tentativo interrotto e
    rilancia — la conferma deve **sospendersi** con il messaggio, non partire.
11. **Regime.** Una scheda per paziente; mai avviare un run e allontanarsi; nella prima settimana,
    a fine turno, scorri le richieste create cercando doppioni o bozze non confermate.

Se un passaggio non torna: il **Registro** (in fondo al pannello) elenca ogni azione con l'orario,
inclusi i primi 160 caratteri di qualsiasi pagina inattesa del server e **da quale strada è stato
ottenuto ogni PDF**. Resta scritto anche cambiando pagina (per scheda e per episodio, 2 ore) e il bottone
**⧉ Copia** lo mette negli appunti pronto da incollare — **il quesito diagnostico viene omesso**,
così non escono testi clinici.

---

## Struttura del progetto

```
ps-app/
├── src/core.js          ← unica fonte: motore + pannello (zero dipendenze)
├── src/catalog.json     ← catalogo esami verificato (SSG: POC/Urgenze/Centrale/RX · OSG: POC/Centrale)
├── src/dimissioni.json  ← gli otto fogli di dimissione (testi rivisti, nessun dato di paziente)
├── test/fixtures/       ← la tabella dello storico ricostruita dalla sua forma (dati inventati)
├── extension/           ← estensione MV3 pronta da caricare (content.js è generato)
├── extension/pdfjs/     ← pdf.js 3.11.174 di Mozilla (Apache-2.0), preso tale e quale: legge i referti
├── tools/build.mjs      ← genera extension/content.js e il bookmarklet
├── tools/icons.mjs      ← genera le icone PNG (niente binari a mano)
├── bookmarklet/         ← piano B per PC bloccati: un preferito, zero installazione (generato)
├── esempi-gestionale/   ← pagine vere del gestionale, contenuti inventati (+ come)
├── demo/                ← guscio del banco di prova (css + il browser finto)
├── tools/esempi.mjs     ← genera esempi-gestionale/ dagli originali (che restano fuori)
├── tools/demo.mjs       ← assembla dist/demo.html: pannello vero + pagine vere
└── test/                ← simulatore SA4PSO + 67 scenari e2e in Chromium reale (+ storico e referti)
```

Sviluppo:

```bash
cd ps-app
npm install        # solo playwright, solo per i test
npm run build      # rigenera extension/content.js + bookmarklet dopo modifiche a src/
npm run esempi     # rigenera esempi-gestionale/ dagli originali e verifica che sia pulito
npm run demo       # rigenera dist/demo.html (il banco di prova)
npm test           # 67 scenari e2e + 49 sull'estensione + 45 sul banco + storico + il cancello privacy
```

I test coprono: percorso felice (con e senza redirect PRG, con verifica **byte-per-byte** del
corpo POST contro la codifica nativa di Chromium), conferma automatica, annullo con Esc e flag
consumato al reload, carrello "in ritardo" (verifica con riletture, un solo invio), esame perso
dal server (hard-stop con **un solo** invio e step successivi mai partiti), **codice rinumerato**
(rifiuto prima dell'invio), sessione scaduta prima e **durante** un inserimento (messaggio di
ambiguità), **cambio episodio a metà run** (zero invii sul paziente sbagliato), quesito
pre-compilato non sovrascritto, aggiunte dalla pagina esami con cambio risorsa, rifiuto live di
esami di risorsa sbagliata (CTA disabilitato con motivo), quesito mancante (CTA disabilitato,
si riattiva scrivendo), apprendimento radiologia end-to-end, STOP, e la stampa: wizard manuale
con sequenza etichette→lista e download singoli, **richiesta divisa su due laboratori → 4 PDF
(PROG 1 e 2, tutte le righe, BRANCA passato intatto dal DOM)**, **prenotazione radiologica**,
auto-apertura sulla pagina post-conferma, attesa-e-ripartenza al ritorno sulla pagina paziente,
wrapper HTML seguito fino al PDF, conferma manuale nativa che arma la stampa, e i referti:
**zero download prima della spunta PRECARICA**, 3 PDF scaricati una volta ciascuno, ordinamento
per data/ora, apertura istantanea da memoria senza nuove richieste, fallback nativo senza
precarica, link-archivio ignorati. In più il bundle
compilato è stato eseguito contro la **vera pagina paziente salvata**: ogni tipo di riga reale
(lab, radiologia, consulenza/ECG) produce il piano di stampa atteso. Il simulatore fallisce
apposta se `Cancel` viaggia insieme a `Update` (regressioni del serializzatore) e le fixture
sono **anonimizzate**: nessun dato di pazienti reali in questo repo.

## Note dall'audit (per chi metterà mano al codice)

- Le pagine sono `windows-1252`; i POST vanno codificati così (il motore ha un encoder dedicato
  con fallback a riferimenti numerici HTML per i caratteri non rappresentabili).
- I `<select>` del server arrivano con **doppio `selected`** (vince l'ultimo): mai leggere gli
  attributi, sempre le proprietà DOM.
- L'elenco esami è una GET pura: stessa URL con `RISORSA_ID` diverso = cambio risorsa. La URL viene
  ricostruita dai parametri dei link `AFCDataLink` (mai da `response.url`).
- Il link "svuota carrello" ha `Delete=Elimina` **senza** `PRESTAZIONE`: un esame è "nel carrello"
  solo se il suo link ha *entrambi*.
- Il form Conferma contiene `MVPG=RcsStampaEtichetteLIS` nascosto: confermare via fetch
  ingoierebbe la stampa etichette — per questo la conferma è un click nativo.
