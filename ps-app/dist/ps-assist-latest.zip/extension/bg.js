/*
 * PS Assist — service worker.
 *
 * Two jobs:
 *  1. reload the extension on request (the panel's "⟳ ricarica estensione");
 *  2. fetch and cache referto PDFs.
 *
 * Why the PDFs are fetched HERE and not in the panel: a referto opens a viewer
 * that lives on ANOTHER internal host and shows the file as a blob: of that
 * origin, so a page script on SA4PSO can neither read it nor fetch it (CORS).
 * The service worker can — for the origins declared in host_permissions — so
 * it follows the chain (redirect → viewer page → its pdf endpoint) and stores
 * the bytes. Everything stays on this machine, in the extension's own storage.
 */

const PDF_SMELL = /uploaddownloadservlet|mimetype=application\/pdf|get_pdf|jasperservlet|refertostream|report|\.pdf(?:[?&"']|$)/i;

// The chain may only walk hosts this extension is FOR (host_permissions):
// viewer HTML can quote any address, and a harvested vendor link must never
// be fetched with hospital credentials.
const ALLOWED_ORIGINS = new Set([
  "https://smarthealth.multimedica.it",
  "http://10.11.0.151:9080",
]);

function candidates(text, baseUrl) {
  const out = [];
  const seen = new Set();
  const push = (raw) => {
    const u = String(raw || "").trim().replace(/&amp;/gi, "&");
    if (!u || u.length < 8 || seen.has(u)) return;
    if (/^(javascript:|#|data:|blob:|mailto:)/i.test(u)) return;
    if (!/^(https?:)?\/|^[\w.-]+\.(?:do|rra2|pdf|jsp|html?)\b/i.test(u)) return;
    if (/[([+=&%]$|%27$/.test(u)) return;
    if (!PDF_SMELL.test(u)) return;
    seen.add(u);
    try {
      const abs = new URL(u, baseUrl);
      if (!ALLOWED_ORIGINS.has(abs.origin)) return;
      out.push(abs.href);
    } catch { /* skip */ }
  };
  // frames, embeds, iframes, forms, links, meta refresh, window.open, plain strings
  for (const re of [
    /<(?:i?frame|embed)[^>]+src\s*=\s*["']([^"']+)["']/gi,
    /<object[^>]+data\s*=\s*["']([^"']+)["']/gi,
    /<form[^>]+action\s*=\s*["']([^"']+)["']/gi,
    /<a[^>]+href\s*=\s*["']([^"']+)["']/gi,
    /content\s*=\s*["'][^"']*url\s*=\s*([^"'\s>]+)/gi,
    /window\.open\(\s*["']([^"']+)["']/gi,
    /location\s*(?:\.\s*(?:href|replace|assign))?\s*[=(]\s*["']([^"']+)["']/gi,
    /"([^"<>\n\r]{8,1200})"/g,
    /'([^'<>\n\r]{8,1200})'/g,
  ]) for (const m of text.matchAll(re)) push(m[1]);
  return out.slice(0, 6);
}

async function grabPdf(url, hop = 0, budget) {
  budget = budget || { n: 0 };
  if (!ALLOWED_ORIGINS.has(new URL(url).origin)) return { ok: false, why: "fuori dall'ospedale" };
  // a hung hospital endpoint must fail a row, never hang the whole save
  const ctl = new AbortController();
  const tid = setTimeout(() => ctl.abort(), 15000);
  let res;
  try {
    res = await fetch(url, { credentials: "include", redirect: "follow", cache: "no-store", signal: ctl.signal });
  } catch (e) {
    clearTimeout(tid);
    return { ok: false, why: e && e.name === "AbortError" ? "timeout" : String(e && e.message || e).slice(0, 40) };
  }
  clearTimeout(tid);
  if (!res.ok) return { ok: false, why: `HTTP ${res.status}` };
  const ctype = (res.headers.get("content-type") || "").toLowerCase();
  const buf = await res.arrayBuffer();
  // come in core.js: il tipo dichiarato è un'etichetta, i primi byte sono il
  // documento — un PDF chiamato «text/html» resta un PDF
  const magico = buf.byteLength > 4 && String.fromCharCode(...new Uint8Array(buf, 0, 5)) === "%PDF-";
  if (magico || ctype.includes("pdf") || ctype.includes("octet-stream")) {
    return { ok: true, buf, type: "application/pdf" };
  }
  if (hop >= 2 || !ctype.includes("html")) return { ok: false, why: `tipo ${ctype.split(";")[0] || "?"}` };
  const text = new TextDecoder("windows-1252").decode(buf);
  if (/name=["']?password/i.test(text)) return { ok: false, why: "sessione scaduta" };
  const cands = candidates(text, res.url || url);
  for (const c of cands) {
    try {
      if (++budget.n > 6) break;   // un tetto solo per tutta la caccia, come in core.js
      const r = await grabPdf(c, hop + 1, budget);
      if (r.ok) return r;
    } catch { /* next candidate */ }
  }
  return { ok: false, why: `visualizzatore (${cands.length} link tentati)` };
}

const b64 = (buf) => {
  const bytes = new Uint8Array(buf);
  let s = "";
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
};

const KEY = (id) => "ref:" + id;
const REF_TTL = 8 * 3600e3;   // a shift: cached documents die with it
// I dati clinici letti restano un giorno e SOPRAVVIVONO alla chiusura del
// browser e al logout: un turno è di dodici ore e i pazienti sono più di
// dodici, quindi una memoria che muore col browser sarebbe inutile. Ventiquattro
// ore dopo l'ultima lettura la scheda scade e viene cancellata da sola.
let codaArch = Promise.resolve();   // le modifiche dell'archivio, una alla volta
const STORICO_TTL = 24 * 3600e3;
const STORICO_MAX = 200;         // di fatto nessun limite per un turno
const REF_MAX = 25;           // and never pile up

async function prune() {
  const all = await chrome.storage.local.get(null);
  const refs = Object.entries(all).filter(([k]) => k.startsWith("ref:"));
  const dead = refs.filter(([, v]) => Date.now() - (v.ts || 0) > REF_TTL).map(([k]) => k);
  const alive = refs.filter(([, v]) => Date.now() - (v.ts || 0) <= REF_TTL)
    .sort((a, b) => (b[1].ts || 0) - (a[1].ts || 0));
  const extra = alive.slice(REF_MAX).map(([k]) => k);
  if (dead.length || extra.length) await chrome.storage.local.remove([...dead, ...extra]);
}
chrome.runtime.onStartup?.addListener(() => chrome.storage.local.get(null).then((all) =>
  chrome.storage.local.remove(Object.keys(all).filter((k) => k.startsWith("ref:")))));

// ---------------------------------------------------------------------------
// «⭳ Carica i valori» apre anche lo storico del portale, in una scheda di
// sottofondo: la stessa pagina che il medico apre col link «Storico Dati
// Clinici», dallo stesso link della pagina — mai un indirizzo costruito, mai
// una richiesta diretta al portale. Lì il content script legge la tabella come
// fa sempre; qui si segue la scheda e la si chiude appena ha consegnato.
// Lo stato sta in storage.session: se il service worker si ferma a metà, non
// si perde niente.
let SOTTO_MAX = 30000;                 // oltre, la tabella non arriverà
const SOTTO_QUIETE = 2500;             // dopo l'ultima consegna, si chiude
const quiete = new Map();
const sottoK = (id) => "sotto:" + id;
const inCorso = (s) => !!s && (s.esito === "attesa" || s.esito === "lettura");
async function sottoGet(id) { if (id == null) return null; return (await chrome.storage.session.get(sottoK(id)))[sottoK(id)] || null; }
const sottoSet = (id, v) => chrome.storage.session.set({ [sottoK(id)]: v });
async function sottoFine(id, esito) {
  const s = await sottoGet(id);
  if (!inCorso(s)) return;
  const t = await chrome.tabs.get(id).catch(() => null);
  if (esito === "tempo" && t && !t.url) esito = "altrove";   // l'url si vede solo sui nostri indirizzi
  await sottoSet(id, { ...s, esito, fine: Date.now() });
  clearTimeout(quiete.get(id)); quiete.delete(id);
  // se il medico ci è andato sopra, la scheda è sua: non si chiude
  if (t && !t.active) await chrome.tabs.remove(id).catch(() => {});
}
async function sottoControlla() {
  for (const [k, s] of Object.entries(await chrome.storage.session.get(null))) {
    if (!k.startsWith("sotto:")) continue;
    const id = Number(k.slice(6));
    if (s.esito === "attesa" && Date.now() - s.ts > SOTTO_MAX) await sottoFine(id, "tempo");
    else if (s.esito === "lettura" && Date.now() - s.ultima > SOTTO_QUIETE) await sottoFine(id, s.suo ? "letto" : "altro");
    else if (s.fine && Date.now() - s.fine > 10 * 60e3) await chrome.storage.session.remove(k);
  }
}
// La scheda ha finito di caricare ma è rimasta sul gestionale: il link non
// ha portato al portale (sessione scaduta, pagina d'errore). Inutile aspettare
// 30 secondi — lo si dice subito, e il pannello legge i Risultati.
chrome.tabs.onUpdated.addListener((id, info, tab) => {
  if (info.status !== "complete" || !tab || !/^https:\/\/smarthealth\.multimedica\.it\//.test(tab.url || "")) return;
  sottoGet(id).then((s) => s && s.esito === "attesa" && sottoFine(id, "nonportale")).catch(() => {});
});
chrome.tabs.onRemoved.addListener((id) => {
  sottoGet(id).then((s) => inCorso(s) && sottoSet(id, {
    ...s, fine: Date.now(), esito: s.esito === "lettura" ? (s.suo ? "letto" : "altro") : "chiusa",
  })).catch(() => {});
});

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg === "psassist-reload") { chrome.runtime.reload(); return; }
  if (!msg || typeof msg !== "object") return;

  if (msg.t === "cacheRef") {
    const salva = async (data, size) => {
      await chrome.storage.local.set({ [KEY(msg.id)]: { data, ts: Date.now(), size, ep: msg.ep || "", pk: msg.pk || "" } });
      await prune();
      reply({ ok: true, size });
    };
    // Il pannello può aver già letto il PDF col suo lettore (che sa replicare
    // un visualizzatore): allora arriva già in base64, e qui si mette solo via.
    if (typeof msg.data === "string" && msg.data) {
      if (!/^JVBERi/.test(msg.data)) return reply({ ok: false, why: "non è un PDF" }), true;
      salva(msg.data, msg.size || 1).catch((e) => reply({ ok: false, why: String(e && e.message || e).slice(0, 60) }));
      return true;
    }
    grabPdf(msg.url)
      .then(async (r) => {
        if (!r.ok) return reply(r);
        await salva(b64(r.buf), r.buf.byteLength);
      })
      .catch((e) => reply({ ok: false, why: String(e && e.message || e).slice(0, 60) }));
    return true; // async reply
  }

  if (msg.t === "getRef") {
    chrome.storage.local.get(KEY(msg.id)).then(async (o) => {
      const hit = o[KEY(msg.id)];
      // Un documento torna solo per l'episodio sotto cui è stato salvato: se
      // uno dei due episodi non si sa, non si può dimostrare che è lo stesso,
      // e allora non si consegna.
      if (!hit || String(msg.ep || "") !== String(hit.ep || "")) return reply({ ok: false });
      if (Date.now() - (hit.ts || 0) > REF_TTL) { await chrome.storage.local.remove(KEY(msg.id)); return reply({ ok: false }); }
      reply({ ok: true, data: hit.data });
    }).catch(() => reply({ ok: false }));   // senza questo il pannello resta appeso
    return true;
  }

  if (msg.t === "listRef") {
    prune().then(() => chrome.storage.local.get(null)).then((all) => {
      const want = Array.isArray(msg.ids) ? new Set(msg.ids) : null;
      const out = {};
      for (const k of Object.keys(all)) {
        if (!k.startsWith("ref:")) continue;
        const id = k.slice(4), rec = all[k];
        if (want && !want.has(id)) continue;                    // only what was asked for
        if (String(msg.ep || "") !== String(rec.ep || "")) continue;   // e solo questo episodio
        out[id] = rec.size || 1;
      }
      reply({ ok: true, cached: out });
    }).catch(() => reply({ ok: false }));
    return true;
  }

  // Le tabelle cliniche lette, UNA SCHEDA PER PAZIENTE. Stanno nella memoria
  // dell'estensione (su disco, non nella RAM della sessione): un turno dura
  // dodici ore e non si può perdere tutto chiudendo il browser. Scadono da
  // sole 24 ore dopo l'ultima lettura. Il pannello chiede prima l'indice e
  // decide LUI quale scheda è di questo paziente: la regola d'identità sta
  // in un posto solo, non anche qui dentro.
  const ARCH = "storicoArch";
  // Leggere-modificare-riscrivere un unico blob da più schede insieme fa
  // perdere schede: la seconda scrittura parte dalla copia che aveva letto
  // prima ed è come se la prima non fosse mai avvenuta. Quindi le modifiche
  // dell'archivio passano una alla volta, in fila.
  const inFila = (fn) => (codaArch = codaArch.then(fn, fn));
  const vivo = (r) => r && Date.now() - (r.letto || 0) <= STORICO_TTL;
  const potaArchivio = (a) => {
    const vive = Object.entries(a).filter(([, r]) => vivo(r))
      .sort((x, y) => (y[1].letto || 0) - (x[1].letto || 0)).slice(0, STORICO_MAX);
    return Object.fromEntries(vive);
  };

  // Il medico apre «Storico dati clinici» DALLA pagina di un paziente: quel
  // passaggio è l'identità, ed è più sicuro di qualunque confronto di nomi.
  // Si annota chi era, e la pagina del portale userà quello.
  if (msg.t === "apreStorico") {
    chrome.storage.session.set({ apertura: { ep: String(msg.ep || ""), nome: String(msg.nome || "").slice(0, 60), ts: Date.now() } })
      .then(() => reply({ ok: true })).catch(() => reply({ ok: false }));
    return true;
  }
  if (msg.t === "chiAprivo") {
    // Prima la scheda aperta da noi in sottofondo: sa per chi è, e lo spazio
    // condiviso «apertura» non si tocca — è quello del clic del medico, e una
    // scheda del portale aperta a mano deve continuare a trovarci il suo.
    sottoGet(_sender.tab && _sender.tab.id).then(async (s) => {
      if (s) return reply({ ok: true, ep: s.ep, nome: s.nome, ts: s.ts, sotto: true });
      const a = (await chrome.storage.session.get("apertura")).apertura;
      reply(a && Date.now() - (a.ts || 0) < 20 * 60e3 ? { ok: true, ...a } : { ok: false });
    }).catch(() => reply({ ok: false }));
    return true;
  }

  if (msg.t === "apriStoricoSotto") {
    (async () => {
      const da = _sender.tab;
      let u;
      try { u = new URL(String(msg.url || "")); } catch { return reply({ ok: false, why: "link non valido" }); }
      // solo il link vero della pagina del paziente, e solo quello
      let origineMia = "";
      try { origineMia = new URL(_sender.url).origin; } catch { /* niente */ }
      if (!da || u.origin !== origineMia || u.origin !== "https://smarthealth.multimedica.it"
          || !/\/Sa4ViewerExtRedirect\.do$/i.test(u.pathname) || u.searchParams.get("MODALITA") !== "CLINICA") {
        return reply({ ok: false, why: "link inatteso" });
      }
      await sottoControlla();
      const vive = Object.entries(await chrome.storage.session.get(null)).filter(([k, s]) => k.startsWith("sotto:") && inCorso(s));
      const gia = vive.find(([, s]) => s.opener === da.id);
      if (gia) return reply({ ok: true, tabId: Number(gia[0].slice(6)), gia: true });   // doppio clic
      if (vive.length >= 3) return reply({ ok: false, why: "troppe letture in corso" });
      // nasce vuota, si annota per chi è, POI parte: così l'annotazione arriva
      // sempre prima dello script del portale
      const vuota = { url: "about:blank", active: false };
      const t = await chrome.tabs.create({ ...vuota, openerTabId: da.id, index: da.index + 1, windowId: da.windowId })
        .catch(() => chrome.tabs.create(vuota));
      await sottoSet(t.id, { opener: da.id, ep: String(msg.ep || ""), nome: String(msg.nome || "").slice(0, 60), ts: Date.now(), esito: "attesa" });
      await chrome.tabs.update(t.id, { url: u.href });
      setTimeout(() => sottoControlla().catch(() => {}), SOTTO_MAX + 500);
      reply({ ok: true, tabId: t.id });
    })().catch((e) => reply({ ok: false, why: String((e && e.message) || e).slice(0, 80) }));
    return true;
  }
  if (msg.t === "esitoSotto") {
    sottoControlla().then(() => sottoGet(Number(msg.tabId)))
      .then((s) => reply(s ? { ok: true, esito: s.esito, esami: s.esami || 0, prelievi: s.prelievi || 0 } : { ok: false }))
      .catch(() => reply({ ok: false }));
    return true;
  }
  // il portale ha chiesto di entrare: vale solo per le schede aperte da noi
  if (msg.t === "sottoLogin") {
    const id = _sender.tab && _sender.tab.id;
    sottoGet(id).then((s) => s && s.esito === "attesa" && sottoFine(id, "login"))
      .catch(() => {}).then(() => reply({ ok: true }));
    return true;
  }

  if (msg.t === "putStorico") {
    const chiave = String(msg.chiave || "").slice(0, 80);
    if (!chiave || !msg.dati) return reply({ ok: false });
    inFila(async () => {
      const o = await chrome.storage.local.get(ARCH);
      const a = potaArchivio(o[ARCH] || {});
      // Chi scrive dice da quale revisione della scheda è partito: se nel
      // frattempo qualcun altro l'ha cambiata (il portale mentre si leggono i
      // Risultati, o due schede insieme), non la si copre — si risponde
      // «conflitto», e chi scrive rilegge, rifonde e riprova.
      if ("base" in msg && ((a[chiave] && a[chiave].rev) || 0) !== (msg.base || 0)) {
        return reply({ ok: false, conflitto: true });
      }
      const nuovo = !a[chiave];
      a[chiave] = { ...msg.dati, rev: ((a[chiave] && a[chiave].rev) || 0) + 1 };
      await chrome.storage.local.set({ [ARCH]: potaArchivio(a) });
      reply({ ok: true, nuovo, pazienti: Object.keys(a).length });
      // se l'ha mandata una scheda aperta da noi in sottofondo: ha letto.
      // Si chiude dopo un momento di calma (la tabella può arrivare a pezzi).
      const id = _sender.tab && _sender.tab.id;
      const st = id != null ? await sottoGet(id) : null;
      if (inCorso(st)) {
        await sottoSet(id, { ...st, esito: "lettura", ultima: Date.now(), suo: String(msg.dati.ep || "") === st.ep,
          esami: (msg.dati.righe || []).length, prelievi: (msg.dati.date || []).length });
        clearTimeout(quiete.get(id));
        quiete.set(id, setTimeout(() => sottoControlla().catch(() => {}), SOTTO_QUIETE + 100));
      }
    }).catch(() => reply({ ok: false }));
    return true;
  }
  // senza chiave: l'indice (chi c'è, non i valori). Con chiave: quel record.
  if (msg.t === "getStorico") {
    chrome.storage.local.get(ARCH)
      .then(async (o) => {
        const a = potaArchivio(o[ARCH] || {});
        if (Object.keys(a).length !== Object.keys(o[ARCH] || {}).length) {
          await chrome.storage.local.set({ [ARCH]: a });   // scaduti: via
        }
        if (msg.chiave) {
          const r = a[msg.chiave];
          return reply(r ? { ok: true, dati: r } : { ok: false });
        }
        reply({
          ok: true,
          indice: Object.entries(a).map(([chiave, r]) => ({
            chiave, cf: r.cf || "", ep: r.ep || "", paziente: r.paziente || {}, letto: r.letto || 0,
            esami: (r.righe || []).length, prelievi: (r.date || []).length,
          })),
        });
      })
      .catch(() => reply({ ok: false }));
    return true;
  }
  // Eliminare un paziente: la sua scheda clinica e i referti tenuti per lui.
  if (msg.t === "delStorico") {
    inFila(async () => {
      // Si cancella per IDENTITÀ, non per la chiave che ci ricordavamo: una
      // scheda arrivata dal portale o da un referto può non aver mai lasciato
      // una chiave nell'elenco, e «eliminato tutto» deve essere vero.
      // Le parole ORDINATE facevano combaciare persone diverse: «DE ROSSI
      // MARIA» e «DE MARIA ROSSI» diventavano la stessa stringa, e cancellare
      // l'una cancellava la scheda dell'altra. Si accettano solo i due ordini
      // veri, come combaciaNome nel pannello.
      const norm = (t) => String(t || "").toUpperCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
        .replace(/[^A-Z0-9 ]+/g, " ").trim().replace(/\s+/g, " ");
      const o = await chrome.storage.local.get(ARCH);
      const a = o[ARCH] || {};
      const suo = norm(msg.nome || "");
      // e il nome si guarda SOLO se la chiave non ha già trovato la scheda:
      // «elimina questo paziente» non deve mai toccarne un altro
      const perChiave = Object.keys(a).filter((k) => k === msg.chiave);
      const stessoNome = (cognome, nome) => {
        const c = norm(cognome), n = norm(nome);
        if (!suo || (!c && !n)) return false;
        return suo === norm(c + " " + n) || suo === norm(n + " " + c);
      };
      const via = perChiave.length ? perChiave
        : Object.keys(a).filter((k) => stessoNome(a[k]?.paziente?.cognome, a[k]?.paziente?.nome));
      if (via.length) { for (const k of via) delete a[k]; await chrome.storage.local.set({ [ARCH]: a }); }
      const all = await chrome.storage.local.get(null);
      const suoi = Object.keys(all).filter((k) => k.startsWith("ref:")
        && ((msg.chiave && all[k]?.pk === msg.chiave) || (msg.ep && String(all[k]?.ep || "") === String(msg.ep))));
      if (suoi.length) await chrome.storage.local.remove(suoi);
      reply({ ok: true, schede: via.length, referti: suoi.length });
    }).catch(() => reply({ ok: false }));
    return true;
  }

  // ---- l'indirizzo del portale clinico, deciso dal medico ----------------
  // L'indirizzo stava scritto dentro il manifest: un numero IP e una porta. Se
  // l'ospedale li cambia — o se sono diversi da un presidio all'altro — il
  // programma semplicemente non parte su quella pagina, e non c'è modo di
  // accorgersene da dentro. Ora l'indirizzo lo aggiunge il medico: Chrome
  // chiede il permesso per QUEL sito e basta, e lo script si registra lì.
  if (msg.t === "portale") {
    chrome.storage.local.get("portale")
      .then((o) => reply({ ok: true, origine: o.portale || "" }))
      .catch(() => reply({ ok: false, origine: "" }));
    return true;
  }
  if (msg.t === "apriImpostazioni") {
    chrome.runtime.openOptionsPage().then(() => reply({ ok: true })).catch(() => reply({ ok: false }));
    return true;
  }
  if (msg.t === "togliPortale") {
    registraPortale(null)
      .then(() => chrome.storage.local.remove("portale"))
      .then(() => reply({ ok: true })).catch(() => reply({ ok: false }));
    return true;
  }
  if (msg.t === "aggiungiPortale") {
    (async () => {
      let origine;
      try { origine = new URL(String(msg.url || "").trim()).origin; }
      catch { return reply({ ok: false, why: "Non è un indirizzo: incolla quello che vedi nella barra del browser." }); }
      if (!/^https?:$/.test(new URL(origine).protocol)) return reply({ ok: false, why: "Serve un indirizzo http o https." });
      const pattern = origine + "/*";
      // Il permesso si chiede dalla PAGINA delle impostazioni, non da qui:
      // chrome.permissions.request vuole un gesto dell'utente, e un gesto non
      // sopravvive al salto di messaggio dal pannello al service worker.
      // Qui si registra soltanto, e SOLO se il permesso c'è davvero.
      const ha = await chrome.permissions.contains({ origins: [pattern] }).catch(() => false);
      if (!ha) return reply({ ok: false, why: "Chrome non ha dato il permesso per questo sito." });
      try { await registraPortale(pattern); }
      catch (e) { return reply({ ok: false, why: "Chrome non ha registrato lo script: " + String(e && e.message || e).slice(0, 80) }); }
      await chrome.storage.local.set({ portale: origine });
      reply({ ok: true, origine });
    })().catch((e) => reply({ ok: false, why: String(e && e.message || e) }));
    return true;
  }

  if (msg.t === "clearRef") {
    chrome.storage.local.get(null).then(async (all) => {
      await chrome.storage.local.remove(Object.keys(all).filter((k) => k.startsWith("ref:")));
      // le schede cliniche NON si cancellano al logout: hanno la loro
      // scadenza a 24 ore, ed è quella a decidere

      reply({ ok: true });
    }).catch(() => reply({ ok: false }));
    return true;
  }
});

// Lo script sul portale scelto dal medico va rimesso a ogni avvio: le
// registrazioni dinamiche sopravvivono, ma se il permesso è stato revocato
// vanno tolte, e un doppione fa fallire register().
async function registraPortale(pattern) {
  try { await chrome.scripting.unregisterContentScripts({ ids: ["portale"] }); } catch { /* non c'era */ }
  if (!pattern) return;
  await chrome.scripting.registerContentScripts([{
    id: "portale", matches: [pattern], js: ["content.js"], runAt: "document_idle", persistAcrossSessions: true,
  }]);
}
async function riallineaPortale() {
  const o = await chrome.storage.local.get("portale");
  if (!o.portale) return;
  const pattern = o.portale + "/*";
  const ok = await chrome.permissions.contains({ origins: [pattern] }).catch(() => false);
  if (ok) await registraPortale(pattern);
  else { await registraPortale(null); await chrome.storage.local.remove("portale"); }
}
// un errore qui non deve diventare un rifiuto non gestito nel service worker
const riallinea = () => { riallineaPortale().catch(() => {}); };
chrome.runtime.onStartup?.addListener(riallinea);
chrome.runtime.onInstalled?.addListener(riallinea);
