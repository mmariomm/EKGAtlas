/*
 * PS Assist — Pronto Soccorso order helper for SA4PSO (Dedalus)
 * ============================================================
 *
 * Rebuilt from scratch (2026 re-audit of the saved SA4PSO pages).
 *
 * WHAT IT DOES
 * ------------
 * From the patient page (or the "Nuova Richiesta" / exam pages) it creates a
 * lab or radiology richiesta, fills the quesito diagnostico, adds the chosen
 * prestazioni and verifies each one landed in the cart — all driven with
 * same-origin fetch() calls that replay exactly the requests the browser
 * would send by clicking. The doctor then reviews the cart on the real page,
 * or — opt-in («+ Conferma») — the real cart page is loaded in a hidden,
 * script-less frame and its own "Conferma" button is clicked natively (the
 * confirm posts to MVPG=RcsStampaEtichetteLIS). "Confermata" is said only on
 * proof: a page of the same episode listing that richiesta's print links.
 *
 * WHY FETCH INSTEAD OF THE OLD "one exam per page reload" WALKER
 * --------------------------------------------------------------
 * The 0.x helper kept a queue in localStorage and re-entered itself after
 * every full-page reload. That design needed TTLs, in-flight markers and a
 * re-check dance to avoid double orders. Driving the server with fetch()
 * from a single page collapses all of that into one linear async function:
 * no cross-reload state, no reload of Insert URLs, and every step's response
 * is parsed and checked before the next request is sent.
 *
 * AUDITED FACTS THIS FILE RELIES ON (from the saved source pages)
 * ---------------------------------------------------------------
 * - Pages are windows-1252; POST bodies must be urlencoded in that charset.
 * - Patient page  : MVPG=PsoEpisodioClinicoAmbulatorio, has entry links
 *                   <a title="Richieste Laboratorio">, "Richieste Radiologia".
 * - Crea page     : form[name=RICHIESTACrea], method=post; fields include
 *                   QUESITO_DIAGNOSTICO (textarea), URGENZA/MODALITA/MEDICO
 *                   (server-prefilled; left untouched), hidden RICHIESTA_ID
 *                   (allocated when the page renders), submit Update="Crea".
 * - Exam page     : form[name=Prestazioni] (POST, submit Update="Conferma"),
 *                   filter select[name=RISORSA_ID] + input[name=s_PRESTAZIONE]
 *                   + submit DoSearch="Cerca". Each orderable exam is an
 *                   <a class="AFCDataLink"> whose href carries PRESTAZIONE=<code>
 *                   and either Insert=Inserisci (add) or Delete=Elimina (in
 *                   cart). A cart-wide "svuota" link also carries
 *                   Delete=Elimina but NO PRESTAZIONE param — so "in cart"
 *                   checks must require BOTH markers.
 * - The rendered list is a plain GET: swapping RISORSA_ID in the list URL
 *   switches resource; s_PRESTAZIONE filters. No pagination (146 rows max).
 * - Saved pages carry two `selected` options in some selects (server quirk);
 *   browsers keep the LAST one — serialization must do the same.
 *
 * SAFETY RULES (all enforced in code)
 * -----------------------------------
 * 1. An Insert URL is requested AT MOST ONCE. Verification re-reads the
 *    plain list URL (no Insert params); if the exam still isn't in the cart
 *    after the re-check budget, the run HARD-STOPS and says what to check.
 * 2. Every fetched page must belong to the same EPISODIO_ID the run started
 *    with; any mismatch aborts before anything else is sent.
 * 3. The final Conferma is opt-in and immediate (the doctor's click on
 *    «+ Conferma» is the decision): a native click on the EHR's own button,
 *    only when the cart equals the receipt of this run. Confirmed = proven
 *    by the EHR's page, never assumed.
 * 4. The quesito diagnostico pre-filled by triage is kept, unless the doctor
 *    typed his own in the panel (not a chip): then his text is written.
 * 5. Stop/Esc aborts in-flight work immediately (AbortController).
 * 6. No request ever leaves the hospital origin.
 */

(function () {
  "use strict";

  // ================================================================ CONFIG
  const APP = "PS Assist";
  const VERSION = "3.61.0";
  const NS = "psassist:"; // storage namespace

  const TIMEOUT_MS = 20000;      // per-request timeout
  const PACE_MS = 250;           // gentle pause between consecutive requests
  // Le riletture dell'elenco prima di dire che un esame non è entrato, e la
  // pausa prima di ciascuna: un gestionale carico mette l'esame in carrello
  // anche dopo 5–10 secondi. Rileggere costa una lettura; non c'è mai un secondo invio.
  const VERIFY_WAITS = [1200, 2000, 3000, 5000, 8000];
  const VERIFY_RECHECKS = VERIFY_WAITS.length;
  // Lo stesso, prima di arrendersi alla conferma: un carrello che arriva senza
  // una riga che deve avere si rilegge (mai un secondo clic), e la pagina del
  // paziente che non elenca ancora la richiesta confermata si rilegge prima
  // di dire «non confermata» (il LIS può metterci qualche secondo).
  const CONFIRM_WAITS = [2000, 4000, 8000];
  const CONFIRM_FLAG_TTL = 120e3;// ms an auto-confirm handoff stays valid
  // un messaggio che deve sopravvivere al cambio di pagina: quello che si è
  // deciso in sottofondo va detto sulla pagina dove il medico arriva
  const AVVISO = "avviso.v1";
  const PRINT_FLAG_TTL = 180e3;  // ms a post-confirm print handoff stays valid
  const QUEUE_TTL = 30 * 60e3;   // ms a still-unconfirmed richiesta keeps reminding
  // Il giro in corso, annotato passo per passo. Il gestionale ricarica la
  // pagina a ogni click e il motore muore con lei: così invece riprende da
  // dov'era, e quello che era già partito non riparte MAI una seconda volta.
  const CORSA = "corsa.v1";
  const CORSA_TTL = 10 * 60e3;   // più vecchio di così non si riprende da solo
  const CORSA_MAX = 12;          // riprese massime: mai un ciclo senza fine
  // Due schede sulla stessa richiesta non devono mandare gli stessi esami.
  // L'appunto sta nella scheda (sessionStorage) e una scheda DUPLICATA se lo
  // porta dietro: il presidio invece sta in memoria condivisa, dove le schede
  // si vedono fra loro, e dice chi ci sta lavorando adesso.
  const PRESIDIO = "corsa.presidio.v1";
  const PRESIDIO_MS = 25e3;      // un segno più vecchio è di una scheda morta
  // Un giro lasciato a metà (scheda chiusa, sessione scaduta, browser caduto)
  // non deve sparire in silenzio: questo lo dice alla prima pagina utile.
  const APERTA = "corsa.aperta.v1";
  const APERTA_TTL = 30 * 60e3;
  const OK_STRISCIA = 2 * 60e3;  // un ordine finito bene resta sulla striscia due minuti

  // Resources ("Risorsa" dropdown values) — verified in the saved pages.
  const RES = {
    POC:     "00660001P", // LABORATORIO ANALISI POC - SSG
    URGENZE: "00720001P", // LABORATORIO ANALISI URGENZE - SSG
    CENTRAL: "00130001P", // LABORATORIO ANALISI - SSG
    RX:      "00120001P", // RADIOLOGIA - RX - SSG
    ECO:     "00400001P", // RADIOLOGIA - ECOGRAFIA - SSG
    RMN:     "00360001P", // RADIOLOGIA - RISONANZA MAGNETICA NUCLEARE - SSG
    TAC:     "00380001P", // RADIOLOGIA - TAC - SSG
  };
  const RES_SHORT = {
    // Urgenze e laboratorio centrale, per chi ordina, sono lo stesso posto:
    // un nome solo, e nella griglia un gruppo solo
    [RES.POC]: "POC", [RES.URGENZE]: "Lab centrale", [RES.CENTRAL]: "Lab centrale",
    [RES.RX]: "RX", [RES.ECO]: "Eco", [RES.RMN]: "RMN", [RES.TAC]: "TAC",
  };

  // Quick presets shown as chips. Codes verified against the saved pages
  // (see ps-app/README.md). A preset is shown only when every code exists in
  // the catalog available on this machine (embedded + learned).
  const PRESETS = [
    { name: "Base PS",  items: [[RES.POC, "320"], [RES.POC, "325"], [RES.POC, "176"]] },          // emocromo, EGA venosa NEW, creatinina
    { name: "Epatico",  items: [[RES.URGENZE, "16"], [RES.URGENZE, "228"], [RES.URGENZE, "53"], [RES.URGENZE, "167"], [RES.URGENZE, "34"]] }, // bili reflex, GPT, GOT, GGT, lipasi
    { name: "Coag POC", items: [[RES.POC, "220"], [RES.POC, "134"], [RES.POC, "135"]] },          // PT, PTT, fibrinogeno POC
    { name: "Coag",     items: [[RES.URGENZE, "181"], [RES.URGENZE, "54"], [RES.URGENZE, "258"]] }, // PT, PTT, fibrinogeno urgenze
  ];
  const SINGLES = [ // one-tap single exams (compact grid, grouped by lab)
    [RES.POC, "320"], [RES.POC, "325"], [RES.POC, "326"], [RES.POC, "176"],
    [RES.POC, "101"], [RES.POC, "324"], [RES.POC, "30"],
    // la coagulazione POC, uno per uno: i pacchetti la mettono, e da qui si vede e si toglie
    [RES.POC, "220"], [RES.POC, "134"],
    [RES.URGENZE, "293"], [RES.URGENZE, "159"], [RES.URGENZE, "297"],
    [RES.URGENZE, "317"],
    // gli epatici: il profilo rapido li ordina insieme, ma quasi sempre se ne
    // vuole uno solo — la lipasi c'era già, gli altri quattro no
    [RES.URGENZE, "228"], [RES.URGENZE, "53"], [RES.URGENZE, "167"],
    [RES.URGENZE, "16"], [RES.URGENZE, "34"],
    [RES.CENTRAL, "212"],
    [RES.RX, "35"], [RES.RX, "36"], [RES.RX, "28"],
  ];
  // Short ward names for the UI only. The catalog label stays the source of
  // truth for the anti-wrong-exam check, so renaming here is always safe.
  const DISPLAY = {
    [`${RES.POC}:320`]: "EMOCROMO POC",
    // Il laboratorio ha rifatto gli emogas: sono i codici «- NEW». Chi ordina
    // deve vedere che è quella nuova, o non saprebbe distinguerla dalla
    // vecchia che resta in elenco.
    [`${RES.POC}:325`]: "EGA VENOSA NEW",
    [`${RES.POC}:326`]: "EGA ARTERIOSA NEW",
    [`${RES.POC}:176`]: "CREATININA POC",
    [`${RES.POC}:101`]: "D-DIMERO POC",
    [`${RES.POC}:324`]: "TROPONINA US",
    [`${RES.POC}:30`]:  "GLUCOSIO POC",
    [`${RES.POC}:220`]: "PT POC",
    [`${RES.POC}:134`]: "PTT POC",
    [`${RES.POC}:135`]: "FIBRINOGENO POC",
    [`${RES.CENTRAL}:212`]: "SARSCOV",
    [`${RES.URGENZE}:293`]: "PCR",
    [`${RES.URGENZE}:34`]:  "LIPASI",
    [`${RES.URGENZE}:228`]: "GPT",
    [`${RES.URGENZE}:53`]:  "GOT",
    [`${RES.URGENZE}:167`]: "GAMMA GT",
    [`${RES.URGENZE}:16`]:  "BILIRUBINA",
    [`${RES.URGENZE}:159`]: "PROCALCITONINA",
    [`${RES.URGENZE}:297`]: "NT PRO-BNP",
    [`${RES.URGENZE}:317`]: "ESAME URINE",
    [`${RES.RX}:35`]: "RX TORACE",
    [`${RES.RX}:36`]: "RX TORACE 1 PROIEZ.",
    [`${RES.RX}:28`]: "RX ADDOME",
  };
  // If EGA arteriosa is selected, the venosa is dropped automatically.
  const EXCLUDE = [
    { keep: [RES.POC, "326"], drop: [RES.POC, "325"], note: "EGA arteriosa sostituisce la venosa" },
    { keep: [RES.POC, "166"], drop: [RES.POC, "3"], note: "EGA arteriosa sostituisce la venosa" },
  ];

  // Common quesiti offered as one-tap chips (editable; last used are kept).
  const QUESITI_DEFAULT = [
    "Dolore toracico", "Dolore addominale", "Dispnea", "Febbre",
    "Trauma", "Sincope", "Vertigini", "Cefalea",
  ];
  // Quesito = pacchetto di esami: toccare il chip scrive il quesito E spunta
  // gli esami che per quel quesito servono quasi sempre. Stanno sempre in
  // testa ai chip, anche se l'elenco dei quesiti salvato non li ha. Un esame
  // che in questa macchina non esiste nel catalogo si salta e si dice.
  // «PT PTT Fantoli» = il laboratorio non-POC, cioè URGENZE (181 PT, 54 PTT).
  const PACCHETTI = [
    // base, coagulazione POC, troponina US
    { q: "Dolore toracico", items: [[RES.POC, "320"], [RES.POC, "325"], [RES.POC, "176"], [RES.POC, "220"], [RES.POC, "134"], [RES.POC, "324"]] },
    // base ma con l'EGA ARTERIOSA (326, non la venosa 325), coag POC, D-dimero, troponina, proBNP
    { q: "Dispnea", items: [[RES.POC, "320"], [RES.POC, "326"], [RES.POC, "176"], [RES.POC, "220"], [RES.POC, "134"], [RES.POC, "101"], [RES.POC, "324"], [RES.URGENZE, "297"]] },
    // base, epatico e pancreatico (bili reflex, GPT, GOT, GGT, lipasi), PT PTT Fantoli
    { q: "Dolore addominale", items: [[RES.POC, "320"], [RES.POC, "325"], [RES.POC, "176"], [RES.URGENZE, "16"], [RES.URGENZE, "228"], [RES.URGENZE, "53"], [RES.URGENZE, "167"], [RES.URGENZE, "34"], [RES.URGENZE, "181"], [RES.URGENZE, "54"]] },
  ];

  // Embedded catalog: every exam extracted from the saved lab pages
  // (code → label per resource). Radiology lists aren't in the saved pages;
  // they are LEARNED automatically the first time the list is seen and kept
  // in localStorage, after which radiology works one-click too.
  const EMBEDDED_CATALOG = {"00660001P":{"label":"LABORATORIO ANALISI POC - SSG (P)","items":{"3":"EMOGASANALISI VENOSA POC (POC2117)","30":"GLUCOSIO (POC1250)","31":"ACIDO LATTICO POC (POC1094)","63":"NA+ POC (POC1434)","64":"K+ POC (POC1435)","101":"D-DIMERO POC (POC1405)","102":"BICARBONATI EMATICI POC (POC1499)","134":"PTT POC (POC1402)","135":"FIBRINOGENO POC (POC1404)","138":"ACT POC (POCACT)","166":"EGA EMOGASANALISI ARTERIOSA (POC1006)","176":"CREATININEMIA (POC1206)","220":"PT (POC1401)","221":"CL- POC (POC1436)","223":"ACT LR POC (POCACTLR)","224":"CALCIO IONIZZATO (POC1982)","225":"TEST GRAVIDANZA URINE (POC1612)","266":"PCR POC (POC1102)","303":"BILIRUBINA (NEONATALE) (POC1341NEO)","305":"PANNELLO 1 – ANEMIA, EMORRAGIA, ISCHEMIA ARTO","306":"PANNELLO 3 - CARDIOPALMO","307":"PANNELLO 4 - TRAUMA","308":"PANNELLO 5 – DISPNEA, STROKE","309":"PANNELLO 6 – PDC, TORACALGIA","310":"PANNELLO 2 - BASE","318":"PANNELLO 9 - ESAMI POC","320":"EMOCROMOCITOMETRICO URGENTE (POCT1502)","323":"EMOGASANALISI CAPILLARE POC (POC2117)","324":"TROPONINA ULTRASENSIBILE (POC3001)","325":"EMOGASANALISI VENOSA POC - NEW (POC21171)","326":"EGA EMOGASANALISI ARTERIOSA POC - NEW (POC10061)","327":"BICARBONATI EMATICI POC - NEW (POC14991)","328":"GLUCOSIO POC - NEW (POC12501)","329":"ACIDO LATTICO POC - NEW (POC10941)","330":"SODIO NEL SIERO POC - NEW (POC14341)","331":"POTASSIO NEL SIERO - NEW (POC14351)","332":"CLORO NEL SIERO POC - NEW (POC14361)","333":"EMOGAS CAPILLARE POC (POC21172)"}},"00720001P":{"label":"LABORATORIO ANALISI URGENZE - SSG (P)","items":{"1":"EMOCROMO (1501)","15":"PEPTIDE NATRIURETICO TIPO B BNP (450057)","16":"BILIRUBINA TOTALE REFLEX (450008)","23":"PSEUDOCOLINESTERASI (450007)","34":"LIPASI (1572)","35":"ANTIGENE URINARIO STRPTOCOCCUS PNEUMONIAE (2136)","53":"GOT (1582)","54":"PTT (1402)","59":"LIQUOR ESAME CHIMICO FISICO (2338)","62":"URINOCOLTURA DA MITTO INTERMEDIO (2015)","73":"EMOCOLTURA (2000)","92":"AZOTEMIA (1200)","93":"CPK (1560)","105":"POTASSIO NEL SIERO (1435)","141":"D-DIMERO (1405)","147":"LEGIONELLE: RICERCA ANTIGENE NELLE URINE (450124)","159":"PROCALCITONINA (1690)","167":"GAMMA GT (1596)","168":"GLUCOSIO (1250)","171":"TROPONINA I (450106)","175":"TIREOTROPINA RIFLESSA(TSH-R)TSH. INCL. EVENTUALE DOSAGGIO DI FT4 E FT3 (450064)","181":"PT (1401)","183":"AMMONIEMIA (1343)","211":"URINOCOLTURA DA SACCHETTO (2036)","215":"CLORO NEL SIERO (1436)","216":"CREATININEMIA (1206)","217":"SODIO NEL SIERO (1434)","228":"GPT (1583)","230":"BETA HCG PLASMATICO (1766)","258":"FIBRINOGENO (450102)","270":"CALCIO TOTALE (1437)","272":"ANTITROMBINA III (1530)","293":"PROTEINA C REATTIVA (1102)","297":"NT PRO-BNP (2040)","316":"RICERCA DIRETTA ANTIGENI MALARIA (21295)","317":"ESAME URINE URGENTI (21296)"}},"00130001P":{"label":"LABORATORIO ANALISI - SSG (P)","items":{"1":"EMOCROMO (1501)","2":"URICEMIA (1300)","6":"COPROCOLTURA (1205)","7":"PF4 (1209)","9":"COLTURALE SU RACCOLTA SIERO EMATICA (1275)","10":"COLTURALE SU LIQUIDO DA CISTI (1282)","15":"PEPTIDE NATRIURETICO TIPO B BNP (450057)","16":"BILIRUBINA TOTALE REFLEX (450008)","17":"QUANTIFERON SINGOLO MITOGENO (1358)","18":"PREALBUMINA (1397)","22":"DOSAGGIO AMIKACINA PICCO (450030)","23":"PSEUDOCOLINESTERASI (450007)","24":"FERRITINA (450042)","25":"DOSAGGIO GENTAMICINA VALLE (450032)","26":"HERPES VIRUS 2: RICERCA ANTICORPI IGM (450153)","27":"VIRUS PAROTITE ANTICORPI IGG E IGM PER SOSPETTA INFEZIONE ACUTA (450160)","28":"ACIDI BILIARI (1999)","29":"AB BORRELIA B. IGG (450109)","34":"LIPASI (1572)","35":"ANTIGENE URINARIO STRPTOCOCCUS PNEUMONIAE (2136)","37":"COLTURALE BRONCOLAVAGGIO BAL (1262)","39":"FT3 (1837)","41":"CRYPTOCOCCO ANTIGENE SU LIQUOR (450115)","42":"PLASMODI DELLA MALARIA: RIC. MICR. STRISCIO SOTTILE E GOCCIA SPESSA (450127)","47":"COLTURALE MICOLOGICO CUTE E ANNESSI UNGHIA (1619)","48":"COLTURALE MICOLOGICO CUTE E ANNESSI CUTE (1657)","49":"COLTURALE MICOLOGICO CUTE E ANNESSI CAPELLI (1658)","50":"FARMACI ANTIBIOTICI: VANCOMICINA (450034)","53":"GOT (1582)","54":"PTT (1402)","55":"VIRUS EPATITE B (HBSAG) ANT. AUSTRA (1119)","58":"LIQUIDO ASCITICO ESAME CHIMICO E FISICO (2335)","59":"LIQUOR ESAME CHIMICO FISICO (2338)","62":"URINOCOLTURA DA MITTO INTERMEDIO (2015)","69":"COLTURALE VALVOLA CARDIACA (2496)","70":"URICURIA (1301)","71":"LDH (LATTATODEIDROGENASI) (1569)","72":"ALCOOL ETILICO (ETANOLO) (2003)","73":"EMOCOLTURA (2000)","76":"COLTURALE SU TAMPONE CUTANEO (1274)","79":"COLTURALE BRONCOASPIRATO (1009)","84":"CONTEGGIO RETICOLOCITI (1511)","86":"IMMUNOGLOBULINE G (1539)","87":"PCR AD ALTA SENSIBILITA' (CRPH) (1556)","92":"AZOTEMIA (1200)","93":"CPK (1560)","94":"VIRUS IMMUNODEF. ACQUISITA [HIV 1-2] TEST COMB. ANTICORPI/ANTIGENE P24 (450158)","95":"VIRUS EPATITE B (HBSAG) ANTICORPI (1121)","98":"VIRUS MORBILLO IGG E IGM PER SOSPETTA INFEZIONE ACUTA (450159)","99":"DOSAGGIO GENTAMICINA PICCO (450033)","105":"POTASSIO NEL SIERO (1435)","106":"CLOSTRIDIOIDES DIFFICILE:RIC. DIRETTA DELLA TOSSINA NELLE FECI (450120)","109":"ESAME COLTURALE SU TAMPONE FARINGEO (12171)","110":"COLTURALE SU TAMPONE PIAGA DECUBITO (1270)","114":"COLTURALE BIOPSIA (1516)","116":"PARASSITI NEL SANGUE (450128)","117":"COLTURALE FERITA CHIRURGICA (1564)","120":"COLTURALE MAMMELLA SINISTRA (1603)","122":"URINOCOLTURA DA CATETERE A PERMANENZA (2035)","126":"FOSFATASI ALCALINA (1590)","127":"VIRUS EPATITE B (HBEAG) ANTIGENE (1116)","130":"COLTURALE FERITE SUPERFICIALI NON CHIRURGICHE (2494)","131":"COLTURALE FILI PACE-MAKER (2495)","133":"ALBUMINURIA (MICROALBUMINURIA) (1953)","141":"D-DIMERO (1405)","142":"VIRUS EPATITE DELTA [HDV]: RICERCA ANTICORPI (450149)","143":"ELETTROFORESI PROTEICA (2109)","147":"LEGIONELLE: RICERCA ANTIGENE NELLE URINE (450124)","149":"TEST DI COOMBS INDIRETTO (1171)","152":"FT4 (1839)","154":"EMOGLOBINE. DETERMINAZIONE FRAZIONI (HBA2, HBF, HB ANOMALE) (450104)","156":"COLTURALE PLACENTA (1575)","158":"COLTURALE MICOLOGICO CUTE E ANNESSI PELI (1654)","159":"PROCALCITONINA (1690)","160":"URINOCOLTURA DA CATETERISMO SINGOLO (2037)","161":"DOSAGGIO AMIKACINA VALLE (450031)","163":"AB BORRELIA B. IGM (450110)","164":"LIQUIDO SINOVIALE ESAME CHIMICO E FISICO (2337)","167":"GAMMA GT (1596)","168":"GLUCOSIO (1250)","169":"VIRUS EPATITE B [HBV] - REFLEX (450148)","170":"VIRUS EPATITE C (HCV) (1099)","171":"TROPONINA I (450106)","174":"HERPES VIRUS 2: RICERCA ANTICORPI IGG (450152)","175":"TIREOTROPINA RIFLESSA(TSH-R)TSH. INCL. EVENTUALE DOSAGGIO DI FT4 E FT3 (450064)","180":"ALBUMINA (2391)","181":"PT (1401)","183":"AMMONIEMIA (1343)","185":"FERRO (450043)","186":"APTOGLOBINA (1098)","187":"TITOLO ANTI-O-STREPTOLISINICO (1100)","195":"LIQUIDO PERICARDICO ESAME CHIIMICO FISICO E MICROSCOPICO (1884)","196":"TRANSFERRINA IND. SATURAZIONE (1351)","197":"COLTURALE PER YERSINIA NELLE FECI (1412)","198":"COLTURALE PER STREPTOCOCCUS AGALACTIAE (1414)","205":"IMMUNOGLOBULINE A (1538)","209":"COLTURALE MAMMELLA DESTRA (1589)","211":"URINOCOLTURA DA SACCHETTO (2036)","212":"TAMPONE ANTIGENICO SARS COV-2 (21225)","213":"BICARBONATI EMATICI (1499)","215":"CLORO NEL SIERO (1436)","216":"CREATININEMIA (1206)","217":"SODIO NEL SIERO (1434)","227":"PROTEINA S LIBERA (90724)","228":"GPT (1583)","229":"PROTEINE TOTALI (1346)","230":"BETA HCG PLASMATICO (1766)","231":"FOSFORO (SIERO) (1438)","232":"TRANSFERRINA TOTALE (1352)","233":"INSULINA (1139)","237":"TSH (1841)","239":"LIQUIDO PERITONEALE ESAME CHIMICO FISICO E MICROSCOPICO (1885)","240":"ALFA 1 GLICOPROTEINA (1348)","241":"QUANTIFERON ANTIGENI TB SPECIFICI (1357)","243":"LITIEMIA (1433)","250":"LIQUIDO DA VERSAMENTO ESAME CHIMICO FISICO (2217)","254":"LIQUIDO PLEURICO ESAME CHIMICO E FISICO (2336)","255":"TEMPO DI TROMBINA (2347)","256":"AMILASI PANCREATICA (1553)","257":"FARMACI: DIGOSSINA (450016)","258":"FIBRINOGENO (450102)","259":"VIRUS EPATITE A [HAV] ANTICORPI IGG E IGM PER SOSPETTA INFEZIONE ACUTA (450147)","260":"FARMACI ANTIEPILETTICI: CARBAMAZEPINA (450018)","261":"PROTEINA C ATTIVATA-RESISTENZA (2301)","263":"HERPES VIRUS 1: RICERCA ANTICORPI IGM (450151)","264":"HERPES VIRUS 1: RICERCA ANTICORPI IGG (450150)","265":"VIRUS VARICELLA ZOSTER ANTICORPI IGG E IGM PER SOSPETTA INF. ACUTA (450162)","267":"MAGNESIO NEL SIERO (1432)","268":"ALFA AMILASI NEL SIERO (1551)","270":"CALCIO TOTALE (1437)","271":"IG M (1540)","272":"ANTITROMBINA III (1530)","273":"VITAMINA B12 (1880)","274":"HBS AB DOSAGGIO QUANTITATIVO (1110)","275":"VELOCITA'ERITROSEDIMENTAZIONE (1095)","279":"COLTURALE MATERIALE VARIO (1212)","281":"COLTURALE SU MATERIALE DA TRACHEOSTOMA (1269)","282":"COLTURALE SU MATERIALE DA FISTOLA (1271)","293":"PROTEINA C REATTIVA (1102)","294":"MIOGLOBINA (1004)","295":"VIRUS EPATITE B (HBEAG) ANTICORPI (1120)","297":"NT PRO-BNP (2040)","299":"TREPONEMA PALLIDUM RICERCA ANTICORPI SCREENING (450137)","311":"PANNELLO 7 - ESAMI EMATICI DI CONTROLLO FANTOLI","312":"PANNELLO 8 - INFORTUNIO BIOLOGICO","316":"RICERCA DIRETTA ANTIGENI MALARIA (21295)"}},"00120001P":{"label":"RADIOLOGIA - RX - SSG (P)","items":{"21":"RX OSSA NASALI (A6952)","22":"ORTOPANORAMICA ARCATE DENTARIE (ORTOPANTOMOGRAFIA) (A699)","23":"SCHELETRO TORACICO COSTALE BIL (A6960)","24":"GINOCCHIO SX (A6936A)","25":"GINOCCHIO DX (A6936B)","26":"RX DIG.PARZ.STOMACO/DUODEN (6930)","27":"SENI PARANASALI (A6962)","28":"RX ADDOME SENZA CONTRASTO (A692)","29":"BACINO (A6917)","30":"RX COLONNA CERVICALE (6920)","31":"CRANIO (A6924)","32":"RX RACHIDE TORACO-DORSALE (A6929)","33":"RX RACHIDE LOMBO-SACRALE (A6941)","35":"RX TORACE (6979)","36":"RX TORACE 1 PROIEZIONE (6980)","37":"RX DELL'ANCA SX (A696A)","38":"RX DELL'ANCA DX (A696B)","39":"MANO SX (A6944A)","40":"GAMBA DX (A6936E)","41":"GAMBA SX (A6936F)","42":"FEMORE DX (A6936C)","43":"FEMORE SX (A6936D)","44":"GOMITO SX (A6937A)","45":"POLSO SX (A6955A)","46":"AVAMBRACCIO SX (A6915A)","47":"AVAMBRACCIO DX (A6915B)","48":"GOMITO DX (A6937B)","49":"MANO DX (A6944B)","50":"PIEDE DX (A6953B)","51":"POLSO DX (A6955B)","52":"PIEDE SX (A6953A)","53":"RX ORBITE (A6906)","54":"STERNO (A6985C)","118":"SPALLA DX (A6964C)","119":"SPALLA SX (A6964D)","120":"RADIOGRAFIA IN REPARTO (6903)","122":"TIBIO-TARSICA DX (A6953C)","123":"TIBIO-TARSICA SX (A6953D)","134":"RX CLAVICOLA DX (A6985D)","135":"RX CLAVICOLA SX (A6985E)"}},"00650002P":{"label":"LABORATORIO ANALISI POC - OSG (P)","items":{"3":"EMOGASANALISI VENOSA POC (POC2117)","30":"GLUCOSIO (POC1250)","31":"ACIDO LATTICO POC (POC1094)","63":"NA+ POC (POC1434)","64":"K+ POC (POC1435)","101":"D-DIMERO POC (POC1405)","102":"BICARBONATI EMATICI POC (POC1499)","134":"PTT POC (POC1402)","135":"FIBRINOGENO POC (POC1404)","138":"ACT POC (POCACT)","166":"EGA EMOGASANALISI ARTERIOSA (POC1006)","176":"CREATININEMIA (POC1206)","220":"PT (POC1401)","221":"CL- POC (POC1436)","223":"ACT LR POC (POCACTLR)","224":"CALCIO IONIZZATO (POC1982)","225":"TEST GRAVIDANZA URINE (POC1612)","266":"PCR POC (POC1102)","303":"BILIRUBINA (NEONATALE) (POC1341NEO)","305":"PANNELLO 1 – ANEMIA, EMORRAGIA, ISCHEMIA ARTO","306":"PANNELLO 3 - CARDIOPALMO","307":"PANNELLO 4 - TRAUMA","308":"PANNELLO 5 – DISPNEA, STROKE","309":"PANNELLO 6 – PDC, TORACALGIA","310":"PANNELLO 2 - BASE","318":"PANNELLO 9 - ESAMI POC","320":"EMOCROMOCITOMETRICO URGENTE (POCT1502)","323":"EMOGASANALISI CAPILLARE POC (POC2117)","324":"TROPONINA ULTRASENSIBILE (POC3001)","325":"EMOGASANALISI VENOSA&nbsp;POC - NEW (POC21171)","326":"EGA EMOGASANALISI ARTERIOSA POC - NEW (POC10061)","327":"BICARBONATI EMATICI POC - NEW (POC14991)","328":"GLUCOSIO POC - NEW (POC12501)","329":"ACIDO LATTICO POC - NEW (POC10941)","330":"SODIO NEL SIERO POC - NEW (POC14341)","331":"POTASSIO NEL SIERO - NEW (POC14351)","332":"CLORO NEL SIERO POC - NEW (POC14361)","333":"EMOGAS CAPILLARE POC (POC21172)"}},"00290002P":{"label":"LABORATORIO ANALISI - OSG (P)","items":{"1":"EMOCROMO (1501)","2":"URICEMIA (1300)","6":"COPROCOLTURA (1205)","7":"PF4 (1209)","9":"COLTURALE SU RACCOLTA SIERO EMATICA (1275)","10":"COLTURALE SU LIQUIDO DA CISTI (1282)","15":"PEPTIDE NATRIURETICO TIPO B BNP (450057)","16":"BILIRUBINA TOTALE REFLEX (450008)","17":"QUANTIFERON SINGOLO MITOGENO (1358)","18":"PREALBUMINA (1397)","22":"DOSAGGIO AMIKACINA PICCO (450030)","23":"PSEUDOCOLINESTERASI (450007)","24":"FERRITINA (450042)","25":"DOSAGGIO GENTAMICINA VALLE (450032)","26":"HERPES VIRUS 2: RICERCA ANTICORPI IGM (450153)","27":"VIRUS PAROTITE ANTICORPI IGG E IGM PER SOSPETTA INFEZIONE ACUTA (450160)","28":"ACIDI BILIARI (1999)","29":"AB BORRELIA B. IGG (450109)","34":"LIPASI (1572)","35":"ANTIGENE URINARIO STRPTOCOCCUS PNEUMONIAE (2136)","37":"COLTURALE BRONCOLAVAGGIO BAL (1262)","39":"FT3 (1837)","41":"CRYPTOCOCCO ANTIGENE SU LIQUOR (450115)","42":"PLASMODI DELLA MALARIA: RIC. MICR. STRISCIO SOTTILE E GOCCIA SPESSA (450127)","47":"COLTURALE MICOLOGICO CUTE E ANNESSI UNGHIA (1619)","48":"COLTURALE MICOLOGICO CUTE E ANNESSI CUTE (1657)","49":"COLTURALE MICOLOGICO CUTE E ANNESSI CAPELLI (1658)","50":"FARMACI ANTIBIOTICI: VANCOMICINA (450034)","53":"GOT (1582)","54":"PTT (1402)","55":"VIRUS EPATITE B (HBSAG) ANT. AUSTRA (1119)","58":"LIQUIDO ASCITICO ESAME CHIMICO E FISICO (2335)","59":"LIQUOR ESAME CHIMICO FISICO (2338)","62":"URINOCOLTURA DA MITTO INTERMEDIO (2015)","69":"COLTURALE VALVOLA CARDIACA (2496)","70":"URICURIA (1301)","71":"LDH (LATTATODEIDROGENASI) (1569)","72":"ALCOOL ETILICO (ETANOLO) (2003)","73":"EMOCOLTURA (2000)","76":"COLTURALE SU TAMPONE CUTANEO (1274)","79":"COLTURALE BRONCOASPIRATO (1009)","84":"CONTEGGIO RETICOLOCITI (1511)","86":"IMMUNOGLOBULINE G (1539)","87":"PCR AD ALTA SENSIBILITA' (CRPH) (1556)","92":"AZOTEMIA (1200)","93":"CPK (1560)","94":"VIRUS IMMUNODEF. ACQUISITA [HIV 1-2] TEST COMB. ANTICORPI/ANTIGENE P24 (450158)","95":"VIRUS EPATITE B (HBSAG) ANTICORPI (1121)","98":"VIRUS MORBILLO IGG E IGM PER SOSPETTA INFEZIONE ACUTA (450159)","99":"DOSAGGIO GENTAMICINA PICCO (450033)","105":"POTASSIO NEL SIERO (1435)","106":"CLOSTRIDIOIDES DIFFICILE:RIC. DIRETTA DELLA TOSSINA NELLE FECI (450120)","109":"ESAME COLTURALE SU TAMPONE FARINGEO (12171)","110":"COLTURALE SU TAMPONE PIAGA DECUBITO (1270)","114":"COLTURALE BIOPSIA (1516)","116":"PARASSITI NEL SANGUE (450128)","117":"COLTURALE FERITA CHIRURGICA (1564)","120":"COLTURALE MAMMELLA SINISTRA (1603)","122":"URINOCOLTURA DA CATETERE A PERMANENZA (2035)","126":"FOSFATASI ALCALINA (1590)","127":"VIRUS EPATITE B (HBEAG) ANTIGENE (1116)","130":"COLTURALE FERITE SUPERFICIALI NON CHIRURGICHE (2494)","131":"COLTURALE FILI PACE-MAKER (2495)","133":"ALBUMINURIA (MICROALBUMINURIA) (1953)","141":"D-DIMERO (1405)","142":"VIRUS EPATITE DELTA [HDV]: RICERCA ANTICORPI (450149)","143":"ELETTROFORESI PROTEICA (2109)","147":"LEGIONELLE: RICERCA ANTIGENE NELLE URINE (450124)","149":"TEST DI COOMBS INDIRETTO (1171)","152":"FT4 (1839)","154":"EMOGLOBINE. DETERMINAZIONE FRAZIONI (HBA2, HBF, HB ANOMALE) (450104)","156":"COLTURALE PLACENTA (1575)","158":"COLTURALE MICOLOGICO CUTE E ANNESSI PELI (1654)","159":"PROCALCITONINA (1690)","160":"URINOCOLTURA DA CATETERISMO SINGOLO (2037)","161":"DOSAGGIO AMIKACINA VALLE (450031)","163":"AB BORRELIA B. IGM (450110)","164":"LIQUIDO SINOVIALE ESAME CHIMICO E FISICO (2337)","167":"GAMMA GT (1596)","168":"GLUCOSIO (1250)","169":"VIRUS EPATITE B [HBV] - REFLEX (450148)","170":"VIRUS EPATITE C (HCV) (1099)","171":"TROPONINA I (450106)","174":"HERPES VIRUS 2: RICERCA ANTICORPI IGG (450152)","175":"TIREOTROPINA RIFLESSA(TSH-R)TSH. INCL. EVENTUALE DOSAGGIO DI FT4 E FT3 (450064)","180":"ALBUMINA (2391)","181":"PT (1401)","183":"AMMONIEMIA (1343)","185":"FERRO (450043)","186":"APTOGLOBINA (1098)","187":"TITOLO ANTI-O-STREPTOLISINICO (1100)","195":"LIQUIDO PERICARDICO ESAME CHIIMICO FISICO E MICROSCOPICO (1884)","196":"TRANSFERRINA IND. SATURAZIONE (1351)","197":"COLTURALE PER YERSINIA NELLE FECI (1412)","198":"COLTURALE PER STREPTOCOCCUS AGALACTIAE (1414)","205":"IMMUNOGLOBULINE A (1538)","209":"COLTURALE MAMMELLA DESTRA (1589)","211":"URINOCOLTURA DA SACCHETTO (2036)","212":"TAMPONE ANTIGENICO SARS COV-2 (21225)","213":"BICARBONATI EMATICI (1499)","215":"CLORO NEL SIERO (1436)","216":"CREATININEMIA (1206)","217":"SODIO NEL SIERO (1434)","227":"PROTEINA S LIBERA (90724)","228":"GPT (1583)","229":"PROTEINE TOTALI (1346)","230":"BETA HCG PLASMATICO (1766)","231":"FOSFORO (SIERO) (1438)","232":"TRANSFERRINA TOTALE (1352)","233":"INSULINA (1139)","237":"TSH (1841)","239":"LIQUIDO PERITONEALE ESAME CHIMICO FISICO E MICROSCOPICO (1885)","240":"ALFA 1 GLICOPROTEINA (1348)","241":"QUANTIFERON ANTIGENI TB SPECIFICI (1357)","243":"LITIEMIA (1433)","250":"LIQUIDO DA VERSAMENTO ESAME CHIMICO FISICO (2217)","254":"LIQUIDO PLEURICO ESAME CHIMICO E FISICO (2336)","255":"TEMPO DI TROMBINA (2347)","256":"AMILASI PANCREATICA (1553)","257":"FARMACI: DIGOSSINA (450016)","258":"FIBRINOGENO (450102)","259":"VIRUS EPATITE A [HAV] ANTICORPI IGG E IGM PER SOSPETTA INFEZIONE ACUTA (450147)","260":"FARMACI ANTIEPILETTICI: CARBAMAZEPINA (450018)","261":"PROTEINA C ATTIVATA-RESISTENZA (2301)","263":"HERPES VIRUS 1: RICERCA ANTICORPI IGM (450151)","264":"HERPES VIRUS 1: RICERCA ANTICORPI IGG (450150)","265":"VIRUS VARICELLA ZOSTER ANTICORPI IGG E IGM PER SOSPETTA INF. ACUTA (450162)","267":"MAGNESIO NEL SIERO (1432)","268":"ALFA AMILASI NEL SIERO (1551)","270":"CALCIO TOTALE (1437)","271":"IG M (1540)","272":"ANTITROMBINA III (1530)","273":"VITAMINA B12 (1880)","274":"HBS AB DOSAGGIO QUANTITATIVO (1110)","275":"VELOCITA'ERITROSEDIMENTAZIONE (1095)","279":"COLTURALE MATERIALE VARIO (1212)","281":"COLTURALE SU MATERIALE DA TRACHEOSTOMA (1269)","282":"COLTURALE SU MATERIALE DA FISTOLA (1271)","293":"PROTEINA C REATTIVA (1102)","294":"MIOGLOBINA (1004)","295":"VIRUS EPATITE B (HBEAG) ANTICORPI (1120)","297":"NT PRO-BNP (2040)","299":"TREPONEMA PALLIDUM RICERCA ANTICORPI SCREENING (450137)","311":"PANNELLO 7 – ESAMI EMATICI DI CONTROLLO FANTOLI","312":"PANNELLO 8 - INFORTUNIO BIOLOGICO","316":"RICERCA DIRETTA ANTIGENI MALARIA (21295)"}}};
  // Discharge instructions, reviewed before shipping and freely editable by
  // the doctor: what is kept here is a TEMPLATE, never a patient's text.
  const DIMISSIONI = {"gastrite":{"nome":"Gastrite acuta","rivisto":true,"testo":"GASTRITE ACUTA — INDICAZIONI ALLA DIMISSIONE\n\nFARMACI\n- Pantoprazolo 40 mg, 1 compressa al mattino a digiuno (30 minuti prima di colazione), per 4 settimane.\n- Antiacido/alginato al bisogno dopo i pasti e alla sera.\n- Sospendere i FANS. Per il dolore utilizzare paracetamolo 1 g fino a 3 volte al giorno.\n\nCOSA FARE A CASA\n- Sospendere alcol e fumo.\n- Pasti piccoli e frequenti; evitare cibi piccanti, grassi, caffè, cioccolato, bevande gassate.\n- Non coricarsi nelle 3 ore dopo il pasto.\n- Prediligere carboidrati come fette biscottate, pasta, patate, riso, e carni bianche come pollo e tacchino.\n\nFOLLOW-UP\n- Rivalutazione dal Medico Curante entro 7–10 giorni.\n- Valutare EGDS in caso di persistenza dei sintomi oltre 4 settimane di terapia, o in presenza di segni d'allarme.\n\nRITORNARE IN PRONTO SOCCORSO O CHIAMARE IL 112 SE\n- Vomito con sangue o a «fondo di caffè».\n- Feci nere, catramose o con sangue.\n- Dolore addominale intenso o improvviso.\n- Vomito persistente con impossibilità a bere.\n- Febbre.\n- Svenimento, vertigini, sudorazione fredda o palpitazioni.\n- Dolore che si irradia al dorso o al torace.\n\nQueste indicazioni si riferiscono alla valutazione di oggi e non sostituiscono il medico curante. Se compaiono sintomi nuovi o il disturbo peggiora torni in Pronto Soccorso anche prima dei tempi indicati; chiami il 112 se il sintomo è grave o improvviso e non si metta alla guida. Porti con sé questo foglio, la documentazione consegnata e l'elenco dei farmaci che assume, allergie comprese. Attenzione ai preparati per l'influenza: contengono già paracetamolo."},"gastroenterite":{"nome":"Gastroenterite / diarrea acuta","rivisto":true,"testo":"GASTROENTERITE ACUTA — INDICAZIONI ALLA DIMISSIONE\n\nBERE\n- Almeno 2 litri al giorno a piccoli sorsi, più un bicchiere in più dopo ogni scarica.\n- Evitare bevande molto zuccherate, alcolici, caffè.\n\nMANGIARE\n- Appena tollerato, in bianco, con pasti piccoli e frequenti.\n- Nei primi giorni evitare latte e latticini, fritti e cibi grassi, frutta e verdura (in particolare cruda).\n- Prediligere carboidrati semplici come fette biscottate, pasta, patate, riso, e carni bianche come pollo e tacchino.\n- Utili i fermenti lattici.\n\nIGIENE\n- Lavarsi le mani con acqua e sapone dopo ogni evacuazione.\n- Non preparare cibo per altri fino a 48 ore dopo l'ultima scarica.\n\nFARMACI\n- Sospendere metformina, farmaci per la pressione, diuretici o gliflozine.\n- Se dolore o febbre: paracetamolo 1 g ogni 8 ore (massimo 3 g al giorno).\n- NON prendere antinfiammatori (ibuprofene, ketoprofene, diclofenac, aspirina) finché vomito e diarrea non sono passati.\n- Se la diarrea è un problema pratico: loperamide 2 mg (Imodium, Dissenten) 2 compresse subito, poi 1 compressa dopo ogni scarica liquida; massimo 8 compresse al giorno, per non più di due giorni consecutivi. NON assumerla se ha febbre o sangue nelle feci.\n\nTORNI IN PRONTO SOCCORSO SE\n- Sangue nelle feci o feci nere.\n- Vomito continuo che impedisce di bere.\n- Febbre oltre 39 °C che non risponde al paracetamolo o che dura più di 3 giorni.\n- Dolore addominale forte e localizzato, in peggioramento.\n\nCONTROLLO\n- Medico curante se non migliora in 3–4 giorni.\n\nQueste indicazioni si riferiscono alla valutazione di oggi e non sostituiscono il medico curante. Se compaiono sintomi nuovi o il disturbo peggiora torni in Pronto Soccorso anche prima dei tempi indicati; chiami il 112 se il sintomo è grave o improvviso e non si metta alla guida. Porti con sé questo foglio, la documentazione consegnata e l'elenco dei farmaci che assume, allergie comprese. Attenzione ai preparati per l'influenza: contengono già paracetamolo."},"colica-renale":{"nome":"Colica renale","rivisto":true,"testo":"COLICA RENALE — INDICAZIONI ALLA DIMISSIONE\n\nFARMACI\n- Metoclopramide 10 mg, 1 compressa fino a 3 volte al giorno.\n- Tamsulosina 0,4 mg dopo cena: si alzi lentamente e non la associ a farmaci per l'erezione.\n- Cefixoral 400 mg, 1 compressa al giorno per 5 giorni.\n\nSE DOLORE\n- Ketoprofene sale di lisina 80 mg (1 bustina) fino a 3 volte al giorno, a stomaco pieno (in alternativa ibuprofene 600 mg fino a 3 volte al giorno).\n- Se il dolore non è controllato, insieme al ketoprofene: Tachidol 500/30 mg, 1 bustina al bisogno, massimo 3 volte al giorno.\n- In alternativa, sospendere quanto sopra e assumere Lenizak 75/25, 1 bustina fino a 3 volte al giorno.\n\nCOSA FARE A CASA\n- Bere normalmente, 1,5–2 litri al giorno: non deve forzarsi a bere di più, ma nemmeno bere di meno.\n- Filtrare l'urina (con un filtro da caffè americano) se possibile e conservare il calcolo espulso per l'analisi.\n- Il calcolo può essere espulso in giorni o settimane: un nuovo episodio di dolore è possibile.\n\nTORNI SUBITO IN PRONTO SOCCORSO SE\n- Febbre o brividi: possono indicare un rene ostruito e infetto. Chiami il 112.\n- Dolore che non passa con la terapia.\n- Vomito che impedisce di assumere i farmaci.\n- Urina assente o molto ridotta.\n\nCONTROLLI\n- Ecografia addome completo entro 5 giorni.\n- Visita urologica in 7–14 giorni, con esami e documentazione del Pronto Soccorso.\n- Se il calcolo non viene espulso entro 4 settimane serve comunque una rivalutazione.\n\nQueste indicazioni si riferiscono alla valutazione di oggi e non sostituiscono il medico curante. Se compaiono sintomi nuovi o il disturbo peggiora torni in Pronto Soccorso anche prima dei tempi indicati; chiami il 112 se il sintomo è grave o improvviso e non si metta alla guida. Porti con sé questo foglio, la documentazione consegnata e l'elenco dei farmaci che assume, allergie comprese. Attenzione ai preparati per l'influenza: contengono già paracetamolo."},"cistite":{"nome":"Cistite non complicata","rivisto":true,"testo":"CISTITE NON COMPLICATA — INDICAZIONI ALLA DIMISSIONE\n(indicazioni per la donna non in gravidanza; nell'uomo la cistite va sempre rivalutata dal medico)\n\nANTIBIOTICO\n- Se nitriti presenti: fosfomicina 3 g, una sola bustina sciolta in un bicchiere d'acqua, la sera prima di coricarsi dopo aver urinato, lontano dai pasti. Una dose sola è tutta la cura.\n- Cefixoral 400 mg, 1 compressa al giorno per 5 giorni.\n\nSINTOMI\n- Paracetamolo 1 g ogni 8 ore (massimo 3 g al giorno) oppure ibuprofene 400 mg fino a 3 volte al giorno per bruciore e dolore.\n- Bere 1,5–2 litri al giorno e urinare spesso, senza trattenere.\n\nSE È O POTREBBE ESSERE IN GRAVIDANZA\n- Lo dica subito: non prenda ibuprofene, servono un esame delle urine con antibiogramma e un controllo dopo la terapia. Usi solo paracetamolo e non assuma antibiotici di sua iniziativa.\n\nPER EVITARE CHE TORNI\n- Urinare dopo i rapporti sessuali.\n- Evitare lavande vaginali e detergenti aggressivi.\n\nTORNI IN PRONTO SOCCORSO SE\n- Febbre oltre 38 °C, brividi, dolore al fianco o alla schiena: possibile infezione del rene.\n- Vomito che impedisce di assumere l'antibiotico.\n\nCONTROLLO\nDal medico di base se:\n- I sintomi non migliorano dopo 48–72 ore di terapia.\n- Sangue nelle urine che persiste a terapia finita.\n- Se i sintomi scompaiono non serve un esame delle urine di controllo.\n- Se i sintomi non passano o tornano entro 2 settimane, serve un esame delle urine con antibiogramma prima di riprendere l'antibiotico.\n- Se gli episodi si ripetono (3 o più in un anno).\n\nQueste indicazioni si riferiscono alla valutazione di oggi e non sostituiscono il medico curante. Se compaiono sintomi nuovi o il disturbo peggiora torni in Pronto Soccorso anche prima dei tempi indicati; chiami il 112 se il sintomo è grave o improvviso e non si metta alla guida. Porti con sé questo foglio, la documentazione consegnata e l'elenco dei farmaci che assume, allergie comprese. Attenzione ai preparati per l'influenza: contengono già paracetamolo."},"trauma-cranico-minore":{"nome":"Trauma cranico minore","rivisto":true,"testo":"TRAUMA CRANICO MINORE — INDICAZIONI ALLA DIMISSIONE\n\nSE ASSUME ANTICOAGULANTI O CARDIOASPIRINA\n- Non resti solo nelle prossime 24 ore e torni in Pronto Soccorso per qualsiasi sintomo nuovo, anche solo mal di testa.\n- Non sospenda di sua iniziativa l'anticoagulante o la cardioaspirina.\n- Il sanguinamento può comparire anche dopo 3–7 giorni.\n\nLE PROSSIME 24–48 ORE\n- Non resti solo: una persona adulta deve poterla assistere.\n- Può dormire normalmente. Chi assiste deve solo verificare che respiri regolarmente e che si svegli facilmente chiamandolo; se non si sveglia facilmente, chiami subito il 112.\n- Riposo nelle prime 24–48 ore, poi ripresa graduale.\n- Niente alcol, niente sonniferi o sedativi.\n- Non guidare, non usare macchinari, non fare sport finché i sintomi non sono scomparsi. Ritorno allo sport per gradi.\n\nFARMACI\n- Per il mal di testa usi solo paracetamolo 1 g ogni 8 ore (massimo 3 g al giorno).\n- Non prenda antinfiammatori (ibuprofene, ketoprofene, aspirina come antidolorifico) per una settimana.\n\nCHIAMI IL 112 SE COMPARE ANCHE UNO SOLO DI QUESTI (non si metta alla guida)\n- Mal di testa che peggiora e non passa con il paracetamolo.\n- Vomito ripetuto.\n- Sonnolenza insolita o difficoltà a svegliarsi.\n- Confusione, difficoltà a parlare, vista doppia, pupille di dimensione diversa, debolezza o formicolio a un braccio o a una gamba, perdita di equilibrio.\n- Convulsioni.\n- Sangue o liquido chiaro dal naso o dalle orecchie.\n\nNELLE SETTIMANE SUCCESSIVE\n- Sopra i 65 anni o in terapia anticoagulante i sintomi possono comparire anche dopo 2–6 settimane: mal di testa persistente, sonnolenza, cambiamento di carattere o difficoltà a camminare vanno rivalutati dal medico.\n\nCONTROLLO\n- Medico curante se mal di testa, stanchezza, difficoltà di concentrazione o irritabilità durano oltre una settimana.\n\nQueste indicazioni si riferiscono alla valutazione di oggi e non sostituiscono il medico curante. Se compaiono sintomi nuovi o il disturbo peggiora torni in Pronto Soccorso anche prima dei tempi indicati; chiami il 112 se il sintomo è grave o improvviso e non si metta alla guida. Porti con sé questo foglio, la documentazione consegnata e l'elenco dei farmaci che assume, allergie comprese. Attenzione ai preparati per l'influenza: contengono già paracetamolo."},"artrosi":{"nome":"Artrosi (fase dolorosa)","testo":"ARTROSI IN FASE DOLOROSA — INDICAZIONI ALLA DIMISSIONE\n\nLA CURA PRINCIPALE È IL MOVIMENTO\n- Camminare in piano ogni giorno, secondo tolleranza: il riposo assoluto peggiora l'artrosi.\n- Esercizi quotidiani di rinforzo della coscia (li insegna il fisioterapista o il medico curante).\n- Evitare solo ciò che provoca dolore forte.\n- Perdere peso quando indicato: ogni chilo in meno scarica il ginocchio in modo significativo.\n- Bastone dal lato opposto all'articolazione dolente, se serve.\n- Ghiaccio 15–20 minuti 2–3 volte al giorno in fase acuta; calore se prevale la rigidità.\n\nFARMACI\n- Gel antinfiammatorio localmente 2–3 volte al giorno: è la prima scelta, più sicuro degli antinfiammatori per bocca. Non esporre al sole la zona trattata durante la cura e nelle 2 settimane successive.\n- Paracetamolo 1 g ogni 8 ore (massimo 3 g al giorno; massimo 2 g sopra i 75 anni, sotto i 50 kg, con problemi di fegato o se beve alcolici).\n- Se non basta: ibuprofene 400–600 mg fino a 3 volte al giorno a stomaco pieno, per pochi giorni, con un farmaco che protegge lo stomaco.\n\nQUANDO NON PRENDERE ANTINFIAMMATORI PER BOCCA\n- Se prende anticoagulanti (warfarin, apixaban, rivaroxaban, edoxaban, dabigatran) o due antiaggreganti: in questi casi NON vanno presi in nessun caso, nemmeno con il gastroprotettore. Usi paracetamolo e gel locale.\n- Problemi di reni, scompenso cardiaco, pressione alta non controllata, ulcera.\n\nTORNI IN PRONTO SOCCORSO SE\n- Articolazione calda, molto gonfia e arrossata, con febbre: possibile infezione.\n- Articolazione che si gonfia improvvisamente senza trauma.\n- Impossibilità totale di caricare il peso, o deformità dopo una caduta.\n- Feci nere o vomito con sangue: sospenda l'antinfiammatorio e venga subito.\n\nCONTROLLO\n- Medico curante entro 1–2 settimane per la terapia di fondo e la fisioterapia.\n- Valutazione ortopedica se il dolore limita la vita quotidiana nonostante la terapia.\n\nQueste indicazioni si riferiscono alla valutazione di oggi e non sostituiscono il medico curante. Se compaiono sintomi nuovi o il disturbo peggiora torni in Pronto Soccorso anche prima dei tempi indicati; chiami il 112 se il sintomo è grave o improvviso e non si metta alla guida. Porti con sé questo foglio, la documentazione consegnata e l'elenco dei farmaci che assume, allergie comprese. Attenzione ai preparati per l'influenza: contengono già paracetamolo."},"lombalgia":{"nome":"Lombalgia acuta","testo":"MAL DI SCHIENA ACUTO — INDICAZIONI ALLA DIMISSIONE\n\nCOSA SAPERE\n- Nella grande maggioranza dei casi non c'è una lesione grave e il dolore migliora in 2–6 settimane.\n- Le radiografie non servono nel mal di schiena semplice: non cambiano la cura.\n\nCOSA FARE\n- Restare attivi: continuare le normali attività riducendo ciò che fa male. Il riposo a letto oltre 1–2 giorni PEGGIORA il dolore.\n- Camminare ogni giorno e alzarsi spesso se si sta seduti a lungo.\n- Calore locale 20 minuti più volte al giorno.\n\nFARMACI\n- Ibuprofene 400–600 mg fino a 3 volte al giorno a stomaco pieno per 5–7 giorni, oppure ketoprofene sale di lisina 80 mg 2 volte al giorno.\n- Paracetamolo 1 g ogni 8 ore, associabile (massimo 3 g al giorno; 2 g sopra i 75 anni, sotto i 50 kg, con problemi di fegato o se beve alcolici).\n- Farmaco che protegge lo stomaco se prende antinfiammatori per più giorni, ha più di 65 anni, ha avuto ulcera o gastrite, o prende cortisone o cardioaspirina.\n- Se le è stato prescritto un farmaco che rilassa i muscoli (tiocolchicoside 4 mg 2 volte al giorno): non più di 7 giorni, mai in gravidanza, allattamento o in età fertile senza contraccezione sicura. Dà sonnolenza: non guidi, non usi macchinari, non beva alcolici.\n\nTORNI IN PRONTO SOCCORSO SE\n- Difficoltà a urinare, o perdita di urina o feci.\n- Perdita di sensibilità nella zona genitale o all'interno delle cosce.\n- Debolezza di una gamba che peggiora.\n- Febbre insieme al mal di schiena.\n- Dolore che non si calma nemmeno da sdraiati o che sveglia di notte.\n\nCONTATTI PRESTO IL MEDICO SE\n- Ha avuto un tumore, prende cortisone, ha osteoporosi, ha perso peso senza motivo, oppure ha più di 65 anni e il dolore è comparso dopo una caduta.\n\nCONTROLLO\n- Medico curante se il dolore non migliora in 7–10 giorni o si accompagna a dolore lungo la gamba.\n\nQueste indicazioni si riferiscono alla valutazione di oggi e non sostituiscono il medico curante. Se compaiono sintomi nuovi o il disturbo peggiora torni in Pronto Soccorso anche prima dei tempi indicati; chiami il 112 se il sintomo è grave o improvviso e non si metta alla guida. Porti con sé questo foglio, la documentazione consegnata e l'elenco dei farmaci che assume, allergie comprese. Attenzione ai preparati per l'influenza: contengono già paracetamolo."},"distorsione-caviglia":{"nome":"Distorsione di caviglia","testo":"DISTORSIONE DI CAVIGLIA — INDICAZIONI ALLA DIMISSIONE\n\nPRIME 48–72 ORE\n- Ghiaccio 15–20 minuti ogni 2–3 ore, mai a contatto diretto con la pelle.\n- Bendaggio elastico durante il giorno, da togliere la notte.\n- Gamba sollevata sopra il livello del cuore da seduti o sdraiati.\n- Appoggiare il piede quanto il dolore permette, aiutandosi con le stampelle all'inizio.\n\nFARMACI\n- Paracetamolo 1 g ogni 8 ore (massimo 3 g al giorno; 2 g sopra i 75 anni, sotto i 50 kg, con problemi di fegato o se beve alcolici).\n- Ibuprofene 400–600 mg fino a 3 volte al giorno a stomaco pieno per 3–5 giorni; gel antinfiammatorio localmente 2–3 volte al giorno.\n- Non prenda antinfiammatori in gravidanza, con anticoagulanti, ulcera o problemi di reni.\n\nDOPO I PRIMI GIORNI\n- Riprendere gradualmente il movimento: la caviglia rigida guarisce peggio.\n- Esercizi: muovere il piede su e giù, disegnare l'alfabeto con l'alluce, più volte al giorno; poi equilibrio su un piede solo.\n- Tornare allo sport quando si cammina e si corre senza dolore né gonfiore, di solito in 2–6 settimane; cavigliera negli sport per i 6 mesi successivi riduce le recidive.\n\nTORNI IN PRONTO SOCCORSO SE\n- Polpaccio dolente, gonfio e caldo, oppure affanno improvviso o dolore al torace.\n- Dolore sopra la caviglia lungo la gamba, vicino al ginocchio sul lato esterno, o sul bordo esterno del piede: possono essere fratture non visibili all'inizio.\n- Impossibilità di appoggiare il piede dopo 3–4 giorni.\n- Deformità evidente, formicolii persistenti, piede freddo o pallido.\n- Dolore o gonfiore che peggiorano dopo il terzo giorno.\n\nCONTROLLO\n- Medico curante o visita ortopedica se dopo 7–10 giorni persistono dolore o instabilità.\n- Se le è stato messo un tutore o un gesso, chieda al medico curante se le serve una puntura anticoagulante.\n\nQueste indicazioni si riferiscono alla valutazione di oggi e non sostituiscono il medico curante. Se compaiono sintomi nuovi o il disturbo peggiora torni in Pronto Soccorso anche prima dei tempi indicati; chiami il 112 se il sintomo è grave o improvviso e non si metta alla guida. Porti con sé questo foglio, la documentazione consegnata e l'elenco dei farmaci che assume, allergie comprese. Attenzione ai preparati per l'influenza: contengono già paracetamolo."},"faringotonsillite":{"nome":"Faringite / mal di gola","testo":"MAL DI GOLA — INDICAZIONI ALLA DIMISSIONE\n\nCOSA SAPERE\n- La maggior parte dei mal di gola è virale e guarisce da sola in 5–7 giorni: l'antibiotico non serve e non accorcia i tempi.\n- L'antibiotico serve solo nelle forme da streptococco, quando lo indica il medico: in quel caso va completato tutto il ciclo.\n\nFARMACI\n- Paracetamolo 1 g ogni 8 ore (massimo 3 g al giorno; 2 g sopra i 75 anni, sotto i 50 kg, con problemi di fegato o se beve alcolici), oppure ibuprofene 400–600 mg fino a 3 volte al giorno a stomaco pieno.\n- Non prenda insieme bustine o compresse per l'influenza e il raffreddore: contengono già paracetamolo.\n- Bevande fresche o tiepide, ghiaccioli, miele (non sotto l'anno di età).\n\nCOSA FARE\n- Riposo relativo, bere spesso, non fumare.\n- Rientro al lavoro o a scuola dopo almeno 24 ore di antibiotico E almeno 24 ore senza febbre.\n\nTORNI IN PRONTO SOCCORSO SE\n- Difficoltà a respirare, voce ovattata come se avesse qualcosa in bocca, saliva che cola perché non riesce a deglutire.\n- Impossibilità a deglutire anche i liquidi.\n- Difficoltà ad aprire la bocca, gonfiore del collo, dolore forte da un lato solo.\n- Macchie rosse o violacee che NON scompaiono premendoci sopra un bicchiere trasparente.\n- Febbre che dura oltre 5 giorni o che ricompare dopo il miglioramento.\n- Gonfiore del viso, orticaria o affanno dopo l'antibiotico: lo sospenda e chiami il 112.\n\nATTENZIONE PARTICOLARE\n- Se assume metimazolo (per la tiroide), clozapina, immunosoppressori o chemioterapia, un mal di gola con febbre richiede un emocromo urgente: lo dica subito al medico.\n\nCONTROLLO\n- Medico curante se non migliora in 5 giorni.\n\nQueste indicazioni si riferiscono alla valutazione di oggi e non sostituiscono il medico curante. Se compaiono sintomi nuovi o il disturbo peggiora torni in Pronto Soccorso anche prima dei tempi indicati; chiami il 112 se il sintomo è grave o improvviso e non si metta alla guida. Porti con sé questo foglio, la documentazione consegnata e l'elenco dei farmaci che assume, allergie comprese."}};
  // Esame obiettivo: modelli PER IL MEDICO, da incollare nella cartella.
  // Non escono mai dal computer e non contengono dati di nessun paziente.
  const EO = {"base":{"nome":"EO generale","meta":"completo, tutto negativo","testo":"Vigile, orientato, eupnoico, normocolorito, ben perfuso, apiretico. Non segni di distress.\nTorace: MV normotrasmesso bilateralmente, non rumori patologici aggiunti. Cuore: toni ritmici, validi, non soffi. Polsi periferici presenti e simmetrici.\nAddome: piano, trattabile, non dolente né dolorabile, peristalsi presente, Blumberg e Murphy negativi, Giordano negativo bilateralmente. Non masse, non organomegalie.\nArti inferiori: non edemi, non segni di TVP, polpacci indolori.\nNeuro: non deficit focali, forza e sensibilità conservate ai 4 arti, non segni meningei. Cute: integra, non lesioni, non esantemi."},"basi":[{"k":"solito","nome":"Mio solito base","meta":"breve","testo":"Vigile, lucido, orientato, collaborante. Eupnoico in AA. Cute normocromica, non sudata.\nToni cardiaci ritmici, pause libere.\nTorace MV normotrasmesso, no rpa."}],"casi":[{"k":"toracico","nome":"Dolore toracico","testo":"Dolore non riproducibile alla palpazione della parete / riproducibile. Toni validi, non sfregamenti. Polsi radiali e femorali simmetrici, PA comparativa agli arti superiori [dx/sx]. Non turgore giugulare. Non edemi. Polpacci indolori simmetrici."},{"k":"dispnea","nome":"Dispnea","testo":"Utilizzo dei muscoli accessori sì/no, parla per frasi intere. MV ridotto alle basi con crepitii bibasali fino a [livello] / sibili diffusi espiratori. Non ottusità plessica. Turgore giugulare. Edemi declivi improntabili fino a [livello]. Polpacci simmetrici."},{"k":"addominale","nome":"Dolore addominale","testo":"Blumberg, Rovsing, Murphy, Giordano, psoas. Non difesa, non peritonismo. Non masse pulsanti (AAA). Orifizi erniari liberi. Peristalsi presente/torpida."},{"k":"cefalea","nome":"Cefalea","testo":"Non segni meningei (Kernig, Brudzinski negativi). Pupille isocoriche isocicliche normoreagenti. Nervi cranici indenni. Non deficit focali, non atassia, Romberg negativo. arterie temporali non dolenti (>50 anni)."},{"k":"trauma","nome":"Trauma / caduta","testo":"Non ferite lacerocontuse. Rachide cervicale non dolente alla palpazione della linea mediana, ROM conservato (criteri NEXUS soddisfatti). Bacino stabile. Non dolorabilità sternale né costale. Arti: assi conservati, non deformità, articolarità e polsi distali conservati, sensibilità integra. Sempre: polso distale + sensibilità + motilità distalmente alla lesione."},{"k":"sincope","nome":"Sincope","testo":"PA in clino e ortostatismo [valori], toni validi non soffi, polsi simmetrici, non deficit neurologici, esplorazione rettale negativa per melena se indicata."},{"k":"lombalgia","nome":"Lombalgia","testo":"Lasègue negativo bilateralmente, forza 5/5 ai distretti L2-S1, ROT rotulei e achillei normoevocabili simmetrici, sensibilità conservata, non anestesia a sella, tono sfinteriale conservato, non globo vescicale (cauda equina)"},{"k":"vertigine","nome":"Vertigine","testo":"Nistagmo [assente/orizzontale con fase rapida verso...], HINTS: head impulse [ ], nistagmo direzione fissa/mutevole, skew deviation assente. Marcia e Romberg [ ]. Non dismetria, non deficit focali."},{"k":"pediatrico","nome":"Pediatrico","testo":"Bambino vivace, reattivo, consolabile, colorito valido, refill capillare <2s, non segni di disidratazione (mucose umide, lacrimazione presente, diuresi riferita normale). Non esantemi, non petecchie. Fontanella normotesa. Non segni meningei."}],"frasi":[{"k":"rettale","nome":"Rettale non eseguita","testo":"Esplorazione rettale non eseguita per rifiuto del paziente"},{"k":"collaborazione","nome":"Neuro poco collaborante","testo":"esame neurologico limitato dalla scarsa collaborazione"},{"k":"nexus","nome":"NEXUS: niente collare","testo":"criteri NEXUS applicabili, non necessaria immobilizzazione"},{"k":"allarme","nome":"Segni d'allarme spiegati","testo":"Paziente informato dei segni d'allarme (elencati), che dichiara di aver compreso, con indicazione a tornare in PS."}]};

  // ================================================================ UTILS
  const sleep = (ms, signal) => new Promise((res, rej) => {
    const t = setTimeout(res, ms);
    if (signal) signal.addEventListener("abort", () => { clearTimeout(t); rej(new DOMException("Aborted", "AbortError")); }, { once: true });
  });
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const now = () => new Date().toLocaleTimeString("it-IT");

  // Copiare negli appunti. navigator.clipboard non esiste sulle origini non
  // sicure (il portale clinico è http://): lì si passa dal vecchio
  // execCommand, che invece funziona. Un pulsante «copia» non deve dipendere
  // da quale delle due pagine si ha davanti.
  // il lampo sul pulsante dopo una copia: era ricopiato in sette punti
  function segnaCopia(b, ok, riposo = "⧉ Copia", ms = 2000) {
    if (!b) return ok;
    b.textContent = ok ? "✓ copiato" : "non riuscito";
    setTimeout(() => { if (b.isConnected) b.textContent = riposo; }, ms);
    return ok;
  }
  async function copiaTesto(text) {
    const t = String(text ?? "");
    try { await navigator.clipboard.writeText(t); return true; } catch { /* ripiego qui sotto */ }
    let ok = false;
    try {
      const ta = document.createElement("textarea");
      ta.value = t;
      ta.style.cssText = "position:fixed;left:-9999px;top:0";
      document.body.appendChild(ta);
      ta.select();
      ok = document.execCommand("copy");
      ta.remove();
    } catch { ok = false; }
    return ok;
  }

  // Controlled hard-stop carrying a headline + body the UI can render loudly.
  class StopError extends Error {
    constructor(head, body = "") { super(body ? `${head} — ${body}` : head); this.head = head; this.body = body; }
  }

  // Una pagina a cui ci ha portato il PANNELLO si apre con la finestra
  // aperta; una a cui è arrivato il medico dal gestionale, con la pill.
  const nav = (url) => {
    try { sessionStorage.setItem("psassist:navPannello.v1", JSON.stringify(Date.now())); } catch { /* niente */ }
    location.href = url;
  };
  const openTab = (url, name) => window.open(url, name);

  // Il medico sta scrivendo nel gestionale? Una navigazione decisa dal
  // programma (errore → carrello, revisione, conferma sospesa) non deve mai
  // portarsi via quello che ha sotto le dita: un campo col cursore dentro, un
  // campo cambiato e non salvato, un tasto premuto da poco. Allora non si va:
  // lo dice la pill, e un tocco porta dove si sarebbe andati.
  const TASTO_MS = 15e3;
  const scrittura = { tasto: 0, cambiato: false, toccato: false, nostri: new WeakSet(), attivo: false };
  const dalGestionale = (e) => e.isTrusted && !(e.composedPath ? e.composedPath() : []).some((x) => x && x.id === "psassist-host");
  const NON_SCRITTURA = /^(button|submit|reset|image|hidden|checkbox|radio|file|range|color)$/i;
  const eCampo = (el) => !!el && el.id !== "psassist-host" && (el.isContentEditable || el.tagName === "TEXTAREA" || el.tagName === "SELECT"
    || (el.tagName === "INPUT" && !NON_SCRITTURA.test(el.type || "")));
  function osservaScrittura() {
    if (scrittura.attivo) return;
    scrittura.attivo = true;
    document.addEventListener("keydown", (e) => { if (dalGestionale(e)) { scrittura.tasto = Date.now(); scrittura.toccato = true; } }, true);
    // il cursore in un campo conta se ce l'ha messo lui (un campo col fuoco
    // automatico, appena caricata la pagina, non è qualcuno che scrive)
    document.addEventListener("pointerdown", (e) => { if (dalGestionale(e)) scrittura.toccato = true; }, true);
    const cambia = (e) => { if (dalGestionale(e) && eCampo(e.target)) scrittura.cambiato = true; };
    document.addEventListener("input", cambia, true);
    document.addEventListener("change", cambia, true);
  }
  // perché adesso non si cambia pagina ("" = si può). `adesso`: sta scrivendo
  // in questo momento (il cursore in un campo, un tasto da poco) — quello che
  // un dialogo di stampa interromperebbe; un campo cambiato e lasciato no.
  function staScrivendo(adesso = false) {
    if (scrittura.toccato && eCampo(document.activeElement)) return "cursore in un campo";
    if (adesso) return Date.now() - scrittura.tasto < TASTO_MS ? "un tasto premuto da poco" : "";
    if (scrittura.cambiato) return "un campo modificato";
    // il testo scritto prima che il programma arrivasse (il bookmarklet si clicca dopo).
    // Non nella scheda di un ordine: quella pagina l'ha aperta il programma, e
    // un campo diverso dal suo valore di partenza lì l'ha cambiato la pagina.
    if (!LAVORO) for (const t of document.querySelectorAll("textarea")) {
      if (!scrittura.nostri.has(t) && t.value !== t.defaultValue) return "un campo modificato";
    }
    if (Date.now() - scrittura.tasto < TASTO_MS) return "un tasto premuto da poco";
    return "";
  }

  function param(url, name) {
    try { return new URL(url, location.href).searchParams.get(name); } catch { return null; }
  }

  // --- windows-1252 form body encoder --------------------------------------
  // application/x-www-form-urlencoded in the page charset, like a real form
  // submit: space → "+", bytes outside the safe set → %XX of the win1252
  // byte, characters not representable in win1252 → HTML numeric reference.
  const W1252_EXTRA = { // unicode → win1252 byte for the 0x80–0x9F specials
    0x20AC: 0x80, 0x201A: 0x82, 0x0192: 0x83, 0x201E: 0x84, 0x2026: 0x85,
    0x2020: 0x86, 0x2021: 0x87, 0x02C6: 0x88, 0x2030: 0x89, 0x0160: 0x8A,
    0x2039: 0x8B, 0x0152: 0x8C, 0x017D: 0x8E, 0x2018: 0x91, 0x2019: 0x92,
    0x201C: 0x93, 0x201D: 0x94, 0x2022: 0x95, 0x2013: 0x96, 0x2014: 0x97,
    0x02DC: 0x98, 0x2122: 0x99, 0x0161: 0x9A, 0x203A: 0x9B, 0x0153: 0x9C,
    0x017E: 0x9E, 0x0178: 0x9F,
  };
  function encodeW1252Component(str) {
    let out = "";
    for (const ch of String(str)) {
      const cp = ch.codePointAt(0);
      let byte = null;
      if (cp <= 0x7F) byte = cp;
      else if (cp >= 0xA0 && cp <= 0xFF) byte = cp;
      else if (W1252_EXTRA[cp] !== undefined) byte = W1252_EXTRA[cp];
      if (byte === null) { out += encodeW1252Component(`&#${cp};`); continue; }
      if (byte === 0x20) out += "+";
      else if ((byte >= 0x30 && byte <= 0x39) || (byte >= 0x41 && byte <= 0x5A) || (byte >= 0x61 && byte <= 0x7A) || byte === 0x2A || byte === 0x2D || byte === 0x2E || byte === 0x5F) {
        out += String.fromCharCode(byte);
      } else out += "%" + byte.toString(16).toUpperCase().padStart(2, "0");
    }
    return out;
  }
  const encodeFormBody = (pairs) => pairs.map(([k, v]) => encodeW1252Component(k) + "=" + encodeW1252Component(v)).join("&");

  // --- fetch + parse --------------------------------------------------------
  // Returns {doc, url} where url is the FINAL response URL — every href or
  // action extracted from doc must be resolved against it (DOMParser docs
  // inherit the creating page's URL, which is NOT the fetched page's URL).
  async function fetchDoc(url, { method = "GET", body = null, signal } = {}) {
    // Enforce, not just promise, that nothing ever leaves the hospital origin.
    const target = new URL(url, location.href);
    if (target.origin !== location.origin) {
      throw new StopError("Richiesta fuori dall'ospedale bloccata", `destinazione inattesa: ${target.origin}`);
    }
    // Own timeout composition (AbortSignal.any needs Chrome 116+; hospital
    // Chromes can be older and a hung request must never hang the run).
    const ctl = new AbortController();
    const tid = setTimeout(() => ctl.abort(new DOMException("Timeout", "TimeoutError")), TIMEOUT_MS);
    const onAbort = () => ctl.abort(new DOMException("Aborted", "AbortError"));
    if (signal) {
      if (signal.aborted) { clearTimeout(tid); throw new DOMException("Aborted", "AbortError"); }
      signal.addEventListener("abort", onAbort, { once: true });
    }
    let res, buf;
    try {
      res = await fetch(target.href, {
        method, body, signal: ctl.signal,
        credentials: "same-origin",
        cache: "no-store",
        redirect: "follow",
        headers: method === "POST" ? { "Content-Type": "application/x-www-form-urlencoded" } : undefined,
      });
      // La scadenza e lo STOP devono coprire ANCHE il corpo: il vecchio
      // finally li spegneva appena arrivavano le intestazioni, e un corpo che
      // non arriva mai lasciava la corsa appesa senza modo di fermarla.
      if (new URL(res.url || target.href).origin !== location.origin) {
        throw new StopError("Risposta fuori dall'ospedale bloccata", `destinazione inattesa: ${res.url}`);
      }
      if (!res.ok) throw new StopError(`Il server ha risposto HTTP ${res.status}`, res.statusText || "");
      buf = await res.arrayBuffer();
    } finally {
      clearTimeout(tid);
      if (signal) signal.removeEventListener("abort", onAbort);
    }
    const ct = res.headers.get("content-type") || "";
    const m = /charset=([\w-]+)/i.exec(ct);
    let charset = (m ? m[1] : "windows-1252").toLowerCase();
    let text;
    try { text = new TextDecoder(charset).decode(buf); }
    catch { text = new TextDecoder("windows-1252").decode(buf); }
    const doc = new DOMParser().parseFromString(text, "text/html");
    return { doc, url: res.url || String(url) };
  }

  const absUrl = (el, attr, baseUrl) => {
    const raw = el.getAttribute(attr);
    return raw ? new URL(raw, baseUrl).href : baseUrl;
  };

  // --- form serialization (browser semantics) -------------------------------
  // Successful controls in tree order; only the activated submit button is
  // included. Select values honour "last selected wins" explicitly, because
  // the server emits duplicate `selected` attributes on some pages.
  // Both live documents and DOMParser documents resolve duplicate `selected`
  // attributes with "last one wins" during parsing, so the value/selectedOptions
  // IDL properties are already correct — use them, never the attributes.
  function selectValue(sel) {
    if (sel.multiple) return [...sel.selectedOptions].map((o) => o.value);
    return sel.value;
  }
  function serializeForm(form, submitEl) {
    const pairs = [];
    for (const el of form.elements) {
      if (!el.name || el.disabled) continue;
      const type = (el.type || "").toLowerCase();
      if (type === "submit" || type === "button" || type === "image" || type === "reset") {
        if (el === submitEl) pairs.push([el.name, el.value ?? ""]);
        continue;
      }
      if ((type === "checkbox" || type === "radio") && !el.checked) continue;
      if (el.tagName === "SELECT") {
        const v = selectValue(el);
        if (Array.isArray(v)) v.forEach((x) => pairs.push([el.name, x]));
        else pairs.push([el.name, v]);
        continue;
      }
      if (type === "file") continue;
      pairs.push([el.name, el.value ?? ""]);
    }
    return pairs;
  }

  // ============================================================ PAGE MODELS
  function classify(doc) {
    if (doc.querySelector('form[name="RICHIESTACrea"]')) return "crea";
    if (doc.querySelector('form[name="Prestazioni"]')) return "exam";
    if (doc.querySelector('form[name="AmbulatorioPSO"]') ||
        doc.querySelector('a[title="Richieste Laboratorio"], a[title="Richieste Radiologia"]')) return "patient";
    if (doc.querySelector('input[type="password"]')) return "login";
    return "other";
  }

  // Episode id as stated by the SERVER inside the page (links/forms).
  function findEpisodeIdInDoc(doc) {
    const el = doc.querySelector('a[href*="EPISODIO_ID="], form[action*="EPISODIO_ID="]');
    if (el) {
      const raw = el.getAttribute("href") || el.getAttribute("action") || "";
      const m = /[?&]EPISODIO_ID=([^&]+)/.exec(raw);
      if (m) return decodeURIComponent(m[1]);
    }
    return null;
  }
  function findEpisodeId(doc, baseUrl) {
    return param(baseUrl, "EPISODIO_ID") || findEpisodeIdInDoc(doc);
  }

  // Lab names as they are read at a glance. The LIS writes them out in full
  // ("MCH Cont. Media Hgb"), which is unreadable in a two-line preview: what a
  // doctor scans is the short form and the number.
  const SIGLE = [
    [/^leucociti|^globuli bianchi|^wbc/i, "GB"],
    // l'emoglobina glicata è un'altra grandezza in un'altra unità: non deve
    // mai finire nella riga dell'Hb accanto a un'emoglobina in g/dL
    [/emoglobina\s*glicat|^hba1c|\bhb\s?a1c\b/i, "HbA1c"],
    [/^emoglobina(?!\s*glicat)|^hgb\b|^hb\b|^c?thb\b/i, "Hb"],
    [/^ematocrito|^hct/i, "Ht"], [/^piastrine|^plt/i, "PLT"], [/^eritrociti|globuli rossi|^rbc/i, "GR"],
    [/^mcv|vol\.? glob/i, "MCV"], [/^mchc/i, "MCHC"], [/^mch\b|cont\.? media/i, "MCH"], [/^rdw/i, "RDW"],
    [/^(granulociti\s+)?eosinofil/i, "Eos"], [/^(granulociti\s+)?basofil/i, "Bas"], [/^granulociti|neutrofil/i, "Neu"], [/^linfocit/i, "Lin"], [/^monocit/i, "Mon"],
    [/^eosinofil/i, "Eos"], [/^basofil/i, "Bas"], [/altre popolazioni/i, "Altre"],
    [/^creatinin/i, "Cr"], [/^azotemia|^urea/i, "Az"], [/^sodio|^na\b/i, "Na"], [/^potassio|^k\b/i, "K"],
    [/^cloro|^cl\b/i, "Cl"], [/calcio ioniz/i, "Ca++"], [/^calcio/i, "Ca"], [/^magnesio/i, "Mg"],
    [/^glucosio|glicemia/i, "Glu"], [/proteina c reattiva|^pcr\b/i, "PCR"], [/procalcitonin/i, "PCT"],
    [/troponina/i, "Trop"], [/d.?dimero/i, "DD"], [/^inr/i, "INR"], [/^pt\b|protrombin/i, "PT"],
    // il rapporto del PTT è un'altra grandezza dei secondi: con la stessa
    // sigla le due righe finivano scritte per esteso, e sembravano un doppione
    [/^a?ptt\s*ratio/i, "PTTr"],
    [/^ptt|tromboplastin/i, "PTT"], [/fibrinogeno/i, "Fib"],
    // "indiretta" contiene "diretta": vanno distinte, o la bilirubina diretta
    // e l'indiretta diventano due righe con la stessa etichetta
    [/bilirubina\s+indiretta|bil\.?\s*indiretta/i, "BilI"],
    [/bilirubina\s+diretta|bil\.?\s*diretta/i, "BilD"],
    [/bilirubina/i, "Bil"], [/^got\b|^ast\b/i, "AST"], [/^gpt\b|^alt\b/i, "ALT"],
    [/gamma\s?gt|^ggt/i, "γGT"], [/fosfatasi alc/i, "ALP"], [/^ldh/i, "LDH"],
    // «cK+» è il potassio dell'emogas: senza questa riga la regola del CPK
    // (^ck) lo prendeva, e il potassio compariva come CPK fra gli enzimi
    [/^c?k\s*\+/i, "K"],
    // gli altri nomi dell'emogas, scritti come li scrive l'emogasanalizzatore
    [/^c?na\s*\+/i, "Na"], [/^c?cl\s*-/i, "Cl"], [/^c?ca\s*(?:2\s*\+|\+\+)/i, "Ca++"],
    [/^c?glu\b/i, "Glu"], [/^cLac\b/, "Lac"],   // «LAC» (lupus anticoagulant) non è lattato
    [/\bck\s?-?\s?mb\b/i, "CKMB"], [/^cpk|creatinchinasi|^ck\b(?!\s?-?\s?mb)/i, "CPK"],
    [/^lipasi/i, "Lip"], [/^amilasi/i, "Amy"],
    [/albuminuria|microalbuminur/i, "Albu"], [/^albumin/i, "Alb"],
    [/nt.?pro.?bnp/i, "NTproBNP"], [/^bnp/i, "BNP"], [/^ves\b/i, "VES"],
    [/^ph\b/i, "pH"], [/pco2|pco₂/i, "pCO2"], [/po2\b|po₂/i, "pO2"], [/hco3|bicarbon/i, "HCO3"],
    [/base excess|^be\b|^eb\b|^[as]be\b|^cbase/i, "BE"],
    [/lattico\s+deidrogen|lattato\s+deidrogen/i, "LDH"],   // prima di "lattat"
    [/lattat/i, "Lac"], [/saturaz|^so2/i, "SatO2"],
    [/carbossiemo|^cohb/i, "COHb"], [/metaemo|^methb/i, "MetHb"], [/^tsh/i, "TSH"],
    [/emogas/i, "EGA"], [/^ammonio|ammoniem/i, "NH3"], [/^mioglobin/i, "Mb"],
    // urine dipstick and blood-gas derivatives: names the portal's multi-day
    // table shows and the Risultati window does not
    [/corpi chetonici|^chetoni/i, "Chet"], [/esterasi leucocit/i, "EstLeu"],
    [/peso specifico/i, "PesoSp"], [/urobilinogen/i, "Urob"], [/^nitriti/i, "Nitr"],
    [/anion gap/i, "AG"], [/^ca\+\+/i, "Ca++"],
    [/^fcohb/i, "FCOHb"], [/^fo2hb|^fo₂hb/i, "FO2Hb"], [/^hhb/i, "HHb"],
    [/^shunt/i, "Shunt"], [/^ctco2|^ctco₂/i, "ctCO2"], [/^cto2|^cto₂/i, "ctO2"],
  ];
  // The portal writes the specimen in front of the analyte: S-ALT, P-Sodio,
  // U-Emoglobina, Lcr-Glucosio. Serum, plasma and blood are what a sigla
  // already means, so they drop; every other specimen STAYS in the label,
  // because urine haemoglobin is not haemoglobin and must never read as Hb.
  const CAMPIONE = /^\s*(S|P|B|Sg|Ser|Pl)\s*-\s*/i;
  const CAMPIONE_ALTRO = /^\s*(U|Lcr|Liq|F|Fec|Exp|Esc)\s*-\s*/i;
  // Le sezioni dello storico. La chiave è la SIGLA (l'uscita di sigla()), non
  // il nome del laboratorio: così bastano poche righe invece di un elenco di
  // sinonimi, e l'ordine dentro ogni sezione è l'ordine in cui si leggono.
  // Chi non è in elenco finisce in «Altri»: non si perde niente, mai.
  const SEZIONI = [
    ["Emocromo", ["GB", "Neu", "Lin", "Mon", "Eos", "Bas", "Altre", "Hb", "Ht", "GR", "MCV", "MCH", "MCHC", "RDW", "PLT"]],
    ["Coagulazione", ["PT", "INR", "PTT", "PTTr", "Fib", "DD"]],
    ["Biochim", ["PCR", "PCT", "VES", "Trop", "NTproBNP", "BNP", "CPK", "CKMB", "Mb", "LDH"]],
    ["Organi", ["Cr", "Az", "AST", "ALT", "γGT", "ALP", "Bil", "BilD", "BilI", "Amy", "Lip", "Alb", "NH3"]],
    ["Elettroliti e metabolismo", ["Na", "K", "Cl", "Ca", "Ca++", "Mg", "Glu", "HbA1c", "TSH"]],
    ["Emogas", ["pH", "pCO2", "pO2", "HCO3", "BE", "Lac", "SatO2", "AG", "ctCO2", "ctO2", "COHb", "MetHb", "FCOHb", "FO2Hb", "HHb", "Shunt", "EGA"]],
    ["Urine e altri liquidi", ["Albu", "PesoSp", "Nitr", "Chet", "EstLeu", "Urob"]],
  ];
  const ALTRI = "Altri";
  // sigla → [sezione, posizione dentro la sezione], costruita una volta sola
  const DOVE = (() => {
    const m = new Map();
    SEZIONI.forEach(([sez, sigle]) => sigle.forEach((s, i) => m.set(s, [sez, i])));
    return m;
  })();
  // Un'abbreviazione che porta il campione (U·Hb, Lcr·Glu) non è quell'analita
  // nel sangue: l'emoglobina delle urine non va nell'emocromo. Il campione
  // decide la sezione prima di tutto il resto.
  function sezioneDi(sg) {
    const s = String(sg || "");
    if (s.includes("·")) return ["Urine e altri liquidi", 900];
    return DOVE.get(s) || [ALTRI, 900];
  }
  // L'emogas è un'altra macchina e un altro campione: Hb, Ht, K, Na, Cl, Ca++
  // e glucosio dell'emogas NON sono quelli dell'emocromo o della chimica.
  // Chi li legge li vuole divisi: stanno nella sezione Emogas, su righe loro,
  // e non si fondono mai con gli stessi analiti fatti in laboratorio. Lo dice
  // l'ESAME che li ha prodotti (EGA venosa, emogasanalisi…), non il nome.
  const eEga = (esame) => /EMOGAS|\bEGA\b/i.test(String(esame || ""));
  const ORDINE_EGA = ["pH", "pCO2", "pO2", "HCO3", "BE", "Lac", "SatO2", "Hb", "Ht", "Na", "K", "Cl", "Ca++", "Glu",
    "AG", "ctCO2", "ctO2", "COHb", "MetHb", "FCOHb", "FO2Hb", "HHb", "Shunt", "EGA"];
  function sezioneRiga(r, sg = sigla(r.nome)) {
    const [sez, ord] = eEga(r.esame) && !String(sg).includes("·") ? ["Emogas", 0] : sezioneDi(sg);
    if (sez !== "Emogas") return [sez, ord];
    const i = ORDINE_EGA.indexOf(sg);
    return ["Emogas", i < 0 ? 900 : i];
  }
  const ordineSezioni = [...SEZIONI.map(([n]) => n), "Urine e altri liquidi", ALTRI]
    .filter((n, i, a) => a.indexOf(n) === i);

  function scomponi(nome) {
    const n = String(nome || "").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim();
    if (CAMPIONE.test(n)) return { pre: "", resto: n.replace(CAMPIONE, "") };
    const m = CAMPIONE_ALTRO.exec(n);
    if (m) return { pre: m[1].toUpperCase() + "·", resto: n.slice(m[0].length) };
    return { pre: "", resto: n };
  }
  function sigla(nome) {
    const n = String(nome || "").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim();
    const { pre, resto } = scomponi(n);
    for (const [re, s] of SIGLE) if (re.test(resto)) return pre + s;
    // Dropping the prefix only pays off when what is left is a name we KNOW.
    // Otherwise that letter was never a specimen: "S-100" is a protein, not
    // serum 100, and "B-12" is a vitamin. Keep the name whole.
    const w = n.split(/[\s(,]+/).filter(Boolean)[0] || n;   // first word, never a paragraph
    return w.length > 9 ? w.slice(0, 8) + "." : w;
  }
  // An abbreviation this program has NOT been taught is a guess, and a guess
  // that looks like a known sigla is how a doctor reads the wrong analyte.
  // Everywhere a guess is shown it is marked, and counted.
  // «x10» da solo non dice niente: il gestionale perde l'esponente. Per i
  // conteggi cellulari l'unità è una sola in tutti i laboratori italiani —
  // globuli bianchi e piastrine ×10⁹/L (= 10³/µL), globuli rossi ×10¹²/L — e si
  // scrive per esteso SOLO se l'unità è proprio «x10» nuda e l'analita è una
  // di queste sigle curate. Altrimenti resta com'è: mai un'ipotesi.
  const ESPONENTI_CONTEGGI = { GB: 9, Neu: 9, Lin: 9, Mon: 9, Eos: 9, Bas: 9, Altre: 9, PLT: 9, GR: 12 };
  function unitaChiara(um, nome) {
    const u = String(um || "").trim();
    if (!/^[x×*]\s?10$/i.test(u)) return u;
    const e = ESPONENTI_CONTEGGI[sigla(nome)];
    return e ? "×10" + String(e).replace(/\d/g, (c) => "⁰¹²³⁴⁵⁶⁷⁸⁹"[c]) + "/L" : u;
  }
  const siglaCurata = (nome) => SIGLE.some(([re]) => re.test(scomponi(nome).resto));
  // Peggio di un nome che non conosciamo: due nomi DIVERSI che nello stesso
  // prelievo escono con la stessa abbreviazione («PTT secondi» e «PTT Ratio»,
  // «Granulociti» e «Granulociti %»). Anche quelli vanno scritti per esteso.
  // (L'Hb dell'emogas e quella dell'emocromo stanno in due sezioni diverse:
  // la stessa sigla non le confonde. Si confondono due righe della STESSA
  // sezione con la stessa sigla — la chiave è quella.)
  const chiaveAmbigua = (r) => sezioneRiga(r)[0] + "|" + sigla(r.nome);
  function sigleAmbigue(rows) {
    const per = new Map();
    for (const r of rows || []) {
      const nome = String(r.nome || "").trim();
      if (!nome) continue;
      const k = chiaveAmbigua(r);
      const set = per.get(k) || new Set();
      set.add(nome + (eEga(r.esame) ? "|ega" : ""));
      per.set(k, set);
    }
    const out = new Set();
    for (const [k, nomi] of per) if (nomi.size > 1) out.add(k);
    return out;
  }
  // Le righe divise in sezioni, in ordine FISSO. L'ordine non deve dipendere da
  // come il laboratorio ha stampato la tabella: se dipendesse, lo stesso esame
  // cambierebbe posto da un prelievo all'altro e lo si cercherebbe ogni volta.
  // La formula leucocitaria arriva in coppia — «Granulociti» (x10³/µL) e
  // «Granulociti %» — e in tabella erano due righe con lo stesso nome, che il
  // medico leggeva come doppioni (e che, per non confonderle, finivano pure
  // scritte per esteso). Diventano UNA riga: il valore assoluto, e fra
  // parentesi la percentuale. Il fuori range è quello dell'assoluto; una
  // percentuale senza assoluto resta da sola («Altre 5.9%»).
  const FORMULA = new Set(["Neu", "Lin", "Mon", "Eos", "Bas", "Altre"]);
  const ePct = (r) => /%/.test(String(r.nome || "")) || (r.valori || []).some((v) => v && String(v.um || "").trim() === "%");
  function fondiFormula(righe) {
    const coppie = new Map();   // sigla → { abs, pct }
    const out = [];
    for (const r of righe || []) {
      const sg = sigla(r.nome);
      if (!FORMULA.has(sg)) { out.push(r); continue; }
      const stelo = valKey(String(r.nome).replace(/[%#]/g, " "));   // «Granulociti %» → «granulociti»
      const c = coppie.get(stelo) || {};
      const lato = ePct(r) ? "pct" : "abs";
      // una terza riga con la stessa sigla non si indovina: resta com'è
      if (c[lato]) { out.push(r); continue; }
      c[lato] = r;
      if (!coppie.has(stelo)) { coppie.set(stelo, c); out.push({ segnaposto: stelo }); }
    }
    return out.map((r) => {
      if (!r.segnaposto) return r;
      const { abs, pct } = coppie.get(r.segnaposto);
      if (!abs || !pct) return abs || pct;
      const n = Math.max(abs.valori.length, pct.valori.length);
      const valori = Array.from({ length: n }, (_, i) => {
        const a = abs.valori[i], q = pct.valori[i];
        if (a && a.v) return { ...a, pct: q && q.v ? String(q.v) : "" };
        // solo la percentuale in quel prelievo: il numero porta il suo «%», e
        // l'unità resta quella dell'assoluto per tutta la riga
        if (q && q.v) return { ...q, v: String(q.v) + "%", um: "" };
        return a || q;
      });
      return { ...abs, valori };
    });
  }

  // Lo stesso esame in due prestazioni della stessa richiesta («EMOCROMO» e
  // «EMOCROMO CON FORMULA») dà le stesse righe due volte, a volte col nome
  // scritto in due modi («MCH Cont. Medio Hgb», «… Media Hgb»): in tabella
  // erano doppioni. Due righe della stessa sezione con la stessa sigla
  // diventano una sola se dicono LA STESSA COSA: tutte e due assolute o
  // tutte e due percentuali, almeno un prelievo in comune e lo stesso valore
  // in ognuno. Un solo valore diverso, e restano due (scritte per esteso).
  function fondiDoppioni(righe) {
    const numero = (x) => (/^-?\d+(?:[.,]\d+)?$/.test(x) ? Number(x.replace(",", ".")) : NaN);
    const uguali = (a, b) => a === b || numero(a) === numero(b);   // «131.0» e «131»: lo stesso numero
    const stessa = (a, b) => {
      let comuni = 0;
      for (let i = 0; i < Math.max(a.valori.length, b.valori.length); i++) {
        const x = String(a.valori[i]?.v || "").trim(), y = String(b.valori[i]?.v || "").trim();
        if (!x || !y) continue;
        if (!uguali(x, y)) return false;
        comuni++;
      }
      return comuni > 0;
    };
    const out = [];
    for (const r of righe || []) {
      const k = chiaveAmbigua(r) + (ePct(r) ? "|%" : "") + (eEga(r.esame) ? "|ega" : "");
      const gemella = out.find((x) => x.k === k && stessa(x.r, r));
      if (!gemella) { out.push({ k, r }); continue; }
      gemella.r = { ...gemella.r, valori: gemella.r.valori.map((v, i) => (v && v.v ? v : r.valori[i] || v)) };
    }
    return out.map((x) => x.r);
  }
  // le righe come si mostrano: prima via i doppioni, poi la formula in coppia
  const righeTabella = (righe) => fondiFormula(fondiDoppioni(righe));

  function raggruppaStorico(righe) {
    const per = new Map();
    for (const r of righe || []) {
      const sg = sigla(r.nome);
      const [sez, ord] = sezioneRiga(r, sg);
      if (!per.has(sez)) per.set(sez, []);
      per.get(sez).push({ ...r, sg, ord });
    }
    const out = [];
    for (const sez of ordineSezioni) {
      const l = per.get(sez);
      if (!l) continue;
      l.sort((a, b) => (a.ord - b.ord) || String(a.sg).localeCompare(String(b.sg), "it"));
      out.push({ nome: sez, righe: l });
      per.delete(sez);
    }
    for (const [sez, l] of per) out.push({ nome: sez, righe: l });   // mai, ma non si perde
    return out;
  }

  // Chi ha fatto quale valore. Quasi sempre una macchina sola, e allora non si
  // segna niente. Quando sono due o più — l'emocromo del POC e quello del
  // laboratorio — la più frequente resta muta e le altre prendono un segno,
  // spiegato sotto la tabella e sul valore stesso.
  const SEGNI = ["*", "†", "‡", "§"];
  // `simboli` è condiviso da tutta la tabella (esame → segno): così «*» vuol
  // dire lo stesso esame in ogni riga, e la legenda lo spiega una volta sola.
  function provenienze(r, simboli = new Map()) {
    const conta = new Map();
    (r.valori || []).forEach((v, i) => {
      if (!v || !v.v) return;
      const e = String(v.esame || r.esame || "").trim();
      if (!e) return;
      const c = conta.get(e) || { n: 0, ultimo: -1 };
      c.n++; c.ultimo = i;                       // date: dal più vecchio al più recente
      conta.set(e, c);
    });
    const nulla = { solita: "", segno: () => "", legenda: [] };
    if (conta.size < 2) return nulla;
    const ord = [...conta.entries()].sort((a, b) => (b[1].n - a[1].n) || (b[1].ultimo - a[1].ultimo));
    const solita = ord[0][0];
    const marchi = new Map();
    ord.slice(1).forEach(([e]) => {
      if (!simboli.has(e)) simboli.set(e, SEGNI[simboli.size] || "•");
      marchi.set(e, simboli.get(e));
    });
    return {
      solita,
      segno: (v) => marchi.get(String((v && v.esame) || r.esame || "").trim()) || "",
      legenda: [...marchi.entries()].map(([esame, segno]) => ({ segno, esame, solita })),
    };
  }

  const nomiInattesi = (rows) => {
    const out = [];
    for (const r of rows || []) {
      const n = String(r.nome || "").trim();
      if (n && !siglaCurata(n) && !out.includes(n)) out.push(n);
    }
    return out;
  };

  // ---- comparing draws -----------------------------------------------------
  // The identity of an analyte across draws: the same name however the
  // laboratory spelled it. Rows of two draws meet on this key.
  // Il campione neutro (S-, P-, B-…) non fa l'identità, come per sigla(): «S-Sodio» del portale
  // e «Sodio» della finestra Risultati sono lo stesso analita — solo se il resto è un nome noto
  // («S-100» resta intero), e U-/Lcr- restano. pCO₂ = pCO2, «Linfociti%» = «Linfociti %».
  const valKey = (nome) => { const n = String(nome || "").replace(/&nbsp;/g, " ").normalize("NFKC"), { pre, resto } = scomponi(n); return (siglaCurata(n) ? pre + resto : n).replace(/[^a-zà-ù0-9%+]+/gi, " ").replace(/\s*%\s*/g, " % ").trim().toLowerCase(); };

  // First ~160 chars of visible page text, for the log when a page is unexpected.
  function snippet(doc) {
    return (doc.body?.textContent || "").replace(/\s+/g, " ").trim().slice(0, 160);
  }

  // Fail-closed episode pinning: crea/exam pages ALWAYS carry EPISODIO_ID in
  // the audited system, so a page without one is itself an anomaly.
  // IMPORTANT: trust the DOCUMENT first — the response URL only echoes the id
  // WE requested, so it is not independent evidence of what the server served.
  function assertSameEpisode(doc, episodeId, what) {
    const found = findEpisodeIdInDoc(doc);
    if (!found) {
      throw restaQui(new StopError(`Episodio non identificabile nella pagina "${what}"`, "Interrotto per sicurezza."));
    }
    if (episodeId && found !== episodeId) {
      throw restaQui(new StopError(`La pagina "${what}" appartiene a un altro episodio (${found} ≠ ${episodeId})`, "Interrotto per sicurezza."));
    }
  }
  // Un errore dopo il quale la scheda NON va portata sul carrello: un episodio
  // che non torna (quel carrello potrebbe essere di un altro paziente), la
  // sessione scaduta, un'altra scheda al lavoro sulla stessa richiesta.
  const restaQui = (err) => { err.restaQui = true; return err; };
  // Uno stop dopo il quale il giro ritenta da solo, una volta: un elenco
  // venuto male (la riga che non si vede, l'elenco di un'altra risorsa).
  const ritentabile = (err) => { err.ritentabile = true; return err; };

  // Patient page: entry links to open a new richiesta.
  function patientModel(doc, baseUrl) {
    const link = (title) => {
      const a = doc.querySelector(`a[title="${title}"]`);
      return a ? absUrl(a, "href", baseUrl) : null;
    };
    return {
      labUrl: link("Richieste Laboratorio"),
      radioUrl: link("Richieste Radiologia"),
    };
  }

  // ------------------------------------------------------------- PRINT MODEL
  // The patient page (and possibly the post-confirm page) lists, per
  // richiesta, the print links audited from the real pages:
  //   "Stampa Etichette"  → RcsStampaEtichetteLISHMIMU.do?RICHIESTA_ID=…  (barcode icon → label PDF)
  //   "Stampa Richiesta"  → /jasperserverSAN/jasperservlet?REPORT=RcsRichiesta&RICHIESTA_ID=…&BRANCA=…
  //   "Stampa Prenotazione Esterna" → jasperservlet, radiology bookings
  // BRANCA varies per richiesta, so these URLs are always READ from the DOM,
  // never constructed.
  // A richiesta whose exams span more than one laboratory is split by the
  // LIS into MULTIPLE rows — same RICHIESTA_ID, different RICHIESTA_PROG —
  // each with its own label PDF and its own exam-list PDF. ALL of them must
  // be printed, so rows are grouped per (RICHIESTA_ID, RICHIESTA_PROG) and
  // never collapsed.
  function printModel(doc, baseUrl) {
    const map = {}; // richiestaId -> { prog -> row, _meta }
    const sel = 'a[title="Stampa Etichette"], a[title="Stampa Richiesta"], a[title="Stampa Prenotazione Esterna"]';
    for (const a of doc.querySelectorAll(sel)) {
      const href = absUrl(a, "href", baseUrl);
      const rid = param(href, "RICHIESTA_ID");
      if (!rid) continue;
      const prog = param(href, "RICHIESTA_PROG") || "1";
      const rows = (map[rid] = map[rid] || { _meta: { ts: 0, when: "", exams: [] } });
      const row = (rows[prog] = rows[prog] || { prog });
      const t = a.getAttribute("title");
      if (t === "Stampa Etichette") row.etichette = href;
      else if (t === "Stampa Richiesta") row.lista = href;
      else row.prenotazione = href;
      // the row this print icon lives in also carries when + what was ordered
      const tr = a.closest("tr");
      if (tr) {
        const dt = istanteRiga(tr);
        if (dt && (!rows._meta.ts || dt.ts < rows._meta.ts)) { rows._meta.ts = dt.ts; rows._meta.when = dt.when; }
        const desc = tr.querySelector('input[name="DESCRIZIONE_TITLE"]')?.value || "";
        const nice = shortLabel(desc.replace(/^\d+-\d+\s*/, "")).trim();
        if (nice && !rows._meta.exams.includes(nice)) rows._meta.exams.push(nice);
      }
    }
    // every OTHER row of the same richiesta adds its exam to the list
    for (const tr of doc.querySelectorAll("tr")) {
      const link = tr.querySelector('a[href*="RICHIESTA_ID="], a[onclick*="RICHIESTA_ID="]');
      if (!link) continue;
      const raw = link.getAttribute("href") || link.getAttribute("onclick") || "";
      const rid = (/RICHIESTA_ID=([^&'"]+)/.exec(raw) || [])[1];
      if (!rid || !map[rid]) continue;
      const desc = tr.querySelector('input[name="DESCRIZIONE_TITLE"]')?.value || "";
      const nice = shortLabel(desc.replace(/^\d+-\d+\s*/, "")).trim();
      if (nice && !map[rid]._meta.exams.includes(nice)) map[rid]._meta.exams.push(nice);
    }
    return map;
  }

  function printRowsFor(map, rid) {
    return Object.entries(map[rid] || {}).filter(([k]) => k !== "_meta").map(([, v]) => v)
      .sort((a, b) => Number(a.prog) - Number(b.prog));
  }
  const printMeta = (map, rid) => (map[rid] && map[rid]._meta) || { ts: 0, when: "", exams: [] };
  // Jobs grouped by printer to minimise switching: every label PDF first
  // (etichettatrice), then every exam-list sheet, then radiology bookings.
  function printJobsFor(map, rid) {
    const rows = printRowsFor(map, rid);
    const multi = rows.length > 1;
    const tag = (r) => (multi ? ` — riga ${r.prog}` : "");
    const jobs = [];
    for (const r of rows) if (r.etichette) jobs.push({ name: `Etichette provette${tag(r)}`, printer: "etichettatrice", url: r.etichette });
    for (const r of rows) if (r.lista) jobs.push({ name: `Lista esami${tag(r)}`, printer: "stampante normale", url: r.lista });
    for (const r of rows) if (r.prenotazione) jobs.push({ name: `Prenotazione esterna${tag(r)}`, printer: "stampante normale", url: r.prenotazione });
    const seen = new Set();
    return jobs.filter((j) => !seen.has(j.url) && seen.add(j.url));
  }
  // Le richieste che la pagina sa stampare (cioè confermate), la più recente per prima.
  const richiesteStampabili = (map) => Object.keys(map).sort((a, b) => (printMeta(map, b).ts - printMeta(map, a).ts) || Number(b) - Number(a));
  // I fogli di più richieste in un giro solo: tutte le etichette, poi il resto.
  const fogliDi = (map, ids) => {
    const all = ids.map((id) => printJobsFor(map, id));
    return [...all.flatMap((j) => j.filter((x) => x.printer === "etichettatrice")), ...all.flatMap((j) => j.filter((x) => x.printer !== "etichettatrice"))];
  };
  // «Stampa l'ultima richiesta»: la più recente, e con lei quella di prima se è
  // di pochi minuti prima — il laboratorio e la radiologia dello stesso ordine.
  const ULTIMA_INSIEME = 5 * 60e3;
  function ultimeRichieste(map) {
    const [a, b] = richiesteStampabili(map);
    const ta = a ? printMeta(map, a).ts : 0, tb = b ? printMeta(map, b).ts : 0;
    return !a ? [] : ta && tb && ta - tb <= ULTIMA_INSIEME ? [a, b] : [a];
  }
  // Compact description of what a richiesta will print, e.g. "2× etichette + 2× liste".
  function printLabelFor(map, rid) {
    const rows = printRowsFor(map, rid);
    const count = (k) => rows.filter((r) => r[k]).length;
    const parts = [];
    const put = (n, sing, plur) => { if (n === 1) parts.push(sing); else if (n > 1) parts.push(`${n}× ${plur}`); };
    put(count("etichette"), "etichette", "etichette");
    put(count("lista"), "lista esami", "liste esami");
    put(count("prenotazione"), "prenotazione", "prenotazioni");
    return parts.join(" + ");
  }

  // ------------------------------------------------------------ REFERTI MODEL
  // Result rows on the patient page: the sheet icon before the exam name is
  // <a title="REFERTO" onclick="window.open('…Sa4ViewerExtRedirect.do?…
  // REFERTO_SISTEMA=HL7LIS|HL7RIS|HL7AMB&REFERTO_ID=<uuid>')">. The same cell
  // carries hidden inputs DATA_ORD ("YYYY-MM-DD HH:MM:SS.f") and
  // DESCRIZIONE_TITLE. Archive links (MODALITA=ELENCODOC/…) have no
  // REFERTO_ID and are ignored. The same exam can have MORE than one referto
  // (e.g. a TC with two documents): dedupe by REFERTO_ID only.
  function refertiModel(doc, baseUrl) {
    const out = [];
    const seen = new Set();
    for (const a of doc.querySelectorAll('a[title="REFERTO"]')) {
      const m = /window\.open\(\s*['"]([^'"]+)['"]/.exec(a.getAttribute("onclick") || "");
      if (!m) continue;
      let url;
      try { url = new URL(m[1], baseUrl).href; } catch { continue; }
      const id = param(url, "REFERTO_ID");
      if (!id || seen.has(id)) continue;
      seen.add(id);
      const td = a.closest("td");
      const label = (td?.querySelector('input[name="DESCRIZIONE_TITLE"]')?.value ||
                     td?.getAttribute("title") || td?.textContent || "referto")
                    .replace(/\s+/g, " ").trim()
                    .replace(/^\d+-\d+\s+/, "");   // «0-324 TROPONINA» → «TROPONINA»: le prime cifre sono del LIS
      const dt = istanteDa(td?.querySelector('input[name="DATA_ORD"]')?.value) || istanteRiga(a.closest("tr"));
      out.push({
        id, url, label,
        sistema: (param(url, "REFERTO_SISTEMA") || "").replace(/^HL7/, ""),
        ts: dt ? dt.ts : 0,
        when: dt ? dt.when : "—",
      });
    }
    out.sort((a, b) => b.ts - a.ts || a.label.localeCompare(b.label));
    return out;
  }

  // Viewers often navigate (by script) to a DIRECT pdf endpoint, e.g. the
  // field-observed label URL:
  //   /UploadDownload/uploaddownloadservlet.rra2?…&mimetype=application/pdf
  // Those URLs are built inside the page, so we harvest them as text and try
  // them in order — never constructing one ourselves.
  // Volutamente PIÙ STRETTA di quella in extension/bg.js: là si cacciano i
  // referti, dove «report» è un indizio buono; qui si passa in rassegna una
  // pagina intera e si tengono i primi quattro candidati — una parola larga
  // se li mangia prima che tocchi a quello giusto. Le due cacciano documenti
  // diversi su host diversi: farle identiche era un'idea mia, non un requisito.
  const PDF_SMELL = /uploaddownloadservlet|mimetype=application\/pdf|get_pdf|jasperservlet|refertostream|\.pdf(?:[?&"']|$)/i;
  // Quando un visualizzatore non si lascia leggere, l'unica cosa che può
  // dire com'è fatto è la sua pagina. La si copia SENZA numeri
  // (identificativi, date, token) e senza i valori dei campi: resta la
  // struttura, che è quello che serve per adattare il lettore.
  function mascheraDiagnosi(html) {
    return String(html || "")
      .replace(/(value\s*=\s*")[^"]*(")/gi, "$1…$2")
      .replace(/(value\s*=\s*')[^']*(')/gi, "$1…$2")
      .replace(/\d{3,}/g, "###")
      .slice(0, 16000);
  }
  function diagnosiTesto(d) {
    if (!d) return "";
    let dove = String(d.url || "");
    try { const u = new URL(d.url, location.href); dove = u.pathname + "?" + [...u.searchParams.keys()].join("&"); } catch { /* com'è */ }
    return [`PS Assist ${VERSION} · ${d.quando || ""} · ${d.cosa || ""}`, dove, d.diag || "", "---", mascheraDiagnosi(d.html)].join("\n");
  }
  const bufDaB64 = (b64) => Uint8Array.from(atob(b64), (c) => c.charCodeAt(0)).buffer;
  // I referti già aperti (o segnati «visti»), per episodio: gli altri sono
  // «nuovi». Solo gli id dei documenti, niente del loro contenuto; un giorno.
  function refertiVisti(ep) {
    const t = (store.get("refVisti.v1", {}) || {})[ep || "x"];
    return new Set(t && Date.now() - (t.ts || 0) < 24 * 3600e3 ? t.ids || [] : []);
  }
  function segnaVisti(ep, ids) {
    const tutti = store.get("refVisti.v1", {}) || {};
    const vivi = Object.fromEntries(Object.entries(tutti).filter(([, v]) => v && Date.now() - (v.ts || 0) < 24 * 3600e3));
    const k = ep || "x";
    vivi[k] = { ts: Date.now(), ids: [...new Set([...((vivi[k] && vivi[k].ids) || []), ...ids])].slice(-80) };
    store.set("refVisti.v1", vivi);
  }
  function bufB64(buf) {
    const by = new Uint8Array(buf);
    let s = "";
    for (let i = 0; i < by.length; i += 0x8000) s += String.fromCharCode.apply(null, by.subarray(i, i + 0x8000));
    return btoa(s);
  }

  function pdfCandidates(text) {
    const out = [], seen = new Set();
    const push = (raw) => {
      const u = String(raw || "").trim().replace(/&amp;/gi, "&");
      if (!u || u.length < 8 || seen.has(u)) return;
      if (/^(javascript:|#|data:|blob:|mailto:)/i.test(u)) return;
      // must look like a whole URL, not a fragment of one being concatenated
      if (!/^(https?:)?\/|^[\w.-]+\.(?:do|rra2|pdf|jsp)\b/i.test(u)) return;
      if (/[([+=&%]$|%27$/.test(u)) return;
      if (!PDF_SMELL.test(u)) return;
      seen.add(u); out.push(u);
    };
    for (const re of [/"([^"<>\n\r]{8,1200})"/g, /'([^'<>\n\r]{8,1200})'/g]) {
      for (const m of text.matchAll(re)) push(m[1]);
    }
    return out.slice(0, 4);
  }

  const isPdfBlob = (b) => b instanceof Blob && b.size > 4 &&
    (b.type.includes("pdf") || b.type === "" || b.type.includes("octet") || b.type.includes("download"));

  // Raised when an endpoint is a client-side VIEWER we can't safely turn into
  // a Blob (see note below). Carries the URL so the caller opens it natively.
  class ViewerError extends StopError {
    constructor(url) { super("È un visualizzatore, non un PDF diretto"); this.viewerUrl = url; }
  }

  // WHY WE DON'T HARVEST THE VIEWER'S BLOB
  // --------------------------------------
  // SA4PSO's label/referto endpoints are HTML pages whose own script builds
  // the PDF and navigates the tab to a blob: URL. Capturing that Blob from a
  // hidden iframe is not safely possible against an unknown viewer:
  //   - a SANDBOXED iframe that navigates to blob: becomes an OPAQUE origin →
  //     we can't read its location or fetch its Blob (verified);
  //   - a NON-sandboxed iframe can read it, but a framebusting viewer would
  //     navigate the doctor's whole tab away (verified — unacceptable).
  // So we only handle PDFs we can get SAFELY: a direct application/pdf
  // response, or a viewer that builds the Blob INLINE in its first document
  // (caught by a short sandboxed replay, which never navigates). Anything else
  // is opened natively in a new tab — exactly the manual fallback the doctor
  // asked for. This never hangs and never hijacks the page.
  let harvestSeq = 0;
  function harvestInlinePdf(url, { html, baseUrl, signal, timeoutMs = 6000 } = {}) {
    return new Promise((resolve, reject) => {
      const cb = `__psaH${++harvestSeq}`;
      const iframe = document.createElement("iframe");
      iframe.setAttribute("sandbox", "allow-scripts allow-same-origin"); // no top-nav: framebusters are inert
      iframe.style.cssText = "position:fixed;width:2px;height:2px;left:-9999px;top:-9999px;visibility:hidden";
      let done = false;
      const finish = (fn, v) => {
        if (done) return;
        done = true;
        clearTimeout(tt); clearInterval(iv);
        window.removeEventListener("message", onMsg);
        signal?.removeEventListener("abort", onAbort);
        iframe.remove();
        fn(v);
      };
      if (signal?.aborted) return finish(reject, new DOMException("Aborted", "AbortError"));
      const onAbort = () => finish(reject, new DOMException("Aborted", "AbortError"));
      signal?.addEventListener("abort", onAbort, { once: true });
      const tt = setTimeout(() => finish(reject, new ViewerError(url)), timeoutMs);
      const onMsg = (e) => {
        const d = e.data;
        if (!d || d.__psassist !== cb) return;
        if (isPdfBlob(d.blob)) return finish(resolve, { blob: d.blob, url });
        if (typeof d.nav === "string" && d.nav) {
          let u;
          try { u = new URL(d.nav, baseUrl || url); } catch { return; }
          if (u.origin !== location.origin || u.href === (baseUrl || url)) return; // never leave the hospital
          fetch(u.href, { credentials: "same-origin", cache: "no-store" })
            .then((r) => (r.ok ? r.blob() : null))
            .then((blob) => { if (isPdfBlob(blob)) finish(resolve, { blob, url }); })
            .catch(() => {});
        }
      };
      window.addEventListener("message", onMsg);
      document.documentElement.appendChild(iframe);
      // Hook createObjectURL BEFORE the replayed markup runs; postMessage
      // crosses the MV3 isolated world and Blobs survive the structured clone.
      // Prelude + a bounded rewrite of the viewer's own script, so that inside
      // the replay a navigation INTENT (location.replace/assign/href) is handed
      // to us as a URL instead of being attempted, and any Blob it builds is
      // handed over the moment it is created. Both cover viewers that assemble
      // their pdf URL piece by piece.
      const CB = JSON.stringify(cb);
      // Il visualizzatore replicato deve sapere DOV'È. Il suo script gira in
      // una cornice che non ha il suo indirizzo, quindi un visualizzatore che
      // costruisce l'indirizzo del PDF dalla propria query string leggeva la
      // nostra: non trovava niente, e si finiva sul ripiego manuale. Qui non
      // si inventa nessun indirizzo — si toglie una bugia che avevamo messo
      // noi: l'indirizzo che gli si dà è il suo, quello che il medico ha
      // aperto. L'indirizzo del PDF continua a calcolarselo lui.
      const suo = (() => { try { return new URL(baseUrl || url, location.href); } catch { return null; } })();
      const LOC = JSON.stringify(suo ? {
        href: suo.href, search: suo.search, pathname: suo.pathname, origin: suo.origin,
        protocol: suo.protocol, host: suo.host, hostname: suo.hostname, port: suo.port, hash: suo.hash,
        toString: undefined,
      } : {});
      const prelude = `<script>(function(){
        window.__psaLoc = ${LOC};
        window.__psaLoc.toString = function(){ return this.href || ""; };
        function nav(u){ try { parent.postMessage({ __psassist: ${CB}, nav: String(u) }, "*"); } catch (e) {} }
        window.__psaNav = nav;
        try { Object.defineProperty(window, "__psaNavHref", { set: nav, get: function(){ return ""; } }); } catch (e) {}
        function hb(b){ try { if (b instanceof Blob) parent.postMessage({ __psassist: ${CB}, blob: b }, "*"); } catch (e) {} }
        var wo = window.open;
        window.open = function(u){ if (u) nav(u); return { closed: false, close: function(){}, focus: function(){}, document: {} }; };
        var m = window.URL.createObjectURL.bind(window.URL);
        window.URL.createObjectURL = function(b){ hb(b); return m(b); };
        if (window.webkitURL && window.webkitURL.createObjectURL) {
          var wm = window.webkitURL.createObjectURL.bind(window.webkitURL);
          window.webkitURL.createObjectURL = function(b){ hb(b); return wm(b); };
        }
      })();<\/script>`;
      // `location` va riconosciuto SOLO quando è quello globale: preceduto da
      // niente, o da window/self/top/parent/document. Con un prefisso
      // facoltativo «a.location.search» diventava «a.__psaLoc.search», cioè un
      // errore dentro lo script del visualizzatore — che moriva lì.
      const LOCRE = "(?:\\b(?:window|self|top|parent|document)\\s*\\.\\s*|(?<![.\\w$]))location";
      const PROPS = "href|search|pathname|hostname|host|origin|protocol|port|hash";
      const patched = String(html || "")
        .replace(new RegExp(`${LOCRE}\\s*\\.\\s*(?:replace|assign)\\s*\\(`, "g"), "__psaNav(")
        // una SCRITTURA su una qualunque parte dell'indirizzo è una navigazione:
        // prima solo «.href =» era riconosciuta, e «.search = …» finiva fra le
        // letture, cioè spariva senza che nessuno se ne accorgesse
        .replace(new RegExp(`${LOCRE}\\s*\\.\\s*(?:${PROPS})\\s*(?:\\+)?=(?!=)`, "g"), "__psaNavHref =")
        .replace(new RegExp(`\\b(?:window|self|top)\\s*\\.\\s*location\\s*=(?!=)`, "g"), "__psaNavHref =")
        // quello che resta sono LETTURE: codice che vuole sapere dove si trova
        .replace(new RegExp(`${LOCRE}\\s*\\.\\s*(${PROPS})\\b`, "g"), "__psaLoc.$1");
      const idoc = iframe.contentDocument;
      idoc.open();
      idoc.write(prelude + `<base href="${esc(baseUrl || url)}">` + patched);
      idoc.close();
      const grab = (u, opts) => fetch(u, opts).then((r) => (r.ok ? r.blob() : null))
        .then((blob) => { if (isPdfBlob(blob)) finish(resolve, { blob, url }); }).catch(() => {});
      const iv = setInterval(() => {
        try {
          const w = iframe.contentWindow;
          // (a) the viewer navigated the frame to its real pdf endpoint —
          //     same-origin, so readable (a blob: target would be opaque and
          //     is caught by the createObjectURL hook above instead)
          const href = w && w.location ? w.location.href : "";
          if (href && href.startsWith(location.origin)) {
            return grab(href, { credentials: "same-origin", cache: "no-store" });
          }
          // (b) or embedded the pdf inside its own document
          const el = w?.document?.querySelector('embed[src^="blob:"],iframe[src^="blob:"],object[data^="blob:"]');
          const b = el && (el.getAttribute("src") || el.getAttribute("data"));
          if (b) return grab(b);
        } catch { /* transiently inaccessible (cross-doc or opaque) */ }
      }, 150);
    });
  }

  // Get a PDF SAFELY, or throw ViewerError(url) so the caller opens it in a
  // tab. Same origin/timeout guards as fetchDoc.
  // Un prelievo letto dalla finestra Risultati del gestionale, messo nella
  // stessa forma della tabella del portale: una colonna (la sua data e ora) e
  // una riga per analita. Così la scheda del paziente è una sola, alimentata
  // da tutt'e due le finestre — comprese quelle ancora PARZIALI, che restano
  // marcate come tali.
  // La finestra Risultati porta TUTTA la richiesta («PT, PTT POC, EMOCROMO
  // URGENTE»): un valore va attribuito al SUO esame dentro il pacchetto, o
  // due richieste che differiscono per un esame in più segnerebbero come
  // «fatta con un'altra macchina» ogni riga. Si sceglie l'esame che parla
  // della stessa sezione dell'analita; se non è uno solo, resta il pacchetto.
  const ESAME_DI = {
    "Emocromo": /EMOCROM|EMOCITOM/i,
    "Coagulazione": /\bPT\b|\bPTT\b|\bINR\b|FIBRIN|D.?DIM|COAGUL|ANTITROMB/i,
    "Biochim": /\bPCR\b|PROTEINA C|PROCALC|\bPCT\b|\bVES\b|TROPON|BNP|\bCPK\b|CK.?MB|MIOGLOB|\bLDH\b/i,
    "Organi": /CREATININ|AZOT|\bUREA\b|\bAST\b|\bALT\b|TRANSAMIN|\bGGT\b|GAMMA.?GT|γ.?GT|FOSFATASI|BILIRUB|AMILAS|LIPAS|ALBUMIN|AMMON/i,
    "Elettroliti e metabolismo": /SODIO|POTASSIO|CLORO|CALCIO|MAGNESIO|ELETTROL|GLUC|GLICEM|GLICAT|HBA1C|\bTSH\b/i,
    "Emogas": /EMOGAS|\bEGA\b/i,
    "Urine e altri liquidi": /URIN|LIQU|STICK/i,
  };
  // PT e PTT viaggiano quasi sempre insieme: la sezione non basta a dire
  // quale dei due è il SUO, la sigla sì.
  const ESAME_DI_SIGLA = {
    PT: /\bPT\b|PROTROMB/i, INR: /\bPT\b|PROTROMB|\bINR\b/i, PTT: /\bPTT\b|TROMBOPLASTINA/i, Fib: /FIBRIN/i, DD: /D.?DIM/i,
  };
  function esameDiRiga(exams, label, nome) {
    // un tampone o una PCR virale non fanno valori di chimica: fuori dai candidati
    const tutti = (Array.isArray(exams) ? exams : []).map((x) => String(x || "").replace(/\s+/g, " ").trim())
      .filter((x) => x && !/TAMPONE|MOLECOL|SARS|COV|VIRUS|ANTIGEN/i.test(x));
    const pacchetto = String(label || "").replace(/\s+/g, " ").trim();
    if ((Array.isArray(exams) ? exams.length : 0) < 2) return pacchetto;
    // cK+, cNa+, ctHb, cGlu, cLac, Hctc… sono i nomi dell'emogasanalizzatore:
    // in un pacchetto con l'emocromo e l'EGA, quei valori sono dell'EGA
    if (/^c(?:K|Na|Ca|Cl|Glu|Lac|tHb|HCO3|tCO2|tO2|Base|Crea|Urea)(?![a-z])|^Hctc\b|^[as]BE\b/.test(String(nome || "").trim())) {
      const ega = tutti.filter((x) => eEga(x));
      if (ega.length === 1) return ega[0];
    }
    const sg = sigla(nome);
    for (const re of [ESAME_DI_SIGLA[sg], ESAME_DI[sezioneDi(sg)[0]]]) {
      const miei = re ? tutti.filter((x) => re.test(x)) : [];
      if (miei.length === 1) return miei[0];
    }
    return pacchetto;
  }

  function prelievoComeTabella(meta, rows, cf, scartate = []) {
    // La colonna vuole giorno E ora completi: «10/07 22:23» come lo scrive
    // la lista Esiti non dice l'anno, e sia il confronto con «oggi» sia
    // l'ordine fra le colonne si fanno sulla data intera. L'istante della
    // richiesta (DATA_ORD, tenuto come ore UTC) ce l'ha tutta.
    const pad = (n) => String(n).padStart(2, "0");
    const m = DATA_ORA.exec(String(meta?.when || ""));
    const t = !m && meta?.ts ? new Date(meta.ts) : null;
    const data = m ? m[1] : t ? `${pad(t.getUTCDate())}/${pad(t.getUTCMonth() + 1)}/${t.getUTCFullYear()}` : String(meta?.when || "").trim();
    const ora = m ? (m[2] || "") : t ? `${pad(t.getUTCHours())}:${pad(t.getUTCMinutes())}` : "";
    const label = [data, ora].filter(Boolean).join(" ");
    if (!rows || !rows.length) return null;
    // Senza data il prelievo NON sparisce: diventa una colonna «?». Un valore
    // che il medico vede, con l'ora dichiarata ignota, vale infinitamente più
    // di un valore buttato via in silenzio. L'accesso fa da identità, così due
    // prelievi senza ora restano due colonne e non si fondono.
    const ignota = !label;
    const id = String(meta?.id || "");
    // il titolo della richiesta viaggia con la colonna: in tabella lo dice il
    // tooltip dell'intestazione, e non serve più una riga per prelievo
    const date = [{
      data, ora, ignota, id,
      label: label || "?",
      chiave: ignota ? "?#" + (id || Math.random().toString(36).slice(2)) : label + "#1",
      titolo: String(meta?.label || "").replace(/\s+/g, " ").trim(),
    }];
    const righe = rows.filter((r) => r.nome && String(r.valore).trim()).map((r, i) => ({
      nome: String(r.nome).replace(/\s+/g, " ").trim(),
      esame: esameDiRiga(meta?.exams, meta?.label, r.nome),
      codice: "", mnem: "", pos: i,
      valori: [{
        v: String(r.valore).trim(), stato: outOfRange(r.valore, r.range),
        um: String(r.um || "").trim(), range: String(r.range || "").trim(),
        parziale: /parz/i.test(r.stato || ""),
      }],
    }));
    if (!righe.length) return null;
    return { paziente: { idMPI: "", cognome: "", nome: nomeInPagina() },
             // le righe che il lettore ha rifiutato viaggiano con la tabella:
             // in Esiti si devono vedere, non solo nella finestra di origine
             cf: cf || "", periodo: "", date, righe,
             scartate: (scartate || []).filter((x) => x && x.nome).slice(0, 40), letto: Date.now() };
  }

  // ------------------------------------------------------- STORICO (portale clinico)
  // "Storico dati clinici" draws the multi-day table as TWO tables side by
  // side: a frozen left one with the exam names, a scrollable right one with
  // one column per draw, row-aligned by position. Nothing is asked of the
  // server here — this reads the table the doctor already has on screen.
  const STORICO_SX = ".clinical-data-table__freeze-container-left table";
  const STORICO_DX = ".clinical-data-table__freeze-container-right table";
  const DATA_ORA = /\b(\d{2}\/\d{2}\/\d{4})(?:\s+(\d{2}:\d{2}))?/;

  function haStorico(doc) { return !!(doc.querySelector(STORICO_SX) && doc.querySelector(STORICO_DX)); }

  // Both tooltips open with an identifier and " - ": the exam one with the
  // catalogue code ("1583 - ALT TRANSAMINASI", "ABC1234 - …"), the specific
  // one with the LIS mnemonic ("ALT - S-ALT (…)", "LINF% - …", "HbA1c - …").
  function primoToken(t) {
    const m = /^\s*([A-Za-z0-9][A-Za-z0-9%._/-]{0,23})\s+-\s+/.exec(String(t || ""));
    return m ? m[1] : "";
  }
  function pezziTooltip(t) {
    const tok = primoToken(t);
    // a code has a number in it: a bare word is a name, and naming it "code"
    // would be a made-up identifier
    const codice = /\d/.test(tok) ? tok : "";
    const resto = tok ? String(t).slice(String(t).indexOf(tok) + tok.length).replace(/^\s*-\s*/, "") : String(t || "");
    return { codice, nome: resto.trim() };
  }
  const mnemonicoStorico = (t) => primoToken(t);

  function leggiStorico(doc) {
    const sx = doc.querySelector(STORICO_SX), dx = doc.querySelector(STORICO_DX);
    if (!sx || !dx) return null;
    // The two tables are one table cut in half: if they ever stop lining up,
    // a value would land on the wrong exam. Then we read nothing at all.
    if (sx.rows.length !== dx.rows.length) return null;

    // Two draws can carry the SAME date and time — a POC and the central lab
    // drawn together is an ordinary morning here — so a column's identity is
    // not its label: each gets an occurrence key, or merging two reads would
    // pour one draw's values into the other's empty cells.
    const date = [], visti = new Map();
    for (const th of dx.rows[0] ? dx.rows[0].cells : []) {
      const m = DATA_ORA.exec((th.textContent || "").replace(/\s+/g, " "));
      if (!m) { date.push(null); continue; }
      const label = m[1] + (m[2] ? " " + m[2] : "");
      const n = (visti.get(label) || 0) + 1;
      visti.set(label, n);
      date.push({ data: m[1], ora: m[2] || "", label, chiave: label + "#" + n });
    }
    if (!date.some(Boolean)) return null;

    const righe = [], scartate = [];
    const nCol = dx.rows[0] ? dx.rows[0].cells.length : 0;
    for (let i = 1; i < sx.rows.length; i++) {
      const tdE = sx.rows[i].querySelector("td.exam");
      if (!tdE) continue;                                   // header and filler rows
      // The LEFT column is the ordered exam ("ESAME URINE COMPLETO"), the one
      // next to it is the analyte ("U-Albumina", "S-ALT"): a panel repeats the
      // same exam on every one of its rows, so the analyte is the name — and
      // its specimen prefix (U-, S-) stays, because U-Emoglobina is not Hb.
      const esame = (tdE.textContent || "").replace(/\s+/g, " ").trim();
      const tdS = sx.rows[i].querySelector("td.exam-specific");
      const spec = tdS ? tdS.querySelector("[uib-tooltip]") : null;
      const nome = (tdS?.textContent || "").replace(/\s+/g, " ").trim() || esame;
      if (!nome) continue;
      const { codice } = pezziTooltip(tdE.querySelector("[uib-tooltip]")?.getAttribute("uib-tooltip"));
      const mnem = mnemonicoStorico(spec?.getAttribute("uib-tooltip"));
      const valori = [];
      const celle = dx.rows[i] ? dx.rows[i].cells : [];
      // one cell per column, or the values would slide under the wrong draw:
      // a row that does not line up is left out AND declared, never guessed
      if (celle.length !== nCol) { scartate.push({ nome, valore: "riga fuori colonna" }); continue; }
      for (let c = 0; c < date.length; c++) {
        if (!date[c]) continue;
        const d = celle[c] ? celle[c].querySelector(".exam-value") : null;
        const v = d ? (d.textContent || "").replace(/\s+/g, " ").trim() : "";
        // the page already knows what is out of range: SUP above, INF below
        const stato = !v || !d.classList.contains("out-of-range") ? 0
          : d.classList.contains("SUP") ? 1 : d.classList.contains("INF") ? -1 : 0;
        valori.push({ v, stato });
      }
      if (valori.some((x) => x.v)) righe.push({ nome, esame, codice, mnem, pos: i, valori });
    }
    if (!righe.length) return null;

    // who this table belongs to — a value under the wrong name is the worst
    // thing this program could do, so the identity travels WITH the values
    const testa = [...doc.querySelectorAll(".panel-heading, app-root-selected-anagrafe")]
      .map((e) => (e.textContent || "").replace(/\s+/g, " ")).find((t) => /idMPI/i.test(t)) || "";
    // "Nome" must not match inside "Cognome": the label starts a word
    // The heading is one line of "Etichetta: valore" pairs. Cutting it on the
    // labels we know is the only way to keep a two-word name whole: a generic
    // "up to the next word with a colon" stops at the first space, turning
    // "MARIA ANNA" into "MARIA" — the name of a different patient.
    const campi = new Map();
    for (const pezzo of testa.split(/\s+(?=(?:idMPI|Cognome|Nome|Sesso|Data di nascita|Data nascita)\s*:)/i)) {
      const m = /^\s*([A-Za-z ]+?)\s*:\s*(.*)$/.exec(pezzo);
      if (m) campi.set(m[1].toLowerCase(), m[2].trim());
    }
    const campo = (k) => campi.get(k.toLowerCase()) || "";
    const periodo = [...doc.querySelectorAll(".panel-heading")]
      .map((e) => (e.textContent || "").replace(/\s+/g, " ").trim())
      .find((t) => /^Tabella esami periodo/i.test(t)) || "";

    return normalizzaStorico({
      paziente: { idMPI: campo("idMPI"), cognome: campo("Cognome"), nome: campo("Nome") },
      cf: cfImpronta(doc),
      periodo, date: date.filter(Boolean), righe, scartate, letto: Date.now(),
    });
  }

  // Two reads of the same table can show different draws: the portal only
  // renders the columns in view. Merging by (esame, data) means scrolling the
  // period ADDS draws instead of replacing them.
  // Scrivere nella scheda clinica del paziente SENZA cancellare quello che
  // c'è: si legge, si fonde, si riscrive dicendo da quale revisione si è
  // partiti. Se un'altra scrittura è passata nel mezzo, si rilegge e si
  // rifonde. Prima si scriveva e basta: la tabella del portale arrivata dopo i
  // Risultati si portava via i prelievi letti e i referti salvati.
  async function mettiInScheda(chiave, nuovo, fondi = unisciStorico) {
    for (let i = 0; i < 4; i++) {
      const gia = await ask({ t: "getStorico", chiave });
      const vecchio = gia && gia.ok ? gia.dati : null;
      const r = await ask({ t: "putStorico", chiave, dati: fondi(vecchio, nuovo), base: (vecchio && vecchio.rev) || 0 });
      if (!r || !r.conflitto) return r || { ok: false };
    }
    return { ok: false };
  }

  function unisciStorico(vecchio, nuovo) {
    if (!vecchio || !nuovo) return nuovo || vecchio || null;
    // Un altro paziente: si ricomincia. Il nome NON basta a dire «è lo
    // stesso»: sul portale si passa da un omonimo all'altro senza ricaricare
    // la pagina, e due persone con lo stesso nome finirebbero in un unico
    // grafico. Quindi devono combaciare il codice fiscale E il nome, e
    // un'identità che non si è potuta leggere conta come un altro paziente.
    if (!stessoPaziente(vecchio.paziente, nuovo.paziente)) return nuovo;
    // Due codici fiscali che non si sono potuti leggere NON sono lo stesso
    // codice fiscale: "" === "" è vero per JavaScript, non per due persone.
    // Senza questa riga due omonimi senza codice finivano in un grafico solo.
    if (!vecchio.cf || !nuovo.cf || vecchio.cf !== nuovo.cf) return nuovo;
    return fondiStorico(vecchio, nuovo);
  }
  // La fusione vera e propria, SENZA il cancello d'identità: la usa chi sa già
  // che le due tabelle sono dello stesso paziente — i prelievi letti in questa
  // scheda del browser sono tutti della pagina aperta.
  function fondiStorico(vecchio, nuovo) {
    if (!vecchio || !nuovo) return nuovo || vecchio || null;
    const date = [...vecchio.date];
    // Due prelievi allo stesso minuto (POC e laboratorio centrale: una
    // mattina qualunque) NON sono lo stesso prelievo: se l'accesso è un
    // altro, la colonna è un'altra e prende il primo numero libero. Senza
    // accesso (la tabella del portale) vale la chiave com'è.
    const rinomina = new Map();
    for (const d of nuovo.date) {
      const k = chiaveCol(d);
      const gia = date.find((x) => chiaveCol(x) === k);
      if (!gia) { date.push(d); continue; }
      if (!d.id || !gia.id || d.id === gia.id) continue;
      const stesso = date.find((x) => x.id && x.id === d.id);
      if (stesso) { rinomina.set(k, chiaveCol(stesso)); continue; }
      let n = 2;
      while (date.some((x) => chiaveCol(x) === d.label + "#" + n)) n++;
      const nuova = { ...d, chiave: d.label + "#" + n };
      date.push(nuova); rinomina.set(k, nuova.chiave);
    }
    date.sort((a, b) => ordData(a.label) - ordData(b.label));   // stable: same minute keeps its order
    const perEsame = new Map();
    const versa = (dati, mappa) => {
      const colDi = (d) => (mappa && mappa.get(chiaveCol(d))) || chiaveCol(d);
      const qui = new Map();   // chiave → { nome, celle }, dentro QUESTA tabella
      for (const r of dati.righe) {
        // HB is both blood haemoglobin and the urine dipstick: the analyte
        // alone is not an identity, the ordered exam is part of it
        // La chiave di una riga è l'ANALITA, la stessa identità che il
        // programma usa già per dire «è lo stesso esame» fra due prelievi.
        // Così l'emoglobina letta dalla finestra Risultati del gestionale e
        // quella della tabella del portale finiscono nella stessa riga,
        // invece di diventarne due. Quando l'analita non c'è (il nome ricade
        // sulla prestazione) solo la posizione distingue le righe.
        const anonima = !r.mnem && r.nome === r.esame;
        const base = valKey(r.nome) + (anonima ? "|#" + (r.pos ?? 0) : "");
        // L'emogas fa riga a sé (vedi eEga). Si decide valore per valore: una
        // tabella salvata prima di questa regola può avere nella stessa riga
        // valori dell'emocromo e dell'emogas — qui si separano.
        const gruppi = new Map();   // chiave → indici dei valori
        r.valori.forEach((v, i) => {
          if (!(v && v.v && dati.date[i])) return;
          const kv = base + (eEga(v.esame || r.esame) ? "|ega" : "");
          if (!gruppi.has(kv)) gruppi.set(kv, []);
          gruppi.get(kv).push(i);
        });
        if (!gruppi.size) gruppi.set(base + (eEga(r.esame) ? "|ega" : ""), []);
        for (const [k0, idx] of gruppi) {
          let k = k0;
          // due righe della stessa tabella con la stessa chiave (S-Sodio e
          // P-Sodio, o lo stesso nome due volte nello stesso prelievo) si
          // fondono solo se non si contraddicono: un valore non ne copre mai
          // un altro
          const gia = qui.get(k);
          if (gia && idx.some((i) => gia.celle.has(colDi(dati.date[i])) && gia.celle.get(colDi(dati.date[i])) !== r.valori[i].v)) {
            k += gia.nome !== r.nome ? "|" + r.nome : "|#" + (r.pos ?? 0);
          }
          const mio = qui.get(k) || { nome: r.nome, celle: new Map() };
          idx.forEach((i) => mio.celle.set(colDi(dati.date[i]), r.valori[i].v));
          qui.set(k, mio);
          const primo = idx.length ? r.valori[idx[0]] : null;
          const cur = perEsame.get(k) || { nome: r.nome, esame: (primo && primo.esame) || r.esame, codice: r.codice, mnem: r.mnem, pos: r.pos, per: new Map() };
          // La provenienza viaggia CON il valore. Due prelievi possono aver
          // fatto lo stesso esame con macchine diverse (POC e laboratorio):
          // stessa riga, ma si deve poter dire quale cella viene da dove.
          // Una cella che sa già con cosa è stata fatta lo tiene: rifondere una
          // tabella già fusa non deve riscrivere ogni cella con l'esame della
          // riga, o la provenienza (POC vs laboratorio) sparisce alla seconda
          // passata.
          idx.forEach((i) => { const v = r.valori[i]; cur.per.set(colDi(dati.date[i]), v.esame ? v : r.esame ? { ...v, esame: r.esame } : v); });
          perEsame.set(k, cur);
        }
      }
    };
    versa(vecchio); versa(nuovo, rinomina);
    const righe = [...perEsame.values()].map((e) => ({
      nome: e.nome, esame: e.esame, codice: e.codice, mnem: e.mnem, pos: e.pos,
      valori: date.map((d) => e.per.get(chiaveCol(d)) || { v: "", stato: 0 }),
    }));
    // i referti già letti per questo paziente non si perdono in una fusione
    const referti = [...(nuovo.referti || []), ...(vecchio.referti || [])]
      .filter((r, i, a) => r && r.id && a.findIndex((x) => x.id === r.id) === i).slice(0, 40);
    // Chi arriva dopo con meno non cancella quello che c'era: un prelievo dei
    // Risultati non ha il periodo del portale, e ha il nome solo come titolo
    // di pagina. L'identità strutturata (cognome/nome del portale) resta —
    // mai mescolata campo per campo, o «ROSSI» + «ROSSI MARIO» diventerebbe
    // un terzo nome che non combacia più con nessuno.
    const strutturata = (p) => !!(p && (p.cognome || p.idMPI));
    const paziente = strutturata(vecchio.paziente) && !strutturata(nuovo.paziente) ? vecchio.paziente : nuovo.paziente;
    return { paziente, cf: nuovo.cf || vecchio.cf || "",
             ep: nuovo.ep || vecchio.ep || "", nomeSa4: nuovo.nomeSa4 || vecchio.nomeSa4 || "",
      periodo: nuovo.periodo || vecchio.periodo || "", date, righe, referti,
             // le stesse righe rifiutate arrivano da tutt'e due i lati quando
             // una tabella viene rifusa: una volta sola
             scartate: [...(vecchio.scartate || []), ...(nuovo.scartate || [])]
               .filter((x, i, a) => x && a.findIndex((y) => y && y.nome === x.nome && y.valore === x.valore) === i).slice(0, 40),
             letto: Date.now() };
  }
  // Una tabella passa per la fusione anche da sola, appena letta e prima di
  // mostrarla: così le colonne vanno sempre in ordine di tempo (il portale le
  // può dare dalla più recente, e «ultimo» finiva sul prelievo più vecchio),
  // lo stesso analita ripetuto da due prestazioni è una riga sola, e una
  // scheda salvata prima che l'emogas avesse righe sue si divide.
  function normalizzaStorico(st) {
    return st ? fondiStorico(st, { ...st, righe: [], date: [], referti: [], scartate: [] }) : null;
  }
  const chiaveCol = (d) => (d && (d.chiave || d.label)) || "";
  const ordData = (label) => {
    const m = /(\d{2})\/(\d{2})\/(\d{4})(?:\s+(\d{2}):(\d{2}))?/.exec(label || "");
    return m ? Date.UTC(+m[3], +m[2] - 1, +m[1], +(m[4] || 0), +(m[5] || 0)) : 0;
  };
  // names as the two systems write them: "ROSSI MARIO" in SA4PSO's title,
  // Cognome + Nome on the portal. Only those two ORDERS are accepted: sorting
  // the words would make "MARINO BRUNO" and "BRUNO MARINO" the same person,
  // and that check is the only thing standing between one patient's lab table
  // and another patient's screen.
  const normNome = (t) => String(t || "").toUpperCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^A-Z0-9 ]+/g, " ").trim().replace(/\s+/g, " ");
  const chiavePaziente = (p) => normNome([p?.cognome, p?.nome].filter(Boolean).join(" "));
  // La scheda di un paziente nell'archivio: il codice fiscale quando c'è (è
  // l'unica identità che non si può confondere), altrimenti il nome.
  const chiaveArchivio = (d) => (d?.cf ? "cf:" + d.cf : "nome:" + chiavePaziente(d?.paziente));
  // Il gestionale scrive il nome come una stringa sola («ROSSI MARIO» o
  // «MARIO ROSSI», a seconda del presidio), il portale lo dà separato: si
  // accettano i due ordini, mai le parole mescolate.
  function stessoPaziente(a, b) {
    const ka = chiavePaziente(a), kb = chiavePaziente(b);
    if (!ka || !kb) return false;
    if (ka === kb) return true;
    return (!a?.cognome && combaciaNome(a?.nome, b)) || (!b?.cognome && combaciaNome(b?.nome, a));
  }
  // SA4PSO scrive il nome come una stringa sola, il portale lo dà già
  // separato: da lì l'ordine delle due parole non si può dedurre. Ma
  // entrambi i sistemi scrivono anche il CODICE FISCALE — il portale nel
  // titolo, il gestionale accanto al nome nella finestra Risultati, che il
  // pannello legge già per i valori. Quello è un identificativo unico: dove
  // c'è, decide lui. Ne teniamo solo l'IMPRONTA, mai il codice in chiaro.
  const CF_RE = /\b[A-Z]{6}\d{2}[A-Z]\d{2}[A-Z]\d{3}[A-Z]\b/g;
  function cfPagina(doc) {
    const testo = ((doc.title || "") + " " + (doc.body?.textContent || "")).toUpperCase();
    const trovati = [...new Set(testo.match(CF_RE) || [])];
    return trovati.length === 1 ? trovati[0] : "";   // più di uno: non sappiamo quale
  }
  const cfImpronta = (doc) => { const c = cfPagina(doc); return c ? impronta(c) : ""; };

  // Il codice fiscale è più forte del nome, ma le due prove non devono
  // potersi CONTRADDIRE: un codice che combacia accanto a un nome che non
  // ha niente in comune è un segnale che qualcosa non torna, non un via
  // libera. Basta una parola in comune (il titolo può portare altro).
  function nomiCompatibili(titolo, p) {
    const a = normNome(titolo).split(" ").filter((x) => x.length >= 3);
    const b = normNome([p?.cognome, p?.nome].filter(Boolean).join(" ")).split(" ").filter((x) => x.length >= 3);
    if (!a.length || !b.length) return true;          // uno dei due non è leggibile
    return a.some((x) => b.includes(x));
  }
  // Fra le schede in archivio, quella di questo paziente. DUE PASSATE, non
  // una decisione per candidato: se esiste una scheda col codice fiscale di
  // questo paziente è QUELLA, sempre. Si ripiega sul nome solo se nessuna
  // scheda porta un codice fiscale — altrimenti un omonimo senza codice,
  // incontrato per primo, vincerebbe su una scheda verificata col codice.
  function scegliScheda(indice, mio, titolo, ep) {
    const v = indice || [];
    // Prima di tutto: la scheda letta ARRIVANDO DA QUESTO PAZIENTE. È stato il
    // medico ad aprire il portale da questa pagina, e nessun confronto di nomi
    // può essere più sicuro di così.
    // …ma il clic non può CONTRADDIRE le altre prove: sul portale si passa
    // da un omonimo all'altro senza ricaricare, e la scheda arrivata da quel
    // clic può essere di un altro ROSSI MARIO. Con un codice fiscale diverso
    // o un nome che non c'entra, il clic non conta.
    if (ep) {
      const suo = v.find((x) => x.ep && String(x.ep) === String(ep)
        && (!mio || !x.cf || x.cf === mio) && nomiCompatibili(titolo, x.paziente));
      if (suo) return suo;
    }
    // Se di questo paziente conosciamo il codice fiscale, decide SOLO quello:
    // niente ripieghi sul nome, perché una scheda senza codice col suo stesso
    // nome può essere di un omonimo.
    if (mio) return v.find((x) => x.cf === mio && nomiCompatibili(titolo, x.paziente)) || null;
    // Se non lo conosciamo ancora, si può andare solo per nome — ma allora si
    // guarda solo fra le schede che un codice non ce l'hanno: una scheda che
    // porta un codice non si può attribuire a un paziente di cui non ne
    // sappiamo nessuno.
    return v.find((x) => !x.cf && combaciaNome(titolo, x.paziente)) || null;
  }
  function combaciaNome(titolo, p) {
    const t = normNome(titolo);
    const c = normNome(p?.cognome), n = normNome(p?.nome);
    if (!t || (!c && !n)) return false;
    const dritto = [c, n].filter(Boolean).join(" ");
    const rovescio = [n, c].filter(Boolean).join(" ");
    return t === dritto || t === rovescio;
  }

  // ------------------------------------------------------- RISULTATI MODEL
  // While a lab request is still being reported, the patient page shows a
  // coloured icon that pops up RcsAccessiRisultatiElenco.do — plain HTML on
  // THIS origin, so the values can be read and shown inside the panel.
  // QUANDO è stato fatto un prelievo. SA4PSO lo scrive in un campo nascosto
  // della riga (DATA_ORD) come «yyyy-mm-dd HH:MM», ma un presidio può averlo
  // in un'altra forma, e senza un istante un prelievo non può diventare una
  // colonna. Si accettano le forme che NON sono ambigue; il giorno prima del
  // mese perché questo programma gira in un ospedale italiano, dove così è
  // scritto anche a video. Tutto il resto si rifiuta invece di indovinare.
  function istanteDa(grezzo) {
    const s = String(grezzo || "").trim();
    const fatto = (a, me, g, h, mi) => ({ ts: Date.UTC(a, me - 1, g, h, mi), when: `${String(g).padStart(2, "0")}/${String(me).padStart(2, "0")} ${String(h).padStart(2, "0")}:${String(mi).padStart(2, "0")}` });
    let m = /^(\d{4})-(\d{1,2})-(\d{1,2})[ T](\d{1,2})[:.](\d{2})/.exec(s);
    if (m) return fatto(+m[1], +m[2], +m[3], +m[4], +m[5]);
    m = /^(\d{1,2})[/-](\d{1,2})[/-](\d{2}|\d{4})[ ,T]+(\d{1,2})[:.](\d{2})/.exec(s);
    if (m) return fatto(m[3].length === 2 ? 2000 + +m[3] : +m[3], +m[2], +m[1], +m[4], +m[5]);
    m = /^(\d{4})(\d{2})(\d{2})[ T]?(\d{2})(\d{2})/.exec(s);
    if (m) return fatto(+m[1], +m[2], +m[3], +m[4], +m[5]);
    return null;
  }
  // La data della riga, presa dalla riga: prima il campo nascosto, e se non
  // c'è (o è scritto in un modo mai visto) la cella che il medico ha davanti.
  // Non si costruisce niente: si legge quello che la pagina mostra già.
  function istanteRiga(tr) {
    const campo = tr?.querySelector('input[name="DATA_ORD"]');
    const dal = istanteDa(campo ? campo.value : "");
    if (dal) return { ...dal, via: "campo" };
    for (const td of tr?.querySelectorAll(":scope > td") || []) {
      const t = istanteDa(td.textContent.replace(/\s+/g, " ").trim());
      if (t) return { ...t, via: "cella" };
    }
    return null;
  }

  function risultatiModel(doc, baseUrl) {
    const out = [], seen = new Set();
    for (const a of doc.querySelectorAll('a[title="Visualizza Risultati"]')) {
      const m = /window\.open\(\s*['"]([^'"]+)['"]/.exec(a.getAttribute("onclick") || "");
      if (!m) continue;
      let url;
      try { url = new URL(m[1], baseUrl).href; } catch { continue; }
      const id = param(url, "RCS_ACCESSO_ID");
      if (!id || seen.has(id)) continue;
      seen.add(id);
      const td = a.closest("td"), tr = a.closest("tr");
      const exams = (td?.getAttribute("title") || "").split(";")
        .map((x) => shortLabel(x.replace(/^\s*\d+-\d+\s*/, "")).trim()).filter(Boolean);
      const dt = istanteRiga(tr);
      out.push({ id, url, exams, ts: dt ? dt.ts : 0, when: dt ? dt.when : "", dataVia: dt ? dt.via : "" });
    }
    out.sort((a, b) => b.ts - a.ts);
    return out;
  }

  // Perché un prelievo non è diventato una colonna: l'unica risposta sta
  // nelle righe della pagina, non nel pannello. Una riga per collegamento
  // «Visualizza Risultati», con quello che c'era scritto davvero.
  function diagPrelievi(doc, baseUrl) {
    const righe = [], visti = new Set();
    for (const a of doc.querySelectorAll('a[title="Visualizza Risultati"]')) {
      const m = /window\.open\(\s*['"]([^'"]+)['"]/.exec(a.getAttribute("onclick") || "");
      const tr = a.closest("tr");
      const campo = tr?.querySelector('input[name="DATA_ORD"]');
      let id = "";
      if (m) { try { id = param(new URL(m[1], baseUrl).href, "RCS_ACCESSO_ID") || ""; } catch { /* indirizzo rotto */ } }
      const doppio = !!id && visti.has(id);
      if (id) visti.add(id);
      const dt = istanteRiga(tr);
      righe.push({
        ok: !!dt && !doppio && !!id && !!m,
        testo: `${id || "senza identificativo"}${doppio ? " (già visto: la riga si ripete)" : ""} · campo ${
          !campo ? "ASSENTE" : campo.value ? `«${String(campo.value).slice(0, 30)}»` : "vuoto"} · ${
          dt ? `letta dalla ${dt.via}: ${dt.when}` : "NESSUNA data leggibile in questa riga"}${m ? "" : " · senza collegamento"}`,
      });
    }
    return righe;
  }

  // a value outside its own reference range is worth the eye
  // Is this value outside its reference range? Returns -1 / 0 / +1.
  //
  // Laboratories write ranges in more ways than one ("4 - 10", "< 0.5",
  // "fino a 5", "> 60", "-2 - +2", "4 - 10 x10^3"), and values come with
  // modifiers ("<0.01") or as words ("NEGATIVO"). The rule here is
  // deliberately one-sided: when a format is not understood — or the range
  // depends on something we cannot know, like sex — it returns 0 and the
  // value is shown plain. Never a red mark we cannot justify.
  function outOfRange(value, range) {
    const num = (s) => {
      const m = /-?\d+(?:[.,]\d+)?/.exec(String(s));
      return m ? parseFloat(m[0].replace(",", ".")) : NaN;
    };
    const raw = String(range || "").replace(/\s+/g, " ").trim();
    const vs = String(value).replace(/\s+/g, " ").trim();
    if (!raw || !vs) return 0;
    // "M: 13-17 F: 12-16", or two ranges in one cell: which one applies is not
    // ours to guess
    if (/\b[MF]\s*[:=]/.test(raw)) return 0;
    if ((raw.match(/\s[-–]\s/g) || []).length > 1) return 0;

    const v = num(vs);
    if (!isFinite(v)) return 0;                       // NEGATIVO, Assente, tracce…
    const vLt = /^[<≤]/.test(vs), vGt = /^[>≥]/.test(vs);

    let lo = NaN, hi = NaN;
    const due = /^(-?[\d.,]+)\s*[-–]\s*([+-]?[\d.,]+)/.exec(raw);
    if (due) { lo = num(due[1]); hi = num(due[2]); }
    else if (/^[<≤]|^inf\.?\s*a\b|^fino a\b|^minore\b/i.test(raw)) hi = num(raw);
    else if (/^[>≥]|^sup\.?\s*a\b|^maggiore\b|^oltre\b/i.test(raw)) lo = num(raw);
    else return 0;
    if (!isFinite(lo) && !isFinite(hi)) return 0;
    if (isFinite(lo) && isFinite(hi) && lo > hi) return 0;   // unreadable, not a range

    if (isFinite(lo) && (v < lo || (vLt && v <= lo))) return -1;
    if (isFinite(hi) && (v > hi || (vGt && v >= hi))) return 1;
    return 0;
  }

  // Returns the value rows AND the candidate rows it refused: a row this
  // parser does not understand must become a warning, never a hole.
  function parseRisultati(doc) {
    const rows = [], scartate = [];
    for (const tr of doc.querySelectorAll("tr")) {
      // DIRECT children only: the patient header of the same table nests its own
      // tables, and cells picked up from those made a row look like a result
      const tds = [...tr.querySelectorAll(":scope > td.AFCDataTD")];
      if (tds.length < 5) continue;
      const [nome, valore, um, range, stato, data] = tds.map((t) => t.textContent.replace(/\s+/g, " ").trim());
      if (!nome || !valore) continue;
      // the same table carries the patient header (Assistito, Pronto Soccorso,
      // Quesito…): those rows have no date, no range and no state, and would
      // otherwise show up among the values as a nonsense line
      if (/^(assistito|pronto soccorso|quesito|reparto|medico|paziente|data)\b/i.test(nome)) continue;
      // A result row proves itself: a reporting date, a numeric range, or a
      // laboratory state. The header block of the same table (name, età, CF,
      // quesito) has none of the three, whichever way it is nested.
      const dataOk = /\d{1,2}\/\d{1,2}\/\d{2,4}/.test(data || "");
      const rangeOk = /\d/.test(range || "") && /[-–<>≤≥]|fino a|inf\.|sup\./i.test(range || "");
      const statoOk = /^(parziale|definitiv|refertat|eseguit|in corso|validat|preliminar|provvisori)/i.test(stato || "");
      if (!dataOk && !rangeOk && !statoOk) { scartate.push({ nome, valore }); continue; }
      rows.push({ nome, valore, um, range, stato });
    }
    return { rows, scartate };
  }

  // One chronological list of everything the lab/radiology returned for this
  // patient: values we can read (risultati) and reported documents (referti).
  // what a values row needs to exist on its own, without the page
  const risMeta = (e) => ({ id: e.id || "", url: e.url, label: e.label || "", exams: e.exams || [], when: e.when || "", ts: e.ts || 0 });

  // What a referto row is, from its own label: decides how it opens today and
  // which ones become inline text when their sources are wired (lab table, RX
  // and ECG referti). Anything else stays a document you open.
  // ------------------------------------------------------------ WORKUP
  // Quello che è stato chiesto e non è ancora refertato, dalla pagina del
  // paziente: le righe «RICH» del diario senza l'icona del referto. Chi ha la
  // finestra Risultati è un esame di laboratorio già in lavorazione (parziale).
  function richiesteInAttesa(doc) {
    const out = [];
    for (const tr of doc.querySelectorAll('tr[id="RICH"]')) {
      if (tr.querySelector('a[title="REFERTO"]')) continue;
      const icone = [...tr.querySelectorAll("img[title], a[title]")].map((x) => x.getAttribute("title") || "");
      const desc = tr.querySelector('input[name="DESCRIZIONE_TITLE"]')?.value || "";
      const esami = desc.split(";").map((x) => shortLabel(x.replace(/^\s*\d+-\d+\s*/, "")).trim()).filter(Boolean);
      if (!esami.length) continue;
      const dt = istanteRiga(tr);
      const tipo = esami.some((x) => /ELETTROCARDIOGRAMM|\bECG\b/i.test(x)) ? "ecg"
        : icone.includes("Radiologia") || esami.some((x) => /\bRX\b|RADIOGRAF|\bTC\b|\bTAC\b|ECOGRAF|RISONANZA|\bRMN\b/i.test(x)) ? "rx"
        : icone.includes("Laboratorio") ? "lab" : "altro";
      out.push({ tipo, esami, ts: dt ? dt.ts : 0, when: dt ? dt.when : "", parziale: icone.includes("Visualizza Risultati") });
    }
    return out.sort((a, b) => b.ts - a.ts);
  }
  // Da quanto aspetta: gli istanti del gestionale sono ore «di muro» scritte
  // come UTC (vedi istanteDa), e l'adesso va scritto allo stesso modo.
  function attesaDa(ts) {
    if (!ts) return "";
    const d = new Date();
    const min = Math.floor((Date.UTC(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes()) - ts) / 60e3);
    if (min < 0 || min > 48 * 60) return "";
    return min < 60 ? `${min}′` : `${Math.floor(min / 60)}h${String(min % 60).padStart(2, "0")}`;
  }
  // La data di nascita del paziente, dal riquadro in testa alla scheda
  // («17/05/1949 (77) M»): serve solo a confrontarla col referto, non si tiene.
  function nascitaInPagina(doc = document) {
    const r = riquadroPaziente(doc);
    const m = r && /\b(\d{1,2}\/\d{1,2}\/\d{4})\s*\(\d{1,3}\)/.exec((r.textContent || "").replace(/\s+/g, " "));
    return m ? m[1] : "";
  }
  // Il codice fiscale scritto nel riquadro del paziente (uno solo, o niente).
  function cfInRiquadro(doc = document) {
    const r = riquadroPaziente(doc);
    const tutti = r ? [...new Set(((r.textContent || "").toUpperCase().match(new RegExp(CF_UNO.source, "g"))) || [])] : [];
    return tutti.length === 1 ? tutti[0] : "";
  }
  // La riga in cima agli Esiti: prima i valori fuori range dell'ultimo
  // prelievo di ciascun esame (i più gravi per primi), la troponina con la
  // misura precedente e la sua ora.
  const PRIMA_DI_TUTTI = ["K", "Na", "Hb", "Trop", "Lac", "pH", "Glu", "Cr", "PLT", "INR", "GB", "PCR", "Ca++", "pCO2", "pO2", "HCO3"];
  function fuoriRangeUltimi(st) {
    if (!st || !st.righe) return [];
    const oggi = new Date();
    const gg = `${String(oggi.getDate()).padStart(2, "0")}/${String(oggi.getMonth() + 1).padStart(2, "0")}/${oggi.getFullYear()}`;
    const quando = (d) => (!d || d.ignota ? "" : d.data === gg ? d.ora || "" : `${String(d.data || "").slice(0, 5)}${d.ora ? " " + d.ora : ""}`);
    const out = [];
    for (const r of righeTabella(st.righe)) {
      let i = r.valori.length - 1;
      while (i >= 0 && !(r.valori[i] && r.valori[i].v)) i--;
      if (i < 0 || !r.valori[i].stato) continue;
      const s = siglaCurata(r.nome) ? sigla(r.nome) : String(r.nome).replace(/\s+/g, " ").trim().split(" ")[0];
      const nuda = s.replace(/^[A-Z]·/, "");
      let prima = null;
      if (nuda === "Trop") {
        let k = i - 1;
        while (k >= 0 && !(r.valori[k] && r.valori[k].v)) k--;
        if (k >= 0) prima = { v: r.valori[k].v, quando: quando(st.date[k]) };
      }
      const pos = PRIMA_DI_TUTTI.indexOf(nuda);
      out.push({ sigla: s, v: r.valori[i].v, stato: r.valori[i].stato, prima, ord: pos < 0 ? 99 : pos });
    }
    return out.sort((a, b) => a.ord - b.ord);
  }
  // Una riga per dire cosa dice un referto, sulla sua riga chiusa: le
  // conclusioni se ci sono, se no la prima frase vera (non l'intestazione,
  // non un'etichetta «Quesito: …», non il medico).
  function anteprimaReferto(righe) {
    const r = (righe || []).map((x) => String(x || "").trim()).filter(Boolean);
    const i = r.findIndex((x) => /^conclusion[ei]\b/i.test(x));
    if (i >= 0) {
      const dopo = r[i].replace(/^conclusion[ei]\s*:?\s*/i, "");
      return dopo || r[i + 1] || "";
    }
    return r.find((x) => /[a-zà-ù]/.test(x) && x.split(/\s+/).length >= 4 && !/^[^:]{1,28}:/.test(x)
      && !/ospedale|azienda|presidio|\bdott|\bdr\.|medico|paziente|\bnat[oa]\b|\bdata\b|pagina/i.test(x)) || r[0] || "";
  }
  // Al massimo due scaricamenti di referti insieme, per tutta la scheda: un
  // tocco su un referto e «Salva» passano dalla stessa fila.
  const scaricaRef = codaLimitata(2);
  const PAUSA_REF = [600, 1600];   // ms prima di ogni scaricamento in fila: mai a raffica

  function refertoTipo(e) {
    const l = String(e.label || "").toUpperCase();
    const sis = String(e.sistema || "").toUpperCase();
    if (/ELETTROCARDIOGRAMM|\bECG\b/.test(l)) return "ecg";
    // the whole of radiology reads as text, not just plain films: the system
    // that issued the document says it better than the exam's name does
    if (sis.includes("RIS") || /\bRX\b|RADIOGRAF|\bTC\b|\bTAC\b|ECOGRAF|RISONANZA|\bRMN\b/.test(l)) return "rx";
    if (sis.includes("LIS")) return "lab";
    return "altro";
  }

  // Quali sistemi di referti stanno nel portale (lo si scopre al primo tocco:
  // il link del gestionale rimanda là). Vale un turno, poi si riverifica.
  const nelPortale = (e) => {
    if (!hasExt() || !e || !e.sistema) return false;
    const t = (store.get("refPortale", {}) || {})[String(e.sistema).toUpperCase()];
    return !!t && Date.now() - t < 12 * 3600e3;
  };
  const segnaPortale = (e) => {
    if (!e || !e.sistema) return;
    store.set("refPortale", { ...(store.get("refPortale", {}) || {}), [String(e.sistema).toUpperCase()]: Date.now() });
  };

  function esitiModel(doc, baseUrl) {
    const out = [
      ...risultatiModel(doc, baseUrl).map((r) => ({ ...r, kind: "valori", label: r.exams.join(", ") })),
      ...refertiModel(doc, baseUrl).map((r) => ({ ...r, kind: "referto" })),
    ];
    // Once an exam is reported the LIS takes its Risultati window away, and the
    // values we had already read would vanish with it. They are ours: the draws
    // read earlier in this tab stay in the list, marked as read before, each
    // with its own time. They are never attached to a referto — nothing links
    // the two — they simply keep their place.
    const ep = findEpisodeId(doc, baseUrl) || "x";
    const vivi = new Set(out.filter((r) => r.kind === "valori").map((r) => r.id));
    for (const k of tabStore.keys(`ris.${ep}.`)) {
      const id = k.slice(`ris.${ep}.`.length);
      if (!id || vivi.has(id)) continue;
      const v = tabStore.get(k, null);
      if (!v || !v.rows || !v.rows.length || !v.meta) continue;
      out.push({ ...v.meta, id, kind: "valori", storico: true });
    }
    out.sort((a, b) => b.ts - a.ts);
    return out;
  }

  // Un tetto duro ai tentativi, UNO SOLO per tutta la caccia: un documento che
  // non si lascia catturare in pochi colpi si apre in una scheda e si stampa da
  // lì. Il contatore va passato ai livelli sotto — quando stava dentro la
  // funzione ogni ricorsione ripartiva da zero e il tetto vero era 6+6×6 = 43.
  const MAX_TENTATIVI = 6;
  async function fetchPdf(url, { signal, hop = 0, budget } = {}) {
    budget = budget || { n: 0 };
    const target = new URL(url, location.href);
    if (target.origin !== location.origin) {
      throw new StopError("Richiesta fuori dall'ospedale bloccata", `destinazione inattesa: ${target.origin}`);
    }
    const ctl = new AbortController();
    const tid = setTimeout(() => ctl.abort(new DOMException("Timeout", "TimeoutError")), TIMEOUT_MS);
    const onAbort = () => ctl.abort(new DOMException("Aborted", "AbortError"));
    if (signal) {
      // agganciarsi a un segnale GIÀ abortito non fa scattare niente: chiudere
      // la finestra di stampa deve fermare anche il tentativo che deve ancora
      // partire, non solo quello in volo
      if (signal.aborted) { clearTimeout(tid); throw new DOMException("Aborted", "AbortError"); }
      signal.addEventListener("abort", onAbort, { once: true });
    }
    let res;
    try {
      try {
        res = await fetch(target.href, { signal: ctl.signal, credentials: "same-origin", cache: "no-store", redirect: "follow" });
      } catch (e) {
        // Solo l'errore di rete (TypeError) si traduce: timeout e stop
        // restano quello che sono. Quasi sempre è un rinvio verso un ALTRO
        // server (il RIS, gli ECG, il portale in http): la pagina del
        // gestionale non può leggerlo, il medico che clicca sì — per questo
        // il referto si apre ma non si lascia salvare.
        if (!(e instanceof TypeError)) throw e;
        throw new StopError("Non raggiungibile da qui", "rete, o rinvio a un altro server");
      }
      if (new URL(res.url || target.href).origin !== location.origin) {
        // si dice DOVE (solo il server: nell'indirizzo ci sono gli id del paziente)
        throw new StopError("Il documento sta su un altro server", `rimanda a ${new URL(res.url).origin}`);
      }
      if (!res.ok) throw new StopError(`Il server ha risposto HTTP ${res.status}`, res.statusText || "");
    } finally {
      clearTimeout(tid);
      if (signal) signal.removeEventListener("abort", onAbort);
    }
    const ctype = (res.headers.get("content-type") || "").toLowerCase();
    const buf = await res.arrayBuffer();
    // Il tipo dichiarato è un'etichetta; i primi cinque byte sono il
    // documento. Un servlet che manda un PDF chiamandolo «text/html» o
    // «application/force-download» manda comunque un PDF, e buttarlo via per
    // il nome sarebbe l'unico errore vero: si guarda dentro.
    const magico = buf.byteLength > 4
      && String.fromCharCode(...new Uint8Array(buf, 0, 5)) === "%PDF-";
    if (magico || ctype.includes("pdf") || ctype.includes("octet-stream")) {
      return { blob: new Blob([buf], { type: "application/pdf" }), url: res.url || target.href,
               via: hop === 0 ? "diretto" : magico && !ctype.includes("pdf") ? `dichiarato ${ctype.split(";")[0] || "senza tipo"}` : "" };
    }
    if (ctype.includes("html") && hop < 2) {
      const text = new TextDecoder("windows-1252").decode(buf);
      const doc = new DOMParser().parseFromString(text, "text/html");
      if (classify(doc) === "login") throw new StopError("Sessione scaduta", "Fai l'accesso a SA4PSO e riprova la stampa.");
      const base = res.url || target.href;
      const tried = [];
      const fuoriQui = new Set();   // dove rimanda, quando rimanda a un altro server
      const attempt = async (raw, via) => {
        if (!raw || /^(javascript:|#|about:)/i.test(raw)) return null;
        if (++budget.n > MAX_TENTATIVI) return null;
        let u; try { u = new URL(String(raw).replace(/&amp;/gi, "&").trim(), base); } catch { return null; }
        if (u.origin !== location.origin && /^https?:$/.test(u.protocol)) fuoriQui.add(u.origin);
        if (u.origin !== location.origin || u.href === base) return null;
        if (tried.includes(u.href)) return null;
        tried.push(u.href);
        try {
          const r = await fetchPdf(u.href, { signal, hop: hop + 1, budget });
          return r ? { ...r, via: r.via || via } : r;
        } catch (e) { if (e?.name === "AbortError") throw e; return null; }
      };

      // 1. explicit references in the markup (old apps still use <frameset>)
      const domCands = [];
      for (const el of doc.querySelectorAll('frame[src], iframe[src], embed[src], object[data], a[href], form[action]')) {
        const v = el.getAttribute("src") || el.getAttribute("data") || el.getAttribute("href") || el.getAttribute("action");
        const loose = el.tagName === "FRAME" || el.tagName === "IFRAME" || el.tagName === "EMBED" || el.tagName === "OBJECT";
        if (v && (loose || /jasperservlet|uploaddownload|\.pdf|report|stampa/i.test(v))) domCands.push(v);
      }
      // Il rinvio del visualizzatore delle etichette porta l'indirizzo del PDF
      // con dentro degli APICI:
      //   URL=…uploaddownloadservlet.rra2?…blobfield=…get_pdf('PSOWEB_HL7_123')…
      // Tagliarlo al primo apice dava un indirizzo monco — ed era l'unico
      // tentativo che il programma faceva, quindi le etichette non uscivano.
      // Dopo «URL=» finisce l'attributo: si prende tutto quello che resta.
      const meta = doc.querySelector('meta[http-equiv="refresh" i]')?.getAttribute("content") || "";
      const rinvio = /url\s*=\s*(.+)$/is.exec(meta);
      // Un rinvio verso un ALTRO server è il portale (ECG, radiologia): là il
      // referto si apre con un accesso a token, e la pagina lo scarica e lo
      // mostra da sé. Da qui non si legge e non ci si prova nemmeno (niente
      // replay, niente attese): chi chiama lo apre nel portale, in una scheda.
      if (rinvio) {
        let dest = null;
        try { dest = new URL(rinvio[1].trim().replace(/^(["'])([\s\S]*)\1$/, "$2").trim().replace(/&amp;/gi, "&"), base); } catch { /* niente */ }
        if (dest && dest.origin !== location.origin && /^https?:$/.test(dest.protocol)) {
          const x = new StopError("Il referto si apre nel portale", `rimanda a ${dest.origin}`);
          x.portale = dest.origin;
          throw x;
        }
      }
      domCands.push(rinvio ? rinvio[1].trim().replace(/^(["'])([\s\S]*)\1$/, "$2").trim() : undefined);
      for (const m of text.matchAll(/window\.open\(\s*["']([^"']+)["']/gi)) domCands.push(m[1]);
      for (const c of domCands) { const r = await attempt(c, "link nella pagina"); if (r) return r; }

      // 2. a whole direct-pdf URL sitting in the viewer's own script
      for (const c of pdfCandidates(text)) { const r = await attempt(c, "URL nello script"); if (r) return r; }

      // Qui prima c'era una terza strada: prendere l'id del documento dalla
      // pagina e COSTRUIRE l'indirizzo del PDF. È stata tolta. Un indirizzo
      // costruito a mano su un id letto male non dà un errore: dà il
      // documento di qualcun altro. La regola del programma è che gli
      // indirizzi si prendono dalla pagina, e questa era l'unica eccezione.

      // 3. replay the viewer (sandboxed) and take the URL/Blob it produces
      try { return { ...(await harvestInlinePdf(target.href, { html: text, baseUrl: base, signal })), via: "replay del visualizzatore" }; }
      catch (e) {
        if (e?.name === "AbortError") throw e;
        const err = new ViewerError(target.href);
        // NB: questa diagnosi è l'unica cosa che dice, da uno schermo al
        // lavoro, com'è fatto il visualizzatore vero. Era morta: citava una
        // variabile che non esiste più, quindi al posto del ViewerError con la
        // diagnosi partiva un ReferenceError, e non si vedeva niente.
        const idQui = /\b[A-Z][A-Z0-9]*_[A-Z0-9]+_\d{6,}\b/.test(text);
        err.diag = `html ${Math.round(text.length / 1024)}KB · ${(text.match(/<script/gi) || []).length} script · ${(text.match(/<frame\b/gi) || []).length} frame · tentati ${tried.length} URL · id ${idQui ? "sì" : "no"} · upload ${/uploaddownloadservlet/i.test(text) ? "sì" : "no"}${fuoriQui.size ? ` · rimanda a ${[...fuoriQui].join(", ")}` : ""}`;
        err.html = text;   // la pagina stessa, per «⧉ Diagnosi» (mascherata prima di copiarla)
        throw err;
      }
    }
    throw new ViewerError(target.href);
  }

  // Exam page: everything the engine needs from a rendered list.
  function examModel(doc, baseUrl) {
    const form = doc.querySelector('form[name="Prestazioni"]');
    let links = form ? [...form.querySelectorAll("a.AFCDataLink")] : [];
    if (!links.length) links = [...doc.querySelectorAll("a.AFCDataLink")];
    const exams = [];
    for (const a of links) {
      const href = absUrl(a, "href", baseUrl);
      const code = param(href, "PRESTAZIONE");
      if (!code) continue; // e.g. the cart-wide "svuota" link
      exams.push({
        code,
        label: a.textContent.replace(/\s+/g, " ").replace(/^\d+-\d+\s*/, "").trim(),
        isAdd: /[?&]Insert=Inserisci/.test(href),
        isDel: /[?&]Delete=Elimina/.test(href),
        href,
      });
    }
    const sel = doc.querySelector('select[name="RISORSA_ID"]');
    const res = sel ? selectValue(sel) : null;
    const resOptions = sel ? [...sel.options].filter((o) => o.value).map((o) => ({ value: o.value, label: o.textContent.replace(/\s+/g, " ").trim() })) : [];

    // Plain list URL template, derived from a data link's own params (they
    // carry the complete state). Fallback: the Prestazioni form action.
    // (RICHIESTA_PRESTAZIONE_PROG: la riga «Elimina» di un esame in carrello lo
    // porta, e da lì passerebbe in ogni rilettura dell'elenco)
    const DROP = ["Insert", "Delete", "MVPG", "ccsForm", "PRESTAZIONE", "BRANCA", "toPG", "RICHIESTA_PRESTAZIONE_PROG"];
    let template = null;
    const src = exams.find((e) => e.href);
    if (src) template = new URL(src.href);
    else if (form) { template = new URL(absUrl(form, "action", baseUrl)); }
    if (template) {
      DROP.forEach((k) => template.searchParams.delete(k));
      template.searchParams.set("MVPG", "RcsRichiestaPrestazioniRicercaErogatore");
      template.searchParams.set("toPage", "RcsRichiestaPrestazioniRicercaErogatore");
      template.searchParams.set("s_PRESTAZIONE", "");
    }
    const listUrl = (targetRes) => {
      if (!template) return null;
      const u = new URL(template);
      if (targetRes) u.searchParams.set("RISORSA_ID", targetRes);
      return u.href;
    };
    const richiestaId = template ? template.searchParams.get("RICHIESTA_ID") : null;

    return {
      form, exams, res, resOptions, listUrl, richiestaId,
      inCart: (code) => exams.some((e) => e.code === code && e.isDel),
      addLink: (code) => exams.find((e) => e.code === code && e.isAdd),
      confirmButton: form ? form.querySelector('input[type="submit"][name="Update"]') || form.querySelector('input[type="submit"][name="Update1"]') : null,
    };
  }

  // Che cosa c'è ancora nel carrello di questa sezione: le righe dell'elenco
  // col loro «Elimina» (codice e nome) e, nelle pagine vere, le righe della
  // tabella «Carrello Prestazioni» (RICHIESTA_PRESTAZIONE_PROG, senza
  // PRESTAZIONE) che l'elenco non mostra già. Il «Svuota carrello» non ha né
  // l'una né l'altra: non è una riga.
  function righeVive(doc, m) {
    const out = m.exams.filter((e) => e.isDel).map((e) => ({ res: m.res, code: String(e.code), label: e.label }));
    const visti = new Set(out.map(nomeRiga));
    for (const a of doc.querySelectorAll('a[href*="Delete=Elimina"]')) {
      let p;
      try { p = new URL(a.getAttribute("href"), location.href).searchParams; } catch { continue; }
      if (p.has("PRESTAZIONE") || !p.has("RICHIESTA_PRESTAZIONE_PROG")) continue;
      const r = { res: m.res, code: null, label: (a.closest("tr")?.textContent || "").replace(/\s+/g, " ").trim().replace(/^\d+-\d+\s*/, "") };
      if (!visti.has(nomeRiga(r))) { visti.add(nomeRiga(r)); out.push(r); }
    }
    return out;
  }
  const nomeRiga = (r) => (r.code ? DISPLAY[`${r.res}:${r.code}`] : "") || shortLabel(r.label) || "una riga senza nome";
  const righeCarrello = (doc, m) => righeVive(doc, m).map(nomeRiga);
  // Il carrello vero di una richiesta, sezione per sezione, riletto dal
  // server (solo letture): ogni pagina dev'essere di quella richiesta, di
  // quell'episodio e di quella sezione — e non la pagina di accesso.
  async function leggiSezione(model0, res, { rid, ep, signal, cosa = "Niente toccato" }) {
    const u = model0.listUrl(res);
    if (!u) throw new StopError("Non ritrovo il carrello della richiesta", "Controllalo a mano.");
    const r = await fetchDoc(u, { signal });
    if (classify(r.doc) === "login") {
      const e = restaQui(new StopError("Sessione scaduta durante l'operazione", `${cosa}. Rifai l'accesso e controlla il carrello.`));
      e.sessione = true;
      throw e;
    }
    assertSameEpisode(r.doc, ep, "carrello");
    if (classify(r.doc) !== "exam") throw new StopError("Non ritrovo il carrello della richiesta", "Controllalo a mano.");
    const m = examModel(r.doc, r.url);
    if (String(m.richiestaId) !== String(rid)) throw restaQui(new StopError("Non è il carrello di questa richiesta", "Mi fermo qui."));
    if (m.res !== res) throw new StopError(`Non apro la sezione ${risorsaCorta(res)} del carrello`, "Controllalo a mano.");
    return { res, m, doc: r.doc, url: r.url, righe: righeVive(r.doc, m) };
  }
  async function leggiCarrello(model0, opz) {
    const sezioni = [];
    for (const res of new Set([model0.res, ...model0.resOptions.map((o) => o.value)].filter(Boolean))) sezioni.push(await leggiSezione(model0, res, opz));
    return { sezioni, righe: sezioni.flatMap((s) => s.righe) };
  }
  // Che cosa rimette «Svuota il carrello e ricomincia»: la selezione di
  // partenza e, in più, ogni riga del carrello vero che non ne fa parte
  // (aggiunta a mano, o rimasta da un giro di prima) — per codice, col nome
  // del catalogo, che dev'essere quello che la riga porta oggi: svuotare non
  // deve mai far sparire un esame. Una riga che non si saprebbe rimettere
  // ferma tutto prima di togliere qualunque cosa. (`nostri`: con quale codice
  // sono entrati gli esami del giro — un riflesso ne cambia il numero.)
  function daRimettere(righe, sel, nostri = [], cat = fullCatalog()) {
    const noti = [...sel, ...nostri];
    const suo = (r) => noti.some((x) => (String(x.res) === String(r.res) && String(x.code) === String(r.code)) || stessoNomeVivo(x.label, r.label));
    const extra = [], ignoti = [];
    for (const r of righe) {
      if (suo(r)) continue;
      const label = r.code ? (cat[r.res]?.items || {})[r.code] : "";
      if (label && stessoNomeVivo(label, r.label)) {
        const it = { res: r.res, code: r.code, label, display: displayLabel(r.res, r.code) };
        extra.push(it); noti.push(it);
      } else ignoti.push(nomeRiga(r));
    }
    return { items: [...sel, ...extra], extra, ignoti };
  }

  const agoLabel = (ts) => {
    const min = Math.max(0, Math.round((Date.now() - (ts || 0)) / 60000));
    if (min < 1) return "adesso";
    if (min < 60) return `${min} min fa`;
    const d = new Date(ts || 0);
    const today = new Date().toDateString() === d.toDateString();
    return `${today ? "alle" : "ieri"} ${hhmm(ts)}`;
  };
  const hhmm = (ts) => { const d = new Date(ts || 0); return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`; };
  const shortLabel = (l) => String(l).replace(/\s*\([\w./-]*\)\s*$/, "");

  // =============================================================== CATALOG
  // Merged view of the embedded (audited) catalog and everything learned
  // from live pages. Learning happens on every parsed list, so radiology
  // becomes one-click after it has been seen once.
  // Un solo magazzino, due depositi. `set` torna false quando la scrittura NON
  // è avvenuta (memoria piena o bloccata): chi promette al medico «salvato»
  // deve poterlo verificare — e ora vale anche per le consegne fra pagina e
  // pagina, che prima fallivano in silenzio.
  const magazzino = (dep) => ({
    get(key, fallback) {
      try { const v = JSON.parse(dep.getItem(NS + key)); return v ?? fallback; }
      catch { return fallback; }
    },
    set(key, value) { try { dep.setItem(NS + key, JSON.stringify(value)); return true; } catch { return false; } },
    del(key) { try { dep.removeItem(NS + key); return true; } catch { return false; } },
    keys(prefix) {
      try { return Object.keys(dep).filter((k) => k.startsWith(NS + prefix)).map((k) => k.slice(NS.length)); }
      catch { return []; }
    },
  });
  const store = magazzino(localStorage);
  // il presidio del giro: chi lo tiene, su quale richiesta, e da quando
  const presidioLibero = (rid, token) => {
    const p = store.get(PRESIDIO, null);
    if (!p || !p.rid || !rid || p.rid !== String(rid)) return true;
    if (p.token === token) return true;
    return Date.now() - (p.ts || 0) > PRESIDIO_MS;
  };
  const segnaPresidio = (rid, token) => { if (rid) store.set(PRESIDIO, { rid: String(rid), token, ts: Date.now() }); };
  const liberaPresidio = (token) => { const p = store.get(PRESIDIO, null); if (p && p.token === token) store.set(PRESIDIO, null); };
  // Tab-scoped storage for the run→landing handoffs (receipt + auto-confirm
  // flag): sessionStorage survives the same-tab navigation but is invisible
  // to other tabs, so two patients in two tabs can never clobber or clear
  // each other's pending confirm.
  const tabStore = magazzino(sessionStorage);

  // ------------------------------------------------------- KNOWN PATIENTS
  // I pazienti su cui si è lavorato, per ritrovarli dalla schermata iniziale:
  // nome, episodio, indirizzo della pagina, il colore di triage e l'età che la
  // sua intestazione mostra (il numero, mai la data di nascita). Un turno è di
  // dodici ore e i pazienti sono più di dodici, quindi l'elenco tiene un giorno
  // e non ha un limite che dia fastidio. Qui non entra MAI altro contenuto clinico (né esami,
  // né valori, né quesito): quello sta nella scheda, che è un'altra cosa.
  // Chi viene dimesso si ARCHIVIA: esce dall'elenco principale e resta negli
  // archiviati, da dove si può riportare indietro o cancellare del tutto.
  const PATIENTS_TTL = 24 * 3600e3;
  const PATIENTS_MAX = 60;

  function tuttiPazienti() {
    const list = store.get("patients.v1", []);
    const fresh = Array.isArray(list) ? list.filter((p) => p && p.ep && Date.now() - (p.ts || 0) < PATIENTS_TTL)
      .map((p) => (p.name && NON_NOME.test(p.name) ? { ...p, name: "" } : p)) : [];
    return fresh.sort((a, b) => (b.ts || 0) - (a.ts || 0)).slice(0, PATIENTS_MAX);
  }
  const knownPatients = () => tuttiPazienti().filter((p) => !p.arch);
  const pazientiArchiviati = () => tuttiPazienti().filter((p) => p.arch);
  // Il codice colore del triage, come lo mostra l'intestazione della scheda:
  // un elemento col titolo esatto. Le righe del diario (.myRiepilogo) portano
  // il colore di quando sono state scritte, e non contano.
  const TRIAGE_COLORI = ["ROSSO", "ARANCIONE", "AZZURRO", "VERDE", "BIANCO"];
  function triageDi(doc) {
    for (const el of doc.querySelectorAll("[title]")) {
      const t = (el.getAttribute("title") || "").trim();
      if (TRIAGE_COLORI.includes(t) && !el.closest(".myRiepilogo")) return t;
    }
    return "";
  }
  // Chi è il paziente di QUESTA pagina lo dice il riquadro in testa alla
  // scheda — episodio, NOME, nascita, codice fiscale, motivo — quello col
  // colore del triage. Il titolo della scheda del browser NON è un nome: su
  // molte pagine il gestionale ci scrive «ROSSI MARIO», su altre «Pronto
  // Soccorso» o «PRONTO SOCCORSO - LISTA», e prenderlo per un nome faceva
  // entrare in elenco un paziente chiamato «Pronto Soccorso». Il titolo resta
  // solo un ripiego, dove il riquadro non c'è, e solo se sembra un nome.
  const NON_NOME = /pronto\s*soccorso|\blista\b|sa4pso|gestionale/i;
  const pareNome = (t) => !!t && t.length >= 3 && t.length <= 80 && !/\d/.test(t) && /[a-z]/i.test(t) && !NON_NOME.test(t);
  function riquadroPaziente(doc) {
    for (const el of doc.querySelectorAll("td[title]")) {
      if (TRIAGE_COLORI.includes((el.getAttribute("title") || "").trim()) && !el.closest(".myRiepilogo") && el.querySelector("font")) return el;
    }
    return null;
  }
  function nomeInPagina(doc = document) {
    const r = riquadroPaziente(doc);
    if (r) {
      // il nome è la riga scritta più grande del riquadro
      let nome = null, max = 0;
      for (const f of r.querySelectorAll("font")) {
        const m = /font-size:\s*(\d+)%/i.exec(f.getAttribute("style") || "");
        if (m && Number(m[1]) > max) { max = Number(m[1]); nome = f; }
      }
      const t = (nome?.textContent || "").replace(/\s+/g, " ").trim();
      if (pareNome(t)) return t;
    }
    const t = (doc.title || "").replace(/\s+/g, " ").trim();
    return pareNome(t) ? t : "";
  }
  // Accanto al codice fiscale, nel riquadro in testa alla scheda, un'icona
  // che lo copia. È la sola cosa che il pannello aggiunge alla pagina del
  // gestionale: piccola, del colore del testo, e il suo clic non arriva al
  // doppio clic del riquadro (che riporta alla home dell'episodio).
  const CF_UNO = /\b[A-Z]{6}[0-9LMNPQRSTUV]{2}[A-Z][0-9LMNPQRSTUV]{2}[A-Z][0-9LMNPQRSTUV]{3}[A-Z]\b/;
  const ICO_COPIA = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>';
  const ICO_FATTO = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 12.5l5 5L20 6.5"/></svg>';
  function iconaCf(doc = document) {
    const r = riquadroPaziente(doc);
    if (!r || r.querySelector(".psassist-cf")) return;
    const giro = doc.createTreeWalker(r, NodeFilter.SHOW_TEXT);
    for (let n = giro.nextNode(); n; n = giro.nextNode()) {
      const m = CF_UNO.exec((n.nodeValue || "").toUpperCase());
      if (!m) continue;
      const cf = m[0];
      const dopo = n.splitText(m.index + cf.length);
      const b = doc.createElement("span");
      b.className = "psassist-cf";
      b.setAttribute("role", "button");
      b.tabIndex = 0;
      b.title = "Copia il codice fiscale";
      b.setAttribute("aria-label", "Copia il codice fiscale");
      b.style.cssText = "display:inline-flex;align-items:center;vertical-align:-2px;margin-left:7px;cursor:pointer;opacity:.85;line-height:0";
      b.innerHTML = ICO_COPIA;
      let t = 0;
      const copia = async (e) => {
        e.preventDefault(); e.stopPropagation();
        const ok = await copiaTesto(cf);
        b.innerHTML = ok ? ICO_FATTO : ICO_COPIA;
        b.title = ok ? "Copiato" : "Non copiato: riprova";
        clearTimeout(t);
        t = setTimeout(() => { b.innerHTML = ICO_COPIA; b.title = "Copia il codice fiscale"; }, 1600);
      };
      b.addEventListener("click", copia);
      b.addEventListener("dblclick", (e) => e.stopPropagation());
      b.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") copia(e); });
      b.addEventListener("mouseenter", () => { b.style.opacity = "1"; });
      b.addEventListener("mouseleave", () => { b.style.opacity = ".85"; });
      n.parentNode.insertBefore(b, dopo);
      return;
    }
  }
  // L'età: la riga in corpo 120% del riquadro la dice dopo la data di nascita
  // («17/05/1949 (77) M»); se no, dal codice fiscale. Si tiene solo il numero,
  // mai la data.
  function etaDaCf(cf) {
    if (!/^[A-Z]{6}[\dLMNPQRSTUV]{2}[A-Z][\dLMNPQRSTUV]{2}/.test(cf)) return null;
    const n = (t) => Number(t.replace(/[LMNPQRSTUV]/g, (c) => "LMNPQRSTUV".indexOf(c)));
    const mese = "ABCDEHLMPRST".indexOf(cf[8]), giorno = n(cf.slice(9, 11)) % 40, oggi = new Date();
    if (mese < 0 || !giorno) return null;
    // il secolo non c'è: nato nel 2000 e qualcosa, o cent'anni prima
    const eta = oggi.getFullYear() - 2000 - n(cf.slice(6, 8)) - (oggi.getMonth() < mese || (oggi.getMonth() === mese && oggi.getDate() < giorno) ? 1 : 0);
    return eta < 0 ? eta + 100 : eta;
  }
  function etaInPagina(doc = document) {
    const r = riquadroPaziente(doc);
    if (!r) return null;
    // riga per riga (fra un <br> e l'altro il testo si attaccherebbe)
    const righe = [];
    const giro = doc.createTreeWalker(r, NodeFilter.SHOW_TEXT);
    for (let n = giro.nextNode(); n; n = giro.nextNode()) righe.push([n.parentElement?.closest("font")?.getAttribute("style") || "", (n.nodeValue || "").toUpperCase()]);
    for (const [stile, t] of righe) {
      const m = /font-size:\s*120%/i.test(stile) && /\b\d{1,2}\/\d{1,2}\/\d{4}\s*\((\d{1,3})\)/.exec(t);
      if (m) return Number(m[1]);
    }
    const cf = righe.map(([, t]) => CF_UNO.exec(t)).find(Boolean);
    return cf ? etaDaCf(cf[0]) : null;
  }
  function rememberPatient(ep, name, url, triage, eta, sesso) {
    if (!ep) return;
    const prima = tuttiPazienti().find((p) => p.ep === ep);
    const list = tuttiPazienti().filter((p) => p.ep !== ep);
    // il triage è quello letto all'ultima apertura; se la pagina non lo dice,
    // resta quello di prima
    const tr = TRIAGE_COLORI.includes(triage) ? { triage, triageTs: Date.now() }
      : prima?.triage ? { triage: prima.triage, triageTs: prima.triageTs || 0 } : {};
    const anni = Number.isInteger(eta) && eta >= 0 && eta < 130 ? eta : prima?.eta;
    // riaprire un paziente archiviato lo riporta fra i vivi: se sei sulla sua
    // pagina, è di lui che ti stai occupando
    list.unshift({ ep, name: ((name || "").trim() || prima?.name || "").slice(0, 60), url: url || "", ts: Date.now(),
                   pk: prima?.pk || "", ...tr, ...(Number.isInteger(anni) ? { eta: anni } : {}),
                   ...(sesso === "M" || sesso === "F" ? { sesso } : prima?.sesso ? { sesso: prima.sesso } : {}) });
    store.set("patients.v1", list.slice(0, PATIENTS_MAX));
  }
  // la chiave della scheda clinica, annotata quando la conosciamo, così
  // archiviare o eliminare un paziente sa cosa toccare
  function segnaChiave(ep, pk) {
    if (!ep || !pk) return;
    const list = tuttiPazienti();
    const p = list.find((x) => x.ep === ep);
    if (!p || p.pk === pk) return;
    p.pk = pk;
    store.set("patients.v1", list);
  }
  function archiviaPaziente(ep, si = true) {
    const list = tuttiPazienti();
    const p = list.find((x) => x.ep === ep);
    if (!p) return false;
    p.arch = !!si;
    p.archTs = si ? Date.now() : 0;
    return store.set("patients.v1", list);
  }
  // Eliminare un paziente vuol dire eliminare TUTTO quello che il programma
  // sa di lui: la riga nell'elenco, la sua scheda clinica, i referti tenuti,
  // la nota, e i dati per episodio in questa scheda del browser.
  function eliminaPaziente(ep, pk, nome) {
    const list = tuttiPazienti().filter((x) => x.ep !== ep);
    store.set("patients.v1", list);
    // la nota può stare sotto la chiave del codice fiscale O sotto il nome,
    // a seconda di quando è stata scritta: si tolgono tutt'e due
    const n = store.get(noteKey, {});
    const perNome = nome ? "nome:" + normNome(nome) : "";
    let tolte = 0;
    for (const k of [pk, perNome].filter(Boolean)) if (n[k]) { delete n[k]; tolte++; }
    if (tolte) store.set(noteKey, n);
    const s = store.get(segniKey, {});   // e i segni sui valori, stesse chiavi
    let toltiSegni = 0;
    for (const k of [pk, perNome].filter(Boolean)) if (s[k]) { delete s[k]; toltiSegni++; }
    if (toltiSegni) store.set(segniKey, s);
    try {
      for (const k of Object.keys(sessionStorage)) {
        const kk = k.startsWith(NS) ? k.slice(NS.length) : "";
        if (kk && new RegExp(`(^|\\.)(ris|visto|reftxt|log|refopen|ui)\\.${ep}\\b`).test(kk)) sessionStorage.removeItem(k);
      }
    } catch { /* memoria bloccata: niente da togliere */ }
    const corsa = tabStore.get(CORSA, null);
    if (corsa && corsa.ep === ep) tabStore.set(CORSA, null);
    const aperta = store.get(APERTA, null);
    if (aperta && aperta.ep === ep) store.set(APERTA, null);
    const posti = store.get("stanza.posti.v1", null);   // e il suo posto nella stanza
    if (posti && posti[ep]) { delete posti[ep]; store.set("stanza.posti.v1", posti); }
    const prom = store.get(PROM, null);   // e i suoi promemoria
    if (prom && prom[ep]) { delete prom[ep]; store.set(PROM, prom); }
    const stato = store.get(STATO, null);   // e lo stato dei suoi esami
    if (stato && stato[ep]) { delete stato[ep]; store.set(STATO, stato); }
    if (hasExt()) ask({ t: "delStorico", chiave: pk, ep, nome: nome || "" }).catch(() => {});
    return true;
  }
  function forgetPatients() { store.set("patients.v1", []); }
  // end of shift / another user: drop names and every per-episode leftover
  function forgetAll() {
    forgetPatients();
    forgetQuesiti();
    try {
      for (const k of Object.keys(sessionStorage)) {
        if (k.startsWith(NS) && /(^|\.)(ris|visto|reftxt|log|refopen|receipt|confirm|queue|print|ui|afterNav|dimdraft|eodraft|storico|corsa)\b/.test(k.slice(NS.length))) sessionStorage.removeItem(k);
      }
    } catch { /* blocked storage: nothing to clear */ }
    store.set(APERTA, null);    // porta un nome: se ne va col turno
    dimenticaAnagrafiche();     // le allergie lette: testo clinico, se ne vanno col turno
    store.set(PRESIDIO, null);
    // I posti nella stanza NO: sono solo numeri di episodio, e chi viene
    // riaperto dopo una sessione scaduta deve ritrovare il suo letto.
    try { if (typeof chrome !== "undefined" && chrome.runtime?.id) chrome.runtime.sendMessage({ t: "clearRef" }, () => void chrome.runtime.lastError); } catch { /* not the extension build */ }
  }
  // «Reset dati pazienti» (⋯): via tutto quello che si sa dei pazienti e del
  // turno, qui e nella memoria di questa scheda. Restano le impostazioni
  // (finestra, stanza, catalogo, stampe già fatte) e i modelli del medico.
  const RESET_VIA = () => ["patients.v1", "stanza.posti.v1", STATO, PROM, PROM_VECCHI, noteKey, segniKey, "refVisti.v1",
    "refPortale", DA_CONFERMARE, "quesiti", "quesiti.ts", "lastQ", APERTA, PRESIDIO];
  function azzeraScheda() {
    try { for (const k of Object.keys(sessionStorage)) if (k.startsWith(NS)) sessionStorage.removeItem(k); } catch { /* niente */ }
  }
  function azzeraPazienti() {
    for (const k of RESET_VIA()) store.del(k);
    const t = store.get(tempiKey, null);   // i tempi restano, senza chi
    if (Array.isArray(t)) store.set(tempiKey, t.map(({ paz, ep, ...x }) => x));
    azzeraScheda();
    // le altre schede puliscono la loro (vedi «storage» all'avvio)
    try { localStorage.setItem(NS + "reset.v1", String(Date.now())); localStorage.removeItem(NS + "reset.v1"); } catch { /* niente */ }
  }

  // The doctor's edits live in localStorage under their own key. They are
  // templates, not patient data, so forgetAll leaves them alone — and nothing
  // patient-specific ever gets written here.
  // ------------------------------------------------------------- CONSENSI
  // I moduli di consenso stanno DENTRO l'estensione (cartella consensi/):
  // niente rete, niente server, funzionano anche se il gestionale è giù.
  // Un tocco apre il PDF e la finestra di stampa, come per la lista esami.
  // `pagine` è quanta carta esce: nove pagine non si scoprono dalla stampante.
  // `gruppo` separa i consensi da firmare dalle deleghe per il ritiro.
  const CONSENSI = [
    { k: "emocolture", nome: "Emocolture", file: "emocolture.pdf", pagine: 1,
      esteso: "Esame colturale su campioni biologici diversi" },
    { k: "hiv-dipendente", nome: "HIV Dipendente", file: "hiv-dipendente.pdf", pagine: 1,
      esteso: "Consenso del dipendente all'esecuzione del test HIV (MDL 170)" },
    { k: "lesioni-animali", nome: "Lesioni Animali", file: "lesioni-animali.pdf", pagine: 1,
      esteso: "Rapporto di lesione provocata da animali" },
    { k: "antitetano", nome: "Antitetano", file: "antitetano.pdf", pagine: 1,
      esteso: "Immuno-profilassi antitetanica" },
    { k: "tac-cmdc", nome: "TAC cmdc", file: "tac-cmdc.pdf", pagine: 1,
      esteso: "Consenso alla TAC con mezzo di contrasto" },
    { k: "emotrasfusione", nome: "Emotrasfusione", file: "emotrasfusione.pdf", pagine: 9,
      esteso: "Pacchetto trasfusionale: consenso informato, richiesta emocomponenti, dichiarazione del medico in urgenza" },
    { k: "ritiro-esami", nome: "Ritiro esami", file: "ritiro-esami.pdf", pagine: 1, gruppo: "ritiro",
      esteso: "Delega per il ritiro del referto degli esami ematochimici di Pronto Soccorso" },
    { k: "ritiro-referto-rx", nome: "Ritiro referto RX", file: "ritiro-referto-rx.pdf", pagine: 1, gruppo: "ritiro",
      esteso: "Delega per il ritiro del referto radiologico" },
    { k: "ritiro-cartella-cd", nome: "Ritiro cartella e CD", file: "ritiro-cartella-cd.pdf", pagine: 5, gruppo: "ritiro",
      esteso: "Richiesta e delega per copia della documentazione sanitaria: verbale di PS, referti, CD radiologico" },
  ];
  const urlConsenso = (c) => (hasExt() ? chrome.runtime.getURL("consensi/" + c.file) : "");

  // ============================================================ STATO ESAMI
  // Quello che il pannello sa degli esami di un paziente, per la riga dei
  // Pazienti, il letto, la riga «Aperti» delle Dimissioni e il suffisso grigio
  // delle Richieste. Viene da due posti soli, e da nient'altro:
  //  1. la pagina del paziente quando è aperta (dal medico, dal pannello, da
  //     un ordine in sottofondo): ogni richiesta del gestionale è una riga
  //     con TIPO=RICH — anche quelle fatte a mano —, l'ora (DATA_ORD), gli
  //     esami (DESCRIZIONE_TITLE), il tipo (l'icona: Laboratorio, Radiologia,
  //     Consulenze → ECG solo se l'esame è un elettrocardiogramma) e lo stato:
  //     un REFERTO, o la finestra «Visualizza Risultati», vuol dire «tornato»;
  //     niente dei due, «in attesa»; un'icona che dice annullata/revocata la
  //     toglie dal conto;
  //  2. gli esami che PS Assist ha messo in carrello (il giro finito), per
  //     numero di richiesta: finché la pagina del paziente non elenca quella
  //     richiesta contano come «ordinati da qui, in attesa».
  // Un ordine e il suo risultato si legano solo così: stessa riga del
  // gestionale, o stesso numero di richiesta. Mai per nome e ora a occhio.
  // Al server non si chiede niente: si aggiorna quando la pagina si apre.
  // Solo numeri di episodio, ore e nomi di esami: mai il nome del paziente.
  //
  // Quanto può aspettare un esame prima di farsi ambra e poi rosso (minuti
  // dall'ora della richiesta). Li tara il medico, qui.
  const ATTESA_LAB = [60, 120];
  const ATTESA_ECG = [15, 30];
  const ATTESA_IMG = [90, 180];
  const ATTESA = { lab: ATTESA_LAB, ecg: ATTESA_ECG, img: ATTESA_IMG };
  // letto più di mezz'ora fa: grigio, «letto alle 11:02»
  const STATO_VECCHIO = 30 * 60e3;
  const STATO = "stato.v1";
  const STATO_TTL = 24 * 3600e3;
  const TIPI_ESAME = [["lab", "Lab"], ["ecg", "ECG"], ["img", "RX"]];
  const ANNULLATA = /annullat|revocat|cancellat|rifiutat|non\s+esegu|sospes/i;
  // «0-324 TROPONINA ULTRASENSIBILE (POC3001)» → «TROPONINA ULTRASENSIBILE (POC3001)»: il nome del catalogo
  const nomeEsame = (s) => String(s || "").replace(/ /g, " ").replace(/^\s*\d+-\d+\s+/, "").replace(/\s+/g, " ").trim();
  const chiaveEsame = (s) => nomeEsame(s).toUpperCase();
  // istanteDa() scrive l'ora del gestionale come se fosse UTC: qui serve l'istante vero
  const istanteLocale = (dt) => {
    if (!dt || !dt.ts) return 0;
    const d = new Date(dt.ts);
    return new Date(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), d.getUTCHours(), d.getUTCMinutes()).getTime();
  };
  function tipoEsame(label, icone, sistema) {
    const l = chiaveEsame(label), t = icone.join(" ");
    if (/ELETTROCARDIOGRAMM|\bECG\b/.test(l)) return "ecg";
    if (/radiolog/i.test(t)) return "img";
    if (/laborator/i.test(t)) return "lab";
    if (/consulen/i.test(t)) return "";
    const s = String(sistema || "").toUpperCase();
    if (s.includes("RIS") || /\bRX\b|RADIOGRAF|\bTC\b|\bTAC\b|ECOGRAF|RISONANZA|\bRMN\b/.test(l)) return "img";
    if (s.includes("LIS")) return "lab";
    return "";
  }
  // Le richieste che la pagina del paziente elenca. Una riga per richiesta
  // (o per prelievo, per le finestre Risultati), coi suoi esami e il loro tipo.
  function richiestePagina(doc) {
    const out = [], righe = new Set(), chiavi = new Set();
    const ancore = doc.querySelectorAll('input[name="TIPO"][value="RICH"], a[title="Visualizza Risultati"]');
    for (const el of ancore) {
      const tr = el.closest("tr");
      if (!tr || righe.has(tr)) continue;
      righe.add(tr);
      const cella = el.closest("td");
      const descr = cella?.querySelector('input[name="DESCRIZIONE_TITLE"]')?.value || cella?.getAttribute("title") || "";
      const nomi = descr.split(";").map(nomeEsame).filter(Boolean);
      if (!nomi.length) continue;
      const stati = [...(cella?.querySelectorAll("img[title]") || [])].map((x) => x.getAttribute("title") || "");
      if (stati.some((t) => ANNULLATA.test(t))) continue;
      const prima = tr.querySelector(":scope > td");
      const icone = prima && prima !== cella ? [...prima.querySelectorAll("[title]")].map((x) => x.getAttribute("title") || "") : [];
      const ref = [...tr.querySelectorAll('a[title="REFERTO"]')].find((a) => /REFERTO_ID=/.test(a.getAttribute("onclick") || a.getAttribute("href") || ""));
      const ris = tr.querySelector('a[title="Visualizza Risultati"]');
      const sistema = (/REFERTO_SISTEMA=([^&'"]+)/.exec(ref?.getAttribute("onclick") || "") || [])[1] || "";
      const rid = (/RICHIESTA_ID=(\d+)/.exec(prima?.innerHTML || "") || [])[1] || "";
      const accesso = (/RCS_ACCESSO_ID=(\d+)/.exec(ris?.getAttribute("onclick") || "") || [])[1] || "";
      const esami = nomi.map((n) => [tipoEsame(n, icone, sistema), n]).filter(([t]) => t);
      if (!esami.length) continue;
      const ts = istanteLocale(istanteRiga(tr));
      const k = rid ? `r${rid}:${nomi.join("|")}` : accesso ? `a${accesso}` : `t${ts}:${nomi.join("|")}`;
      if (chiavi.has(k)) continue;
      chiavi.add(k);
      out.push({ k, rid, ts, esami, fatto: ref ? "referto" : ris ? "risultati" : "" });
    }
    return out;
  }
  // Allergie e Attenzione del gestionale, parola per parola. Senza il campo
  // in pagina: non lette — mai «nessuna».
  function allergiePagina(doc) {
    const ta = doc.querySelector('textarea[name="ALLERGIE"]');
    const nega = doc.querySelector('input[name="ALLERGIE_NEGA"]');
    if (!ta && !nega) return null;
    const testo = String(ta ? ta.value : "").replace(/\s*\n\s*/g, " · ").replace(/\s+/g, " ").trim();
    return { nega: !!(nega && nega.checked), testo };
  }
  function attenzionePagina(doc) {
    const tit = [...doc.querySelectorAll("td.AFCColumnTD")].find((td) => td.textContent.replace(/\s+/g, " ").trim() === "Attenzione");
    if (!tit) return null;
    const td = tit.closest("tr")?.nextElementSibling?.querySelector("td");
    if (!td) return [];
    const righe = [""];
    const giro = doc.createTreeWalker(td, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
    for (let n = giro.nextNode(); n; n = giro.nextNode()) {
      if (n.nodeType === 1 && n.tagName === "BR") righe.push("");
      else if (n.nodeType === 3) righe[righe.length - 1] += n.nodeValue;
    }
    return righe.map((r) => r.replace(/\s+/g, " ").trim()).filter(Boolean);
  }
  // L'età e il sesso: la riga in corpo 120% del riquadro («17/05/1949 (77) M»),
  // se no il codice fiscale (giorno oltre 40: femmina).
  function sessoDaCf(cf) {
    if (!/^[A-Z]{6}[\dLMNPQRSTUV]{2}[A-Z][\dLMNPQRSTUV]{2}/.test(cf || "")) return "";
    const g = Number(cf.slice(9, 11).replace(/[LMNPQRSTUV]/g, (c) => "LMNPQRSTUV".indexOf(c)));
    return g > 40 ? "F" : g ? "M" : "";
  }
  function anagraficaPagina(doc = document) {
    const r = riquadroPaziente(doc);
    const eta = etaInPagina(doc);
    if (!r) return { eta, sesso: "" };
    // riga per riga: fra un <br> e l'altro il testo si attaccherebbe («M» e il codice fiscale)
    const pezzi = [], giro = doc.createTreeWalker(r, NodeFilter.SHOW_TEXT);
    for (let n = giro.nextNode(); n; n = giro.nextNode()) pezzi.push(n.nodeValue || "");
    const t = pezzi.join(" ").replace(/\s+/g, " ").toUpperCase();
    const m = /\b\d{1,2}\/\d{1,2}\/\d{4}\s*\(\d{1,3}\)\s*([MF])\b/.exec(t);
    const cf = CF_UNO.exec(t);
    return { eta, sesso: m ? m[1] : cf ? sessoDaCf(cf[0]) : "" };
  }

  // ======================================================= PARAMETRI VITALI
  // Il cuore accanto al nome: dalle righe dei parametri vitali della pagina
  // del paziente (`<tr id="VAMI">`: l'ora, poi «ETICHETTA: <b>valore</b>» uno
  // dopo l'altro). Anche quelli del triage stanno lì. Conta la riga più
  // recente che porta almeno un parametro (il triage, quindi, solo finché è
  // l'unica); un parametro che quella riga non ha NON si prende da una riga
  // più vecchia e non si inventa: si conta su quello che c'è e il passaggio
  // del mouse dice cosa manca. Si legge solo quando la pagina è aperta.
  //
  // Rosso: un parametro da solo nella fascia rossa NEWS2 (3 punti) — SpO2 ≤91
  // (una soglia per tutti), FR ≤8 o ≥25, PAS ≤90 o ≥220, FC ≤40 o ≥131,
  // T ≤35,0, coscienza: ACVPU diverso da A o GCS <15 — oppure NEWS2 ≥7.
  // Ambra: NEWS2 5–6. Altrimenti niente. Dopo 4 ore senza una riga più nuova
  // il cuore resta, vuoto: «♡ 5h».
  const VIT_VECCHIO = 4 * 3600e3;
  const VIT_ETICHETTE = [
    ["acvpu", /^ACVPU$/], ["gcs", /^GCS$/], ["fio2", /^FIO2$/],
    ["fr", /^(FREQUENZARESPIRATORIA|FR|FREQRESP|ATTIRESPIRATORI)$/],
    ["spo2", /^(SATURIMETRIA|SPO2|SATO2|SATURAZIONE)$/],
    ["fc", /^(FCRAR|FC|FREQUENZACARDIACA|POLSOFC)$/],
    ["pas", /^(SISTOLICAMAX|SISTOLICA|PAS|PASISTOLICA)$/], ["pad", /^(DIASTOLICAMIN|DIASTOLICA|PAD|PADIASTOLICA)$/],
    ["t", /^(TCTIMPASC|TC|TEMPERATURA|TEMP)$/],
  ];
  // valori fuori da questi limiti sono un errore di battitura, non un paziente
  const VIT_LIMITI = { gcs: [3, 15], fio2: [21, 100], fr: [1, 80], spo2: [40, 100], fc: [15, 300], pas: [40, 300], pad: [15, 200], t: [25, 45] };
  function vitaliRiga(tr) {
    const p = {};
    for (const b of tr.querySelectorAll("td b")) {
      // l'etichetta è il testo fra il valore di prima (o l'inizio) e questo
      let et = "";
      for (let n = b.previousSibling; n && !(n.nodeType === 1 && n.tagName === "B"); n = n.previousSibling) et = (n.textContent || "") + et;
      et = (et.split(/\s\/\s/).pop() || "").replace(/:\s*$/, "").toUpperCase().replace(/[^A-Z0-9]/g, "");
      const chi = VIT_ETICHETTE.find(([, re]) => re.test(et))?.[0];
      if (!chi || chi in p) continue;
      const v = b.textContent.replace(/\s+/g, " ").trim();
      if (chi === "acvpu") { const m = /^([ACVPU])(?![A-Z])/i.exec(v); if (m) p.acvpu = m[1].toUpperCase(); continue; }
      if (!/^\d{1,3}(?:[.,]\d{1,2})?$/.test(v)) continue;
      const n = Number(v.replace(",", ".")), [lo, hi] = VIT_LIMITI[chi];
      if (n >= lo && n <= hi) p[chi] = n;
    }
    return ["fr", "spo2", "fc", "pas", "t", "acvpu", "gcs"].some((k) => k in p) ? p : null;
  }
  function vitaliPagina(doc) {
    let ultima = null, righe = 0;
    for (const tr of doc.querySelectorAll('tr[id="VAMI"]')) {
      const p = vitaliRiga(tr);
      const ts = p ? istanteLocale(istanteRiga(tr)) : 0;
      if (!p || !ts) continue;   // senza l'ora non si sa se è l'ultima: non conta
      righe++;
      if (!ultima || ts > ultima.ts) ultima = { ts, p };
    }
    return ultima ? { ...ultima, righe } : null;
  }
  // NEWS2 su quello che c'è: i punti, i parametri in fascia rossa (3 punti da
  // soli), quelli che la riga non ha. Coscienza: ACVPU diverso da A, o GCS <15.
  function news2(p) {
    const fasce = {
      fr: ["FR", (v) => (v <= 8 ? 3 : v <= 11 ? 1 : v <= 20 ? 0 : v <= 24 ? 2 : 3)],
      spo2: ["SpO2", (v) => (v <= 91 ? 3 : v <= 93 ? 2 : v <= 95 ? 1 : 0)],
      fio2: ["O2 (FiO2)", (v) => (v > 21 ? 2 : 0)],
      pas: ["PA", (v) => (v <= 90 ? 3 : v <= 100 ? 2 : v <= 110 ? 1 : v <= 219 ? 0 : 3)],
      fc: ["FC", (v) => (v <= 40 ? 3 : v <= 50 ? 1 : v <= 90 ? 0 : v <= 110 ? 1 : v <= 130 ? 2 : 3)],
      t: ["T", (v) => (v <= 35 ? 3 : v <= 36 ? 1 : v <= 38 ? 0 : v <= 39 ? 1 : 2)],
    };
    let punti = 0;
    const rossi = [], mancano = [];
    for (const [k, [nome, f]] of Object.entries(fasce)) {
      if (p[k] == null) { mancano.push(nome); continue; }
      const n = f(p[k]);
      punti += n;
      if (n === 3) rossi.push(k);
    }
    if (p.acvpu == null && p.gcs == null) mancano.push("coscienza");
    else if ((p.acvpu && p.acvpu !== "A") || (p.gcs != null && p.gcs < 15)) { punti += 3; rossi.push(p.acvpu && p.acvpu !== "A" ? "acvpu" : "gcs"); }
    return { punti, rossi, mancano, livello: rossi.length || punti >= 7 ? "ros" : punti >= 5 ? "amb" : "" };
  }
  // Il cuore di un paziente, o null: rosso, ambra, e vuoto se la riga ha più di 4 ore
  function cuoreDi(vit, ora = Date.now()) {
    if (!vit || !vit.p || !vit.ts) return null;
    const n = news2(vit.p);
    if (!n.livello) return null;
    const eta = Math.max(0, ora - vit.ts), vecchio = eta > VIT_VECCHIO, p = vit.p;
    const num = (v) => String(v).replace(".", ",");
    const testo = {
      fr: p.fr != null && `FR ${p.fr}`, spo2: p.spo2 != null && `SpO2 ${p.spo2}`, fio2: p.fio2 > 21 && `FiO2 ${p.fio2}`,
      fc: p.fc != null && `FC ${p.fc}`, pas: p.pas != null && `PA ${p.pas}${p.pad != null ? "/" + p.pad : ""}`,
      t: p.t != null && `T ${num(p.t)}`, acvpu: p.acvpu && p.acvpu !== "A" && `ACVPU ${p.acvpu}`, gcs: p.gcs != null && `GCS ${p.gcs}`,
    };
    const tutti = Object.values(testo).filter(Boolean), rossi = n.rossi.map((k) => testo[k]).filter(Boolean);
    const titolo = [
      n.rossi.length ? `Parametro critico: ${rossi.join(" · ")} · NEWS2 ${n.punti}` : `NEWS2 ${n.punti} (${n.livello === "ros" ? "7 o più" : "5–6"})`,
      `Parametri misurati ${promOra(vit.ts, ora).replace(/^(?:(\S+) )?(\d)/, (m, g, c) => (g ? g + " alle " : "alle ") + c)}: ${tutti.join(" · ")}`,
      n.mancano.length ? `Non in quella riga (non contati): ${n.mancano.join(", ")}` : "",
      vecchio ? `Nessuna riga più nuova da ${Math.floor(eta / 3600e3)} ore` : "",
    ].filter(Boolean).join("\n");
    return { livello: n.livello, punti: n.punti, vecchio, ore: Math.floor(eta / 3600e3), ts: vit.ts, titolo, chiave: `${vit.ts}|${n.livello}` };
  }

  function statoTutti() {
    const s = store.get(STATO, {});
    const tutti = s && typeof s === "object" && !Array.isArray(s) ? s : {};
    const ora = Date.now();
    let pulito = false;
    for (const k of Object.keys(tutti)) if (!tutti[k] || ora - (tutti[k].agg || 0) > STATO_TTL) { delete tutti[k]; pulito = true; }
    if (pulito) store.set(STATO, tutti);
    return tutti;
  }
  const statoDi = (ep) => (ep ? statoTutti()[ep] || null : null);
  function scriviStato(ep, cambia) {
    if (!ep) return false;
    const tutti = statoTutti();
    const s = cambia({ ...(tutti[ep] || {}) });
    if (!s) return false;
    tutti[ep] = { ...s, agg: Date.now() };
    const tieni = Object.entries(tutti).sort((a, b) => (b[1].agg || 0) - (a[1].agg || 0)).slice(0, PATIENTS_MAX);
    return store.set(STATO, Object.fromEntries(tieni));
  }
  // La pagina del paziente letta adesso. Un risultato che c'è adesso e prima
  // no porta l'ora in cui è stato visto: è «nuovo» finché il medico non guarda
  // gli Esiti. La prima lettura di un paziente è il riferimento: niente nuovi.
  function leggiStatoPagina(ep, doc = document) {
    const righe = richiestePagina(doc), all = allergiePagina(doc), att = attenzionePagina(doc), vit = vitaliPagina(doc);
    return scriviStato(ep, (s) => {
      const ora = Date.now(), primaVolta = !s.letto;
      const prima = new Map((s.righe || []).map((r) => [r.k, r]));
      s.righe = righe.slice(0, 80).map((r) => {
        const p = prima.get(r.k);
        return { ...r, quando: r.fatto ? (p && p.fatto ? p.quando || 0 : primaVolta ? 0 : ora) : 0 };
      });
      s.letto = ora;
      if (all || att) s.anag = { allergie: all, attenzione: att, ts: ora };
      if (vit) s.vit = vit;   // una pagina senza righe dei parametri non cancella le ultime lette
      return s;
    });
  }
  // Gli esami appena messi in carrello da PS Assist, con il numero della richiesta.
  function segnaOrdineNostro(ep, rid, items) {
    const esami = (items || []).map((it) => {
      const label = nomeEsame(it.label || examLabel(it.res, it.code));
      return [RADIO_SET.includes(it.res) ? "img" : /ELETTROCARDIOGRAMM|\bECG\b/i.test(label) ? "ecg" : "lab", label];
    }).filter(([, l]) => l);
    if (!ep || !esami.length) return false;
    return scriviStato(ep, (s) => {
      const l = (s.nostri || []).filter((o) => !rid || o.rid !== String(rid));
      l.push({ ts: Date.now(), rid: rid ? String(rid) : "", esami });
      s.nostri = l.slice(-20);
      return s;
    });
  }
  // Fine turno (pagina di login): le allergie se ne vanno, il resto no — come
  // i promemoria, sono solo episodi, ore e nomi di esami.
  function dimenticaAnagrafiche() {
    const tutti = statoTutti();
    let tolte = 0;
    for (const s of Object.values(tutti)) if (s.anag) { delete s.anag; tolte++; }
    if (tolte) store.set(STATO, tutti);
  }

  // Tutti gli esami noti di un paziente, uno per voce, e il conto per tipo.
  function statoEsami(s, ora = Date.now()) {
    if (!s) return null;
    const pagina = new Set((s.righe || []).map((r) => r.rid).filter(Boolean));
    const aperte = new Set(daConfermare().map((x) => x.rid));   // ancora da confermare: non sono ordini
    const esami = [];
    for (const r of s.righe || []) for (const [tipo, label] of r.esami || []) {
      esami.push({ tipo, label, ts: r.ts || 0, fatto: r.fatto || "", quando: r.quando || 0, qui: false });
    }
    let ultimoNostro = 0;
    for (const o of s.nostri || []) {
      if (o.rid && (pagina.has(o.rid) || aperte.has(o.rid))) continue;
      ultimoNostro = Math.max(ultimoNostro, o.ts || 0);
      for (const [tipo, label] of o.esami || []) esami.push({ tipo, label, ts: o.ts || 0, fatto: "", quando: 0, qui: true });
    }
    if (!esami.length) return null;
    const tipi = {};
    for (const e of esami) {
      const t = (tipi[e.tipo] = tipi[e.tipo] || { n: 0, fatti: 0, attesa: 0, pendenti: 0 });
      t.n++;
      if (e.fatto) t.fatti++;
      else { t.pendenti++; if (e.ts && (!t.attesa || e.ts < t.attesa)) t.attesa = e.ts; }
    }
    const visto = Math.max(s.esitiVisto || 0, 0);
    const nuovi = esami.filter((e) => e.fatto && e.quando && e.quando > visto);
    const v = s.valori || {};
    const letto = s.letto || ultimoNostro;
    return {
      esami, tipi, nuovi, valoriNuovi: v.nuovi || 0, valoriFuori: v.fuori || 0,
      nuovo: !!nuovi.length || (v.nuovi || 0) > 0, rosso: (v.fuori || 0) > 0,
      // la pagina del paziente non è mai stata letta: si sa solo quello che è partito da qui
      letto, vecchio: !!letto && ora - letto > STATO_VECCHIO, soloQui: !s.letto,
    };
  }
  // «ROSSI MARIO» → «ROSSI M.» (il cognome si porta dietro le particelle: DE LUCA A.)
  function nomeBreve(nome) {
    const w = String(nome || "").trim().split(/\s+/).filter(Boolean);
    let i = 0;
    while (i < w.length - 2 && PARTICELLE_COGNOME.has(w[i].toUpperCase())) i++;
    const cognome = w.slice(0, i + 1).join(" "), resto = w.slice(i + 1);
    return !cognome ? "" : resto.length ? `${cognome} ${resto[0][0].toUpperCase()}.` : cognome;
  }
  // «50′», «1h20», «2h»
  function attesaTesto(min) { return min < 60 ? `${min}′` : `${Math.floor(min / 60)}h${min % 60 ? String(min % 60).padStart(2, "0") : ""}`; }
  // neutro sotto la prima soglia, ambra da lì, rosso dalla seconda
  function bandaAttesa(min, [amb, ros]) { return min >= ros ? "ros" : min >= amb ? "amb" : ""; }
  const attesaBanda = (tipo, min) => bandaAttesa(min, ATTESA[tipo] || ATTESA_LAB);
  const minDa = (ts, ora) => Math.max(0, Math.floor((ora - ts) / 60e3));
  // «RX ADDOME SENZA CONTRASTO (A692)» → «RX addome senza contrasto»: le sigle restano sigle
  const frase = (label) => {
    const w = shortLabel(nomeEsame(label)).split(" ").map((x, i) => (x.length <= 3 && /^[A-Z0-9-]+$/.test(x) ? x : i ? x.toLowerCase() : x[0] + x.slice(1).toLowerCase()));
    return w.join(" ");
  };
  // Tutto quello che si sa degli esami, in parole: il passaggio del mouse
  // della riga, del letto e del segnale.
  function statoTitolo(st, ora = Date.now()) {
    if (!st) return "";
    return [
      ...st.esami.map((e) => `${frase(e.label)}: ${e.fatto ? `${e.fatto === "referto" ? "refertato" : "risultati"}${e.ts ? ` (richiesta ${hhmm(e.ts)})` : ""}`
        : `in attesa${e.ts ? ` da ${attesaTesto(minDa(e.ts, ora))} (richiesta ${hhmm(e.ts)})` : ""}`}${e.qui ? " · ordinato da qui" : ""}`),
      st.nuovi.length ? `● nuovo da quando hai guardato gli Esiti: ${st.nuovi.map((e) => frase(e.label)).join(", ")}` : "",
      st.valoriNuovi ? `${st.valoriNuovi} ${st.valoriNuovi === 1 ? "valore nuovo" : "valori nuovi"} non ancora letti${st.valoriFuori ? `, ${st.valoriFuori} fuori range` : ""}` : "",
      st.soloQui ? "Solo gli esami ordinati da qui: la pagina del paziente non è ancora stata letta" : "",
      st.letto ? `letto alle ${hhmm(st.letto)}` : "",
    ].filter(Boolean).join("\n");
  }
  // La riga di stato: un pezzetto per tipo, sempre Lab · ECG · RX in
  // quest'ordine e ognuno col colore della sua sezione negli Esiti:
  // «Lab 3/6 50′», «ECG ✓», «RX 0/1 1h20». L'ambra e il rosso stanno solo sul
  // tempo che aspetta; il pallino «nuovo» dentro il pezzo del suo tipo (i
  // valori nuovi sono del Lab). Nella lista ogni pezzo ha la sua colonna,
  // così il Lab sta sempre allo stesso posto. Corta (l'area): solo quello che
  // aspetta, o ✓ se è tornato tutto.
  function statoHtml(st, { breve = false, ora = Date.now() } = {}) {
    if (!st) return "";
    const pezzi = [];
    const nuovoDi = (t) => st.nuovi.some((e) => e.tipo === t) || (t === "lab" && st.valoriNuovi > 0);
    const dot = (rosso) => `<b class="esdot${rosso ? " ros" : ""}" aria-label="${rosso ? "nuovo, fuori range" : "nuovo"}">●</b>`;
    for (const [t, nome] of TIPI_ESAME) {
      const x = st.tipi[t], nuovo = !breve && nuovoDi(t);
      if (!x && !nuovo) continue;
      if (breve && !x.pendenti) continue;
      const min = x && x.pendenti && x.attesa ? minDa(x.attesa, ora) : null, banda = min == null ? "" : attesaBanda(t, min);
      const timer = min == null ? "" : ` <i class="esatt${banda ? " " + banda : ""}">${attesaTesto(min)}</i>`;
      const conto = breve || !x ? "" : ` ${x.n === 1 && x.fatti === 1 ? "✓" : `${x.fatti}/${x.n}`}`;
      pezzi.push(`<span class="esp es-${t}"><b class="esn">${nome}</b>${conto}${timer}${nuovo ? " " + dot(t === "lab" && st.rosso) : ""}</span>`);
    }
    if (breve && !pezzi.length) pezzi.push(`<span class="esp">✓</span>`);
    const tutto = breve && st.nuovo ? " " + dot(st.rosso) : "";
    return `<span class="esst${breve ? " breve" : ""}${st.vecchio ? " vecchio" : ""}" title="${esc(statoTitolo(st, ora))}">${pezzi.join(" ")}${tutto}</span>`;
  }
  // Il letto è piccolo: nome ed età, e al massimo UN segnale — un pallino.
  // Rosso: un esame oltre la seconda soglia, valori nuovi fuori range, un
  // promemoria passato. Ambra: oltre la prima soglia, o un promemoria fra
  // meno di 15 minuti. Blu: un risultato nuovo. Grigio: qualcosa aspetta
  // (un esame, una cosa da fare). Il resto lo dice il passaggio del mouse.
  function segnaleLetto(st, aperte, ora = Date.now()) {
    const perche = { ros: [], amb: [], nuovo: [], att: [] };
    if (st) {
      for (const [t, nome] of TIPI_ESAME) {
        const x = st.tipi[t];
        if (!x || !x.pendenti) continue;
        const min = x.attesa ? minDa(x.attesa, ora) : null, b = min == null ? "" : attesaBanda(t, min);
        perche[b || "att"].push(`${nome} in attesa${min == null ? "" : ` da ${attesaTesto(min)}`}`);
      }
      if (st.rosso) perche.ros.push("valori nuovi fuori range");
      else if (st.valoriNuovi) perche.nuovo.push(st.valoriNuovi === 1 ? "un valore nuovo" : `${st.valoriNuovi} valori nuovi`);
      if (st.nuovi.length) perche.nuovo.push(`nuovo: ${st.nuovi.map((e) => frase(e.label)).join(", ")}`);
    }
    for (const x of aperte || []) {
      const b = x.t != null ? promBanda(x.t, ora) : "";
      perche[b || "att"].push(`da fare: ${x.t != null ? hhmm(x.t) + " " : ""}${x.testo}`);
    }
    const livello = ["ros", "amb", "nuovo", "att"].find((k) => perche[k].length);
    if (!livello) return "";
    const testo = ["ros", "amb", "nuovo", "att"].flatMap((k) => perche[k]).join("\n");
    return `<b class="stseg ${livello}" role="img" aria-label="${esc(testo.replace(/\n/g, "; "))}" title="${esc(testo)}"></b>`;
  }

  // ------------------------------------------------------------------ NOTA
  // Fino alla 3.57 c'era una nota per paziente (codice fiscale, o il nome),
  // che scadeva dopo 24 ore. Ora è la prima voce di «Da fare» (dfMigra la
  // porta lì): qui resta solo la chiave, per leggere quelle rimaste e per
  // toglierle con il paziente. La stessa scadenza vale per i segni sui valori.
  const noteKey = "note.v1";
  const NOTA_TTL = 24 * 3600e3;

  // ----------------------------------------------------------------- SEGNI
  // Un valore toccato si evidenzia: giallo, al secondo tocco arancio, al
  // terzo torna com'era. Il medico «segna» quello che vuole tenere d'occhio.
  // Per paziente come la nota, con la stessa chiave e la stessa scadenza;
  // la cella è «colonna|analita», la stessa identità della tabella.
  const segniKey = "segni.v1";
  function segniTutti() {
    const s = store.get(segniKey, {});
    const ora = Date.now();
    let pulito = false;
    for (const k of Object.keys(s)) if (ora - (s[k]?.ts || 0) > NOTA_TTL) { delete s[k]; pulito = true; }
    if (pulito) store.set(segniKey, s);
    return s;
  }
  const leggiSegni = (chiave) => (chiave ? (segniTutti()[chiave]?.celle || {}) : {});
  function scriviSegno(chiave, cella, stato) {
    if (!chiave || !cella) return false;
    const s = segniTutti();
    const celle = { ...(s[chiave]?.celle || {}) };
    if (stato) celle[cella] = stato; else delete celle[cella];
    if (Object.keys(celle).length) s[chiave] = { celle, ts: Date.now() }; else delete s[chiave];
    return store.set(segniKey, s);
  }
  // come la nota: i segni fatti prima di conoscere il codice fiscale lo seguono
  function migraSegni(da, a) {
    const s = segniTutti();
    if (!s[da]) return;
    // due buste (una per il nome, una per il codice) si sommano, non si scelgono
    s[a] = { celle: { ...s[da].celle, ...(s[a]?.celle || {}) }, ts: Date.now() };
    delete s[da];
    store.set(segniKey, s);
  }

  // --------------------------------------------------------------- DA FARE
  // Una lista sola per paziente, a spunte tonde: le cose da fare, e — con
  // un'ora scritta dentro («11:30 tropo», «tra 2h ECG») — i promemoria. Si
  // tiene l'ISTANTE, come il cronometro: ricaricare la pagina non sposta
  // niente. La prima voce aperta è il post-it della riga e del letto; l'ordine
  // lo decide il medico (trascinando). Una voce spuntata resta 5 minuti, poi se
  // ne va. Per episodio, mai un nome; al massimo 15 aperte; una con l'ora
  // scade 12 ore dopo l'ora fissata, una senza 24 ore dopo l'ultima modifica.
  // Stanno in questo browser e non vanno da nessuna parte.
  // Fino alla 3.57 c'erano la nota (per paziente) e i promemoria (per
  // episodio): la prima lettura li porta qui (dfMigra) — la nota come prima
  // voce senza ora, i promemoria come voci con l'ora.
  const PROM = "dafare.v1";                  // { ep: [{ id, testo, t|null, fatto|null, ord, ts }] }
  const PROM_VECCHI = "promemoria.v1";
  const PROM_MAX = 15;                       // voci aperte per paziente
  const PROM_TTL = 12 * 3600e3;              // una voce con l'ora, dopo l'ora fissata
  const DF_TTL = 24 * 3600e3;                // una voce senza ora, dopo l'ultima modifica
  const DF_FATTO = 5 * 60e3;                 // una voce spuntata resta 5 minuti
  const DF_LUNGO = 120;                      // una riga sola: la cosa da fare si tiene corta
  // Il primo orario scritto nel testo; il resto è la cosa da fare. Solo le
  // forme che non si confondono con un valore: un'ora coi due punti «11:30»,
  // col punto solo dopo «alle», «ore» o «h» («alle 9.10», «ore 15.30»),
  // «11h30», «11h», «alle 14». Fra quanto: «tra 2h», «+2h», «2h», «2h30»,
  // «90m», «30 min», «30'», «+30′», «tra 45 minuti», «2 ore». Un numero col
  // punto o la virgola da solo («Hb 9.10», «K 5,30») non è mai un'ora. Con una
  // cifra «2h» è fra quanto, con due «11h» è un'ora. Un'ora passata da non più
  // di 2 ore è di oggi (già scaduta); più indietro è di domani: il turno di notte.
  function leggiPromemoria(testo, ora, max = 40) {
    const s = String(testo || "").replace(/\s+/g, " ").trim();
    const T = "(?<![\\p{L}\\p{N}_])", F = "(?![\\p{L}\\p{N}_])";
    const FRA = "(?:(?:tra|fra|entro|in|dopo)\\s+|\\+\\s?)", ALLE = "(?:(?:alle|verso\\s+le|per\\s+le|entro\\s+le)(?:\\s+ore)?\\s+|ore\\s+|h\\s?)";
    const eFra = (p) => new RegExp(`^${FRA}$`, "i").test(p || "");   // «entro le 14» è un'ora, «entro 2h» fra quanto
    const alle = (h, m) => {
      if (h > 23 || m > 59) return null;
      const d = new Date(ora);
      d.setHours(h, m, 0, 0);
      if (d.getTime() < ora - 2 * 3600e3) d.setDate(d.getDate() + 1);
      else if (d.getTime() >= ora + 22 * 3600e3) d.setDate(d.getDate() - 1);
      return d.getTime();
    };
    const fra = (min) => (min >= 1 && min <= 1440 ? Math.floor((ora + min * 60e3) / 60e3) * 60e3 : null);
    const forme = [
      // 11:30 (e «tra 1:30»: fra un'ora e mezza). Col punto è anche un numero
      // («Hb 9.10», «K 5.30»): un'ora solo dopo «alle», «ore» o «h»
      [`${T}(${FRA}|${ALLE})?(\\d{1,2})([:.])(\\d{2})${F}`, (m) => (+m[4] > 59 || (m[3] === "." && !(m[1] && !eFra(m[1]))) ? null
        : eFra(m[1]) ? fra(+m[2] * 60 + +m[4]) : alle(+m[2], +m[4]))],
      // 11h, 11h30 · 2h, 2h30, tra 2h
      [`${T}(${FRA}|${ALLE})?(\\d{1,2}) ?h(?:(\\d{2})(?: ?min| ?m)?)?${F}`, (m) => {
        const h = +m[2], mm = +(m[3] || 0);
        if (mm > 59) return null;
        return (m[1] ? eFra(m[1]) : m[2].length === 1) ? fra(h * 60 + mm) : alle(h, mm);
      }],
      // 2 ore, tra 1 ora
      [`${T}${FRA}?(\\d{1,2}) ?or[ae]${F}`, (m) => fra(+m[1] * 60)],
      // 90m, 30 min, 30', tra 45 minuti
      [`${T}${FRA}?(\\d{1,4}) ?(?:minut[io]|min|m|['’′])(?![\\p{L}\\p{N}_'’′])`, (m) => fra(+m[1])],
      // alle 14, ore 14
      [`${T}${ALLE}(\\d{1,2})(?![\\p{L}\\p{N}_:'’′]|\\.\\d)`, (m) => alle(+m[1], 0)],
    ];
    let primo = null;
    for (const [re, quando] of forme) {
      for (const m of s.matchAll(new RegExp(re, "giu"))) {
        const t = quando(m);
        if (t == null) continue;
        const c = { i: m.index, n: m[0].length, t, debole: m[3] === "." ? 1 : 0 };
        if (!primo || c.debole < primo.debole
          || (c.debole === primo.debole && (c.i < primo.i || (c.i === primo.i && c.n > primo.n)))) primo = c;
        break;   // di ogni forma conta la prima che vale
      }
    }
    if (!primo) return null;
    // il resto è la cosa da fare: senza la punteggiatura rimasta dove stava l'orario
    const prima = s.slice(0, primo.i).replace(/[\s·:,;\-–—]+$/, ""), dopo = s.slice(primo.i + primo.n).replace(/^[\s·:,;.\-–—]+/, "");
    const resto = `${prima} ${dopo}`.replace(/^[\s·:,;.\-–—]+|[\s·:,;\-–—]+$/g, "").slice(0, max).trim();
    return { t: primo.t, testo: resto || "promemoria" };
  }
  // Quanto manca, nel modo più corto: «1h40», «40m», «ora», «−5m».
  function promTempo(t, ora) {
    const hm = (min) => (min >= 60 ? `${Math.floor(min / 60)}h${min % 60 ? String(min % 60).padStart(2, "0") : ""}` : `${min}m`);
    if (t > ora) return hm(Math.ceil((t - ora) / 60e3));
    const tardi = Math.floor((ora - t) / 60e3);
    return tardi < 1 ? "ora" : "−" + hm(tardi);
  }
  // «FERRARI LUCA» → «Ferrari», «DE LUCA GIOVANNI» → «De Luca», «D'ANGELO M» → «D'Angelo»:
  // il cognome (con le sue particelle) in minuscolo con le iniziali maiuscole
  const PARTICELLE_COGNOME = new Set(["DE", "DI", "DA", "DEL", "DELLA", "DELLE", "DELLO", "DEI", "DEGLI", "DAL", "DALLA", "DALLE", "DALLO",
    "LA", "LO", "LE", "LI", "SAN", "SANTA", "SANTO", "VAN", "VON", "MC", "MAC", "DOS", "DAS", "DU"]);
  function cognomeTitolo(nome) {
    const w = String(nome || "").trim().split(/\s+/).filter(Boolean);
    let i = 0;
    while (i < w.length - 2 && PARTICELLE_COGNOME.has(w[i].toUpperCase())) i++;
    return w.slice(0, i + 1).join(" ").toLowerCase().replace(/(^|[\s'’-])(\p{L})/gu, (m, a, b) => a + b.toUpperCase());
  }
  // Il colore dell'icona «Da fare»: tranquilla; ambra dai 15 minuti prima;
  // rossa quando l'ora è passata (scaduto).
  function promBanda(t, ora) { return t <= ora ? "ros" : t - ora <= 15 * 60e3 ? "amb" : ""; }
  // La sveglia sulla pill ridotta, quella di sempre: a 10 minuti, o passata.
  const promAllarme = (t, ora) => Math.ceil((t - ora) / 60e3) <= 10;
  // l'ora fissata, col giorno quando non è oggi: «11:30», «domani 07:30»
  function promOra(t, ora) {
    const giorno = (x) => { const d = new Date(x); d.setHours(0, 0, 0, 0); return d.getTime(); };
    const g = Math.round((giorno(t) - giorno(ora)) / 864e5);
    return `${g === 1 ? "domani " : g === -1 ? "ieri " : ""}${hhmm(t)}`;
  }
  // per esteso, per il passaggio del mouse: «11:30 · tropo · tra 15 min»
  function promRiga(p, ora) {
    const parole = (min) => (min >= 60 ? `${Math.floor(min / 60)} h${min % 60 ? ` ${min % 60} min` : ""}` : `${min} min`);
    const tardi = Math.floor((ora - p.t) / 60e3);
    const quando = p.t > ora ? "tra " + parole(Math.ceil((p.t - ora) / 60e3)) : tardi < 1 ? "adesso" : "in ritardo di " + parole(tardi);
    return `${promOra(p.t, ora)}${p.testo ? " · " + p.testo : ""} · ${quando}`;
  }
  const dfId = () => "d" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const dfValida = (x) => x && typeof x.id === "string" && typeof x.testo === "string"
    && (x.t == null || Number.isFinite(x.t)) && (x.fatto == null || Number.isFinite(x.fatto));
  // Le voci di tutti, ognuna nel suo ordine; quelle scadute e quelle spuntate
  // da più di 5 minuti se ne vanno qui, alla lettura.
  function dfTutti(ora = Date.now()) {
    let raw = store.get(PROM, {});
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) raw = {};
    let cambiato = dfMigra(raw, ora);
    const tutti = {};
    for (const [ep, l] of Object.entries(raw)) {
      const vive = /^[\w.-]{1,40}$/.test(ep) && Array.isArray(l)
        ? l.filter((x) => dfValida(x) && !(x.fatto && ora - x.fatto > DF_FATTO)
            && (x.t != null ? ora - x.t <= PROM_TTL : ora - (x.ts || 0) <= DF_TTL))
        : [];
      if (vive.length !== (Array.isArray(l) ? l.length : -1)) cambiato = true;
      vive.sort((x, y) => (x.ord ?? 0) - (y.ord ?? 0));
      if (vive.length) tutti[ep] = vive.map((x, i) => ({ id: x.id, testo: x.testo, t: x.t ?? null, fatto: x.fatto ?? null, ord: i, ts: x.ts || ora }));
    }
    if (cambiato) store.set(PROM, tutti);
    return tutti;
  }
  // La nota (per paziente) e i promemoria (per episodio) di prima: la nota
  // diventa la prima voce, senza ora, dell'episodio più recente di quel
  // paziente; i promemoria, voci con l'ora. Una nota che non si sa di chi sia
  // (un omonimo, un paziente non in elenco) resta dov'era, finché scade.
  function dfMigra(raw, ora) {
    const vecchi = store.get(PROM_VECCHI, null), note = store.get(noteKey, null);
    const conNote = !!note && typeof note === "object" && Object.keys(note).length > 0;
    if (!vecchi && !conNote) return false;
    const voce = (testo, t, ts) => ({ id: dfId(), testo, t, fatto: null, ord: 0, ts: ts || ora });
    let cambiato = false;
    if (vecchi && typeof vecchi === "object") {
      for (const [ep, l] of Object.entries(vecchi)) {
        if (!/^[\w.-]{1,40}$/.test(ep) || !Array.isArray(l)) continue;
        const qui = Array.isArray(raw[ep]) ? raw[ep] : [];
        for (const p of l) {
          if (!p || !Number.isFinite(p.t) || typeof p.testo !== "string" || qui.some((x) => x.id === p.id)) continue;
          qui.push({ ...voce(p.testo, p.t, p.ts), id: typeof p.id === "string" ? p.id : dfId(), ord: qui.length + 1000 });
        }
        if (qui.length) { raw[ep] = qui; cambiato = true; }
      }
    }
    if (vecchi) store.del(PROM_VECCHI);
    if (conNote) {
      const pazienti = tuttiPazienti(), attivi = pazienti.filter((p) => !p.arch);
      let tolte = false;
      for (const [k, n] of Object.entries(note)) {
        const testo = String(n?.t || "").replace(/\s*\n+\s*/g, " · ").trim();
        if (!testo || ora - (n.ts || 0) > NOTA_TTL) continue;
        let suoi;
        if (k.startsWith("cf:")) suoi = pazienti.filter((p) => p.pk === k);
        else {
          const nome = k.replace(/^nome:/, "");
          if (attivi.filter((p) => normNome(p.name) === nome).length > 1) continue;   // un omonimo: non si attribuisce
          suoi = pazienti.filter((p) => !String(p.pk || "").startsWith("cf:") && normNome(p.name) === nome);
        }
        const p = [...suoi].sort((a, b) => (!!a.arch - !!b.arch) || (b.ts || 0) - (a.ts || 0))[0];
        if (!p) continue;
        const qui = Array.isArray(raw[p.ep]) ? raw[p.ep] : [];
        qui.unshift({ ...voce(testo.slice(0, 500), null, n.ts), ord: -1e6 });
        raw[p.ep] = qui;
        delete note[k];
        tolte = cambiato = true;
      }
      if (tolte) store.set(noteKey, note);
    }
    return cambiato;
  }
  // tutte le voci di un paziente, nel suo ordine (anche quelle appena spuntate)
  const dfDi = (ep, tutti = dfTutti()) => (ep && tutti[ep] ? tutti[ep].map((x) => ({ ...x })) : []);
  const dfAperte = (ep, tutti) => dfDi(ep, tutti).filter((x) => !x.fatto);
  function dfScrivi(ep, l) {
    if (!ep) return false;
    const tutti = dfTutti();
    if (l.length) tutti[ep] = l.map((x, i) => ({ ...x, ord: i })); else delete tutti[ep];
    return store.set(PROM, tutti);
  }
  // Una voce nuova, in fondo (la prima resta il post-it). Con un'ora scritta
  // dentro è un promemoria; senza, una cosa da fare. null: troppe, o vuota.
  function dfAggiungi(ep, testo, { t, inCima = false, max = DF_LUNGO } = {}) {
    const s = String(testo || "").replace(/\s+/g, " ").trim();
    const l = dfDi(ep);
    if (!ep || !s || l.filter((x) => !x.fatto).length >= PROM_MAX) return null;
    let quando = t ?? null, cosa = s;
    if (t === undefined) {
      const p = leggiPromemoria(s, Date.now(), DF_LUNGO);
      if (p) { quando = p.t; cosa = p.testo; }
    }
    const x = { id: dfId(), testo: cosa.slice(0, max), t: quando, fatto: null, ord: 0, ts: Date.now() };
    if (inCima) l.unshift(x); else l.push(x);
    return dfScrivi(ep, l) ? x : null;
  }
  // spuntata (o tolta la spunta): resta al suo posto, barrata, 5 minuti
  function dfSpunta(ep, id, si = true) {
    const l = dfDi(ep), x = l.find((v) => v.id === id);
    if (!x) return null;
    x.fatto = si ? Date.now() : null;
    x.ts = Date.now();
    return dfScrivi(ep, l) ? x : null;
  }
  // in un altro posto della lista: `a` è l'indice nuovo
  function dfSposta(ep, id, a) {
    const l = dfDi(ep), i = l.findIndex((v) => v.id === id);
    if (i < 0) return false;
    const [x] = l.splice(i, 1);
    l.splice(Math.max(0, Math.min(l.length, a)), 0, x);
    return dfScrivi(ep, l);
  }
  function dfCambia(ep, id, testo) {
    const l = dfDi(ep), x = l.find((v) => v.id === id);
    if (!x) return false;
    x.testo = String(testo).slice(0, 500); x.ts = Date.now();
    return dfScrivi(ep, l);
  }
  const dfTogli = (ep, id) => dfScrivi(ep, dfDi(ep).filter((x) => x.id !== id));
  // Il post-it: la prima voce aperta, nell'ordine del medico
  const dfPrima = (ep, tutti) => dfAperte(ep, tutti)[0] || null;
  // La «nota» del telefono è la prima voce aperta SENZA ora (vedi il Ponte)
  const dfNota = (ep, tutti) => dfAperte(ep, tutti).find((x) => x.t == null) || null;

  // I promemoria sono le voci aperte con un'ora: le stesse funzioni di prima,
  // così la sveglia sulla pill, il +15′ e il telefono restano quelli.
  function promTutti(tutti = dfTutti()) {
    const out = {};
    for (const [ep, l] of Object.entries(tutti)) {
      const p = l.filter((x) => x.t != null && !x.fatto).map((x) => ({ id: x.id, t: x.t, testo: x.testo, ts: x.ts }));
      if (p.length) out[ep] = p;
    }
    return out;
  }
  // quelli di un paziente, il più vicino per primo
  const promDi = (ep, tutti = promTutti()) => (ep && tutti[ep] ? [...tutti[ep]].sort((a, b) => a.t - b.t) : []);
  const promAggiungi = (ep, p) => !!dfAggiungi(ep, String(p.testo || "").slice(0, 40), { t: p.t });
  // ✓ Fatto: spuntato (se ne va fra 5 minuti; «Annulla» toglie la spunta)
  function promTogli(ep, id) {
    const x = dfDi(ep).find((v) => v.id === id && v.t != null && !v.fatto);
    return x && dfSpunta(ep, id, true) ? { id: x.id, t: x.t, testo: x.testo, ts: x.ts } : null;
  }
  // «+15 min»: da quando era fissato, o da adesso se è già passato
  function promRinvia(ep, id, ms = 15 * 60e3) {
    const l = dfDi(ep), p = l.find((x) => x.id === id && x.t != null);
    if (!p) return false;
    p.t = Math.floor((Math.max(p.t, Date.now()) + ms) / 60e3) * 60e3;
    return dfScrivi(ep, l);
  }
  function promRimetti(ep, p) {
    if (dfDi(ep).some((x) => x.id === p.id)) return !!dfSpunta(ep, p.id, false);
    return !!dfAggiungi(ep, p.testo, { t: p.t });
  }

  // ------------------------------------------------------------ RIFERIMENTI
  // La tabella del medico, i «can't-miss killers»: per sintomo, cosa
  // escludere per primo. Testo suo, in inglese come l'ha scritta; la terza
  // voce sono solo parole per trovarla scrivendo in italiano.
  const RIFERIMENTI = {
    ancora: "Don't anchor the DDx — lethal DDx for this complaint? · actively excluded (not assumed)? · every vital explained?",
    gruppi: [
      { titolo: "Can't-miss killers — by complaint, rule out first", voci: [
        ["Chest pain", "ACS · PE · dissection · tamponade · tension PTX · Boerhaave", "dolore toracico torace petto"],
        ["Dyspnoea", "PE · APE/SCAPE · tension PTX · anaphylaxis · sepsis · near-fatal asthma", "dispnea affanno respiro"],
        ["Headache", "SAH · meningitis · mass/↑ICP · CVST · GCA · carotid/vertebral dissection · pituitary apoplexy · CO · angle-closure glaucoma", "cefalea mal di testa"],
        ["Back pain", "AAA · dissection · cord compression · epidural abscess · epidural haematoma", "lombalgia dorsalgia schiena mal di schiena"],
        ["Abdo pain", "AAA · mesenteric ischaemia · ectopic · perforation · strangulated obstruction", "dolore addominale addome pancia"],
        ["Syncope", "PE · SAH · AAA · malignant arrhythmia · ectopic · AS · HCM (exertional = flag)", "sincope svenimento"],
        ["Palpitations", "WPW + pre-excited AF · long QT · Brugada · ARVC · HCM", "palpitazioni cardiopalmo"],
        ["Sore throat / neck", "Ludwig's · epiglottitis · retropharyngeal abscess · carotid dissection · Lemierre's", "mal di gola faringodinia collo"],
        ["Unilateral leg", "DVT · acute limb ischaemia · nec fasc · compartment syndrome", "gamba arto inferiore edema"],
        ["Fever + rash", "meningococcaemia · sepsis · nec fasc · toxic shock", "febbre esantema rash petecchie"],
        ["Altered mental state", "hypoglycaemia · hypoxia · sepsis/CNS · stroke · tox · ↑ICP · non-convulsive status · Wernicke", "alterazione coscienza confusione stato mentale"],
        ["Vomiting", "strangulated obstruction · DKA (incl. euglycaemic) · ↑ICP · bowel ischaemia", "vomito"],
        ["♀ pain / bleeding", "ectopic until proven otherwise · haemorrhage", "donna gravidanza metrorragia sanguinamento"],
        ["Overdose", "TCA · salicylates · toxic alcohols · paracetamol (silent) · CCB/BB · CO", "intossicazione sovradosaggio"],
        ["Traveller (febrile)", "malaria · typhoid · viral haemorrhagic fever · sepsis", "viaggiatore viaggio febbre"],
      ] },
      { titolo: "Benign labels that hide killers", freccia: true, voci: [
        ["Gastroenteritis", "surgical abdomen · DKA · inferior MI · Addisonian", "gastroenterite"],
        ["Mechanical back pain", "leaking AAA · epidural abscess", "lombalgia meccanica"],
        ["Anxiety / hypervent.", "PE", "ansia iperventilazione"],
        ["Renal colic >50", "ruptured AAA", "colica renale"],
        ["Muscular chest pain", "ACS", "dolore toracico muscolare"],
        ["Simple faint", "exertional/structural (AS, HCM, arrhythmia)", "sincope vasovagale"],
        ["UTI (elderly)", "urosepsis / source unproven", "infezione urinaria anziano"],
      ] },
      { titolo: "Who reweights the list", freccia: true, voci: [
        ["Pregnant", "ectopic · PE · pre-eclampsia · dissection", "gravidanza incinta"],
        ["Immunocompromised", "atypical/late · neutropenic sepsis = emergency", "immunodepresso"],
        ["Anticoagulated", "ICH · epidural haematoma · occult bleed", "anticoagulato tao doac"],
        ["Elderly", "atypical MI · silent sepsis · delirium = presentation", "anziano"],
        ["IV drug user", "endocarditis · septic emboli · abscess", "tossicodipendente"],
        ["Traveller", "malaria · typhoid · VHF", "viaggiatore viaggio"],
      ] },
    ],
    piede: "Same complaint, different killer list — who is this patient reweights everything.",
  };
  // il filtro: tutte le parole scritte devono esserci (in inglese o in italiano)
  const rifCombacia = (testo, q) => {
    const t = testo.toLowerCase();
    return q.toLowerCase().split(/\s+/).filter(Boolean).every((w) => t.includes(w));
  };

  // ----------------------------------------------------------------- TEMPI
  // Un cronometro per capire dove va il tempo di un turno. Si tiene solo
  // l'ISTANTE DI INIZIO, mai i secondi passati: così ricaricare la pagina o
  // riavviare il browser non perde niente e il conto resta giusto. Il
  // cronometro in corso è semplicemente la voce che non ha ancora una fine.
  const tempiKey = "tempi.v1";
  const TEMPI_TTL = 7 * 24 * 3600e3;
  const TITOLI = ["Visita ed esami", "Scrittura cartella", "Gestione (consulenti)", "Dimissione"];
  function tempi() {
    const l = store.get(tempiKey, []);
    const ora = Date.now();
    const vivi = (Array.isArray(l) ? l : []).filter((t) => t && t.inizio && ora - t.inizio < TEMPI_TTL);
    if (vivi.length !== (Array.isArray(l) ? l.length : 0)) store.set(tempiKey, vivi);
    return vivi;
  }
  const tempoInCorso = () => tempi().find((t) => !t.fine) || null;
  function avviaTempo(titolo, paz, ep) {
    const l = tempi();
    const ora = Date.now();
    for (const t of l) if (!t.fine) t.fine = ora;   // uno solo alla volta: il precedente si chiude
    l.push({ id: "t" + ora.toString(36), titolo: String(titolo || "").slice(0, 60) || "Attivita",
             paz: String(paz || "").slice(0, 60), ep: String(ep || ""), inizio: ora });
    return store.set(tempiKey, l);
  }
  function fermaTempo() {
    const l = tempi();
    const t = l.find((x) => !x.fine);
    if (!t) return false;
    t.fine = Date.now();
    return store.set(tempiKey, l);
  }
  const scordaTempo = (id) => store.set(tempiKey, tempi().filter((t) => t.id !== id));
  const durata = (t) => Math.max(0, ((t.fine || Date.now()) - t.inizio));
  const mmss = (ms) => {
    const s = Math.floor(ms / 1000);
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60);
    return h ? `${h}h ${String(m).padStart(2, "0")}m` : `${m}m ${String(s % 60).padStart(2, "0")}s`;
  };
  const oraDi = (ms) => new Date(ms).toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" });
  const giornoDi = (ms) => new Date(ms).toLocaleDateString("it-IT", { day: "2-digit", month: "2-digit", year: "numeric" });

  const dimKey = "dimissioni.v1";
  // A short fingerprint of the text a doctor's version was forked from. It is
  // what lets a later release SAY that the original changed (a dose, a
  // contraindication): without it, a corrected sheet would be silently
  // invisible to everyone who had ever edited that sheet.
  function impronta(testo) {
    let h = 0x811c9dc5;
    const t = String(testo || "").replace(/\s+/g, " ").trim();
    for (let i = 0; i < t.length; i++) { h ^= t.charCodeAt(i); h = Math.imul(h, 0x01000193); }
    return (h >>> 0).toString(36);
  }
  const dimValido = (v) => !!(v && typeof v.testo === "string" && v.testo.trim());
  // un foglio nuovo, prima di avere un nome: la chiave dell'editor vuoto
  const DIM_NUOVO = "+nuovo";
  function dimissioni() {
    const mie = store.get(dimKey, {});
    const out = {};
    // i fogli scritti dal medico vengono per primi: li ha voluti lui
    for (const [k, v] of Object.entries(mie)) {
      if (!DIMISSIONI[k] && dimValido(v)) out[k] = { nome: (v.nome || k), testo: v.testo, originale: "", modificato: true, mio: true };
    }
    for (const [k, v] of Object.entries(DIMISSIONI)) {
      const m = dimValido(mie[k]) ? mie[k] : null;
      out[k] = {
        nome: v.nome, testo: m ? m.testo : v.testo, originale: v.testo, modificato: !!m,
        rivisto: !!v.rivisto,
        // the shipped text moved AFTER this doctor forked it
        aggiornato: !!(m && m.base && m.base !== impronta(v.testo)),
      };
    }
    return out;
  }
  function salvaDimissione(k, nome, testo) {
    const mie = store.get(dimKey, {});
    const base = DIMISSIONI[k];
    if (base && testo.trim() === base.testo.trim()) delete mie[k];   // back to the original: stop overriding
    else mie[k] = { nome, testo, base: base ? impronta(base.testo) : "" };
    return store.set(dimKey, mie);
  }
  function ripristinaDimissione(k) {
    const mie = store.get(dimKey, {});
    delete mie[k];
    return store.set(dimKey, mie);
  }

  // EO — un elenco piatto chiave→voce, così una riga o una tendina copiano
  // allo stesso modo. I testi sono quelli scritti dal medico, verbatim.
  // Il medico li può riscrivere (✎), come i fogli di dimissione: la sua
  // versione sta in "eo.v1" e ricorda da quale originale è partita, così se
  // l'originale cambia glielo si dice.
  const eoKey = "eo.v1";
  function eoVoci() {
    const out = {};
    // gli EO di base, uno per riga in cima: prima quelli del medico («Mio
    // solito base»), poi l'EO generale
    for (const v of EO.basi || []) if (v && v.k && v.testo) out["base:" + v.k] = { nome: v.nome || v.k, meta: v.meta || "", testo: v.testo, gruppo: "base" };
    if (EO.base && EO.base.testo) out.base = { nome: EO.base.nome || "EO generale", meta: EO.base.meta || "", testo: EO.base.testo, gruppo: "base" };
    for (const v of EO.casi || []) if (v && v.k && v.testo) out["caso:" + v.k] = { nome: v.nome || v.k, testo: v.testo, gruppo: "casi" };
    for (const v of EO.frasi || []) if (v && v.k && v.testo) out["frase:" + v.k] = { nome: v.nome || v.k, testo: v.testo, gruppo: "frasi" };
    const mie = store.get(eoKey, {}) || {};
    for (const [k, v] of Object.entries(out)) {
      const m = Object.prototype.hasOwnProperty.call(mie, k) && dimValido(mie[k]) ? mie[k] : null;
      v.originale = v.testo;
      if (!m) continue;
      v.testo = m.testo; v.modificato = true;
      v.aggiornato = !!(m.base && m.base !== impronta(v.originale));
    }
    return out;
  }
  function salvaEo(k, testo) {
    const v = eoVoci()[k];
    if (!v) return false;
    const mie = store.get(eoKey, {}) || {};
    if (testo.trim() === v.originale.trim()) delete mie[k];   // tornato com'era: niente da ricordare
    else mie[k] = { testo, base: impronta(v.originale) };
    return store.set(eoKey, mie);
  }
  function ripristinaEo(k) {
    const mie = store.get(eoKey, {}) || {};
    delete mie[k];
    return store.set(eoKey, mie);
  }

  function learnedCatalog() { return store.get("catalog.v1", {}); }
  // Il catalogo si impara dalle pagine vere, MA un nome già noto non viene
  // mai sovrascritto. Il motivo è il controllo anti-esame-sbagliato: quello
  // confronta il nome della riga viva col nome con cui l'esame è stato
  // scelto. Se la stessa pagina potesse riscrivere il catalogo un istante
  // prima del click, il confronto sarebbe fra un valore e se stesso — e non
  // potrebbe più fallire. Un codice che oggi porta un altro nome è proprio
  // l'anomalia che deve fermare tutto: la ferma quel controllo, non si assorbe.
  function learnFrom(model) {
    if (!model.res || !model.exams.length) return;
    const cat = learnedCatalog();
    const entry = cat[model.res] || { label: "", items: {} };
    const opt = model.resOptions.find((o) => o.value === model.res);
    if (opt) entry.label = opt.label;
    const incisi = (EMBEDDED_CATALOG[model.res] || {}).items || {};
    for (const e of model.exams) if (!incisi[e.code] && !entry.items[e.code]) entry.items[e.code] = e.label;
    // gli appunti delle versioni prima (lo schema dell'«aggiungi», BRANCA, i
    // nomi cambiati) servivano solo a mandare un esame col codice salvato:
    // quella strada non c'è più, e nemmeno loro
    delete entry.ins; delete entry.par; delete entry.rinominati;
    entry.ts = Date.now();
    cat[model.res] = entry;
    store.set("catalog.v1", cat);
  }
  // La ricerca del gestionale, quella della casella «Prestazione» sopra la
  // griglia: l'elenco stesso, con s_PRESTAZIONE scritto (ogni link della
  // pagina lo porta già: è lo stato della ricerca). Si cerca per mnemonico LIS
  // se il nome ne ha uno — «(POC1401)» — altrimenti per nome.
  const termineRicerca = (label) => mnemonico(label) || shortLabel(String(label || "")).replace(/\s+/g, " ").trim();
  function urlRicerca(listUrl, termine) {
    if (!listUrl || !termine || !/[?&]s_PRESTAZIONE=/.test(listUrl)) return null;
    return listUrl.replace(/([?&]s_PRESTAZIONE=)[^&#]*/, (m, k) => k + encodeW1252Component(termine));
  }
  // A resource id is site-local: "LABORATORIO ANALISI POC" is 00660001P in one
  // presidio and something else in another, and the same is true of radiology.
  // What travels is the NAME, so that is what we match on — the site suffix
  // ("- SSG (P)") is dropped first. Nothing is ordered on the strength of this
  // alone: the exam's own live name is still checked before every send.
  const chiaveRisorsa = (label) => String(label || "")
    .toUpperCase().replace(/\s+/g, " ")
    .replace(/\s*-\s*[A-Z]{2,5}\s*(\([A-Z]\))?\s*$/, "")
    .replace(/\s*\([A-Z]\)\s*$/, "")
    .trim();
  // the mnemonic the LIS puts in brackets — "EMOCROMOCITOMETRICO URGENTE
  // (POCT1502)" — identifies an exam far better than its numeric code
  const mnemonico = (label) => { const m = /\(([A-Z0-9._-]{3,})\)\s*$/i.exec(String(label || "").trim()); return m ? m[1].toUpperCase() : ""; };
  const normEsame = (s) => String(s || "").replace(/\s+/g, " ").trim().toUpperCase();
  // Lo stesso esame su una riga viva: lo stesso nome (la tipografia non conta:
  // i trattini cambiano da una sede all'altra) o lo stesso mnemonico LIS. Mai
  // per somiglianza. È il cancello prima di ogni invio (regola 4).
  const nomeVivo = (s) => String(s || "").replace(/[–—‐‑‒−]/g, "-").replace(/\s+/g, " ").trim().toUpperCase();
  const stessoNomeVivo = (a, b) => (!!nomeVivo(a) && nomeVivo(a) === nomeVivo(b)) || (!!mnemonico(a) && mnemonico(a) === mnemonico(b));

  // Dove va un esame in QUESTA sede. Le risorse cambiano numero da una sede
  // all'altra (e si riconoscono per nome), ma una sede può anche non avere
  // proprio quella risorsa: a OSG il laboratorio «Urgenze» non esiste, e i
  // suoi esami stanno nel laboratorio unico. Allora vale la risorsa offerta
  // qui che ha lo STESSO esame — stesso nome o stesso mnemonico LIS — e mai un
  // POC per un esame che POC non è (è un altro strumento, un'altra provetta),
  // né il contrario. Nessun esame viene inviato sulla fiducia di questa
  // scelta: il nome vero si ricontrolla sull'elenco vivo prima di ogni invio.
  const ePoc = (label) => /\bPOC\b/i.test(String(label || ""));
  function risorsaQui(it, opzioni, cat) {
    const offerte = new Set(opzioni.map((o) => o.value));
    if (!it.res || offerte.has(it.res)) return it.res ? { res: it.res } : null;
    const nomeRis = (cat[it.res] && cat[it.res].label) || "";
    const atteso = chiaveRisorsa(nomeRis);
    const stessoNome = atteso ? opzioni.find((o) => chiaveRisorsa(o.label) === atteso) : null;
    if (stessoNome) return { res: stessoNome.value, perNome: true, opt: stessoNome };
    const mioPoc = ePoc(nomeRis) || ePoc(it.label);
    const mioNome = normEsame(it.label), mioMn = mnemonico(it.label);
    if (!mioNome || /^ESAME \d+$/.test(mioNome)) return null;
    for (const o of opzioni) {
      if (ePoc(o.label) !== mioPoc) continue;
      const voci = Object.entries((cat[o.value] && cat[o.value].items) || {});
      const hit = voci.find(([, l]) => normEsame(l) === mioNome) || (mioMn ? voci.find(([, l]) => mnemonico(l) === mioMn) : null);
      if (hit) return { res: o.value, code: hit[0], label: hit[1], opt: o };
    }
    return null;
  }
  // Come si chiamano in reparto → come comincia il nome nel catalogo del LIS.
  const ALIAS_RICERCA = {
    PCR: ["PROTEINA C REATTIVA"], PCT: ["PROCALCITONINA"],
    EGA: ["EMOGAS", "EGA "], GGT: ["GAMMA GT"], AST: ["GOT"], ALT: ["GPT"],
    BNP: ["NT PRO-BNP", "NT-PRO", "BNP"], TROPO: ["TROPONINA"], TROP: ["TROPONINA"],
    EMOCROMO: ["EMOCROMOCITOMETRICO"], URINE: ["ESAME URINE"],
  };
  // a parità di nome: urgenze, poi il laboratorio, poi il POC, poi il resto
  function ordineRisorsa(res, cat) {
    const l = chiaveRisorsa((cat[res] && cat[res].label) || "");
    if (/URGENZ/.test(l)) return 0;
    if (/\bPOC\b/.test(l)) return 2;
    if (/^LABORATORIO/.test(l)) return 1;
    return 3;
  }
  // un nome corto per una risorsa che RES_SHORT non conosce (quelle di
  // un'altra sede): «LABORATORIO ANALISI POC - OSG (P)» → «POC»
  function risorsaCorta(res, cat = fullCatalog()) {
    if (RES_SHORT[res]) return RES_SHORT[res];
    const l = chiaveRisorsa((cat[res] && cat[res].label) || "");
    if (!l) return res;
    if (/\bPOC\b/.test(l)) return "POC";
    if (/URGENZ/.test(l)) return "Lab centrale";
    if (/^RADIOLOGIA/.test(l)) return l.replace(/^RADIOLOGIA\s*-?\s*/, "").replace(/RISONANZA MAGNETICA NUCLEARE/, "RMN").trim() || "Radiologia";
    if (/^LABORATORIO/.test(l)) return "Lab centrale";
    return l.slice(0, 18);
  }

  function fullCatalog() {
    const out = {};
    for (const [res, v] of Object.entries(EMBEDDED_CATALOG)) out[res] = { label: v.label, items: { ...v.items } };
    for (const [res, v] of Object.entries(learnedCatalog())) {
      out[res] = out[res] || { label: v.label || res, items: {} };
      if (v.label) out[res].label = v.label;
      Object.assign(out[res].items, v.items);
    }
    return out;
  }
  const examLabel = (res, code) => (fullCatalog()[res]?.items || {})[code] || `esame ${code}`;
  // Il laboratorio affianca al vecchio esame la sua versione «- NEW» e lascia
  // in elenco tutti e due (l'emogas venoso e l'arterioso sono così). Chi
  // ordina vuole il nuovo. Il confronto è sul NOME, non sul numero, che cambia
  // da un ospedale all'altro.
  // NB: si toglie SOLO il mnemonico in fondo — «(POC2117)» — non tutte le
  // parentesi: «EPATITE B (HBSAG) ANTICORPI» e «EPATITE B (HBEAG) ANTICORPI»
  // sono due esami diversi e diventerebbero lo stesso nome.
  const baseEsame = (label) => String(label || "").replace(/&nbsp;/gi, " ").toUpperCase()
    .replace(/\s*\([A-Z]*\d+\)\s*$/, " ").replace(/\s+-\s*NEW\b/g, " ").replace(/\bPOC\b/g, " ")
    .replace(/[^A-Z0-9()]+/g, " ").trim();
  const eNuovo = (label) => /\s-\s*NEW\b/i.test(String(label || "").replace(/&nbsp;/gi, " "));
  // Due nomi che parlano dello stesso esame: identici, stesso mnemonico, o
  // l'uno dentro l'altro parola per parola — «BILIRUBINA TOTALE REFLEX» mette
  // in carrello «BILIRUBINA TOTALE». Serve SOLO a riconoscere la riga che il
  // nostro inserimento ha appena prodotto: nessun esame viene mai scelto o
  // inviato in base a questo.
  const stessoEsame = (a, b) => {
    const x = baseEsame(a), y = baseEsame(b);
    if (!x || !y) return false;
    if (x === y) return true;
    const ma = mnemonico(a), mb = mnemonico(b);
    if (ma && ma === mb) return true;
    const [lungo, corto] = x.length >= y.length ? [x, y] : [y, x];
    return corto.length >= 6 && ` ${lungo} `.includes(` ${corto} `);
  };
  // UI-facing short name (falls back to the catalog label, trimmed of its code)
  const displayLabel = (res, code) => DISPLAY[`${res}:${code}`] || shortLabel(examLabel(res, code));

  // ================================================================ ENGINE
  // A run is a linear list of steps executed by runPlan(). Each step updates
  // its own status so the UI can render live progress.
  //
  // plan = {
  //   startPage: 'patient' | 'crea' | 'exam' | 'ripresa',
  //   entryUrl:  (patient only) crea-page URL to open,
  //   creaForm:  (crea only) the LIVE form element to serialize,
  //   examDoc/examUrl: (exam only) the live page — used ONLY to find the
  //              list URL, which is then re-read from the server,
  //   quesito:   text written if the server field is empty — or over the
  //              triage's, when quesitoMio (typed by the doctor in #q),
  //   quesitoMio: the doctor typed the quesito himself (not a chip/package),
  //   items:     [{res, code, label}],
  //   autoConfirm: boolean,
  //   episodeId: pinned patient episode,
  //   listUrl:   (ripresa only) the exam list to re-read — nothing is created,
  //   items:     (ripresa) what is still to send; the one that was IN FLIGHT
  //              when the page changed comes first, marked soloVerifica: it is
  //              looked up in the cart and NEVER sent again.
  // }

  function orderItems(items, currentRes) {
    const rank = (r) => (r === currentRes ? "0" : "1" + r);
    return [...items].sort((a, b) => rank(a.res).localeCompare(rank(b.res)) || a.code.localeCompare(b.code));
  }

  function applyExclusions(items, log) {
    let out = [...items];
    for (const rule of EXCLUDE) {
      const has = out.some((i) => i.res === rule.keep[0] && i.code === rule.keep[1]);
      if (!has) continue;
      const before = out.length;
      out = out.filter((i) => !(i.res === rule.drop[0] && i.code === rule.drop[1]));
      if (out.length !== before) log(`↺ ${rule.note}`);
    }
    const seen = new Set();
    return out.filter((i) => { const k = i.res + ":" + i.code; if (seen.has(k)) return false; seen.add(k); return true; });
  }

  async function runPlan(plan, ui) {
    const ctrl = new AbortController();
    const signal = ctrl.signal;
    // Un giro solo si riprende dopo un cambio pagina; una catena
    // lab+radiologia no: le sue due gambe vivono nella memoria del pannello,
    // e a metà non si riprendono. Lì si avvisa prima di uscire, come sempre.
    // Nemmeno «Svuota» dalla riga di una richiesta da confermare: non ha niente
    // da annotare, quindi niente da riprendere — si avvisa prima di uscire.
    plan.riprendibile = !plan.hold && !plan.soloSvuota;
    const token = Math.random().toString(36).slice(2);   // questo motore, per il presidio
    // La pagina che se ne va porta via il motore: il presidio si molla subito,
    // o la pagina dopo crederebbe che ci sia ancora qualcuno a lavorare.
    const mollaPresidio = () => liberaPresidio(token);
    window.addEventListener("pagehide", mollaPresidio);
    const state = {
      steps: [], added: [], stop: () => ctrl.abort(),
      finishedListUrl: null, lastListUrl: null, richiestaId: null,
    };
    // quale quesito è partito (una ripresa lo porta con sé dall'appunto)
    if (plan.qinfo) state.quesito = plan.qinfo;
    ui.beginRun(state, plan);
    const log = (msg) => ui.log(`${now()}  ${msg}`);
    // Any fetched page that is a login page means the session died mid-flow.
    const guardSession = (doc, whatMayHaveHappened) => {
      if (classify(doc) === "login") {
        const e = restaQui(new StopError("Sessione scaduta durante l'operazione",
          `${whatMayHaveHappened ? whatMayHaveHappened + ". " : ""}Rifai l'accesso e controlla il carrello.`));
        e.sessione = true;
        throw e;
      }
    };
    const step = (label) => {
      const s = { label, status: "pending", note: "" };
      state.steps.push(s);
      return s;
    };
    const running = (s, note) => { s.status = "running"; if (note) s.note = note; ui.renderRun(state); };
    const done = (s, note) => { s.status = "ok"; if (note) s.note = note; ui.renderRun(state); };
    const pace = () => sleep(PACE_MS, signal);

    plan.items = applyExclusions(plan.items, log);
    // La selezione del medico com'era, prima che il motore traduca codici e
    // risorse per la sede (o che un esame a riflesso entri con un altro
    // numero): è quella che «Svuota il carrello e ricomincia» rimette.
    // Viaggia con il giro: «Riprova» e la ripresa dopo un cambio pagina la portano.
    const nudoSel = (i) => ({ res: i.res, code: i.code, label: i.label, display: i.display || i.label,
      ...(i.resCat ? { resCat: i.resCat } : {}), ...(i.chiave ? { chiave: i.chiave } : {}) });
    if (!Array.isArray(plan.originali) || !plan.originali.length) {
      // (un giro ripreso o rifatto senza la selezione di partenza non la sa: niente «Svuota»)
      const parziale = plan.startPage === "ripresa" || plan.items.some((i) => i.soloVerifica) || (plan.daControllare || []).length > 0;
      plan.originali = parziale ? null : plan.items.map(nudoSel);
    }

    // Pre-build the visible step list.
    const legTag = plan.legLabel ? ` (${plan.legLabel})` : "";
    const riprende = plan.startPage === "ripresa";
    // dal carrello di una richiesta già nata (dopo «Svuota il carrello»): niente da creare
    const daCarrello = plan.startPage === "carrello";
    // il ritentativo da solo dopo un elenco venuto male: lo dice la striscia
    const daSolo = daCarrello && !!plan.ritentato;
    const nMai = plan.items.filter((i) => !i.soloVerifica).length;
    const sOpen = plan.startPage === "patient" ? step("Apro la nuova richiesta" + legTag) : null;
    const sRipresa = riprende ? step("Riprendo la richiesta da dov'ero")
      : daCarrello ? step(daSolo ? `Riprovo ${nMai === 1 ? "1 esame" : `${nMai} esami`}…` : "Apro il carrello della richiesta") : null;
    const sCrea = plan.startPage !== "exam" && !riprende && !daCarrello ? step("Compilo quesito e creo la richiesta" + legTag) : null;
    const sSvuota = plan.svuota ? step("Svuoto il carrello") : null;
    const sVuoto = plan.svuota ? step("Controllo che sia vuoto") : null;
    const itemSteps = new Map();
    // i passi-esame si contano a parte: la striscia dice «esame 2 di 6», non i passi
    for (const it of plan.items) { const s = step(it.display || it.label); s.esame = true; itemSteps.set(it, s); }
    const sEnd = plan.soloSvuota ? null : step(riprende && !plan.autoConfirm ? "Chiudo: il carrello è pronto"
      : plan.autoConfirm ? "Passo alla pagina esami per la conferma" : "Passo alla pagina esami per la revisione");
    ui.renderRun(state);

    // Svuotare il carrello di UNA richiesta, quella del giro, e dimostrarlo.
    // Col link «Svuota carrello» del gestionale — un'azione sola, niente che
    // resta indietro — preso dalla pagina esami della richiesta e seguito solo
    // se porta la sua RICHIESTA_ID e il suo EPISODIO_ID (e, quando c'è, la
    // RISORSA_ID della sezione: nelle pagine vere svuota una sezione alla
    // volta, quindi si segue per ogni sezione che ha righe). Una sezione senza
    // «Svuota» si toglie riga per riga coi suoi «Elimina» (PRESTAZIONE sempre
    // presente). Mai una richiesta confermata: prima si legge la pagina del
    // paziente, e se la elenca fra quelle coi fogli da stampare non si tocca
    // niente. Prima di togliere qualunque cosa si legge il carrello vero: quello
    // che c'è e non è della selezione si rimette anche lui, e una riga che non
    // si saprebbe rimettere ferma tutto lì. Poi OGNI sezione si rilegge dal
    // server: se c'è ancora una riga, stop — si dice cosa resta e non si
    // rimette niente.
    const svuotaCarrello = async (model0) => {
      const rid = String(plan.richiestaId || ""), ep = String(plan.episodeId || "");
      if (!rid || String(model0.richiestaId) !== rid) throw new StopError("Non so quale carrello svuotare", "Niente toccato.");
      state.svuotando = true;
      running(sSvuota, "controllo che non sia confermata…");
      const pu = [plan.patientUrl, (tuttiPazienti().find((p) => p.ep === ep) || {}).url].find(leggibilePagina);
      if (!pu) throw new StopError("Non riesco a controllare che la richiesta non sia confermata", "Non svuoto niente.");
      const pz = await fetchDoc(pu, { signal });
      guardSession(pz.doc, "Niente svuotato");
      assertSameEpisode(pz.doc, ep, "pagina del paziente");
      if (classify(pz.doc) !== "patient") throw new StopError("Non ritrovo la pagina del paziente", "Non svuoto niente.");
      if (printModel(pz.doc, pz.url)[rid]) throw new StopError("Questa richiesta risulta già confermata", "Una richiesta confermata non si svuota: non tocco niente.");
      if (!model0.confirmButton) throw new StopError("Il carrello non ha più la Conferma", "Forse è già confermata: non svuoto niente.");
      const leggi = (res, cosa) => leggiSezione(model0, res, { rid, ep, signal, cosa });
      // il carrello vero, tutte le sezioni: che cosa si toglie, e che cosa si rimette
      running(sSvuota, "leggo il carrello…");
      const { sezioni, righe } = await leggiCarrello(model0, { rid, ep, signal, cosa: "Niente svuotato" });
      state.inCarrello = righe.map(nomeRiga);
      // (con niente da rimettere, niente che non si saprebbe rimettere)
      const piano = plan.soloSvuota ? { extra: [], ignoti: [] } : daRimettere(righe, plan.items, plan.nostri || []);
      if (piano.ignoti.length) {
        throw new StopError(`Non saprei rimettere ${piano.ignoti.map((x) => `«${x}»`).join(", ")}`,
          "È nel carrello ma non so ordinarlo da qui: non svuoto niente.");
      }
      for (const it of piano.extra) {
        log(`nel carrello c'è anche «${it.display}», fuori dalla selezione: lo rimetto con gli altri`);
        plan.items.push(it);
        const s = { label: it.display, status: "pending", note: "", esame: true };
        state.steps.splice(state.steps.indexOf(sEnd), 0, s);
        itemSteps.set(it, s);
      }
      if (piano.extra.length) plan.originali = [...(plan.originali || []), ...piano.extra.map(nudoSel)];
      // il link «Svuota» di questa sezione, e solo se è suo
      const linkSvuota = (d, base, res) => {
        for (const a of d.querySelectorAll('a[href*="Delete=Elimina"]')) {
          let u; try { u = new URL(a.getAttribute("href"), base); } catch { continue; }
          const p = u.searchParams;
          if (u.origin !== location.origin || p.get("Delete") !== "Elimina" || p.get("MVPG") !== "RcsRichiestaCarrelloSvuota") continue;
          if (p.has("PRESTAZIONE") || p.has("RICHIESTA_PRESTAZIONE_PROG") || p.has("Insert")) continue;
          if (p.get("RICHIESTA_ID") !== rid || p.get("EPISODIO_ID") !== ep) continue;
          if (p.has("RISORSA_ID") && p.get("RISORSA_ID") !== res) continue;
          return u.href;
        }
        return null;
      };
      // l'«Elimina» di una riga: il suo esame, la sua richiesta, la sua sezione
      const eliminaDi = (e, res) => {
        let u; try { u = new URL(e.href); } catch { return null; }
        const p = u.searchParams;
        if (u.origin !== location.origin || !e.isDel || p.get("Delete") !== "Elimina" || p.has("Insert")) return null;
        if (p.get("PRESTAZIONE") !== String(e.code) || p.get("RICHIESTA_ID") !== rid || p.get("RISORSA_ID") !== res) return null;
        if (p.has("EPISODIO_ID") && p.get("EPISODIO_ID") !== ep) return null;
        return u.href;
      };
      const presidio = () => {
        if (!presidioLibero(rid, token)) {
          throw restaQui(new StopError("Un'altra scheda sta lavorando su questa richiesta", "Da qui non svuoto niente."));
        }
        segnaPresidio(rid, token);
      };
      // Da qui non si sa più che cosa c'è nel carrello finché non si rimette:
      // se la scheda muore adesso, la prima pagina utile dice di controllare.
      store.set(APERTA, { ts: Date.now(), ep, paziente: plan.patientName || "", rid, quanti: 0, forse: plan.items.length });
      let tolti = 0;
      for (const { res, m: m0, doc: d, url: u, righe: suo } of sezioni) {
        let m = m0;
        const prima = suo.map(nomeRiga);
        if (!prima.length) continue;
        presidio();
        state.tolgo = true;
        const sv = linkSvuota(d, u, res);
        if (sv) {
          running(sSvuota, `svuoto ${risorsaCorta(res)} (${prima.length})…`);
          log(`svuoto ${risorsaCorta(res)} col «Svuota carrello» del gestionale: ${prima.join(", ")}`);
          const r = await fetchDoc(sv, { signal });
          guardSession(r.doc, "Il carrello potrebbe essere svuotato o no");
          assertSameEpisode(r.doc, ep, "svuota carrello");
          tolti += prima.length;
          await pace();
          continue;
        }
        // niente «Svuota» in questa sezione: una riga alla volta, rileggendo
        // il carrello dopo ognuna (ogni link porta il suo stato)
        log(`${risorsaCorta(res)}: nessun «Svuota carrello» in pagina — tolgo le righe una per una`);
        for (let giro = 0; giro < prima.length + 2; giro++) {
          const e = m.exams.find((x) => x.isDel && eliminaDi(x, res));
          if (!e) break;
          presidio();
          running(sSvuota, `tolgo ${shortLabel(e.label)}…`);
          log(`tolgo «${shortLabel(e.label)}» col suo «Elimina»`);
          const r = await fetchDoc(eliminaDi(e, res), { signal });
          guardSession(r.doc, `«${shortLabel(e.label)}» potrebbe essere tolto o no`);
          assertSameEpisode(r.doc, ep, "elimina esame");
          tolti++;
          await pace();
          ({ m } = await leggi(res, "Il carrello potrebbe essere svuotato in parte"));
        }
      }
      done(sSvuota, tolti ? `${tolti} ${tolti === 1 ? "tolto" : "tolti"}` : "era già vuoto");
      // la prova: ogni sezione riletta dal server, e vuota
      running(sVuoto);
      const restano = [];
      let primo = null;
      for (const { res } of sezioni) {
        const l = await leggi(res, "Il carrello potrebbe essere svuotato in parte");
        for (const n of righeCarrello(l.doc, l.m)) restano.push(sezioni.length > 1 ? `${n} (${risorsaCorta(res)})` : n);
        if (res === model0.res) primo = l;
        await pace();
      }
      if (restano.length) {
        state.rimasti = restano;
        throw new StopError("Il carrello non si è svuotato", `Restano: ${restano.join(", ")}. Non rimetto niente: finiscilo a mano.`);
      }
      if (!primo) throw new StopError("Non ritrovo la sezione del carrello da cui ripartire", "Il carrello è vuoto: rimetti gli esami a mano.");
      done(sVuoto, "vuoto ✓");
      log(`carrello vuoto su ${sezioni.length === 1 ? "1 sezione" : `tutte le ${sezioni.length} sezioni`}, riletto dal server: ${
        plan.soloSvuota ? "niente da rimettere" : `rimetto ${plan.items.length} esami`}`);
      // un carrello vuoto non ha niente da confermare: il promemoria torna
      // quando rientra il primo esame
      confermataProvata(rid);
      state.svuotando = false;
      state.svuotato = true;
      return { model: primo.m, doc: primo.doc, url: primo.url };
    };

    try {
      // ---- 1. reach the exam page --------------------------------------
      let doc, url;
      if (plan.startPage === "patient") {
        running(sOpen);
        ({ doc, url } = await fetchDoc(plan.entryUrl, { signal }));
        guardSession(doc, "Nessuna richiesta creata");
        assertSameEpisode(doc, plan.episodeId, "nuova richiesta");
        if (classify(doc) !== "crea") throw new StopError("Pagina Nuova Richiesta inattesa", "Il server non ha aperto la pagina prevista. Nessuna richiesta creata.");
        done(sOpen);
      }

      if (riprende || daCarrello) {
        // Non si crea niente e non si manda niente: si rilegge l'elenco della
        // richiesta che era già aperta, e da lì si continua.
        running(sRipresa);
        if (daSolo) await sleep(VERIFY_WAITS[0], signal);   // un attimo all'elenco, come prima di una verifica
        ({ doc, url } = await fetchDoc(plan.listUrl, { signal }));
        guardSession(doc, "Nessun esame inviato");
        assertSameEpisode(doc, plan.episodeId, "elenco esami");
        if (classify(doc) !== "exam") {
          log(`elenco esami inatteso alla ripresa: "${snippet(doc)}"`);
          throw new StopError("Non ritrovo l'elenco esami della richiesta", "Il giro si ferma qui: apri il carrello e controlla.");
        }
        done(sRipresa);
      } else if (plan.startPage !== "exam") {
        running(sCrea);
        if (plan.startPage === "patient") await pace();
        let form, base;
        if (plan.startPage === "crea") { form = plan.creaForm; base = plan.creaUrl; }
        else { form = doc.querySelector('form[name="RICHIESTACrea"]'); base = url; }
        if (!form) throw new StopError("form RICHIESTACrea non trovato");

        // Il quesito del triage resta, di norma. Ma se il medico ha scritto
        // il suo nel pannello — a mano, non un chip né un pacchetto — vale il
        // suo: l'ha deciso lui, e ignorarlo in silenzio era il difetto.
        const quesitoEl = form.elements.namedItem("QUESITO_DIAGNOSTICO");
        if (quesitoEl) {
          const existing = (quesitoEl.value || "").trim();
          const q = (plan.quesito || "").trim();
          const mio = !!plan.quesitoMio && !!q && q !== existing;
          if (!existing || mio) {
            if (!q) throw new StopError("Quesito diagnostico mancante", "Scrivilo nel pannello e riprova. Nessuna richiesta creata.");
            quesitoEl.value = q;
            scrittura.nostri.add(quesitoEl);   // scritto da noi: non è il medico che sta scrivendo
            state.quesito = existing ? { fonte: "tuo", sopra: true } : { fonte: "tuo" };
            // (nessun testo fra virgolette: il Registro si copia, e il quesito non deve uscire)
            if (existing) log("quesito del triage sostituito col tuo, scritto nel pannello");
          } else {
            state.quesitoKept = existing;
            state.quesito = { fonte: "triage", testo: existing.slice(0, 80) };
            log(`quesito del triage mantenuto: "${existing.slice(0, 60)}"`);
          }
        }
        const submit = form.querySelector('input[type="submit"][name="Update"]');
        if (!submit) throw new StopError('bottone "Crea" non trovato');
        const body = encodeFormBody(serializeForm(form, submit));
        const action = absUrl(form, "action", base);
        ({ doc, url } = await fetchDoc(action, { method: "POST", body, signal }));
        guardSession(doc, "La richiesta potrebbe non essere stata creata");
        assertSameEpisode(doc, plan.episodeId, "esami della richiesta");
        if (classify(doc) !== "exam") {
          log(`pagina inattesa dopo Crea: "${snippet(doc)}"`);
          throw new StopError("Il server non ha aperto la pagina esami dopo la creazione", "Controlla a mano (vedi Registro).");
        }
        done(sCrea);
        await pace();
      } else {
        // La pagina esami che il medico ha davanti NON è una fonte attendibile:
        // gli inserimenti viaggiano in background, quindi dopo una corsa
        // interrotta il carrello sullo schermo è quello di prima. Fidarsene
        // vorrebbe dire leggere «non c'è» un esame che c'è già — e ordinarlo
        // una seconda volta. Del DOM vivo si prende solo l'INDIRIZZO
        // dell'elenco, e lo si rilegge dal server come fa tutto il resto del
        // motore: una richiesta in più, e in cambio i due controlli che questa
        // strada saltava — sessione scaduta ed episodio.
        const vivo = examModel(plan.examDoc, plan.examUrl);
        ({ doc, url } = await fetchDoc(vivo.listUrl(vivo.res) || plan.examUrl, { signal }));
        guardSession(doc, "Nessun esame inviato");
        assertSameEpisode(doc, plan.episodeId, "esami della richiesta");
        if (classify(doc) !== "exam") {
          log(`pagina esami inattesa alla partenza: "${snippet(doc)}"`);
          throw new StopError("Questa non è più la pagina degli esami", "Ricaricala e riprova. Nessun esame inviato.");
        }
      }

      // ---- 2. add each exam, verifying every add ------------------------
      let model = examModel(doc, url);
      learnFrom(model);
      // «↻ Riprova» lavora sul carrello della richiesta di prima e su nessun
      // altro: un elenco di un'altra richiesta non si tocca.
      if (plan.richiestaId && String(model.richiestaId) !== String(plan.richiestaId)) {
        throw new StopError("Non è il carrello della richiesta di prima", "Nessun esame inviato.");
      }
      state.richiestaId = model.richiestaId;
      segnaNostra(model.richiestaId);   // da qui la sua Conferma nativa arma la stampa
      const noteList = () => { const u = model.listUrl(model.res); if (u) state.lastListUrl = u; };
      noteList();
      // Una pagina riletta per verificare vale solo se è l'elenco di QUESTA
      // richiesta, su quella risorsa: un altro elenco non dice niente del
      // nostro carrello, e da lui non si prende nemmeno l'indirizzo della
      // rilettura dopo. Si conta il tentativo e si rilegge il nostro.
      const nostroElenco = (m, res) => {
        if (String(m.richiestaId) === String(state.richiestaId) && m.res === res) return true;
        log(`è tornato l'elenco di un'altra richiesta o risorsa (${m.richiestaId || "?"}, ${risorsaCorta(m.res) || "?"}): non lo uso, rileggo il nostro`);
        return false;
      };
      if (!state.lastListUrl) throw new StopError("Impossibile ricostruire l'indirizzo dell'elenco esami", "Nessun esame inviato.");
      // «Svuota il carrello e ricomincia»: prima il carrello di QUESTA
      // richiesta si vuota e si dimostra vuoto, poi si rimette tutta la
      // selezione, come il primo giro.
      if (plan.svuota) ({ model, doc, url } = await svuotaCarrello(model));
      if (plan.soloSvuota) {
        // «Svuota» dalla riga di una richiesta da confermare: niente da
        // rimettere. Vuoto e provato, la richiesta è già dimenticata.
        tabStore.set(CORSA, null);
        store.set(APERTA, null);
        liberaPresidio(token);
        window.removeEventListener("pagehide", mollaPresidio);
        state.finishedListUrl = model.listUrl(model.res);
        ui.svuotato(state, plan);
        return state;
      }
      const offered = new Set(model.resOptions.map((o) => o.value));
      if (offered.size) {
        const cat = fullCatalog();
        for (const i of plan.items) {
          if (!i.res || offered.has(i.res)) continue;
          const dove = risorsaQui(i, model.resOptions, cat);
          if (!dove) continue;
          if (dove.perNome) log(`risorsa di questo presidio: «${dove.opt.label}» ${dove.res} (nel catalogo ${i.res})`);
          else log(`«${i.display || i.label}»: qui la risorsa ${risorsaCorta(i.res, cat)} non c'è — lo stesso esame sta in «${dove.opt.label}»`);
          i.resCat = i.res;        // il catalogo che conosce questo esame resta quello di partenza
          i.res = dove.res;        // the exam's own name is verified before any send
          if (dove.code && dove.code !== i.code) i.code = dove.code;
        }
        const wrongRes = plan.items.filter((i) => i.res && !offered.has(i.res));
        if (wrongRes.length) {
          const qui = model.resOptions.map((o) => `«${o.label}» ${o.value}`).join(", ") || "nessuna";
          const cercate = [...new Set(wrongRes.map((i) => `«${(cat[i.res] && cat[i.res].label) || RES_SHORT[i.res] || i.res}» ${i.res}`))].join(", ");
          log(`risorse offerte qui: ${qui} — cercavo: ${cercate}`);
          throw new StopError("Esami non ordinabili in questa richiesta",
            `${wrongRes.map((i) => `«${i.display || i.label}»`).join(", ")}. Questa richiesta offre ${qui}. Nessun esame inviato.`);
        }
      }

      // Quello che in questo giro era già passato — sistemato prima
      // dell'interruzione, o in volo nell'istante in cui la pagina è cambiata —
      // viene per primo e si CERCA soltanto in carrello: non si rimanda mai.
      const items = [
        ...plan.items.filter((i) => i.soloVerifica),
        ...orderItems(plan.items.filter((i) => !i.soloVerifica), model.res),
      ];
      state.ordine = items;   // l'ordine vero: dice qual è il primo esame rimasto fuori
      // Il giro annotato dove sopravvive al cambio pagina: cosa è già entrato,
      // cosa era in volo, cosa resta. Si riscrive a ogni passo — è la memoria
      // da cui il pannello riparte, e l'unica che non muore con la pagina.
      // …con la risorsa di catalogo di partenza: serve al ritorno alla versione
      // vecchia in una sede che la «- NEW» non ce l'ha
      // (e la chiave della selezione da cui è nato: dopo un errore «Chiudi»
      // lascia scelti solo quelli che mancano davvero)
      const nudo = (i) => ({ res: i.res, code: i.code, label: i.label, display: i.display || i.label,
        ...(i.resCat ? { resCat: i.resCat } : {}), ...(i.chiave ? { chiave: i.chiave } : {}),
        ...(i.alPostoDi ? { alPostoDi: i.alPostoDi } : {}) });
      const salvaCorsa = (inVolo, resto) => {
        if (!plan.riprendibile) return;
        // Un esame che è già passato di qui non torna mai fra quelli «da
        // mandare»: resta fra i fatti, e alla ripresa si cerca in carrello.
        const rimasti = resto || [];
        segnaPresidio(state.richiestaId, token);
        // Il segno condiviso: se questa scheda muore, la prima pagina utile —
        // anche in un'altra scheda — dirà che un giro è rimasto a metà: quanti
        // non sono partiti, e quanti sono da controllare (quello in volo:
        // mai fra i «non mandati»).
        const mai = rimasti.filter((x) => !x.soloVerifica).length;
        const forse = inVolo ? 1 : rimasti.filter((x) => x.soloVerifica && !x.giaFatto).length;
        store.set(APERTA, mai || forse
          ? { ts: Date.now(), ep: plan.episodeId, paziente: plan.patientName || "", rid: state.richiestaId || null, quanti: mai, forse }
          : null);
        const scritto = tabStore.set(CORSA, {
          ts: Date.now(), ep: plan.episodeId, paziente: plan.patientName || "",
          autoConfirm: !!plan.autoConfirm, quesito: plan.quesito || "", qinfo: state.quesito || null,
          rid: state.richiestaId || null, listUrl: state.lastListUrl || null,
          riprese: plan.riprese || 0,
          ...(plan.ritentato ? { ritentato: true } : {}),   // il ritentativo da solo c'è già stato
          // il giro di un ordine in sottofondo: si riprende solo nella sua
          // scheda, e solo finché il service worker lo conosce
          ...(LAVORO ? { ordine: LAVORO.id } : {}),
          // la selezione di partenza (per «Svuota il carrello»)
          ...(plan.originali ? { originali: plan.originali } : {}),
          ...(plan.patientUrl ? { patientUrl: plan.patientUrl } : {}),
          // «in volo» resta in volo finché non lo si ritrova: se scivolasse fra
          // i fatti, alla ripresa dopo passerebbe per uno che qualcuno ha tolto
          // dal carrello — e un esame mai partito sparirebbe in silenzio.
          fatti: [...state.added, ...rimasti.filter((x) => x.giaFatto)].map(nudo),
          involo: inVolo ? nudo(inVolo) : (rimasti.find((x) => x.soloVerifica && !x.giaFatto) ? nudo(rimasti.find((x) => x.soloVerifica && !x.giaFatto)) : null),
          restanti: rimasti.filter((x) => !x.soloVerifica).map(nudo),
        });
        // Memoria piena o bloccata: l'appunto non c'è. Non si promette una
        // ripresa che non ci sarà — si dice, una volta sola, e da qui in poi
        // il giro è quello di prima: se cambi pagina, va perso.
        if (!scritto && plan.riprendibile) {
          plan.riprendibile = false;
          log("⚠ non riesco ad annotare il giro: se cambi pagina adesso, quello che resta non riparte da solo");
        }
      };
      for (let i = 0; i < items.length; i++) {
        const it = items[i];
        const st = itemSteps.get(it);
        const nm = it.display || it.label; // short name for messages
        salvaCorsa(null, items.slice(i));   // da qui in poi, questo è ancora da mandare
        running(st);
        await pace(); // pace AFTER marking, so exactly one step is always live

        // Switch list when the exam lives on another resource.
        if (it.res && model.res !== it.res) {
          running(st, `passo a ${risorsaCorta(it.res)}`);
          ({ doc, url } = await fetchDoc(model.listUrl(it.res) || state.lastListUrl, { signal }));
          guardSession(doc);
          assertSameEpisode(doc, plan.episodeId, "elenco esami");
          model = examModel(doc, url);
          learnFrom(model);
          if (model.res !== it.res) throw ritentabile(new StopError(`Cambio risorsa fallito (${risorsaCorta(it.res)})`, "Nessun ordine inviato per questo esame."));
          noteList();
        }

        if (model.inCart(it.code)) {
          done(st, "già nel carrello");
          log(`già presente ✓ ${nm}`);
          state.added.push(it);
          // anche qui il carrello vero di questa risorsa va registrato: la
          // conferma automatica confronta la ricevuta col carrello, e una
          // risorsa mai «toccata» in questo giro le risulterebbe non vista
          state.carrelli = state.carrelli || {};
          state.carrelli[model.res] = model.exams.filter((e) => e.isDel).map((e) => String(e.code));
          salvaCorsa(null, items.slice(i + 1));
          continue;
        }
        if (it.soloVerifica) {
          // Questo era IN VOLO quando la pagina è cambiata: il server può
          // averlo preso lo stesso. Si guarda — con le stesse riletture di
          // sempre — e non si rimanda mai: un esame ordinato due volte è una
          // provetta in più al laboratorio.
          running(st, "controllo se è entrato…");
          let riga = null;
          for (let attempt = 1; !riga && attempt <= VERIFY_RECHECKS; attempt++) {
            running(st, `controllo il carrello ${attempt}/${VERIFY_RECHECKS}…`);
            await sleep(VERIFY_WAITS[attempt - 1], signal);
            ({ doc, url } = await fetchDoc(model.listUrl(it.res || model.res) || state.lastListUrl, { signal }));
            guardSession(doc, `«${nm}» potrebbe essere stato aggiunto o no`);
            assertSameEpisode(doc, plan.episodeId, "verifica carrello");
            if (classify(doc) !== "exam") { log(`pagina inattesa in verifica: "${snippet(doc)}"`); continue; }
            const riletto = examModel(doc, url);
            if (!nostroElenco(riletto, it.res || model.res)) continue;
            model = riletto;
            noteList();
            // Qui la fotografia «prima» non c'è più: senza, «POTASSIO» si
            // riconoscerebbe in «POTASSIO URINARIO». Vale il proprio codice,
            // il nome IDENTICO, o lo stesso mnemonico LIS — niente di più
            // largo, o si dichiara entrato un esame che non c'è.
            riga = model.inCart(it.code) ? { code: it.code, label: it.label }
              : model.exams.find((e) => e.isDel && (
                baseEsame(e.label) === baseEsame(it.label) ||
                (mnemonico(it.label) && mnemonico(e.label) === mnemonico(it.label)))) || null;
          }
          if (!riga) {
            if (it.giaFatto) {
              // era entrato prima dell'interruzione e adesso non c'è più: lo
              // ha tolto qualcuno a mano. Non si rimette: si dice e si va.
              st.status = "skipped"; st.note = "non è più in carrello";
              it.tolto = true;   // tolto a mano: non è uno «da aggiungere»
              log(`⚠ «${nm}» era in carrello e adesso non c'è più: non lo rimetto`);
              ui.renderRun(state);
              salvaCorsa(null, items.slice(i + 1));
              continue;
            }
            throw new StopError(`«${nm}»: invio interrotto dal cambio pagina`,
              "Non risulta nel carrello e NON è stato rimandato. Apri il carrello e controlla.");
          }
          if (riga.code !== it.code) {
            log(`«${nm}» era entrato come «${riga.label}» (${riga.code})`);
            it.code = riga.code; it.label = riga.label;
          }
          done(st, "nel carrello ✓");
          log(`ritrovato ✓ ${nm}`);
          state.added.push(it);
          // il carrello vero di questa risorsa, come per un inserimento: senza,
          // una ripresa fatta di sole verifiche lascerebbe la ricevuta vuota e
          // la conferma automatica si sospenderebbe da sola
          state.carrelli = state.carrelli || {};
          state.carrelli[model.res] = model.exams.filter((e) => e.isDel).map((e) => String(e.code));
          salvaCorsa(null, items.slice(i + 1));
          continue;
        }
        // La versione «- NEW» dello stesso esame, se la pagina ne offre una:
        // si guarda l'elenco VIVO, non il catalogo, così vale in ogni sede e
        // anche per gli esami nuovi che il catalogo non ha mai visto.
        // …e al contrario: se qui la «- NEW» non c'è ancora, si torna a quella
        // di sempre invece di fallire per un codice che questa sede non ha.
        if (!/^esame \d+$/i.test(it.label)) {
          const mia = baseEsame(it.label);
          const trova = (nuova) => mia && model.exams.find((e) => e.isAdd && eNuovo(e.label) === nuova && baseEsame(e.label) === mia);
          let scelto = trova(true) || (eNuovo(it.label) ? trova(false) : null);
          // Qui la «- NEW» non c'è e nemmeno la sua gemella in elenco: si
          // torna alla vecchia del NOSTRO catalogo. Serve davvero, perché la
          // versione nuova ha anche un mnemonico nuovo (POC21171 contro
          // POC2117): senza questo passo, in una sede che ha solo la vecchia
          // e la chiama in un altro modo non la ritroverebbe più nessuno.
          if (!scelto && eNuovo(it.label)) {
            const items = (fullCatalog()[it.resCat || it.res]?.items) || {};
            const twin = Object.entries(items).find(([c, l]) => c !== it.code && !eNuovo(l) && baseEsame(l) === mia);
            if (twin) scelto = { code: twin[0], label: twin[1] };
          }
          if (scelto && scelto.code !== it.code) {
            log(eNuovo(scelto.label)
              ? `questa sede ha la versione nuova: «${scelto.label}» al posto di «${it.label}»`
              : `qui la versione «- NEW» non c'è: uso «${scelto.label}»`);
            // Tornare alla vecchia non si dice solo nel Registro: la ricevuta
            // mostra quella che è entrata, «al posto di EGA VENOSA NEW».
            if (!eNuovo(scelto.label)) {
              it.alPostoDi = it.display || shortLabel(it.label);
              it.display = shortLabel(scelto.label);
              st.label = it.display;
            }
            it.code = scelto.code; it.label = scelto.label;
          }
        }
        // la riga dell'esame su un elenco: col suo codice o — il numero cambia
        // da un presidio all'altro, l'esame no — col nome esatto o col
        // mnemonico che il LIS stampa fra parentesi. Mai per somiglianza.
        const rigaDi = (m) => {
          const l = m.addLink(it.code);
          if (l || /^esame \d+$/i.test(it.label)) return l || null;
          const mio = mnemonico(it.label);
          const perNome = m.exams.find((e) => e.isAdd && normEsame(e.label) === normEsame(it.label));
          const alt = perNome || (mio ? m.exams.find((e) => e.isAdd && mnemonico(e.label) === mio) : null);
          if (!alt) return null;
          log(`codice di questo presidio: ${alt.code} per «${alt.label}» (nel catalogo ${it.code})`);
          it.code = alt.code;
          return alt;
        };
        let link = rigaDi(model);
        // Né il codice né il nome sull'elenco: a volte arriva monco (la riga
        // c'è, ma non si vede). Lo si rilegge UNA volta con la ricerca del
        // gestionale — una semplice lettura — e la riga che compare passa per
        // la strada di sempre: il nome vivo controllato, un invio solo. Se non
        // c'è nemmeno lì, non si manda niente: lo si aggiunge a mano.
        let cercato = false, giaCercando = false, riletto = false;
        if (!link && !/^esame \d+$/i.test(it.label) && !model.inCart(it.code)) {
          const termine = termineRicerca(it.label);
          const su = urlRicerca(model.listUrl(it.res || model.res), termine);
          if (su) {
            running(st, `cerco «${termine}»…`);
            log(`«${nm}» non è sull'elenco: lo cerco con la ricerca del gestionale («${termine}»)`);
            const r = await fetchDoc(su, { signal });
            guardSession(r.doc, "Nessun esame inviato");
            assertSameEpisode(r.doc, plan.episodeId, "ricerca esame");
            const trovata = classify(r.doc) === "exam" ? examModel(r.doc, r.url) : null;
            if (!trovata) log(`pagina inattesa nella ricerca: "${snippet(r.doc)}"`);
            else if (trovata.res !== model.res || trovata.richiestaId !== model.richiestaId) log("la ricerca ha risposto con un altro elenco: non la uso");
            else {
              riletto = true;
              link = rigaDi(trovata);
              giaCercando = trovata.inCart(it.code);
              if (link) { cercato = true; log(`riletto con la ricerca del gestionale: «${link.label}»`); }
            }
            await pace();
          }
        }
        if (!link) {
          const gia = model.inCart(it.code) || giaCercando;
          throw ritentabile(new StopError(`«${nm}» non è nell'elenco di ${risorsaCorta(it.res)}`,
            gia ? "Risulta già nel carrello: controlla a mano."
              : riletto ? "Non c'è nemmeno con la ricerca del gestionale: non inviato. Aggiungilo a mano." : "Non inviato. Completa a mano."));
        }
        // Anti wrong-exam guardrail: the LIVE row label must match what the
        // doctor picked. If the hospital ever renumbers a code, every other
        // check would stay green — this one goes red BEFORE anything is sent.
        // (skipped for items carrying only the "esame N" fallback label)
        // Dashes differ between sites ("PANNELLO 1 – ANEMIA" vs "- ANEMIA") and
        // so does the odd word ("EMOGASANALISI MISTA" vs "CAPILLARE", same
        // POC2117). Typography is never a rename, and neither is a different
        // wording carrying the SAME LIS mnemonic — anything else still stops.
        if (!/^esame \d+$/i.test(it.label) && nomeVivo(link.label) !== nomeVivo(it.label)) {
          if (!stessoNomeVivo(link.label, it.label)) {
            throw new StopError(`Il codice ${it.code} oggi si chiama «${link.label}»`, `Selezionato come «${nm}» — non inviato.`);
          }
          log(`stesso esame, nome diverso in questa sede: «${link.label}» (${mnemonico(link.label)})`);
        }

        // ---- the one and only send of this exam -----------------------
        running(st, "invio…");
        log(`aggiungo → ${nm}`);
        // Il carrello com'è un attimo prima: se l'esame entra sotto un altro
        // codice — le prestazioni «REFLEX» lo fanno — è questa differenza a
        // dire quale riga ha prodotto il nostro clic.
        // Un'altra scheda sta mandando gli esami di QUESTA richiesta (succede
        // duplicando la scheda: si porta dietro l'appunto del giro). Due
        // motori sullo stesso carrello vuol dire due volte lo stesso esame.
        if (!presidioLibero(state.richiestaId, token)) {
          throw restaQui(new StopError("Un'altra scheda sta mandando gli esami di questa richiesta",
            "Da qui non mando niente. Finisci di là, o ricarica questa pagina."));
        }
        const prima = new Set(model.exams.filter((e) => e.isDel).map((e) => e.code));
        const resQui = model.res;
        salvaCorsa(it, items.slice(i + 1));   // da qui è IN VOLO: non si rimanda
        it.inviato = true;   // da qui, se non si vede in carrello, è «da controllare» — mai «manca»
        // …e così lo sa anche il service worker, PRIMA che parta (si aspetta
        // la sua risposta): se questa scheda muore adesso, quell'esame è da
        // guardare, non da rifare
        if (LAVORO) await ui.annunciaLavoro?.();
        ({ doc, url } = await fetchDoc(link.href, { signal }));
        guardSession(doc, `«${nm}» potrebbe essere stato aggiunto o no`);
        assertSameEpisode(doc, plan.episodeId, "conferma inserimento");
        // Una pagina inattesa QUI non dice che l'esame non sia entrato:
        // l'inserimento è già partito. Invece di fermarsi al buio si rilegge
        // l'elenco pulito — mai un secondo invio — e si guarda il carrello.
        let risposta = classify(doc) === "exam" ? examModel(doc, url) : null;
        if (!risposta) {
          log(`pagina inattesa dopo l'inserimento: "${snippet(doc)}" — rileggo il carrello`);
        } else if (!nostroElenco(risposta, resQui)) {
          risposta = null;
        } else {
          model = risposta;
          learnFrom(model);
          noteList();
        }

        // ---- verify (re-reading the clean list only — never re-insert) --
        // In carrello l'esame può comparire col proprio codice oppure, se è a
        // riflesso, con quello dell'esame che ne deriva: una riga nuova vale
        // solo se porta il NOME di quello che il medico ha scelto.
        const entrato = () => {
          if (model.inCart(it.code)) return { code: it.code, label: it.label };
          const nuove = model.exams.filter((e) => e.isDel && !prima.has(e.code));
          if (nuove.length) log(`nuove righe in carrello: ${nuove.map((e) => `«${e.label}» ${e.code}`).join(", ")}`);
          return nuove.find((e) => stessoEsame(e.label, it.label)) || null;
        };
        // Mandato da una ricerca, la risposta è l'elenco FILTRATO: il carrello
        // che la conferma automatica confronta deve essere quello intero, e
        // lo dà solo una rilettura dell'elenco pulito.
        let verified = !!risposta && !cercato && entrato();
        for (let attempt = 1; !verified && attempt <= VERIFY_RECHECKS; attempt++) {
          running(st, `verifica ${attempt}/${VERIFY_RECHECKS}…`);
          await sleep(VERIFY_WAITS[attempt - 1], signal);
          ({ doc, url } = await fetchDoc(model.listUrl(resQui) || state.lastListUrl, { signal }));
          guardSession(doc, `«${nm}» potrebbe essere stato aggiunto o no`);
          assertSameEpisode(doc, plan.episodeId, "verifica carrello");
          if (classify(doc) !== "exam") {
            log(`pagina inattesa in verifica: "${snippet(doc)}"`);
            continue; // count the attempt; the next re-read may recover
          }
          const riletto = examModel(doc, url);
          if (!nostroElenco(riletto, resQui)) continue;
          model = riletto;
          verified = entrato();
          noteList();
        }
        if (!verified) {
          // Una riga che porta lo stesso esame sotto un altro nome c'era già
          // PRIMA del nostro clic: non vale come conferma — potrebbe essere
          // un altro esame con un nome che somiglia — ma dirlo evita al medico
          // di cercare al buio.
          const simile = model.exams.find((e) => e.isDel && stessoEsame(e.label, it.label));
          throw new StopError(`«${nm}» non risulta nel carrello`,
            simile ? `In carrello c'è «${simile.label}»: forse c'era già. Non reinviato — controlla.`
              : `Verificato ${VERIFY_RECHECKS} volte, non reinviato. Apri il carrello.`);
        }
        // È entrato con un altro numero: da qui in poi l'esame è QUELLA riga —
        // la ricevuta, il carrello registrato e la conferma automatica devono
        // parlare del carrello vero, non di quello che avevamo chiesto.
        if (verified.code !== it.code) {
          log(`«${nm}» è entrato come «${verified.label}» (${verified.code})`);
          it.code = verified.code;
          it.label = verified.label;
        }
        done(st, it.alPostoDi ? `nel carrello ✓ · al posto di ${it.alPostoDi}` : "nel carrello ✓");
        log(`aggiunto ✓ ${nm}`);
        state.added.push(it);
        // Da qui la richiesta ha un esame in carrello: è da confermare, e lo
        // resta anche se questa scheda muore adesso. Il promemoria segue il
        // carrello vero, esame per esame (solo numeri).
        ricordaDaConfermare(state.richiestaId, plan.episodeId, state.lastListUrl, state.added.length);
        salvaCorsa(null, items.slice(i + 1));
        // Il carrello di QUESTA risorsa come lo vediamo adesso. La Conferma
        // nativa invia la richiesta INTERA, comprese le righe che stanno sul
        // carrello di un'altra risorsa e che questa pagina non mostra: senza
        // registrarle qui, l'auto-conferma non potrebbe nemmeno vederle.
        state.carrelli = state.carrelli || {};
        state.carrelli[model.res] = model.exams.filter((e) => e.isDel).map((e) => String(e.code));
      }

      // ---- 3. hand the visible tab over for review / native confirm -----
      running(sEnd);
      const last = state.added[state.added.length - 1] || null;
      const landUrl = model.listUrl(last ? last.res : model.res);
      state.finishedListUrl = landUrl;
      // Receipt for the landing page: the panel there shows the full,
      // verified accounting (including exams on other resources).
      if (!plan.hold) tabStore.set("receipt.v1", {
        richiestaId: model.richiestaId, episodeId: plan.episodeId, ts: Date.now(),
        quesitoKept: state.quesitoKept || null, quesito: state.quesito || null,
        carrelli: state.carrelli || {},
        items: state.added.map((i) => ({ res: i.res, code: i.code, label: i.label, display: i.display || i.label,
          ...(i.alPostoDi ? { alPostoDi: i.alPostoDi } : {}) })),
      });
      // Radiology is deliberately excluded from auto-confirm (README, collaudo
      // step 8-9): a booking must always be a human click.
      const isRadio = state.added.some((i) => RADIO_SET.includes(i.res));
      if (plan.autoConfirm && state.added.length && !plan.hold && !isRadio) {
        tabStore.set("confirm.v1", {
          richiestaId: model.richiestaId, episodeId: plan.episodeId,
          lastCode: last.code, lastLabel: last.label, count: state.added.length, ts: Date.now(),
        });
      }
      done(sEnd);
      // Da qui in poi il giro non ha più esami da mandare: quello che resta
      // (conferma e stampa) ha già i suoi passaggi di consegna fra le pagine.
      tabStore.set(CORSA, null);
      store.set(APERTA, null);
      liberaPresidio(token);
      window.removeEventListener("pagehide", mollaPresidio);
      log(plan.autoConfirm ? "tutti verificati — passo alla pagina esami per la conferma" : "tutti verificati — rivedi il carrello e premi Conferma");
      ui.finished(state, plan);
      return state;
    } catch (err) {
      // Una decisione — STOP del medico, o un controllo che ha detto no — mette
      // fine al giro: da lì in poi decide lui, con quello che il pannello gli
      // ha appena detto. Un errore non deciso (la rete, o la pagina che muore
      // mentre navighi) invece NON cancella il giro: è proprio quello da cui
      // si riprende.
      if (signal.aborted || err?.name === "AbortError" || err instanceof StopError) {
        tabStore.set(CORSA, null);
        store.set(APERTA, null);   // fermato o fallito: il medico lo sta leggendo adesso
        liberaPresidio(token);
        window.removeEventListener("pagehide", mollaPresidio);
      }
      // Make the failure legible in the step plan: the live step goes red,
      // everything not yet run is explicitly "skipped".
      for (const s of state.steps) {
        if (s.status === "running") { s.status = "fail"; s.note = "fermato qui"; }
        else if (s.status === "pending") { s.status = "skipped"; s.note = "non eseguito"; }
      }
      // Che cosa è in carrello e che cosa resta da aggiungere a mano: è quello
      // che il medico deve sapere per finire dal gestionale. (Un esame tolto a
      // mano durante il giro non è «da aggiungere».)
      const nomeDi = (x) => x.display || shortLabel(x.label);
      const fuori = (state.ordine || plan.items).filter((x) => !state.added.includes(x) && !x.tolto);
      // Mandato (o in volo, o già entrato prima di un cambio pagina) ma non
      // visto in carrello adesso: è da CONTROLLARE, non da rifare — chi lo
      // aggiungesse a mano lo ordinerebbe due volte. «Mancano» sono solo
      // quelli mai partiti.
      // (quelli da controllare di un errore prima, lasciati fuori da «Riprova»,
      // restano in elenco: non sono spariti, sono ancora da guardare)
      const controllare = [...fuori.filter((x) => x.inviato || x.soloVerifica), ...(plan.daControllare || [])];
      const mancanoIt = fuori.filter((x) => !controllare.includes(x));
      // Fermato mentre svuotava il carrello: che cosa c'è dentro adesso lo
      // sa solo il carrello. Niente «Mancano» (si aggiungerebbe un esame che
      // magari è ancora lì), niente «Riprova» né «Svuota» da soli: si dice
      // cosa resta, se lo si è visto, e si finisce a mano.
      const aMeta = !!state.svuotando;
      state.mancanti = aMeta ? [] : mancanoIt;          // per «↻ Riprova i mancanti»: questi soli si mandano
      state.daControllare = aMeta ? [] : controllare;   // …e questi mai
      // il carrello su cui atterrare: quello del laboratorio del primo esame da fare a mano
      const primo = aMeta ? null : mancanoIt[0] || controllare[0] || null;
      state.resMancante = primo ? primo.res : null;
      // (fermato prima di togliere qualunque cosa: il carrello è com'era, e si dice cosa c'è)
      const liste = aMeta
        ? { nel: state.rimasti || (state.tolgo ? [] : state.inCarrello || []), mancano: [], controllare: [], niente: true }
        : { nel: state.added.map(nomeDi), mancano: mancanoIt.map(nomeDi), controllare: controllare.map(nomeDi) };
      if (aMeta && state.tolgo && err instanceof StopError && !state.rimasti) {
        err.body = `${err.body ? err.body + " " : ""}Il carrello potrebbe essere svuotato in parte: controllalo e finiscilo a mano.`;
      }
      if (signal.aborted || err?.name === "AbortError") {
        log("■ interrotto dall'utente");
        ui.stopped(state, { head: "Interrotto", body: "L'ultimo esame inviato potrebbe essere in carrello: controlla.", ...liste }, plan);
      } else if (err instanceof StopError) {
        log(`⚠ ${err.message}`);
        // quanti esami restavano fuori: senza questo, il messaggio parla solo
        // di quello che è andato storto e il resto si vede solo espandendo
        const restavano = aMeta ? 0 : plan.items.filter((x) => !state.added.includes(x)).length - 1;
        ui.failed(state, { head: err.head, body: `${err.body || ""}${
          restavano > 0 ? (restavano === 1 ? " Restava 1 altro esame da mandare." : ` Restavano ${restavano} altri esami da mandare.`) : ""}`,
          ...liste, restaQui: !!err.restaQui, sessione: !!err.sessione, ritentabile: !!err.ritentabile }, plan);
      } else {
        // La pagina che muore mentre navighi arriva qui come una fetch fallita:
        // il giro annotato è ancora lì, e riprende da solo alla pagina dopo.
        const riprende2 = !!tabStore.get(CORSA, null);
        log(`⚠ ${riprende2 ? "giro interrotto" : "errore imprevisto"}: ${err?.message || err}`);
        ui.failed(state, riprende2
          ? { head: "Giro interrotto", body: "Riprende da solo appena si carica una pagina del gestionale: niente viene rimandato due volte.", ...liste }
          : { head: "Errore imprevisto", body: `${err?.message || err} — apri il carrello e controlla.`, ...liste }, plan);
      }
      return state;
    }
  }

  // Che cosa rifà «↻ Riprova i mancanti» dopo un errore: gli esami mai
  // partiti, sulla STESSA richiesta e nello stesso modo (revisione, o conferma
  // automatica e stampa). Quelli già in carrello vanno con loro solo per
  // essere ritrovati — mai rimandati — così ricevuta e conferma parlano della
  // richiesta intera; quelli «da controllare» (mandati e non visti) restano
  // fuori. Se la richiesta non era ancora nata, è un giro nuovo dalla pagina
  // del paziente. Mai per una catena lab+radiologia: a metà non si riprende.
  function ricettaRiprova(state, plan) {
    if (!plan || plan.hold || !plan.episodeId) return null;
    const nudo = (i) => ({ res: i.res, code: i.code, label: i.label, display: i.display || i.label,
      ...(i.resCat ? { resCat: i.resCat } : {}), ...(i.chiave ? { chiave: i.chiave } : {}),
      ...(i.alPostoDi ? { alPostoDi: i.alPostoDi } : {}) });
    const mancanti = (state.mancanti || []).map(nudo);
    const suo = plan.examUrl || plan.listUrl;
    const rid = state.richiestaId || (suo ? param(suo, "RICHIESTA_ID") : null);
    // «Svuota il carrello e ricomincia»: c'è una richiesta nata, qualcosa
    // nel suo carrello (entrato o da controllare) e la selezione di partenza
    const nelCarrello = (state.added || []).length + (state.daControllare || []).length;
    const tutti = Array.isArray(plan.originali) ? plan.originali.map(nudo) : [];
    const svuotabile = !!rid && tutti.length > 0 && nelCarrello > 0 && leggibilePagina(state.lastListUrl || "");
    if (!mancanti.length && !svuotabile) return null;
    if (!rid && plan.startPage !== "patient" && plan.startPage !== "crea") return null;
    return {
      ep: String(plan.episodeId), rid: rid ? String(rid) : null, autoConfirm: !!plan.autoConfirm,
      paziente: plan.patientName || "", patientUrl: plan.patientUrl || "",
      verdi: (state.added || []).map(nudo), mancanti, controllare: (state.daControllare || []).map(nudo),
      ...(svuotabile ? { tutti, listUrl: state.lastListUrl, nCarrello: nelCarrello } : {}),
      ...(state.quesito ? { qinfo: state.quesito } : {}),
      ...(plan.originali ? { originali: plan.originali.map(nudo) } : {}),
      ...(plan.ritentato ? { ritentato: true } : {}),   // una volta per ordine: da qui «Riprova» è solo del medico
    };
  }

  // Quale quesito è partito davvero, in una riga: quello del triage (che di
  // norma resta) o il tuo. Va nella ricevuta e nella striscia finale.
  function quesitoDetto(qi) {
    if (!qi || !qi.fonte) return "";
    if (qi.fonte === "triage") {
      const t = String(qi.testo || "").replace(/\s+/g, " ").trim();
      return t ? `Quesito del triage: "${t.length > 60 ? t.slice(0, 59) + "…" : t}"` : "Quesito del triage";
    }
    return qi.sopra ? "Quesito: il tuo, al posto del triage" : "Quesito: il tuo";
  }

  // «Mancano: … · Da controllare: …», una frase sola e la stessa ovunque: la
  // striscia di questa scheda, quella delle altre, il resoconto passato di
  // mano. Mancano = mai partiti (da aggiungere); da controllare = mandati e non
  // visti in carrello (da guardare, mai da rimandare). Dopo uno svuotamento
  // fermato, quello che c'è ancora nel carrello.
  function testoResto(r) {
    const l = (k) => (r && Array.isArray(r[k]) ? r[k] : []);
    return [l("mancano").length ? `Mancano: ${l("mancano").join(", ")}` : "",
      l("controllare").length ? `Da controllare: ${l("controllare").join(", ")}` : "",
      r && r.niente && l("nel").length ? `Nel carrello: ${l("nel").join(", ")}` : ""].filter(Boolean).join(" · ");
  }
  // «ROSSI MARIO» → «ROSSI M.»: di chi sono, in poco spazio (il nome intero sta sopra)
  const nomeCorto = (n) => {
    const p = String(n || "").trim().split(/\s+/).filter(Boolean);
    return p.length < 2 ? p.join(" ") || "un altro paziente" : `${p.slice(0, -1).join(" ")} ${p[p.length - 1][0]}.`;
  };

  // La pianta della Stanza: una griglia di celle tutte uguali, 40 × 24. Un
  // letto prende 5 × 4 celle, una sedia 4 × 3, un'area almeno 5 × 3. Si
  // salvano solo celle intere: a qualunque misura la stanza si ridisegna
  // uguale, in scala. La sedia è un letto più piccolo (forma: "sedia").
  const PIANTA = { cols: 40, rows: 24, lw: 5, lh: 4, sw: 4, sh: 3, aw: 5, ah: 3 };
  const misuraLetto = (l) => (l.forma === "sedia" ? { w: PIANTA.sw, h: PIANTA.sh } : { w: PIANTA.lw, h: PIANTA.lh });
  // due rettangoli di celle si sovrappongono (con g > 0: stanno a meno di g celle)
  const troppoVicini = (a, b, g = 0) => a.c < b.c + b.w + g && b.c < a.c + a.w + g && a.r < b.r + b.h + g && b.r < a.r + a.h + g;
  // La stanza di partenza, dallo schizzo del PS: OBI, OSS e la sala
  // d'attesa, da sinistra a destra, con due celle vuote fra l'una e l'altra;
  // la seconda sala d'attesa sotto l'OBI. Si vede finché non c'è una stanza
  // salvata, e si salva al primo cambiamento. Gli id sono fissi: un paziente
  // messo in «OBI 1» ci resta anche prima che la stanza sia salvata.
  const STANZA_PS = {
    letti: [
      { id: "obi4", c: 0, r: 0, nome: "OBI 4" }, { id: "obi3", c: 5, r: 0, nome: "OBI 3" },
      { id: "obi2", c: 10, r: 0, nome: "OBI 2" }, { id: "obi1", c: 15, r: 0, nome: "OBI 1" },
      { id: "oss1", c: 22, r: 0, nome: "OSS 1" }, { id: "oss2", c: 27, r: 0, nome: "OSS 2" },
      { id: "oss3", c: 27, r: 4, nome: "OSS 3" }, { id: "oss4", c: 22, r: 4, nome: "OSS 4" },
    ],
    aree: [
      { id: "attesa", c: 34, r: 0, w: 6, h: 11, nome: "Sala attesa" },
      { id: "attesa2", c: 0, r: 6, w: 20, h: 5, nome: "Sala attesa 2" },
    ],
  };

  // ============================================================== UI (panel)
  // Shadow-DOM panel, top right. Collapsible pill with live state; per-page
  // content; running/error states designed to be legible from a metre away;
  // countdown handoff for the native confirm. Design system: one brand blue,
  // green = verified in cart, amber = armed/attention, red = abort/error.

  const COLORS = `
    :host { all: initial; }
    [hidden] { display: none !important; }
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; }
    .wrap { position: fixed; top: 10px; right: 10px; z-index: 2147483647; color: #16232E; }
    .pill { display: flex; align-items: center; gap: 8px; background: #0B5CAD; color: #fff; border: 0; border-radius: 999px;
            padding: 9px 15px 9px 11px; font-size: 13px; font-weight: 600; cursor: pointer; box-shadow: 0 4px 14px rgba(9,42,74,.22);
            touch-action: none; }
    .pill:active { cursor: grabbing; }
    .pill:hover { background: #094a8c; }
    .pill .badge { background: #fff; color: #0B5CAD; border-radius: 999px; padding: 1px 8px; font-size: 11px; font-weight: 800; }
    .pill .dot { width: 8px; height: 8px; border-radius: 50%; background: #7FD1A8; animation: psaPulse 1.2s ease-in-out infinite; }
    /* La striscia del giro in corso: due righe in un angolo, e sotto ci lavori
       come se il pannello non ci fosse. */
    .strip { display: flex; align-items: center; gap: 6px; }
    .pill.run { border-radius: 12px; padding: 7px 13px 7px 11px; max-width: min(380px, 82vw); text-align: left; }
    .pill.run.alt, .pill.run.warn { background: #8A5A00; }
    .pill.run.alt:hover, .pill.run.warn:hover { background: #764d00; }
    /* errore: si completa a mano, nel gestionale */
    .pill.run.err { background: #B3261E; }
    .pill.run.err:hover { background: #8f1e18; }
    .pill .col { display: flex; flex-direction: column; align-items: flex-start; min-width: 0; line-height: 1.3; }
    .pill .l1 { display: flex; align-items: center; gap: 6px; max-width: 100%; min-width: 0; }
    .pill .l1 .who { max-width: 150px; }
    .pill .tag { font-weight: 700; white-space: nowrap; min-width: 0; overflow: hidden; text-overflow: ellipsis; }
    .pill .l2 { font-size: 11.5px; font-weight: 500; opacity: .93; max-width: 100%;
                white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .pill .tick { font-size: 13px; font-weight: 800; }
    /* quale quesito è partito: una riga piccola sotto il resoconto */
    .pill .l3 { font-size: 10.5px; font-weight: 500; opacity: .8; max-width: 100%;
                white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .stopmini { border: 0; border-radius: 999px; width: 30px; height: 30px; cursor: pointer; font-size: 12px;
                background: #B3261E; color: #fff; box-shadow: 0 6px 20px rgba(9,42,74,.35); }
    .stopmini:hover { background: #8f1e18; }
    /* un'azione tranquilla accanto al resoconto («Ristampa») */
    .strazione { border: 1px solid #C4D0DC; background: #fff; color: #0B5CAD; border-radius: 999px; padding: 6px 11px;
                 font: inherit; font-size: 12px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 14px rgba(9,42,74,.18); }
    .strazione:hover { background: #F4F8FB; }
    /* La finestra: al centro, l'85% dello schermo. Intestazione, schede e
       selezione restano ferme; scorre solo il corpo. Il contenuto sta su una
       colonna comoda da leggere; valori e stanza usano tutta la larghezza. */
    .wrap.win { display: flex; }
    .card { position: relative; display: flex; flex-direction: column; width: 100%; height: 100%;
            overflow: hidden; background: #fff; border: 1px solid #D9E2EC; border-radius: 14px;
            box-shadow: 0 28px 70px rgba(9,42,74,.24), 0 2px 8px rgba(9,42,74,.08); font-size: 13px; line-height: 1.45; }
    .cap { flex: 0 0 auto; width: 100%; box-sizing: border-box; }
    .bd { flex: 1 1 auto; min-height: 0; overflow: auto; overscroll-behavior: contain; }
    .bdi { padding: 14px 24px; box-sizing: border-box; }
    /* il testo da leggere di seguito resta su una riga comoda */
    .eotxt, .reftxt, .dedit, .qrow, .btnrow, .banner { max-width: 820px; }
    .rz { position: absolute; z-index: 6; touch-action: none; }
    .rz-n, .rz-s { left: 14px; right: 14px; height: 6px; cursor: ns-resize; }
    .rz-e, .rz-w { top: 14px; bottom: 14px; width: 6px; cursor: ew-resize; }
    .rz-n { top: 0; } .rz-s { bottom: 0; } .rz-e { right: 0; } .rz-w { left: 0; }
    .rz-ne, .rz-nw, .rz-se, .rz-sw { width: 14px; height: 14px; }
    .rz-ne { top: 0; right: 0; cursor: nesw-resize; } .rz-sw { bottom: 0; left: 0; cursor: nesw-resize; }
    .rz-nw { top: 0; left: 0; cursor: nwse-resize; } .rz-se { bottom: 0; right: 0; cursor: nwse-resize; }
    .hd { flex: 0 0 auto; display: flex; align-items: center; gap: 10px; min-height: 52px; padding: 0 12px 0 20px; background: #fff; color: #16232E;
          border-bottom: 1px solid #E6EBF0; border-radius: 13px 13px 0 0; position: relative; z-index: 3; cursor: grab; user-select: none; touch-action: none; }
    .hd:active { cursor: grabbing; }
    .hd .logo { display: inline-flex; }
    .hd b { font-size: 16px; font-weight: 600; letter-spacing: .1px; }
    .hd .who { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; max-width: 50%; }
    .card:focus { outline: none; }
    .hd .hsp { flex: 1 1 auto; }
    .pill .who { max-width: 200px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .hd .sub { font-size: 12px; color: #5B6B7A; white-space: nowrap; font-variant-numeric: tabular-nums; }
    .iconbtn { display: inline-grid; place-items: center; width: 36px; height: 36px; background: transparent; border: 0; color: #5B6B7A;
               cursor: pointer; border-radius: 8px; padding: 0; }
    .iconbtn:hover { background: #F1F4F7; color: #16232E; }
    .iconbtn:focus-visible { outline: 2px solid #0B5CAD; outline-offset: -2px; }
    #stautow { display: contents; }
    .stauto.ko { color: #B3261E; background: #FBEBEA; }
    .stauto.no { display: inline-flex; align-items: center; gap: 4px; width: auto; padding: 0 8px; font-size: 11px; font-weight: 700; white-space: nowrap; }
    .menuw { position: relative; }
    .menu { position: absolute; right: 0; top: 40px; z-index: 20; min-width: 200px; background: #fff; border: 1px solid #E3E8EF;
            border-radius: 10px; box-shadow: 0 12px 32px rgba(9,42,74,.16); padding: 6px; cursor: default; }
    .menu button { display: block; width: 100%; text-align: left; border: 0; background: none; padding: 8px 10px; border-radius: 6px;
                   font-size: 13px; color: #16232E; cursor: pointer; }
    .menu button:hover, .menu button:focus-visible { background: #F1F4F7; outline: none; }
    .menu hr { border: 0; border-top: 1px solid #EEF2F6; margin: 5px 4px; }
    .menu button.mrischio { color: #B3261E; font-weight: 700; }
    .menu .mver { padding: 6px 10px 4px; font-size: 12px; color: #5B6B7A; }
    .pbar { flex: 0 0 auto; height: 3px; background: #E3E8EF; }
    .pbar i { display: block; height: 100%; background: #0B5CAD; transition: width .25s ease; }
    /* compact, always-visible selection strip (plain text, not pills) */
    .selbar { background: #F8FBFE; border-bottom: 1px solid #D9E2EC;
              padding: 7px 24px; font-size: 12px; line-height: 1.8; color: #16232E; }
    .selbar .selgrp { color: #0B5CAD; font-weight: 800; }
    .selbar .selrow { display: block; }
    .selbar .selcount { float: right; color: #5B6B7A; font-size: 10.5px; font-weight: 700; letter-spacing: .4px; }
    .selitem { display: inline; white-space: nowrap; border-radius: 4px; padding: 1px 2px; }
    .selitem:hover { background: #EAF2FA; }
    .selitem .selx { display: none; border: 0; background: #B3261E; color: #fff; border-radius: 999px;
                     width: 15px; height: 15px; line-height: 13px; font-size: 10px; cursor: pointer; padding: 0;
                     vertical-align: 1px; margin-left: 2px; }
    .selitem:hover .selx { display: inline-block; }
    .bd { padding: 0; }
    .sec { margin-bottom: 14px; }
    .lbl { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: .06em; color: #5B6B7A; margin-bottom: 6px; }
    textarea, input[type="text"], input[type="search"] { width: 100%; border: 1px solid #C4D0DC; border-radius: 8px; padding: 8px 10px; font-size: 13px; color: #16232E; background: #fff; }
    textarea:focus-visible, input:focus-visible, .chip:focus-visible, .pbtn:focus-visible, .seg button:focus-visible, .btn:focus-visible, select.res:focus-visible, summary:focus-visible { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    .chips { display: flex; flex-wrap: wrap; gap: 6px; }
    .chip { display: inline-flex; align-items: center; border: 1px solid #C4D0DC; background: #F4F8FB; color: #16232E; border-radius: 999px;
            padding: 6px 12px; font-size: 12.5px; min-height: 28px; cursor: pointer; }
    .chip:hover { border-color: #0B5CAD; }
    .chip.on { background: #EAF2FA; border-color: #0B5CAD; color: #16232E; }
    .chip.on::before { content: "✓ "; font-weight: 800; white-space: pre; }
    .chip.q { background: transparent; border-style: dashed; color: #35506B; }
    .chip.q:hover { border-color: #0B5CAD; color: #0B5CAD; }
    .chip.q { padding: 3px 8px; font-size: 11px; min-height: 22px; }
    /* il quesito che porta un pacchetto di esami: bordo pieno; acceso, come un profilo */
    .chip.q.pk { border-style: solid; border-color: #9DBFDE; color: #16232E; font-weight: 600; }
    .chip.q.pk.on { background: #EAF2FA; border-color: #0B5CAD; color: #16232E; }
    .chip.q.pk .pkn { font-weight: 500; color: #5B6B7A; }
    .qrow { display: flex; gap: 8px; align-items: flex-start; }
    .qrow input { flex: 1 1 52%; min-width: 0; }
    .qchips { flex: 1 1 48%; display: flex; flex-wrap: wrap; gap: 4px; align-content: flex-start; }
    .chip.preset { background: #EAF2FA; border-color: #9DBFDE; font-weight: 600; padding: 5px 11px; font-size: 11.5px; min-height: 26px; }
    /* dense two-column exam grid: many exams, little space, still tappable */
    .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(190px, 1fr)); gap: 4px 5px; }
    .opt { display: flex; align-items: center; gap: 6px; border: 1px solid #E3E8EF; background: #fff; color: #16232E;
           border-radius: 7px; padding: 5px 7px; font-size: 11.5px; line-height: 1.2; cursor: pointer; text-align: left;
           min-height: 27px; overflow: hidden; }
    .opt:hover { border-color: #0B5CAD; background: #F4F8FB; }
    .opt .box { flex: 0 0 13px; width: 13px; height: 13px; border: 1.5px solid #9DBFDE; border-radius: 3px;
                display: inline-grid; place-items: center; font-size: 9px; font-weight: 800; color: transparent; }
    .opt.on { background: #EAF2FA; border-color: #0B5CAD; color: #16232E; font-weight: 600; }
    .opt.on .box { background: #0B5CAD; border-color: #0B5CAD; color: #fff; }
    .opt .nm { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .grouphdr { grid-column: 1 / -1; font-size: 11px; font-weight: 600; letter-spacing: .06em; color: #5B6B7A;
                margin: 5px 0 0; text-transform: uppercase; }
    .chip.preset.on { background: #EAF2FA; border-color: #0B5CAD; color: #16232E; }
    .gchips { grid-column: 1 / -1; display: flex; flex-wrap: wrap; gap: 4px; margin: 1px 0; }
    .qrx { grid-column: 1 / -1; min-width: 0; }
    .chip.cart { background: #EDF7F0; border-color: #BCE0C9; color: #124F31; cursor: default; }
    .chip.ghosted { background: #F4F8FB; border-color: #E3E8EF; color: #5B6B7A; cursor: default; }
    .chip.nel { background: #EDF7F0; border-color: #BCE0C9; color: #124F31; cursor: default; }
    .chip.manca { background: #FBEBEA; border-color: #E9BAB6; color: #7c1a14; cursor: default; font-weight: 600; }
    .chip.controlla { background: #FFF7E6; border-color: #F0D49A; color: #8a4b03; cursor: default; font-weight: 600; }
    /* l'emogas entrato nella versione di sempre: «al posto di EGA VENOSA NEW» */
    .chip .alposto { margin-left: 6px; font-size: 10.5px; font-weight: 500; color: #5B6B7A; }
    /* un'azione secondaria scritta, non un bottone: «solo carrello», «+ aggiungi» */
    .lnk { border: 0; background: transparent; padding: 2px 4px; font: inherit; font-size: 12.5px; font-weight: 600; color: #0B5CAD;
           cursor: pointer; text-decoration: underline; text-decoration-color: #9DBFDE; text-underline-offset: 3px; white-space: nowrap; }
    .lnk:hover:enabled { color: #094a8c; text-decoration-color: currentColor; }
    .lnk:disabled { color: #93A3B3; text-decoration: none; cursor: default; }
    .btnrow .lnk { flex: 0 0 auto; align-self: center; margin-left: 6px; }
    .lnk.piu { display: inline-block; margin: -4px 0 12px; padding-left: 0; }
    .lnk.ultima { display: block; margin: -2px 0 6px; padding-left: 0; }
    /* una richiesta ancora da confermare: una riga, non un allarme */
    .daconf { display: flex; align-items: center; gap: 8px; max-width: 820px; margin: 0 0 12px; font-size: 12px; color: #7a4b03; }
    .daconf .ddot { flex: 0 0 7px; width: 7px; height: 7px; border-radius: 50%; background: #E5A83B; }
    .daconf .lnk { font-size: 12px; padding: 0; margin-left: auto; }
    /* sul suo carrello: «Conferma e stampa» · «Svuota», a due tocchi */
    .daconf.az { flex-wrap: wrap; }
    .daconf .dcaz { margin-left: auto; display: flex; gap: 12px; }
    .daconf .dcaz .lnk { margin-left: 0; }
    .daconf .lnk.chiede { white-space: normal; text-align: right; }
    .daconf .lnk.chiede.via:enabled { color: #9B1C14; text-decoration-color: #E2A6A0; }
    .acsec .ac { margin-top: 0; }
    .btn { display: block; width: 100%; border: 0; border-radius: 10px; padding: 12px; font-size: 14px; font-weight: 700; cursor: pointer; text-align: center; }
    .btn + .btn { margin-top: 7px; }
    .btnrow { display: flex; gap: 7px; }
    .btnrow .btn { flex: 1 1 auto; min-width: 0; padding: 11px 8px; font-size: 13px; margin: 0;
                   white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .btnrow .btn.confirm { flex: 0 1 auto; }
    .btn.primary { background: #0B5CAD; color: #fff; }
    .btn.primary:hover { background: #094a8c; }
    .btn.confirm { background: #FFF7E6; color: #8a4b03; border: 1px solid #E5C588; }
    .btn.confirm:hover { background: #ffefd0; }
    .btn.ghost { background: #F4F8FB; color: #16232E; border: 1px solid #C4D0DC; }
    .btn.ghost:hover { border-color: #0B5CAD; }
    /* «Svuoto 4 esami?»: il secondo tocco svuota davvero */
    .btn.ghost.armato { background: #FBEBEA; color: #7c1a14; border-color: #B3261E; }
    .btn.stop { background: #B3261E; color: #fff; }
    .btn.stop:hover { background: #941e18; }
    .btn:disabled { background: #EDF1F5; color: #93A3B3; border: 1px solid #E3E8EF; cursor: default; opacity: 1; }
    .idline { font-size: 11.5px; color: #5B6B7A; margin: 0 0 7px; text-align: center; }
    .idline b { color: #16232E; }
    .problem { font-size: 11.5px; color: #7a4b03; background: #FFF7E6; border: 1px solid #E5C588; border-radius: 8px; padding: 7px 9px; margin-bottom: 7px; }
    .hint { font-size: 11.5px; color: #5B6B7A; margin-top: 7px; }
    .steps { display: flex; flex-direction: column; gap: 6px; }
    .step { display: flex; align-items: baseline; gap: 8px; padding: 8px 9px; border-radius: 8px; background: #F4F8FB; }
    .step .ic { flex: 0 0 16px; text-align: center; font-size: 12px; display: inline-block; }
    .step.ok { background: #EDF7F0; } .step.ok .ic { color: #177245; }
    .step.running { background: #EAF2FA; outline: 1px solid #9DBFDE; }
    .step.running .ic { animation: psaSpin 1.1s linear infinite; }
    .step.fail { background: #FBEBEA; } .step.fail .ic { color: #B3261E; font-weight: 800; }
    .step.skipped { opacity: .55; }
    .step small { color: #5B6B7A; margin-left: auto; text-align: right; }
    .banner { border-radius: 10px; padding: 10px 12px; margin-bottom: 10px; font-size: 12.5px; }
    .banner b { display: block; font-size: 13px; margin-bottom: 3px; }
    .banner.err { background: #FBEBEA; color: #7c1a14; border: 1px solid #E9BAB6; }
    .banner.ok { background: #EDF7F0; color: #124F31; border: 1px solid #BCE0C9; }
    .banner.warn { background: #FFF7E6; color: #7a4b03; border: 1px solid #E5C588; }
    .banner .qline { display: block; margin-top: 3px; font-size: 11.5px; opacity: .85; }
    .ac { position: relative; margin-top: 8px; }
    .ac input { width: 100%; }
    .acdrop { position: absolute; left: 0; right: 0; top: calc(100% + 4px); z-index: 5; background: #fff;
              border: 1px solid #C4D0DC; border-radius: 10px; box-shadow: 0 10px 24px rgba(9,42,74,.18);
              max-height: 260px; overflow: auto; padding: 4px; }
    .acitem { display: flex; align-items: center; gap: 8px; width: 100%; text-align: left; border: 0; background: transparent;
              border-radius: 6px; padding: 6px 8px; font-size: 12px; cursor: pointer; color: #16232E; }
    .acitem:hover { background: #EAF2FA; }
    .acitem.on { color: #177245; font-weight: 600; }
    .acitem.on::after { content: "✓"; margin-left: auto; }
    .acnm { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .actag { flex: 0 0 auto; margin-left: auto; font-size: 9.5px; font-weight: 800; letter-spacing: .4px; color: #5B6B7A;
             background: #F4F8FB; border: 1px solid #E3E8EF; border-radius: 5px; padding: 1px 5px; }
    .acitem.on .actag { margin-left: 0; }
    .acempty { padding: 8px; font-size: 12px; color: #8296A9; }
    .list { border: 1px solid #D9E2EC; border-radius: 10px; max-height: 320px; overflow: auto; margin-top: 6px; }
    .list label { display: flex; gap: 8px; padding: 9px 10px; font-size: 12px; cursor: pointer; align-items: baseline; border-bottom: 1px solid #EEF2F6; }
    .list label:hover { background: #F4F8FB; }
    .list input[type="checkbox"] { accent-color: #0B5CAD; }
    .log { font: 11px/1.5 ui-monospace, Menlo, Consolas, monospace; font-variant-numeric: tabular-nums; color: #35506B; background: #F8FAFC;
           border: 1px solid #E3E8EF; border-radius: 8px; padding: 8px; max-height: 130px; overflow: auto; white-space: pre-wrap; word-break: break-word; }
    details.reg summary { cursor: pointer; font-size: 11.5px; color: #5B6B7A; margin: 8px 0 6px; }
    /* il resoconto: passi e Registro insieme, chiusi sotto «Dettagli» */
    details.dett { max-width: 820px; margin-bottom: 8px; }
    details.dett > summary { cursor: pointer; font-size: 11.5px; font-weight: 600; color: #5B6B7A; margin: 2px 0 8px; }
    details.dett .reghd { font-size: 11.5px; color: #5B6B7A; margin: 10px 0 6px; }
    details.reflab > summary { cursor: pointer; }
    /* l'angolo per ridimensionare: in basso a destra, come in ogni finestra, e
       come lì senza disegno (il bordo tondo lo tagliava): lo dice il cursore */
    .rsz { position: absolute; right: 0; bottom: 0; width: 16px; height: 16px; cursor: nwse-resize; z-index: 7; touch-action: none; }
    .commit { position: sticky; bottom: -1px; margin: 0 -24px -14px; padding: 10px 24px 14px; background: #fff;
              border-top: 1px solid #EEF2F6; box-shadow: 0 -10px 14px -12px rgba(9,42,74,.25); }
    /* i bottoni stanno in fondo alla finestra anche quando c'è poco sopra
       (ricevuta, resoconto): non a metà, con la loro ombra in mezzo al bianco */
    .bdi:has(> .commit) { min-height: 100%; display: flex; flex-direction: column; }
    .bdi > .commit { margin-top: auto; }
    .bdi > .lnk { align-self: flex-start; }
    .commit > .btn { max-width: 820px; }
    .rlist { display: flex; flex-direction: column; gap: 4px; max-height: 320px; overflow: auto; }
    .rrow { display: flex; align-items: center; gap: 8px; border: 1px solid #E3E8EF; background: #fff; border-radius: 8px;
            padding: 7px 9px; font-size: 12px; cursor: pointer; text-align: left; width: 100%; color: #16232E; }
    .rrow:hover { border-color: #0B5CAD; background: #F4F8FB; }
    .prow { display: flex; flex-direction: column; gap: 1px; align-items: flex-start; width: 100%; text-align: left;
            border: 1px solid #E3E8EF; background: #fff; border-radius: 8px; padding: 6px 9px; cursor: pointer; color: #16232E; }
    .prow:hover { border-color: #0B5CAD; background: #F4F8FB; }
    .prow.hot { border-color: #9DBFDE; background: #EAF2FA; }
    .pline1 { font-size: 12px; font-variant-numeric: tabular-nums; }
    .pline1 small { color: #5B6B7A; font-size: 10.5px; }
    .pline2 { font-size: 10.5px; color: #5B6B7A; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 100%; }

    .rdot { flex: 0 0 7px; width: 7px; height: 7px; border-radius: 50%; border: 1.5px solid #C4D0DC; background: transparent; }
    .rdot.saved { background: #177245; border-color: #177245; }
    .rdot.open { background: #9DBFDE; border-color: #9DBFDE; }
    .rdot.busy { background: #E5A83B; border-color: #E5A83B; animation: psaPulse 1s infinite; }
    .rdot.err { background: #B3261E; border-color: #B3261E; }
    .rrow.saved { background: #F6FBF8; border-color: #BCE0C9; }
    .mini { float: right; border: 1px solid #C4D0DC; background: #fff; color: #0B5CAD; border-radius: 6px;
            padding: 1px 7px; font-size: 10.5px; font-weight: 700; cursor: pointer; letter-spacing: 0; text-transform: none; }
    .mini:hover { border-color: #0B5CAD; background: #F4F8FB; }
    .rwhen { flex: 0 0 auto; font-family: ui-monospace, Menlo, Consolas, monospace; font-size: 11px; color: #35506B; font-variant-numeric: tabular-nums; }
    .rsys { flex: 0 0 auto; font-size: 9.5px; font-weight: 800; letter-spacing: .5px; color: #5B6B7A; background: #F4F8FB;
            border: 1px solid #E3E8EF; border-radius: 5px; padding: 1px 5px; }
    .rlab { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    /* Le schermate in UNA fila di pillole, nell'ordine in cui si lavora:
       Richieste, Esiti, EO, Consensi, Dimissioni. La pillola accesa è quella
       dove sei. */
    .seg { display: flex; align-items: flex-end; flex-wrap: wrap; gap: 2px; margin: 0; padding: 0 24px;
           border-bottom: 1px solid #EEF2F6; min-height: 42px; }
    .seg > button { border: 0; border-bottom: 2px solid transparent; background: none; border-radius: 0; margin-bottom: -1px;
                    padding: 12px 10px 10px; font-size: 13px; font-weight: 400; color: #5B6B7A; cursor: pointer; }
    .seg > button:hover { color: #16232E; }
    .seg > button.on { color: #16232E; font-weight: 600; border-bottom-color: #0B5CAD; }
    /* la scheda accesa è in grassetto, ma occupa già la larghezza del grassetto:
       cambiando schermata le altre non si spostano di lato */
    .seg > button[data-t] { display: inline-flex; flex-direction: column; align-items: center; }
    .seg > button[data-t]::after { content: attr(data-t); font-weight: 600; height: 0; overflow: hidden; visibility: hidden; }
    .segdx { margin-left: auto; align-self: center; display: flex; align-items: center; gap: 6px; padding: 9px 0 3px; }
    /* in Modifica la fila resta com'è (stessa altezza, stesse righe di testo) ma non va mai a capo */
    .seg.modifica { flex-wrap: nowrap; }
    .segtit { flex: 0 1 auto; min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; padding: 12px 0 10px;
              border-bottom: 2px solid transparent; margin-bottom: -1px; font-size: 13px; font-weight: 600; line-height: normal; color: #16232E; }
    .rgo { flex: 0 0 auto; color: #8296A9; font-size: 12px; }
    .dlist, .mlist { display: flex; flex-direction: column; gap: 4px; }
    .dsep { display: flex; align-items: center; gap: 8px; margin: 8px 2px 3px; font-size: 10.5px;
            color: #5B6B7A; text-transform: uppercase; letter-spacing: .06em; }
    .dsep::after { content: ""; flex: 1 1 auto; height: 1px; background: #E3E8EF; }
    .drow { display: flex; align-items: stretch; gap: 5px; }
    .sec > .drow + .drow { margin-top: 6px; }
    .sec > .drow + .lbl { margin-top: 14px; }
    /* Copying is what this list is FOR: the target is the whole row, not a
       13px glyph at its edge. The pencil stays a button of its own. */
    .dcopia { flex: 1 1 auto; display: flex; align-items: center; gap: 8px; min-width: 0; text-align: left;
              border: 1px solid #E3E8EF; border-radius: 9px; background: #fff; cursor: pointer;
              padding: 8px 10px 8px 11px; font: inherit; }
    .dcopia:hover { border-color: #9DBFDE; background: #F4F9FD; }
    .dcopia:focus-visible { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    .dcopia.fatto { border-color: #BCE0C9; background: #EDF7F0; }
    .dcopia.fatto .dico { color: #124F31; }
    .dnome { flex: 1 1 auto; font-size: 12.5px; font-weight: 600; color: #16232E; overflow: hidden;
             white-space: nowrap; text-overflow: ellipsis; }
    .dmeta { flex: 0 0 auto; font-size: 10.5px; color: #5B6B7A; }
    .dico { flex: 0 0 auto; font-size: 13px; color: #6E8398; }
    .dmod { color: #0B5CAD; font-weight: 800; margin-left: 5px; }
    .dtuo { margin-left: 7px; padding: 1px 7px; border-radius: 999px; background: #EAF2FA; color: #0B5CAD;
            font-size: 10.5px; font-weight: 600; vertical-align: 1px; }
    /* in fondo all'elenco, un foglio da scrivere: tratteggiato, come un posto libero */
    .dnuovo { display: flex; align-items: center; gap: 9px; width: 100%; min-height: 38px; margin-top: 2px; padding: 8px 11px;
              border: 1px dashed #C4D0DC; border-radius: 9px; background: transparent; cursor: pointer; text-align: left;
              font: inherit; font-size: 12.5px; font-weight: 600; color: #5B6B7A; transition: border-color .12s, color .12s, background-color .12s; }
    .dnuovo:hover { border-color: #0B5CAD; color: #0B5CAD; background: #F4F9FD; }
    .dnuovo:focus-visible { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    .dplus { font-size: 17px; font-weight: 400; line-height: 1; }
    /* il nome del foglio tuo: un titolo che si scrive, non un modulo */
    .dhd { display: flex; align-items: center; gap: 6px; max-width: 820px; margin-bottom: 10px; }
    .dhd .mini { float: none; flex: none; white-space: nowrap; }
    .dhd input.dtit { flex: 1 1 auto; width: auto; min-width: 0; border: 0; border-bottom: 1px solid #D9E2EC; border-radius: 0;
                      background: transparent; padding: 6px 2px; font: inherit; font-size: 16px; font-weight: 600; color: #16232E; }
    .dhd input.dtit:focus, .dhd input.dtit:focus-visible { outline: none; border-bottom-color: #0B5CAD; }
    .dhd input.dtit::placeholder { color: #A3B2C2; font-weight: 400; }
    .dmod.agg { color: #A2600A; }
    .dbtn { flex: 0 0 auto; min-width: 38px; border: 1px solid #E3E8EF; border-radius: 9px;
            background: #F8FBFE; color: #35506B; font-size: 13px; cursor: pointer; }
    .dbtn:hover { background: #EAF2FA; border-color: #9DBFDE; color: #0B5CAD; }
    .dbtn:focus-visible { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    /* il testo scelto nella tendina: si vede cosa è finito negli appunti */
    .eotxt { margin-top: 8px; border: 1px solid #E3E8EF; border-left: 3px solid #0B5CAD; border-radius: 8px;
             background: #F8FBFE; padding: 9px 11px; font-size: 12.5px; line-height: 1.55; color: #35506B;
             max-height: 34vh; overflow: auto; white-space: pre-wrap; }
    .eoazione { margin-top: 8px; }
    .dedit { width: 100%; min-height: 46vh; resize: vertical; border: 1px solid #D9E2EC; border-radius: 9px;
             padding: 9px 10px; font: 12.5px/1.5 ui-monospace, SFMono-Regular, Consolas, monospace;
             color: #16232E; background: #fff; }
    .dedit:focus { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    /* a name we were never taught: shown in full, and underlined so it can
       never be mistaken for one of the curated sigle */
    .sttab th.stn.grezza { text-decoration: underline dotted #C08A2E; text-underline-offset: 2px; }
    /* un avviso discreto, non un riquadro: una riga piccola sopra la tabella */
    .avvnomi { display: flex; align-items: center; gap: 6px; font-size: 11px; color: #7a4b03; padding: 0 2px; margin-bottom: 5px; }
    .avvnomi .avvi { flex: 0 0 auto; width: 14px; height: 14px; border-radius: 50%; background: #E5C588;
                     color: #4d2f02; font-weight: 800; font-size: 10px; text-align: center; line-height: 14px; }
    .avvnomi .avvb { border: 0; background: transparent; color: #7a4b03; font: inherit;
                     font-weight: 700; cursor: pointer; text-decoration: underline; padding: 0; }
    .infochip { float: right; margin-right: 6px; font-size: 10.5px; font-weight: 600; letter-spacing: 0; text-transform: none; color: #7a4b03;
                background: #FFF7E6; border-radius: 999px; padding: 1px 8px; cursor: help; }
    .infochip:focus-visible { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    /* senza valori letti: un solo bottone, grande, al posto della tabella */
    .carica { display: flex; justify-content: center; padding: 22px 0 14px; }
    .grande { border: 0; border-radius: 12px; background: #0B5CAD; color: #fff; font: inherit; font-size: 16px; font-weight: 700;
              padding: 15px 38px; min-width: 240px; cursor: pointer; box-shadow: 0 6px 18px rgba(11,92,173,.28); }
    .grande:hover { background: #094a8c; }
    .grande:disabled { background: #7FA6CB; box-shadow: none; cursor: default; }
    .grande:focus-visible { outline: 3px solid #9DBFDE; outline-offset: 2px; }
    /* misurata sulla FINESTRA, non sullo schermo: dentro l'Affianca è stretta */
    .esiti { container: esiti / inline-size; }
    /* WORKUP (gli Esiti): Lab · ECG · Imaging, ognuno col suo colore sul bordo
       e nel titolo. Il rosso è SOLO dei valori fuori range; l'ambra di ciò che
       aspetta; il blu (l'accento) dei comandi e di «nuovo». */
    :host, .wu { --wu-lab: #0E7468; --wu-ecg: #5B50B8; --wu-img: #8A4A8F; --wu-altri: #5B6B7A;
          --wu-wait: #8A5A00; --wu-wait-bg: #FFF6E0; --wu-new: #0B5CAD; --wu-new-bg: #EAF2FA; --wu-bad: #B3261E; }
    /* Il Lab sempre per primo, a tutta larghezza; sotto ECG e Imaging, affiancati se c'è posto */
    .wu .esgrid { display: flex; flex-direction: column; gap: 12px; margin-bottom: 12px; }
    .wu .wucol { display: grid; grid-template-columns: minmax(0, 1fr); gap: 12px; align-items: start; min-width: 0; }
    @container esiti (min-width: 760px) {
      .wu .wucol { grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); }
      .wu .wucol > .wualtri { grid-column: 1 / -1; }
    }
    .wusum { display: flex; align-items: center; gap: 8px 12px; flex-wrap: wrap; margin: 0 0 14px; padding: 8px 12px;
             border: 1px solid #E3E8EF; border-radius: 10px; background: #F8FBFE; }
    .wusumv { flex: 1 1 auto; min-width: 0; display: flex; flex-wrap: wrap; align-items: baseline; gap: 2px 7px;
              font-size: 13.5px; color: #16232E; font-variant-numeric: tabular-nums; }
    .wuv { white-space: nowrap; }
    .wuv b { font-weight: 600; color: #35506B; }
    .wuval { color: var(--wu-bad); font-weight: 700; }
    .wuprima { color: #5B6B7A; font-size: 12px; }
    .wusep, .wupiu { color: #8397A8; }
    .wuok { color: #5B6B7A; }
    .wunuovi { border: 0; border-radius: 999px; background: var(--wu-new-bg); color: var(--wu-new); font: inherit; font-size: 12px;
               font-weight: 700; padding: 1px 10px; cursor: pointer; }
    .wunuovi:hover { background: #DCEAF7; }
    .wutools { display: flex; align-items: center; gap: 6px; margin-left: auto; }
    .wutools .mini { float: none; }
    .wuprog { font-size: 11.5px; font-weight: 600; color: #35506B; }
    /* ogni sezione: il suo colore sul bordo e, appena accennato, sul fondo */
    .wusec { --wu-c: #5B6B7A; border-left: 3px solid var(--wu-c); border-radius: 0 10px 10px 0; padding: 9px 12px 10px;
             margin: 0; min-width: 0; background: color-mix(in srgb, var(--wu-c) 5%, #fff); }
    .wulab .stwrap { width: fit-content; max-width: 100%; background: #fff; }
    .wulab { --wu-c: var(--wu-lab); } .wuecg { --wu-c: var(--wu-ecg); } .wuimg { --wu-c: var(--wu-img); } .wualtri { --wu-c: var(--wu-altri); }
    .wuh { display: flow-root; }   /* i bottoni a destra restano nella riga del titolo */
    .wuh .wut { color: var(--wu-c); font-weight: 800; }
    .wucnt { color: #8397A8; font-weight: 600; letter-spacing: 0; }
    .wuvuoto { font-size: 12px; color: #8397A8; }
    .wuwaits { display: flex; flex-direction: column; gap: 3px; margin-bottom: 6px; }
    .wuwait { display: flex; align-items: baseline; gap: 7px; min-width: 0; font-size: 12px; color: #35506B;
              background: var(--wu-wait-bg); border-radius: 7px; padding: 4px 9px; }
    .wuwait b { flex: none; white-space: nowrap; color: var(--wu-wait); font-variant-numeric: tabular-nums; }
    .wuclock { font-size: 11px; }
    .wuwlab { flex: 1 1 auto; min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .wuwq { flex: 0 0 auto; color: #8397A8; font-size: 11px; }
    .wu .rlist { max-height: none; overflow: visible; }
    .wuline { display: flex; align-items: stretch; gap: 4px; }
    .wuline .rrow { flex: 1 1 auto; min-width: 0; }
    .rmain { flex: 1 1 auto; min-width: 0; display: flex; flex-direction: column; gap: 1px; }
    .wuex { font-size: 11.5px; color: #5B6B7A; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .wunew { flex: 0 0 auto; font-size: 10px; font-weight: 700; color: var(--wu-new); background: var(--wu-new-bg); border-radius: 999px; padding: 0 7px; }
    .wust { flex: 0 0 auto; font-size: 11px; color: #8397A8; }
    .wupdf { flex: 0 0 auto; border: 1px solid #E3E8EF; border-radius: 8px; background: #fff; color: #0B5CAD; font: inherit;
             font-size: 11px; font-weight: 700; padding: 0 9px; cursor: pointer; white-space: nowrap; }
    .wupdf:hover { border-color: #0B5CAD; background: #F4F8FB; }
    .wupdf:focus-visible, .wunuovi:focus-visible { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    .wuitem.aperto .rrow { border-color: var(--wu-c); }
    .wutxt { margin: 4px 0 8px 14px; padding: 7px 11px; border-left: 2px solid var(--wu-c); border-radius: 0 8px 8px 0; background: #FBFCFE; }
    .wuver { display: inline-block; margin-bottom: 5px; padding: 0 8px; border-radius: 999px; font-size: 10.5px; font-weight: 700;
             color: var(--wu-wait); background: var(--wu-wait-bg); }
    .wualtro { font-size: 12.5px; font-weight: 700; color: #7a4b03; }
    .wunote { font-size: 12px; color: #5B6B7A; }
    .wuact { display: flex; gap: 6px; margin-top: 7px; }
    .wuact .mini { float: none; }
    .rdot.coda { border-style: dashed; border-color: #8397A8; }
    .rrow.altro .rlab { color: #8397A8; }
    .avvlista { white-space: pre-wrap; font-size: 11px; line-height: 1.45; color: #5B6B7A;
                background: #FFFDF7; border: 1px solid #EEDFC0; border-radius: 8px; padding: 6px 9px; margin-bottom: 6px; }
    .archhd { display: flex; align-items: center; gap: 8px; width: 100%; margin-top: 8px; cursor: pointer;
              border: 1px solid #E3E8EF; border-radius: 9px; background: #F8FBFE; padding: 7px 10px;
              font: 600 12px/1 inherit; color: #5B6B7A; }
    .archhd:hover { border-color: #9DBFDE; color: #16232E; }
    .archhd .an { background: #E3E8EF; color: #35506B; border-radius: 999px; padding: 1px 7px; font-size: 10.5px; }
    .archhd .ago { margin-left: auto; color: #8296A9; }
    .alist { display: flex; flex-direction: column; gap: 3px; margin-top: 4px; }
    .arow { display: flex; align-items: center; gap: 8px; padding: 5px 8px 5px 10px;
            border: 1px solid #EDF1F6; border-radius: 8px; background: #fff; }
    .arow .anm { flex: 1 1 auto; font-size: 12px; color: #5B6B7A; overflow: hidden;
                 white-space: nowrap; text-overflow: ellipsis; }
    .arow .ameta { flex: 0 0 auto; font-size: 10.5px; color: #5B6B7A; }
    .abtn { flex: 0 0 auto; border: 1px solid #D9E2EC; background: #F8FBFE; color: #35506B;
            border-radius: 7px; padding: 3px 8px; font: 600 11px/1.4 inherit; cursor: pointer; }
    .abtn:hover { border-color: #9DBFDE; color: #0B5CAD; }
    .abtn.del:hover { border-color: #E9BAB6; background: #FBEBEA; color: #B3261E; }
    .tchip { display: flex; align-items: center; }
    .tchip button { display: inline-flex; align-items: center; gap: 6px; height: 32px; border: 1px solid #E3E8EF; background: #fff; color: #5B6B7A;
                    font: 600 12px/1 inherit; border-radius: 8px; padding: 0 9px; cursor: pointer; font-variant-numeric: tabular-nums; }
    .tchip.off button { border-color: transparent; width: 36px; justify-content: center; padding: 0; }
    .tchip button:hover { background: #F1F4F7; color: #16232E; }
    .tchip .tdot { width: 7px; height: 7px; border-radius: 50%; background: #C62828; }
    .tchip.on button:first-child { border-radius: 7px 0 0 7px; border-right: 0; font-variant-numeric: tabular-nums; }
    .tchip.on button:last-child { border-radius: 0 7px 7px 0; }
    .tchip.on button { color: #16232E; }
    .recchip { display: inline-flex; align-items: center; padding: 1px 7px; border-radius: 999px; background: #B3261E; color: #fff;
               font-size: 10.5px; font-weight: 800; letter-spacing: .04em; white-space: nowrap; margin: 0 4px; }
    .tnow { display: flex; align-items: center; gap: 10px; background: #EDF7F0; border: 1px solid #BCE0C9;
            border-radius: 10px; padding: 10px 12px; margin-bottom: 8px; }
    .tbig { font: 800 20px/1 inherit; color: #124F31; font-variant-numeric: tabular-nums; }
    .tlab { flex: 1 1 auto; font-size: 12px; color: #35506B; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .tpres { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 6px; }
    .rif { max-width: 820px; }
    .rifanc { font-size: 12px; color: #35506B; background: #F4F8FB; border-left: 3px solid #0B5CAD;
              border-radius: 0 8px 8px 0; padding: 8px 11px; margin-bottom: 10px; line-height: 1.45; }
    #riffiltro { width: 100%; box-sizing: border-box; border: 1px solid #D9E2EC; border-radius: 8px; padding: 8px 10px;
                 font: 13px/1.3 inherit; color: #16232E; margin-bottom: 4px; }
    #riffiltro:focus { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    .rifg { margin-top: 12px; }
    .rift { border-top: 1px solid #EDF1F6; }
    .rifr { display: grid; grid-template-columns: minmax(120px, 170px) 1fr; gap: 12px; padding: 6px 2px;
            border-bottom: 1px solid #EDF1F6; font-size: 12.5px; line-height: 1.45; }
    .rifr b { color: #16232E; font-weight: 700; }
    .rifr span { color: #35506B; }
    .rifr i { font-style: normal; color: #9AAABB; }
    .rifvuoto { font-size: 12px; color: #8296A9; padding: 10px 2px; }
    .rifpiede { font-size: 11.5px; color: #5B6B7A; font-style: italic; margin-top: 12px; }
    .tpre { border: 1px solid #C4D0DC; background: #fff; color: #16232E; border-radius: 999px;
            padding: 7px 12px; font: 600 12px/1 inherit; cursor: pointer; }
    .tpre:hover { border-color: #0B5CAD; color: #0B5CAD; background: #F4F8FB; }
    .tlibero { display: flex; gap: 6px; }
    .tlibero input { flex: 1 1 auto; border: 1px solid #D9E2EC; border-radius: 8px; padding: 7px 9px;
                     font: 12.5px/1.3 inherit; color: #16232E; }
    .tlibero input:focus { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    .ttot { float: right; font-size: 11px; color: #5B6B7A; font-weight: 600; }
    .tlist { display: flex; flex-direction: column; gap: 3px; }
    .trow { display: flex; align-items: center; gap: 8px; padding: 5px 6px 5px 9px; font-size: 11.5px;
            border: 1px solid #EDF1F6; border-radius: 8px; background: #fff; }
    .trow .tt { flex: 1 1 auto; font-weight: 600; color: #16232E; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .trow .tp { flex: 0 1 90px; color: #8296A9; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .trow .td { flex: 0 0 auto; font-weight: 700; color: #0B5CAD; font-variant-numeric: tabular-nums; }
    .trow .to { flex: 0 0 auto; color: #5B6B7A; font-size: 10.5px; font-variant-numeric: tabular-nums; }
    .tdel { border: 0; background: transparent; color: #5B6B7A; cursor: pointer; font-size: 12px; padding: 0 2px; }
    .tdel:hover { color: #B3261E; }
    /* DA FARE. L'icona: le spunte tonde e quante voci sono aperte. Tranquilla;
       ambra 15 minuti prima di un promemoria; rossa quando è passato (solo
       allora un bagliore lento: il movimento vuol dire «è l'ora»). */
    .dfslot, .dfpslot { display: contents; }
    .dfic { position: relative; z-index: 1; flex: none; display: inline-flex; align-items: center; gap: 3px; height: 24px; min-width: 28px;
            padding: 0 7px 0 6px; border: 0; border-radius: 999px; background: #EEF2F6; color: #35506B; cursor: pointer;
            font: inherit; font-size: 12px; font-weight: 700; line-height: 24px; white-space: nowrap; font-variant-numeric: tabular-nums; align-self: center; }
    .dfic svg { width: 14px; height: 14px; flex: none; }
    .dfic b { font: inherit; letter-spacing: 0; }   /* (anche nell'intestazione, dove i <b> sono grandi) */
    .dfic:hover { background: #E3E9F0; color: #16232E; }
    .dfic:focus-visible { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    .dfic.vuota { justify-content: center; padding: 0; width: 28px; background: none; color: #8296A9; }
    .dfic.vuota:hover { background: #EEF2F6; color: #16232E; }
    .dfic.amb { background: #FFF4DB; color: #8A5A00; }
    .dfic.amb:hover { background: #FCEBC4; }
    .dfic.ros { background: #FDEBEA; color: #B3261E; animation: prBagliore 2.6s ease-in-out infinite; }
    .dfic.ros:hover { background: #FADBD8; }
    @keyframes prBagliore { 0%, 100% { box-shadow: 0 0 0 0 rgba(179,38,30,0); } 50% { box-shadow: 0 0 0 4px rgba(179,38,30,.13); } }
    /* il post-it: la prima voce aperta, in grigio, che cede per prima */
    .dfpost { min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; font-size: 13px; color: #5B6B7A; }
    .dfpost b { font-weight: 600; color: #35506B; font-variant-numeric: tabular-nums; }
    /* nell'intestazione, accanto agli identificativi: il cuore e l'icona */
    .hdpaz { flex: none; display: inline-flex; align-items: center; gap: 8px; margin-left: 10px; }
    /* IL CUORE dei parametri vitali: rosso o ambra, fermo. Un impulso solo, da
       un secondo, quando compare; vuoto («♡ 5h») se la riga ha più di 4 ore. */
    .cuore { flex: none; display: inline-block; font-size: 14px; line-height: 1; font-weight: 700; cursor: default; }
    .cuore.ros { color: #C62828; }
    .cuore.amb { color: #B26A00; }
    .cuore.vecchio { font-size: 12px; font-weight: 600; font-variant-numeric: tabular-nums; }
    .cuore.pulsa { animation: cuorePulsa 1s ease-out 1; }
    @keyframes cuorePulsa { 0% { transform: scale(1); } 30% { transform: scale(1.35); } 100% { transform: scale(1); } }
    .pzchi .cuore, .stp2 .cuore { align-self: center; }
    @media (prefers-reduced-motion: reduce) { .cuore.pulsa, .dfic.ros { animation: none; } }
    /* la lista: una piccola finestra sotto l'icona */
    .dfpop { position: absolute; z-index: 30; width: 340px; max-width: calc(100vw - 16px); padding: 4px 6px 8px; border: 1px solid #D9E2EC;
             border-radius: 10px; background: #fff; box-shadow: 0 10px 28px rgba(9,42,74,.16); }
    .dfhd { padding: 6px 6px 4px; font-size: 12px; color: #5B6B7A; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .dfhd b { color: #16232E; }
    .dfl { list-style: none; margin: 0; padding: 0; max-height: 50vh; overflow-y: auto; }
    .dfl:empty { display: none; }
    .dfi { display: flex; align-items: center; gap: 6px; min-height: 38px; padding: 2px 4px 2px 0; border-radius: 6px; background: #fff; }
    .dfi + .dfi { box-shadow: inset 0 1px 0 #EEF2F6; }
    .dfi.presa { position: relative; z-index: 2; box-shadow: 0 6px 18px rgba(9,42,74,.18); }
    .dfl.trascino, .dfl.trascino * { cursor: grabbing !important; }
    .dfgrip { flex: none; width: 16px; text-align: center; color: #B4C2CF; cursor: grab; touch-action: none; user-select: none; -webkit-user-select: none;
              font-size: 13px; letter-spacing: -2px; line-height: 30px; }
    .dfi:hover .dfgrip { color: #5B6B7A; }
    .dfck { flex: none; position: relative; width: 20px; height: 20px; padding: 0; border: 1.6px solid #8296A9; border-radius: 50%; background: #fff; cursor: pointer; }
    .dfck::before { content: ""; position: absolute; inset: -9px; }
    .dfck:hover { border-color: #177245; }
    .dfck:focus-visible { outline: 2px solid #0B5CAD; outline-offset: 2px; }
    .dfi.fatto .dfck { border-color: #177245; background: #177245; }
    .dfi.fatto .dfck::after { content: ""; position: absolute; left: 5.5px; top: 2px; width: 5px; height: 9px; border: solid #fff; border-width: 0 2px 2px 0; transform: rotate(45deg); }
    .dftx { flex: 1 1 auto; min-width: 0; overflow-wrap: anywhere; font-size: 13px; line-height: 1.35; color: #16232E; }
    .dfi.fatto .dftx { text-decoration: line-through; color: #8296A9; }
    .dft { flex: none; padding: 0 6px; border-radius: 999px; background: #EEF2F6; color: #35506B; font-size: 11.5px; font-weight: 700; line-height: 18px; font-variant-numeric: tabular-nums; }
    .dft.amb { background: #FFF4DB; color: #8A5A00; }
    .dft.ros { background: #FDEBEA; color: #B3261E; }
    .dfi.fatto .dft { background: none; color: #9AA8B5; font-weight: 400; }
    .dfpiu { flex: none; min-height: 26px; border: 1px solid #D9E2EC; border-radius: 6px; background: #fff; padding: 0 7px; cursor: pointer;
             font-size: 11.5px; font-weight: 600; color: #16232E; white-space: nowrap; }
    .dfpiu:hover { border-color: #9DBFDE; }
    .dfpiu:focus-visible { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    .dfadd { position: relative; margin-top: 6px; }
    .dfin { display: block; width: 100%; height: 32px; padding: 0 10px; border: 1px solid #D9E2EC; border-radius: 8px; background: #F8FBFE;
            font-size: 13px; color: #16232E; }
    .dfin::placeholder { color: #8296A9; }
    .dfin:focus { outline: 0; border-color: #0B5CAD; background: #fff; box-shadow: 0 0 0 3px rgba(11,92,173,.12); }
    .dfhint { display: block; padding: 4px 4px 0; font-size: 11.5px; line-height: 16px; color: #35506B; font-variant-numeric: tabular-nums; }
    .dfhint:empty { display: none; }
    .dfhint.ko { color: #B3261E; }
    .dfsr { position: absolute; width: 1px; height: 1px; overflow: hidden; clip-path: inset(50%); }
    /* il menu minuscolo della sveglia sulla pill ridotta: ✓ Fatto, +15′, Apri */
    .prmenu { position: absolute; z-index: 30; width: max-content; min-width: 260px; max-width: min(360px, calc(100vw - 16px)); padding: 4px;
              border: 1px solid #D9E2EC; border-radius: 10px; background: #fff; box-shadow: 0 10px 28px rgba(9,42,74,.16); }
    .prmhd { padding: 6px 8px 4px; font-size: 12px; color: #5B6B7A; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .prmrow { display: flex; align-items: center; gap: 8px; min-height: 38px; padding: 3px 4px 3px 8px; }
    .prmrow + .prmrow { border-top: 1px solid #EEF2F6; }
    .prmq { flex: 1 1 auto; min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; font-size: 13px; color: #16232E; }
    .prmq b { font-weight: 600; font-variant-numeric: tabular-nums; }
    .prmb { flex: none; min-height: 28px; border: 1px solid #D9E2EC; border-radius: 6px; background: #fff; padding: 2px 9px; cursor: pointer;
            font-size: 12px; font-weight: 600; color: #16232E; white-space: nowrap; }
    .prmb:hover { border-color: #9DBFDE; }
    .prmb.ok:hover { border-color: #BCE0C9; background: #EDF7F0; color: #177245; }
    .prmb:focus-visible { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    /* sulla pill ridotta, solo quando tocca */
    .pill .prurg { display: inline-flex; align-items: center; gap: 3px; padding: 1px 7px 1px 5px; border-radius: 999px; background: #B3261E;
                   color: #fff; font-size: 11px; font-weight: 700; line-height: 16px; font-variant-numeric: tabular-nums; box-shadow: 0 0 0 1.5px #fff; }
    .pill .prurg svg { width: 12px; height: 12px; flex: none; }
    .pill .prurg { cursor: pointer; max-width: 260px; }
    .pill .prurg:hover { background: #8f1e18; }
    .pill .prurg:focus-visible { outline: 2px solid #fff; outline-offset: 2px; }
    .pill .prurgt { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .pill .prurgp { opacity: .85; }
    .prmini { min-width: 0; width: max-content; }
    .prmini .prmhd { padding: 6px 8px 2px; color: #16232E; }
    .prmini .prmrow { min-height: 36px; padding: 2px 4px 4px 4px; gap: 6px; }
    .prmini .prmq { font-size: 12.5px; color: #35506B; }
    .crow { display: flex; align-items: center; gap: 10px; width: 100%; text-align: left; cursor: pointer;
            border: 1px solid #E3E8EF; border-radius: 9px; background: #fff; padding: 10px 11px; font: inherit; }
    .crow:hover { border-color: #9DBFDE; background: #F4F9FD; }
    .crow:focus-visible { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    .cnome { flex: 1 1 auto; font-size: 12.5px; font-weight: 600; color: #16232E; }
    .cgo { flex: 0 0 auto; font-size: 11px; color: #0B5CAD; font-weight: 700; }
    .cpag { flex: 0 0 auto; font-size: 10px; color: #8a4b03; background: #FFF3DB; border-radius: 999px; padding: 1px 7px; font-weight: 700; }
    .linkbtn { border: 0; background: transparent; color: #0B5CAD; font: inherit; font-weight: 700;
               text-decoration: underline; cursor: pointer; padding: 0; }

    /* La tabella scorre dentro la sua cornice, non col pannello: solo così
       l'intestazione (sticky) resta sotto gli occhi con venti analiti. */
    .stwrap { overflow: auto; max-height: 60vh; overscroll-behavior: contain; border: 1px solid #E3E8EF; border-radius: 8px; }
    /* La tabella è larga quanto i suoi numeri, non quanto il pannello: se il
       medico allarga la finestra i valori restano accanto ai nomi invece di
       allontanarsene. Per lo stesso motivo i numeri sono allineati a
       sinistra, incolonnati dalle cifre tabulari. */
    .sttab { border-collapse: collapse; font-size: 11.5px; width: auto; }
    .sttab th, .sttab td { padding: 3px 7px; white-space: nowrap; border-bottom: 1px solid #EDF1F6; }
    .sttab thead th { position: sticky; top: 0; background: #F8FBFE; color: #5B6B7A; font-weight: 600;
                      font-size: 10.5px; text-align: left; border-bottom: 1px solid #D9E2EC; }
    .sttab .sth { display: block; font-size: 9.5px; color: #5B6B7A; font-weight: 500; }
    .sttab th.stn { position: sticky; left: 0; z-index: 1; background: #fff; text-align: left;
                    font-weight: 600; color: #16232E; max-width: 168px; overflow: hidden; text-overflow: ellipsis; }
    .sttab thead th.stn { background: #F8FBFE; z-index: 2; }
    .sttab td { text-align: left; color: #35506B; font-variant-numeric: tabular-nums; }
    .sttab td.fuori { color: #B3261E; font-weight: 800; }
    .sttab td.parz { font-style: italic; }   /* parziale: in corsivo, niente puntini */
    /* Novelty rides a different channel: a tint behind the number. Text
       colour is untouched, so red keeps meaning "out of range". */
    .sttab td.nuovo, .sttab td.agg, .sttab tbody tr:hover td.nuovo, .sttab tbody tr:hover td.agg {
      background: #DCEAF9; box-shadow: inset 0 -2px 0 #0B5CAD; }
    /* I segni del medico: un tocco giallo, due arancio, tre via. Stanno DOPO
       la novità perché il segno vince sullo sfondo azzurro; la riga blu sotto
       il numero (box-shadow) resta e continua a dire «nuovo». */
    .sttab td[data-cella] { cursor: pointer; user-select: none; }   /* due tocchi non devono selezionare il numero */
    /* Il segno è una pastiglia stretta attorno al numero (freccia e segno
       compresi), non tutta la cella: il margine negativo compensa il padding,
       così il numero non si sposta quando la pastiglia compare. */
    .sttab td .val { display: inline-block; border-radius: 999px; padding: 0 5px; margin: 0 -5px; }
    .sttab td .pct { font-weight: 500; color: #5B6B7A; font-style: normal; }
    .sttab td.marca1 .val { background: #FFE58A; }
    .sttab td.marca2 .val { background: #FFC46B; }
    .sttab tbody tr:hover td, .sttab tbody tr:hover th.stn { background: #F4F9FD; }
    /* Sezioni: gli esami stanno dove un medico li cerca, e sempre nello stesso
       posto. L'ordine non dipende più da come il laboratorio ha stampato. */
    .sttab tr.stsez th.stn, .sttab tr.stsez td { background: #EEF4FA; border-bottom: 1px solid #D9E4EF;
      font-size: 9.5px; font-weight: 800; letter-spacing: .07em; text-transform: uppercase; color: #5B6B7A; }
    .sttab tr.stsez th.stn { color: #35506B; padding-top: 7px; padding-bottom: 4px; }
    .sttab tr.stsez td { text-align: left; padding-top: 7px; padding-bottom: 4px; }
    .sttab tr.stsez:hover th.stn, .sttab tr.stsez:hover td { background: #EEF4FA; }
    /* una cella senza valore si deve VEDERE che è vuota, o una riga con due
       soli prelievi sembra una riga piena */
    .sttab td.vuoto { color: #AEBECD; }
    /* L'unità sta ACCANTO al nome, fra parentesi: su un rigo suo raddoppiava
       l'altezza di ogni riga e allontanava i numeri dal nome. */
    .stum { font-size: 9px; color: #5B6B7A; font-weight: 500; letter-spacing: 0; }
    .sttab th.ultima { color: #0B5CAD; }
    .sttab th.ultima::after { content: "ultimo"; display: block; font-size: 8.5px; font-weight: 700;
      letter-spacing: .06em; text-transform: uppercase; color: #9DBFDE; }
    /* il segno di provenienza: piccolo, in alto, mai confondibile con un valore */
    .sttab .prov { font-style: normal; font-size: 9px; vertical-align: super; color: #0B5CAD;
                   font-weight: 800; margin-left: 1px; cursor: help; }
    .reftxt { font-size: 12.5px; line-height: 1.5; color: #16232E; }
    .reftxt .rt { padding: 1px 0; }
    .reftxt .rt:empty { display: none; }
    .newbar { display: flex; align-items: center; gap: 8px; font-size: 11.5px; color: #0B5CAD;
              background: #EAF2FA; border: 1px solid #9DBFDE; border-radius: 8px; padding: 5px 9px; margin-bottom: 6px; }
    .newbar button { margin-left: auto; border: 0; background: transparent; color: #0B5CAD; font: inherit; font-weight: 700; cursor: pointer; }
    .foot { flex: 0 0 auto; padding: 8px 14px 10px; border-top: 1px solid #EEF2F6; display: flex; justify-content: space-between; align-items: center; color: #5B6B7A; font-size: 11px; }
    .footlink { border: 0; background: transparent; color: #0B5CAD; font-size: 11px; cursor: pointer; padding: 0; text-decoration: underline; }
    select.res { width: 100%; border: 1px solid #C4D0DC; border-radius: 8px; padding: 7px 8px; font-size: 12.5px; background: #fff; }
    @keyframes psaSpin { to { transform: rotate(360deg); } }
    @keyframes psaPulse { 0%,100% { opacity: 1; } 50% { opacity: .35; } }
    @keyframes psaDrain { from { width: 100%; } to { width: 0; } }
    @media (prefers-reduced-motion: reduce) { .step.running .ic, .pill .dot { animation: none; } }

    /* ---- Stanza ---- */
    /* stanza svuotata apposta: due parole e il modo di ridisegnarla */
    .stvuota { position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 10px;
               pointer-events: none; color: #5B6B7A; font-size: 13px; }
    .stvuota b { font-size: 14px; font-weight: 600; color: #16232E; }
    .stvuota button { pointer-events: auto; }
    .stlink { border: 0; background: none; padding: 0; cursor: pointer; font-size: 12px; color: #5B6B7A; text-decoration: underline; }
    /* nella finestra i Pazienti riempiono tutto il corpo che resta, da bordo a bordo */
    .card.stanza .bdi { height: 100%; display: flex; flex-direction: column; padding: 0; }
    .card.stanza .bdi > .sec { flex: 1 1 auto; display: flex; flex-direction: column; min-height: 0; margin-bottom: 0; }
    .card.stanza .bdi > .banner, .card.stanza .bdi > .reg { flex: none; margin: 10px 14px; }
    /* I Pazienti: sopra la lista, sotto la stanza. Due grigi per il testo;
       l'azzurro solo per il paziente di questa pagina, per il fuoco e per
       l'azione che conta; il colore solo per il triage, in una striscia. */
    .t-rosso { --tr: #C62828; } .t-arancione { --tr: #EF6C00; } .t-azzurro { --tr: #1E88E5; }
    .t-verde { --tr: #2E7D32; } .t-bianco { --tr: #B0BEC5; }
    /* in Modifica, in fondo alla fila delle schede: + Letto, + Sedia, + Area,
       Fine. Mai a capo; e la fila è alta uguale con e senza */
    .stazioni { display: inline-flex; flex: none; flex-wrap: nowrap; align-items: center; gap: 6px; height: 32px; margin-left: auto; white-space: nowrap; }
    .seg > .segdx:empty { min-height: 44px; }
    .stbtn, .stazioni .stbtn { border: 1px solid #D9E2EC; border-radius: 8px; background: #fff; padding: 3px 12px; cursor: pointer;
             font-size: 13px; font-weight: 600; line-height: 20px; color: #16232E; white-space: nowrap; }
    .stbtn:hover, .stazioni .stbtn:hover { border-color: #9DBFDE; background: #fff; color: #16232E; }
    .stbtn.pri, .stazioni .stbtn.pri { background: #0B5CAD; border-color: #0B5CAD; color: #fff; }
    .stbtn.pri:hover, .stazioni .stbtn.pri:hover { background: #094a8c; border-color: #094a8c; color: #fff; }
    .stazioni button:focus-visible, .stbtn:focus-visible, .stctl:focus-visible, .stp:focus-visible, .stname:focus-visible,
    .pzrow:has(.pzapri:focus-visible), .pzmetti:focus-visible, .pzx:focus-visible, .pzarchhd:focus-visible,
    .pzsvuota:focus-visible, .pzabtn:focus-visible, .pzfx:focus-visible, .stannulla:focus-visible { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    /* quello che dicono tutti e due: da quanto non lo apri, «questa pagina», i segni */
    .stvisto { flex: none; font-size: 12px; color: #5B6B7A; white-space: nowrap; font-variant-numeric: tabular-nums; }
    .stvisto.amb { padding: 0 7px; border-radius: 999px; background: #FFF4DB; color: #8A5A00; }
    /* lo stato degli esami: un pezzetto per tipo, Lab · ECG · RX, tinto col colore
       della sua sezione negli Esiti. L'ambra e il rosso solo sul tempo che aspetta. */
    .esst { flex: none; font-size: 12px; color: #35506B; white-space: nowrap; font-variant-numeric: tabular-nums; }
    .esp { --c: #5B6B7A; display: inline-flex; align-items: center; gap: 4px; height: 22px; padding: 0 7px; border-radius: 6px;
           background: color-mix(in srgb, var(--c) 9%, #fff); line-height: 1; white-space: nowrap; }
    .es-lab { --c: var(--wu-lab); } .es-ecg { --c: var(--wu-ecg); } .es-img { --c: var(--wu-img); }
    .esp .esn { font-weight: 700; color: var(--c); }
    .esst .esatt { font-style: normal; }
    .esst .esatt.amb { margin: 0 -3px; padding: 2px 4px; border-radius: 4px; background: #FFEFC7; color: #7A4F00; font-weight: 600; }
    .esst .esatt.ros { margin: 0 -3px; padding: 2px 4px; border-radius: 4px; background: #FBE1DF; color: #9B1C14; font-weight: 700; }
    .esst .esdot { font-size: 10px; color: #0B5CAD; }
    .esst .esdot.ros { color: #B3261E; }
    .esst.vecchio .esp { --c: #9AA8B5; color: #9AA8B5; }
    .esst.vecchio .esdot { color: #9AA8B5; }
    .esst.vecchio .esatt.amb, .esst.vecchio .esatt.ros { background: none; color: inherit; font-weight: 400; }
    .stp2 .esst { display: inline-flex; flex: 0 1 auto; flex-wrap: wrap; gap: 3px; font-size: 11.5px; min-width: 0; }
    .stp2 .esp { height: 18px; padding: 0 5px; }
    /* sotto il nome: le allergie e l'Attenzione del gestionale, parola per parola */
    /* una riga sola: un testo lungo finisce coi puntini, e intero nel passaggio del mouse */
    .idriga { flex: none; display: flex; gap: 14px; padding: 0 20px 8px; background: #fff; font-size: 12.5px; line-height: 1.35; min-width: 0; }
    .idriga > span { flex: 0 1 auto; min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .idriga > .idall { flex-shrink: 0; max-width: 60%; }
    .idall.ros { color: #B3261E; font-weight: 600; }
    .idall.nl { color: #8A5A00; }
    .idall.nega { color: #5B6B7A; }
    .idatt { color: #7a4b03; }
    /* Dimissioni: quello che è ancora aperto, una riga */
    .aperti { max-width: 820px; margin: 0 0 12px; font-size: 12.5px; line-height: 1.45; color: #35506B; }
    .aperti b { font-weight: 600; color: #16232E; }
    .aperti .apl { color: #8494A3; }
    /* Richieste: quando è già stato fatto, in grigio accanto al nome */
    .opt .ult { flex: none; margin-left: auto; padding-left: 4px; font-size: 11px; font-weight: 400; color: #8494A3; white-space: nowrap; font-variant-numeric: tabular-nums; }
    .opt .ult.vecchio { color: #A9B5C1; }
    .stqui { flex: none; font-size: 12px; font-weight: 600; color: #0B5CAD; white-space: nowrap; }
    .sttag { flex: none; font-size: 11px; font-weight: 600; letter-spacing: .06em; text-transform: uppercase; color: #5B6B7A; white-space: nowrap; }
    .stom { flex: none; margin-right: 5px; font-weight: 400; color: #8A5A00; }
    .stcoda { font-weight: 400; color: #5B6B7A; white-space: nowrap; }
    .stn { margin-left: 6px; font-size: 12px; font-weight: 400; color: #5B6B7A; font-variant-numeric: tabular-nums; letter-spacing: 0; }
    .stsr { position: absolute; width: 1px; height: 1px; overflow: hidden; clip-path: inset(50%); white-space: nowrap; }   /* solo per chi legge con la voce */

    /* PAZIENTI, una vista sola: sopra la lista di chi non ha ancora un posto,
       sotto la stanza. La lista prende quello che le serve — al massimo poco
       meno di metà, poi scorre dentro — e la stanza il resto: man mano che la
       lista si accorcia, la stanza sale e cresce. Vuota, la lista non c'è. */
    .pzunita { position: relative; flex: 1 1 auto; display: flex; flex-direction: column; min-height: 0;
               user-select: none; -webkit-user-select: none; -webkit-touch-callout: none; }
    .pzunita input { user-select: text; -webkit-user-select: text; }
    .pzcoda { flex: 0 1 auto; max-height: 45%; overflow-y: auto; overscroll-behavior: contain; scrollbar-width: thin;
              padding: 2px max(14px, calc(100% - 1054px)) 6px 14px; border-bottom: 1px solid #E8EDF2; container: pzlista / inline-size; transition: background-color .12s;
              /* LE COLONNE, uguali per tutte le righe: il nome, il cuore, Lab, ECG, RX,
                 «Da fare», il post-it (che cede per primo), visto, ▾, ✕. Una colonna che
                 nessuno usa non occupa niente. */
              display: grid; align-content: start;
              grid-template-columns: [tri] auto [nm] minmax(0, max-content) [cuore] auto [lab] auto [ecg] auto [img] auto [df] auto
                                     [post] minmax(0, 1fr) [visto] auto [metti] auto [x] auto; }
    .pzcoda > .pzvuoto { grid-column: 1 / -1; }
    .pzcoda.over { background: #F1F6FC; }
    /* LISTA: righe da 44px separate da un filo, niente riquadri. Il nome non si
       taglia mai per primo: prima cede la nota */
    .pzarch { max-width: 1040px; }
    .pzrow { position: relative; display: flex; align-items: center; gap: 10px; min-height: 44px; padding: 0 6px 0 10px;
             border-bottom: 1px solid #EEF2F6; color: #16232E; }
    .pzcoda > .pzrow { grid-column: 1 / -1; display: grid; grid-template-columns: subgrid; gap: 0; justify-items: start; }
    .pzcoda > .pzrow > *, .pzcoda .pzchi > *, .pzcoda .pzchi > .esst > * { grid-row: 1; }
    .pzcoda .pzchi, .pzcoda .pzchi > .esst { display: contents; }
    .pzcoda .pztr { grid-column: tri; }
    .pzcoda .pzapri { grid-column: nm; justify-self: stretch; max-width: 240px; margin-left: 10px; }
    .pzcoda .pzchi > .cuore { grid-column: cuore; margin-left: 10px; }
    .pzcoda .es-lab { grid-column: lab; margin-left: 10px; }
    .pzcoda .es-ecg { grid-column: ecg; margin-left: 4px; }
    .pzcoda .es-img { grid-column: img; margin-left: 4px; }
    .pzcoda .dfslot { display: block; grid-column: df; margin-left: 10px; }
    .pzcoda .dfpslot { display: block; grid-column: post; justify-self: stretch; min-width: 0; margin-left: 8px; overflow: hidden; }
    .pzcoda .dfpslot .dfpost { display: block; }
    .pzcoda .pzrow > .stvisto, .pzcoda .pzrow > .stqui, .pzcoda .pzrow > .sttag { grid-column: visto; justify-self: end; margin-left: 10px; }
    .pzcoda .pzmetti { grid-column: metti; margin-left: 6px; }
    .pzcoda .pzx { grid-column: x; margin-left: 2px; }
    .pzcoda > .pzrow:last-child { border-bottom-color: transparent; }
    .pzunita:not(.edit) .pzrow[data-riga], .pzunita:not(.edit) .pzrow[data-riga] .pzapri { cursor: grab; }
    .pzrow[data-riga] { touch-action: pan-y; }
    .pzrow.via { opacity: .3; }
    /* chi è: il nome (che apre), il promemoria accanto, la nota che cede per prima */
    .pzchi { flex: 1 1 auto; min-width: 0; display: flex; align-items: baseline; gap: 10px; }
    .pzapri { flex: 0 1 auto; min-width: 0; display: flex; align-items: baseline; padding: 0; border: 0; background: none;
              color: inherit; text-align: left; cursor: pointer; }
    .pzapri::after { content: ""; position: absolute; inset: 0; }   /* tutta la riga */
    .pzapri:focus-visible { outline: none; }
    .pzrow:has(.pzapri:focus-visible) { outline-offset: -2px; }
    .pzrow:hover { background: #F7F9FB; }
    .pzrow.qui { background: #F4F8FC; box-shadow: inset 3px 0 0 #0B5CAD; }
    .pzrow.prec { opacity: .55; }
    .pztr { flex: none; width: 4px; height: 22px; border-radius: 2px; background: var(--tr, transparent); }
    .pznm { flex: none; max-width: 100%; overflow: hidden; white-space: nowrap; text-overflow: ellipsis;
            font-size: 14px; font-weight: 600; }
    /* l'icona «Da fare» vuota, come la ✕: compare passandoci sopra */
    .pzrow:not(:hover):not(:focus-within) .dfic.vuota { opacity: 0; }
    /* ▾: metterlo nella stanza senza trascinare. Sempre lì, quieto; il bordo
       sulla riga sotto il mouse */
    .pzmetti { position: relative; z-index: 1; flex: none; display: inline-grid; place-items: center; width: 28px; height: 28px; padding: 0;
               border: 1px solid transparent; border-radius: 6px; background: none; cursor: pointer; color: #8296A9; }
    .pzrow:hover .pzmetti, .pzrow:focus-within .pzmetti { border-color: #E3E8EF; background: #fff; color: #35506B; }
    .pzrow .pzmetti:hover { border-color: #9DBFDE; color: #0B5CAD; }
    .pzx { position: relative; z-index: 1; flex: none; width: 28px; height: 28px; border: 0; border-radius: 6px; background: none; cursor: pointer;
           font-size: 13px; color: #5B6B7A; opacity: 0; }
    .pzrow:hover .pzx, .pzrow:focus-within .pzx { opacity: 1; }
    .pzx:hover { background: #FDF1F0; color: #B3261E; }
    /* colonna stretta: il nome da solo sulla prima riga, sotto il promemoria e
       la nota; «visto…» e «questa pagina» li dice solo la voce (la riga di
       questa pagina è già azzurra) */
    @container pzlista (max-width: 720px) {
      .pzcoda > .pzrow { padding-top: 3px; padding-bottom: 3px; row-gap: 1px; }
      .pzcoda .pzchi > .pzapri { line-height: 20px; }
      .pzcoda .esp { height: 20px; }
      .pzcoda .pzchi > .dfslot .dfic { height: 20px; line-height: 20px; }
      .pzcoda .pzchi > *, .pzcoda .pzchi > .esst > * { grid-row: 2; }
      .pzcoda .pzchi > .pzapri { grid-row: 1; grid-column: nm / visto; max-width: none; }
      .pzcoda .pzchi > .dfpslot { grid-column: post / metti; }
      /* l'icona vuota (compare passandoci sopra) sale accanto al ▾: chi non ha altro resta su una riga */
      .pzcoda .pzchi > .dfslot:has(.dfic.vuota) { grid-row: 1; grid-column: visto; }
      .pzcoda .pztr, .pzcoda .pzmetti, .pzcoda .pzx { grid-row: 1 / 3; }
      .pzrow .stvisto, .pzrow .stqui { position: absolute; width: 1px; height: 1px; overflow: hidden; clip-path: inset(50%); }
    }
    .pzvuoto { padding: 14px 24px; font-size: 13px; color: #5B6B7A; }
    .pzcoda > .pzvuoto { padding: 12px 10px; }
    /* il filtro: compare scrivendo una lettera, Esc lo toglie */
    .pzfiltro { flex: none; display: flex; align-items: center; gap: 8px; height: 36px; margin: 8px 14px 2px; padding: 0 4px 0 10px;
                border: 1px solid transparent; border-radius: 8px; background: #F2F5F8; color: #5B6B7A; max-width: 1040px; }
    .pzfiltro:focus-within { border-color: #0B5CAD; background: #fff; box-shadow: 0 0 0 3px rgba(11,92,173,.12); }
    .pzfiltro svg { flex: none; }
    .pzfiltro input { flex: 1 1 auto; min-width: 0; height: 100%; padding: 0; border: 0; outline: 0; background: none; font-size: 14px; color: #16232E; }
    .pzfiltro input::placeholder { color: #8296A9; }
    .pzfx { position: relative; flex: none; width: 28px; height: 28px; padding: 0; border: 0; border-radius: 6px; background: none; cursor: pointer;
            font-size: 12px; color: #5B6B7A; }
    .pzfx:hover { background: #E3E9F0; color: #16232E; }
    .pzunita.filtra .pzrow.nofiltro { display: none; }
    .pzunita.filtra .starbody .stp.nofiltro, .pzunita.filtra .stbed.nofiltro { opacity: .25; }
    /* portando un paziente dalla stanza: in cima, «Rimetti in lista» (anche a lista vuota) */
    .pzrimetti { position: absolute; left: 12px; right: 12px; top: 6px; z-index: 6; display: flex; align-items: center; justify-content: center; gap: 8px;
                 height: 44px; border: 1.5px dashed #6F9FD0; border-radius: 10px; background: rgba(241,246,252,.97); color: #0B5CAD;
                 font-size: 13px; font-weight: 600; box-shadow: 0 6px 18px rgba(9,42,74,.10); visibility: hidden; opacity: 0; transition: opacity .12s; }
    .pzunita.dastanza .pzrimetti { visibility: visible; opacity: 1; }
    /* senza lista la striscia starebbe sopra i letti in cima: la stanza tiene sempre
       libera quella fascia, così mentre si trascina niente si sposta e niente si copre */
    .pzunita:not(:has(> .pzcoda)) > .stmap:not(.edit) > .stcanvas { padding-top: 50px; }
    .pzrimetti.over { border: 1.5px solid #0B5CAD; background: #E2EEFA; }
    /* in fondo, chiusi: gli archiviati e «Svuota l'elenco», sul grigio della stanza */
    .pzpiede { flex: 0 1 auto; max-height: 40%; overflow-y: auto; padding: 0 14px 4px; background: #F7F9FB; scrollbar-width: thin; }
    .pzarchhd { display: inline-flex; align-items: center; gap: 6px; padding: 6px 4px; border: 0; background: none; cursor: pointer;
                font-size: 13px; font-weight: 600; color: #5B6B7A; }
    .pzarchhd:hover { color: #16232E; }
    .pzarchhd .stn { margin-left: 0; }
    .pzarch { padding-bottom: 8px; }
    .pzarow { display: flex; align-items: center; gap: 10px; min-height: 40px; padding: 0 6px 0 10px; border-bottom: 1px solid #EEF2F6; }
    .pzanm { flex: 1 1 auto; min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; font-size: 13px; color: #5B6B7A; }
    .pzameta { flex: none; font-size: 12px; color: #5B6B7A; }
    .pzabtn { position: relative; flex: none; min-height: 28px; border: 1px solid #D9E2EC; border-radius: 6px; background: #fff; padding: 2px 8px;
              cursor: pointer; font-size: 12px; color: #16232E; }
    .pzabtn:hover { border-color: #9DBFDE; }
    .pzabtn.del:hover { border-color: #E9BAB6; background: #FDF1F0; color: #B3261E; }
    .pzhint { padding: 8px 10px 0; font-size: 12px; color: #5B6B7A; }
    .pzsvuota { margin: 8px 0 0 6px; padding: 6px 4px; border: 0; background: none; cursor: pointer; font-size: 13px; color: #5B6B7A; text-decoration: underline; }
    .pzsvuota:hover { color: #16232E; }

    /* STANZA: tutto lo spazio che la lista lascia */
    .stmap { position: relative; flex: 1 1 0; min-height: 0; display: flex; flex-direction: column; background: #F7F9FB; }
    /* La pianta: celle tutte uguali (--u), le più grandi che ci stanno, fra 20 e
       44px. Tutto si misura in celle: allargando o stringendo la finestra la
       stanza cresce o cala tutta insieme e niente si sovrappone; se non ci sta
       nemmeno a 20px (un nome non si leggerebbe più), scorre. In alto, subito
       sotto la lista: accorciandosi la lista, la stanza sale. */
    .stcanvas { position: relative; flex: 1 1 auto; min-width: 0; min-height: 0; overflow: auto; container-type: size;
                display: grid; place-items: start center; }
    .stcanvas.dx { --sf: linear-gradient(to left, transparent, #000 40px); }
    .stcanvas.sx { --sf: linear-gradient(to right, transparent, #000 40px); }
    .stcanvas.sx.dx { --sf: linear-gradient(to right, transparent, #000 40px, #000 calc(100% - 40px), transparent); }
    .stcanvas.sx, .stcanvas.dx { -webkit-mask-image: var(--sf); mask-image: var(--sf); }
    .stplan { position: relative; --u: clamp(20px, min(100cqw / var(--cols), 100cqh / var(--rows)), 44px);
              width: calc(var(--cols) * var(--u)); height: calc(var(--rows) * var(--u)); }
    /* in Modifica la pianta intera, coi puntini agli angoli delle celle (e un
       margine per la × degli oggetti sul bordo) */
    .stmap.edit .stcanvas { padding: 12px; }
    .stmap.edit .stplan { background-image: radial-gradient(circle, #C4D0DC 1px, transparent 1.5px);
                          background-size: var(--u) var(--u); background-position: calc(var(--u) / -2) calc(var(--u) / -2); }
    /* ogni oggetto sulle sue celle, con un filo d'aria: due letti vicini non si toccano */
    .stbed, .starea { position: absolute; left: calc(var(--c) * var(--u) + 3px); top: calc(var(--r) * var(--u) + 3px);
                      width: calc(var(--w) * var(--u) - 6px); height: calc(var(--h) * var(--u) - 6px); }
    .sthd { display: flex; align-items: baseline; min-width: 0; }
    .stname { min-width: 0; max-width: 100%; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .stmap.edit .stname { cursor: text; border-radius: 4px; }
    .stmap.edit .stname:hover { background: #EEF2F6; box-shadow: 0 0 0 3px #EEF2F6; color: #16232E; }
    /* il paziente: il nome; sotto, «questa pagina» e la nota */
    .stp { position: relative; display: flex; flex-direction: column; gap: 1px; min-width: 0; max-width: 100%; padding: 6px 10px 6px 14px;
           border: 1px solid #D9E2EC; border-radius: 8px; background: #fff; cursor: grab; touch-action: none; transition: border-color .12s; }
    /* il triage: la stessa striscia dappertutto, dentro il bordo (nel letto la porta il letto) */
    .stp.tri::before, .stbed.tri::before { content: ""; position: absolute; left: 4px; top: 8px; bottom: 8px; width: 4px; border-radius: 2px; background: var(--tr); }
    .stp:hover { border-color: #9DBFDE; }
    .stp.qui { border-color: #0B5CAD; }
    .stp1 { display: flex; align-items: baseline; min-width: 0; }
    .stpn { min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; font-size: 14px; font-weight: 600; line-height: 18px; color: #16232E; }
    .stp2 { display: flex; align-items: baseline; gap: 6px; min-width: 0; line-height: 16px; }
    .stp2 .dfpost { flex: 0 1 auto; }
    /* nel letto e nell'area l'icona c'è solo con qualcosa da fare (il menu ha «Da fare…») */
    .stmap .dfic { height: 20px; line-height: 20px; font-size: 11px; padding: 0 6px 0 5px; }
    .stmap .dfic svg { width: 12px; height: 12px; }
    .stmap .dfic.vuota, .stmap.edit .dfic { display: none; }
    .stp1 .dfslot .dfic { margin-left: 6px; }
    .stp1:has(.dfic:not(.vuota)) .stpn { flex: 1 1 auto; }
    .stp.spento { opacity: .55; }
    .stp.prec { cursor: pointer; }
    .stp.via { opacity: .3; }
    /* quello che si porta: il nome e basta, accanto al puntatore, mai sopra quello che si mira */
    .stghost { position: absolute; left: 0; top: 0; z-index: 20; max-width: 220px; padding: 3px 10px; border: 1px solid #9DBFDE; border-radius: 6px;
               background: #fff; box-shadow: 0 8px 20px rgba(9,42,74,.18); font-size: 13px; font-weight: 600; line-height: 18px; color: #16232E;
               white-space: nowrap; overflow: hidden; text-overflow: ellipsis; pointer-events: none; }
    .pzunita.trascino, .pzunita.trascino *, .stmap.trascino, .stmap.trascino * { cursor: grabbing !important; }
    /* il letto: il suo nome, poi il paziente — il nome e l'età, e basta. Il
       cuore e il pallino in alto a destra, sulla riga del letto; il resto nel
       passaggio del mouse. Nel letto piccolo sparisce prima il nome del letto
       (e con lui i segni), mai quello del paziente. Vuoto, è più quieto. */
    .stbed { z-index: 1; container: stbed / size; border: 1px solid #E3E8EF; border-radius: 10px; background: transparent; transition: border-color .12s; }
    .stbed.occ { border-color: #C4D0DC; background: #fff; }
    .stbed.qui { border-color: #0B5CAD; box-shadow: 0 0 0 1px #0B5CAD; }
    .stbed.over { z-index: 4; outline: 2px dashed #0B5CAD; outline-offset: 3px; }
    .stmap:not(.edit) .stbed.occ { cursor: grab; touch-action: none; }
    .stbedin { position: absolute; inset: 6px 8px 6px 14px; display: flex; flex-direction: column; gap: 2px; min-width: 0; overflow: hidden; }
    .stbed .stname { flex: none; font-size: 12px; font-weight: 400; line-height: 16px; color: #5B6B7A; }
    .stbedhd { flex: none; display: flex; align-items: center; min-width: 0; }
    .stbedhd .stname { flex: 0 1 auto; min-width: 0; }
    .stbed.occ .stbedhd { padding-right: 34px; }   /* il posto del cuore e del pallino */
    .stglifo { flex: none; margin: auto; }
    .stbed .stp { position: static; flex: 1 1 auto; min-height: 0; gap: 0; padding: 0; border: 0; border-radius: 0; background: none; }
    /* due righe al massimo, tagliate e basta: mai i puntini (l'età, se non ci sta, resta nel passaggio del mouse) */
    .stbed .stp1 { display: block; max-height: 36px; overflow: hidden; line-height: 18px; overflow-wrap: anywhere; }
    .stbed .stpn { display: inline; overflow: visible; white-space: normal; font-size: 13px; }
    .stbed .steta { font-size: 12px; font-weight: 400; color: #5B6B7A; white-space: nowrap; font-variant-numeric: tabular-nums; }
    .stbed .stsegni { position: absolute; top: 0; right: 0; height: 16px; display: flex; align-items: center; gap: 6px; }
    .stbed .stsegni .cuore { font-size: 13px; }
    .stsegslot { display: inline-flex; }
    /* il pallino: rosso, ambra, blu (nuovo), un cerchio grigio (qualcosa aspetta) */
    .stseg { display: block; width: 8px; height: 8px; border-radius: 50%; }
    .stseg.ros { background: #B3261E; } .stseg.amb { background: #D08A00; } .stseg.nuovo { background: #0B5CAD; }
    .stseg.att { box-shadow: inset 0 0 0 1.5px #8296A9; }
    .stbed.occ:not(:has(.stsegni :is(.cuore, .stseg))) .stbedhd { padding-right: 0; }
    @container stbed (max-height: 62px) {
      .stmap:not(.edit) .stbed.occ .stname, .stbed .stsegni, .stbed:not(.sedia) .stglifo { display: none; }
      .stmap.edit .stbed .stp { display: none; }   /* in Modifica conta il nome del letto */
    }
    /* la sedia: un letto più piccolo, il suo glifo ci sta sempre */
    .stbed.sedia { border-radius: 8px; }
    .stbed.sedia .stbedin { inset: 5px 6px 5px 12px; }
    .stfuori { position: absolute; left: 50%; bottom: -12px; z-index: 3; transform: translateX(-50%); padding: 2px 9px; border-radius: 999px;
               background: #16232E; color: #fff; font-size: 12px; font-weight: 600; white-space: nowrap; pointer-events: none; }
    /* le aree: senza letto, dentro quanti pazienti servono */
    .starea { display: flex; flex-direction: column; border: 1.5px dashed #C4D0DC; border-radius: 12px; background: rgba(255,255,255,.6);
              transition: border-color .12s, background-color .12s; }
    .starea > .sthd { flex: none; padding: 8px 10px 6px; }
    .starea .stname { font-size: 11px; font-weight: 600; letter-spacing: .06em; text-transform: uppercase; color: #5B6B7A; }
    .starea.over { border-color: #0B5CAD; background: #EAF2FA; }
    .starbody { flex: 1 1 auto; min-height: 0; overflow: auto; display: flex; flex-wrap: wrap; align-content: flex-start; gap: 6px; padding: 0 8px 8px; }
    .starbody .stp { max-width: 240px; }
    /* anche nell'area il nome va a capo invece di perdere le lettere (colonna stretta) */
    .starbody .stpn { white-space: normal; overflow-wrap: anywhere; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 2; }
    /* Modifica: i pazienti si fermano; l'oggetto scelto (o sotto il mouse) mostra la × e, l'area, l'angolo */
    .stmap.edit .stp { opacity: .4; pointer-events: none; }
    .stmap.edit .stbed, .stmap.edit .starea { cursor: move; touch-action: none; }
    .stmap.edit .stbed { background: #F7F9FB; }   /* i puntini non passano dentro il letto */
    .stmap.edit .stbed.occ { background: #fff; }
    .stbed.sel, .starea.sel { outline: 2px solid #9DBFDE; outline-offset: 3px; }
    .stbed.drag, .starea.drag { z-index: 5; background: #fff; box-shadow: 0 10px 24px rgba(9,42,74,.16); }
    /* sopra un altro non ci sta: rosso, e lasciato lì torna dov'era */
    .stbed.bad, .starea.bad { outline: 2px solid #B3261E; outline-offset: 2px; }
    .stctl { position: absolute; z-index: 4; width: 24px; height: 24px; padding: 0; border: 1px solid #D9E2EC; border-radius: 50%;
             background: #fff; cursor: pointer; font-size: 13px; line-height: 22px; text-align: center; color: #16232E;
             opacity: 0; pointer-events: none; transition: opacity .12s; }
    .stctl::before, .pzmetti::before, .pzx::before, .pzabtn::before, .stannulla::before { content: ""; position: absolute; inset: -4px; }
    .strsz::before { content: ""; position: absolute; inset: -8px; }
    .stbed:hover > .stctl, .starea:hover > .stctl, .sel > .stctl, .stbed:focus-within > .stctl, .starea:focus-within > .stctl,
    .starea:hover > .strsz, .starea.sel > .strsz { opacity: 1; pointer-events: auto; }
    .stctl:hover { border-color: #9DBFDE; }
    .stx { top: -12px; right: -12px; }
    .stx:hover { border-color: #E9BAB6; background: #FDF1F0; color: #B3261E; }
    .strsz { position: absolute; right: 3px; bottom: 3px; width: 16px; height: 16px; cursor: nwse-resize; touch-action: none; opacity: 0;
             pointer-events: none; transition: opacity .12s;
             background: linear-gradient(135deg, transparent 48%, #C4D0DC 48% 56%, transparent 56% 68%, #C4D0DC 68% 76%, transparent 76%); }
    .strsz:hover { background: linear-gradient(135deg, transparent 48%, #0B5CAD 48% 56%, transparent 56% 68%, #0B5CAD 68% 76%, transparent 76%); }
    .stmap .stnomein { width: 100%; min-width: 56px; height: 24px; padding: 1px 6px; border: 1px solid #9DBFDE; border-radius: 6px;
                       background: #fff; font-size: 13px; color: #16232E; user-select: text; -webkit-user-select: text; }
    /* «Sposta in…» */
    .stmenu { position: absolute; z-index: 30; min-width: 220px; max-width: 300px; max-height: min(72vh, 540px); overflow-y: auto; padding: 4px;
              border: 1px solid #D9E2EC; border-radius: 10px; background: #fff; box-shadow: 0 10px 28px rgba(9,42,74,.16); }
    .stmenuhd { padding: 6px 10px 4px; font-size: 12px; color: #5B6B7A; }
    .stmi { display: flex; align-items: baseline; gap: 12px; width: 100%; min-height: 32px; padding: 6px 10px; border: 0; border-radius: 6px;
            background: none; cursor: pointer; text-align: left; font-size: 13px; color: #16232E; }
    .stmi span { min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .stmi small { flex: none; margin-left: auto; font-size: 12px; color: #5B6B7A; }
    .stmi:hover, .stmi:focus { outline: none; background: #EEF2F6; }
    .stmi:focus-visible { outline: 2px solid #0B5CAD; outline-offset: -2px; }
    .stmi.cur { cursor: default; color: #5B6B7A; }
    .stmsep { height: 1px; margin: 4px 6px; background: #EEF2F6; }
    /* «Annulla», per 8 secondi */
    .stsnack { position: absolute; left: 50%; bottom: 16px; z-index: 25; transform: translateX(-50%); display: flex; align-items: center; gap: 12px;
               max-width: calc(100% - 32px); padding: 6px 6px 6px 14px; border: 1px solid #D9E2EC; border-radius: 10px; background: #fff;
               box-shadow: 0 6px 18px rgba(9,42,74,.12); font-size: 13px; color: #16232E; pointer-events: none; }
    .stsnack span { min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .stannulla { position: relative; flex: none; min-height: 28px; border: 0; border-radius: 6px; background: none; padding: 2px 10px; cursor: pointer; pointer-events: auto;
                 font-size: 13px; font-weight: 600; color: #0B5CAD; }
    .stannulla:hover { background: #EAF2FA; }
    @media (pointer: coarse) {
      .stazioni { height: 40px; }
      .stbtn, .stazioni .stbtn { min-height: 36px; }
      .pzx, .pzrow .dfic.vuota { opacity: 1; }
      .stctl { width: 32px; height: 32px; line-height: 30px; }
      .stx { top: -16px; right: -16px; }
    }
    @media (prefers-reduced-motion: reduce) { .pzunita, .pzunita *, .stazioni * { transition: none !important; } }
  `;

  const LOGO = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M12 5v14M5 12h14" stroke="#fff" stroke-width="3.2" stroke-linecap="round"/>
  </svg>`;

  // il logo sull'intestazione bianca: stessa croce, fondo blu
  const LOGO_BLU = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <rect x="1" y="1" width="22" height="22" rx="6" fill="#0B5CAD"/>
    <path d="M12 6v12M6 12h12" stroke="#fff" stroke-width="3" stroke-linecap="round"/>
  </svg>`;
  // Icone a tratto, 16px, colore del testo: le emoji cambiano faccia da un
  // computer all'altro (il ▶ diventava un quadratino nero).
  const ico = (d) => `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
  const ICO = {
    indietro: ico('<path d="M10 3 5 8l5 5"/>'),
    riduci: ico('<path d="M3.5 8h9"/>'),
    altro: ico('<circle cx="3.5" cy="8" r=".9" fill="currentColor" stroke="none"/><circle cx="8" cy="8" r=".9" fill="currentColor" stroke="none"/><circle cx="12.5" cy="8" r=".9" fill="currentColor" stroke="none"/>'),
    crono: ico('<circle cx="8" cy="9" r="5"/><path d="M8 9V6.5M6.5 2h3M12 4.5l1-1"/>'),
    ferma: ico('<rect x="4.5" y="4.5" width="7" height="7" rx="1.2" fill="currentColor" stroke="none"/>'),
    // la sveglia dei promemoria (il cronometro è un'altra cosa)
    sveglia: ico('<circle cx="8" cy="9" r="5.2"/><path d="M8 6.6V9l1.7 1.1M2.6 4.3l1.9-1.7M13.4 4.3l-1.9-1.7"/>'),
    // «Da fare»: due spunte tonde e le loro righe
    dafare: ico('<circle cx="4" cy="4.5" r="2.2"/><circle cx="4" cy="11.5" r="2.2"/><path d="M8.5 4.5h5.5M8.5 11.5h5.5"/>'),
    stampante: ico('<path d="M4.5 6V2.5h7V6"/><rect x="2" y="6" width="12" height="5.5" rx="1.2"/><path d="M4.5 9.5h7v4h-7z"/>'),
  };

  const RADIO_SET = [RES.RX, RES.ECO, RES.RMN, RES.TAC];
  function rememberQuesito(q) {
    store.set("lastQ", q);
    store.set("quesiti.ts", Date.now());
    const list = store.get("quesiti", QUESITI_DEFAULT);
    const next = [q, ...list.filter((x) => x.toLowerCase() !== q.toLowerCase())].slice(0, 8);
    store.set("quesiti", next);
  }
  // Quesiti are clinical text: they live at most a shift, and the login page
  // (forgetAll) drops them like every other clinical trace.
  function scadenzaQuesiti() {
    const ts = store.get("quesiti.ts", 0);
    if (ts && Date.now() - ts > PATIENTS_TTL) forgetQuesiti();
  }
  function forgetQuesiti() {
    store.set("lastQ", "");
    store.set("quesiti", QUESITI_DEFAULT);
    store.set("quesiti.ts", 0);
  }
  const hasExt = () => { try { return !!(chrome && chrome.runtime && chrome.runtime.id); } catch { return false; } };
  // (nessuna risposta = `perso`: il service worker non l'ha detta, non ha detto di no)
  const ask = (msg) => new Promise((res) => {
    try { chrome.runtime.sendMessage(msg, (r) => { void chrome.runtime.lastError; res(r || { ok: false, perso: true }); }); }
    catch { res({ ok: false, perso: true }); }
  });
  // Solo l'indirizzo di una pagina da LEGGERE di questo ospedale: mai quello di
  // un modulo inviato, di un inserimento o di una cancellazione.
  const leggibilePagina = (x) => {
    try { return !!x && new URL(x).origin === location.origin && !/[?&](ccsForm|Insert|Delete|Update)=/i.test(x); }
    catch { return false; }
  };

  // ------------------------------------------- l'ordine in sottofondo
  // Con l'estensione «Conferma e stampa» non manda gli esami da questa
  // scheda: li manda una seconda scheda, aperta dal service worker accanto e
  // dietro, sulla pagina vera del paziente. Quella scheda, quando nasce, chiede
  // al service worker chi è (per numero di scheda: nell'indirizzo non c'è
  // niente che il gestionale vedrebbe) e, se è lei, fa girare il motore di
  // sempre. LAVORO è quell'ordine, finché gira; null in ogni altra scheda.
  // La scheda dell'ordine esegue e basta: ogni esito — anche quello da finire
  // a mano — lo passa alle schede del medico, poi si slega.
  let LAVORO = null;
  // La pagina del paziente, da riaprire così com'è (la scheda di un ordine, o
  // quella che dà i PDF di una stampa): `prima` se si riapre (non arriva da un
  // modulo), il link della pagina a se stessa, o quello dei pazienti
  // conosciuti. Mai un indirizzo costruito.
  function urlPaziente(ep, prima = "") {
    const ok = (u) => (leggibilePagina(u) && param(u, "EPISODIO_ID") === String(ep) ? u : "");
    const se = [...document.querySelectorAll('a[href*="MVPG=PsoEpisodioClinicoAmbulatorio"]')].map((a) => {
      try { const u = new URL(a.getAttribute("href"), location.href); u.hash = ""; return u; } catch { return null; }
    }).find((u) => u && [...u.searchParams.keys()].every((k) => k === "MVPG" || k === "EPISODIO_ID")
      && u.searchParams.get("MVPG") === "PsoEpisodioClinicoAmbulatorio");
    return ok(prima) || ok(se ? se.href : "") || ok((tuttiPazienti().find((p) => p.ep === String(ep)) || {}).url);
  }
  // quelli che la scheda del medico tiene d'occhio (e per cui chiede al service worker)
  const ORDINE_APERTO = new Set(["coda", "avvio", "corre", "stampo", "stampa"]);

  function freshReceipt(richiestaId) {
    const r = tabStore.get("receipt.v1", null);
    if (!r || !r.items) return null;
    if (Date.now() - (r.ts || 0) > CONFIRM_FLAG_TTL) return null;
    if (richiestaId && r.richiestaId !== richiestaId) return null;
    return r;
  }

  // La finestra aperta: frazioni dello schermo, così segue il browser quando
  // cambia misura. Di partenza al centro, all'85%. Mai più piccola di così,
  // e un pezzo d'intestazione resta sempre a portata di mano.
  const FINESTRA = { x: 0.075, y: 0.075, w: 0.85, h: 0.85 };
  // Su uno schermo grande l'85% è una lenzuolata: di partenza la finestra non
  // supera questa larghezza (sempre al centro). Quella che hai spostato o
  // ridimensionato, e «Affianca», restano come le hai messe.
  const FINESTRA_MAX_PX = 1150;
  const AFFIANCA = { x: 0.63, y: 0.02, w: 0.36, h: 0.96 };   // una colonna a destra: il gestionale resta visibile
  const eAffiancata = (w) => !!w && ["x", "y", "w", "h"].every((k) => Math.abs(w[k] - AFFIANCA[k]) < 0.005);
  const geometriaPropria = (win) => !!win && [win.x, win.y, win.w, win.h].every(Number.isFinite);
  function geometriaFinestra(win) {
    const vw = window.innerWidth || 1000, vh = window.innerHeight || 800;
    const mia = geometriaPropria(win);
    const wMax = Math.min(FINESTRA.w, FINESTRA_MAX_PX / vw);
    const g = mia ? win : { ...FINESTRA, w: wMax, x: (1 - wMax) / 2 };
    const w = Math.min(1, Math.max(380 / vw, g.w)), h = Math.min(1, Math.max(320 / vh, g.h));
    const x = Math.min(Math.max(g.x, 120 / vw - w), 1 - 120 / vw);
    const y = Math.min(Math.max(g.y, 0), 1 - 44 / vh);
    return { x, y, w, h };
  }

  class Panel {
    constructor(pageType) {
      this.pageType = pageType;
      this.selected = new Map(); // "res:code" -> {res, code, label}
      this.pacchetto = "";       // il quesito-pacchetto attivo («Dispnea»), o ""
      this.pkgDa = new Set();    // gli esami che ha messo LUI (non quelli scelti a mano)
      // il quesito l'ha scritto il medico, a mano, nella casella: allora vale
      // il suo anche sopra quello del triage. Un chip o un pacchetto no.
      this.quesitoMio = false;
      this.aggiungi = false;     // sulla ricevuta: la griglia degli esami aperta con «+ aggiungi»
      this.tieneDopoErrore = null; // dopo un errore: le chiavi degli esami che mancano davvero
      const saved = tabStore.get("log." + (findEpisodeId(document, location.href) || "x"), null);
      this.logLines = saved && Date.now() - (saved.ts || 0) < 2 * 3600e3 ? saved.lines || [] : [];
      this.runState = null; // null | 'running' | 'done' | 'fail' | 'stopped'
      this.runData = null;
      this.message = null;  // string (inline) or {head, body} (result banner)
      this.stopFn = null;
      this.host = document.createElement("div");
      this.host.id = "psassist-host";
      this.root = this.host.attachShadow({ mode: "open" });
      document.documentElement.appendChild(this.host);
      // Aperto o ridotto, a ogni pagina. Il gestionale ricarica la pagina a
      // ogni clic: se ci è arrivato il medico dal gestionale voleva VEDERE il
      // gestionale, e la finestra all'85% glielo coprirebbe — si parte dalla
      // pill. Se ce l'ha portato il pannello (un paziente scelto qui, la fine
      // di un giro), si parte aperti.
      const daPannello = Date.now() - (Number(tabStore.get("navPannello.v1", 0)) || 0) < 30e3;
      tabStore.set("navPannello.v1", 0);
      this.collapsed = !daPannello;
      this.menuAperto = false;   // il menu «⋯» dell'intestazione
      this.avvisoPill = "";      // una parola sulla pill, per pochi secondi («✓ Copiato · incolla»)
      // Che cosa sta succedendo fuori dalla finestra — conferma, etichette,
      // un errore da finire a mano — detto dalla striscia nell'angolo:
      // {tag, testo, tono: ok|run|warn|err, badge?, paziente?, onTap?, onStop?}
      this.striscia = null;
      // Gli ordini che girano nelle schede di sottofondo (dal service worker):
      // ogni scheda del gestionale ne mostra la striscia.
      this.ordini = [];
      this._lavoroChiuso = false;   // la scheda di sottofondo ha già detto l'ultima parola
      // la stampa automatica, dalla memoria dell'estensione: { s: { attiva, etichette, a4 }, esito }
      this.stampaAuto = null;
      this.acq = "";           // catalog search text
      this.esiti = [];                  // risultati + referti, newest first
      this.storico = null;              // the portal's multi-day table, if it is THIS patient's
      this.storicoAltri = "";           // ...or the name it belongs to, when it is not
      this.storicoVia = "dal nome";     // su cosa è stata confermata l'identità
      this.storicoDaConfermare = false; // c'è, ma serve il codice fiscale per dire che è suo
      this.portale = "";                // indirizzo del portale aggiunto dal medico
      this.soloAlterati = false;        // valori: show only what is out of range
      this.nColEsiti = 0;               // colonne della tabella degli Esiti: decide la larghezza
      this.mostraNomi = false;          // the unexpected-name list, open or closed
      this.mostraArch = false;          // l'elenco degli archiviati, aperto o chiuso
      this.rottiTab = new Set();        // prelievi che hanno già fallito: niente ritentativi da soli
      // La finestra aperta e la pill ridotta vivono in due posti diversi: la
      // finestra (frazioni dello schermo, così segue il browser che cambia
      // misura) parte al centro e prende l'85%; la pill resta dove la metti.
      this.win = store.get("win.v1", null);       // {x, y, w, h} in frazioni dello schermo
      this.pillPos = store.get("pillpos.v1", null); // {left, top} in px
      this.runPatient = null;           // patient name PINNED when a run starts
      this.episodeId = findEpisodeId(document, location.href);
      this.view = null;                 // home | richieste | esiti | valori
      this.viewId = null;               // which esito is open in 'valori'
      // The header must always show the patient this page belongs to: follow
      // any <title> change (the EHR sets it to the patient name).
      const titleEl = document.querySelector("title");
      if (titleEl) {
        this._titleObs = new MutationObserver(() => {
          // mai ricostruire una schermata in cui si sta scrivendo
          const scrive = ["dfin", "riffiltro"].includes(this.root.activeElement?.id);
          if (this.runState !== "running" && !scrive
              && this.view !== "dimtesto" && this.view !== "dimimport" && this.view !== "eotesto") this.render();
        });
        this._titleObs.observe(titleEl, { childList: true, characterData: true, subtree: true });
      }
      // the portal page is another tab: coming back here is the moment to look
    // for a table read in the meantime
    // (e i promemoria rifanno i conti: in una scheda nascosta il tempo non si aggiorna)
    this._visibile = () => {
      if (document.hidden) return;
      this.promTick();
      if (this.pageType === "patient") this.caricaStorico();
    };
    document.addEventListener("visibilitychange", this._visibile);
    this._unload = (e) => { e.preventDefault(); e.returnValue = ""; };
      this._esc = (e) => {
        if (e.key !== "Escape") return;
        if (this.escLocale && this.escLocale()) {   // la stanza lo usa per sé (menu, trascinamento)
          // la lista «Da fare» aperta, col fuoco altrove: Esc chiude lei, non la finestra
          const d = this._df;
          if (d?.pop?.isConnected && !this._dfPresa && !(e.composedPath ? e.composedPath() : []).includes(d.pop)) { e.preventDefault(); this.dfChiudi(true); }
          return;
        }
        // una stampa in corso (Esc la annulla) e il conto alla rovescia della conferma: l'Esc è loro
        if (document.getElementById("psassist-print") || document.getElementById("psassist-confirm") || document.getElementById("psassist-visore")) return;
        // Solo col pannello aperto: da quando il giro va in sottofondo, un Esc
        // dato al gestionale (una tendina, un campo) non deve fermare gli
        // esami. Dalla striscia si ferma col quadratino rosso.
        if (this.runState === "running" && !this.collapsed) return this.stop();
        if (this.collapsed || this.runState) return;
        // Altrimenti Esc riduce la finestra alla pill — ma solo se viene dal
        // pannello (o da nessuna parte: la finestra copre la pagina), e mai
        // da un campo in cui si sta scrivendo: lì Esc è del campo.
        const via = e.composedPath ? e.composedPath() : [];
        const dentro = via.includes(this.host);
        const t = via[0];
        if (!dentro && t && t !== document.body && t !== document.documentElement && t !== document) return;
        if (t && /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName || "")) return;
        e.preventDefault();
        if (this.menuAperto) { this.menuAperto = false; this.render(); return; }
        if (this.stanzaEdit) { this.stanzaEdit = false; this.render(); return; }
        this.riduci();
      };
      window.addEventListener("keydown", this._esc, true);
      // Un clic FUORI dalla finestra (sul gestionale che si vede ai bordi) la
      // riduce alla pill: il clic intanto arriva alla pagina, non si ferma.
      // Dentro la finestra, un clic fuori dal menu «⋯» lo chiude.
      this._fuori = (e) => {
        const via = e.composedPath ? e.composedPath() : [];
        if (via.includes(this.host)) {
          if (this.menuAperto && !via.some((x) => x.classList && x.classList.contains("menuw"))) { this.menuAperto = false; this.render(); }
          return;
        }
        if (this.collapsed || this.runState === "running") return;
        if (via.some((x) => x.id === "psassist-print" || x.id === "psassist-confirm" || x.id === "psassist-visore")) return;   // le nostre finestre: stampa, conferma, visore
        this.riduci();
      };
      window.addEventListener("pointerdown", this._fuori, true);
      // il fuoco sopravvive al ridisegno: dopo ogni azione resta dov'era
      this.root.addEventListener("focusin", (e) => { const id = e.target && e.target.id; if (id) this._fuocoId = id; });
      // I promemoria: un tocco sulla pill apre il suo elenco, la sveglia apre
      // il campo. Ogni 30 secondi le pill rifanno i conti, sul posto.
      this.root.addEventListener("click", (e) => this.promClic(e));
      this.root.addEventListener("keydown", (e) => {
        const segno = e.target.closest?.("[data-prurg]");
        if (segno && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); e.stopPropagation(); this.promClic({ target: segno }); }
      });
      this._promOgni = setInterval(() => this.promTick(), 30e3);
    }

    // ---- cross-page continuity -------------------------------------------
    // The EHR reloads the page at every click (that's the app, not us). To
    // make the panel FEEL persistent, its working state — quesito, selected
    // exams, open sections — is saved per (tab,
    // episode) and restored on the next page of the SAME patient. A page of
    // another episode restores nothing.
    uiKey() { return this.episodeId ? `ui.${this.episodeId}` : null; }
    // the view is per (tab, episode) like the rest of the working state
    refKey() { return "refopen." + (this.episodeId || "x"); }
    risKey(id) { return `ris.${this.episodeId || "x"}.${id}`; }
    // what this draw looked like the last time the doctor actually looked at it
    vistoKey(id) { return `visto.${this.episodeId || "x"}.${id}`; }
    segnaVisto(id, rows) {
      const vals = {};
      for (const r of rows || []) { const k = valKey(r.nome); if (k) vals[k] = String(r.valore); }
      tabStore.set(this.vistoKey(id), { ts: Date.now(), vals });
    }
    // key → "nuovo" (analyte that was not there) | "cambiato" (value moved
    // since the last look). Empty until there IS a previous look: the first
    // read of a draw is the baseline, never a wall of marks.
    novita(id, rows) {
      const out = new Map();
      const seen = tabStore.get(this.vistoKey(id), null);
      if (!seen || !seen.vals) return out;
      for (const r of rows || []) {
        const k = valKey(r.nome);
        if (!k) continue;
        if (!(k in seen.vals)) out.set(k, "nuovo");
        else if (seen.vals[k] !== String(r.valore)) out.set(k, "cambiato");
      }
      return out;
    }
    setView(v, id, nota) {
      // a banner belongs to the screen that raised it: changing screen clears
      // it, unless this navigation is itself carrying the answer
      this.message = nota || null;
      this.view = v; this.viewId = id || null; this.persistUi(); this.render();
      if (v === "esiti") this.caricaStorico();   // letto sul portale intanto? e l'identità è cambiata?
    }
    // Il cronometro si vede da ogni schermata MENTRE corre, altrimenti ci si
    // dimentica di fermarlo — ed è l'unica cosa che lo rende utile. Un tocco sul
    // tempo apre la scheda, un tocco su ⏹ lo ferma: fermarlo non deve costare
    // due passaggi. Fermo non occupa posto: «Tempi» sta nel menu ⋯.
    chipTempo() {
      const t = tempoInCorso();
      if (!t) return "";
      return `<span class="tchip on"><button id="tapri" title="${esc(t.titolo)}${t.paz ? " · " + esc(t.paz) : ""} — apri i tempi"><i class="tdot"></i>${esc(mmss(durata(t)))}</button><button id="tstop" title="Ferma il cronometro" aria-label="Ferma il cronometro">${ICO.ferma}</button></span>`;
    }
    // La stampa automatica: le due stampanti scelte (allora si può accendere e spegnere)…
    stampaPronta() {
      const s = this.stampaAuto && this.stampaAuto.s;
      return !!(s && s.etichette && s.a4);
    }
    // …e, accesa, una stampantina in intestazione che dice dove vanno i fogli —
    // rossa se l'ultimo non è uscito (o non si sa), e «non installata» se
    // l'aiutante non c'è più. Un tocco apre le impostazioni.
    chipStampa() {
      if (!this.stampaPronta() || this.stampaAuto.s.attiva === false) return "";
      const { s, esito } = this.stampaAuto;
      const ko = !!esito && esito.ok === false;
      const titolo = esito && esito.nonInstallata ? `Stampa automatica non installata: ${esito.why}`
        : `Stampa automatica attiva: etichette su ${s.etichette}, A4 su ${s.a4}${ko ? ` · l'ultima stampa ${esito.esito === "sconosciuto" ? "ha un esito sconosciuto" : "non è uscita"}: ${esito.why}` : ""}`;
      const no = !!esito && !!esito.nonInstallata;
      return `<button class="iconbtn stauto${ko ? " ko" : ""}${no ? " no" : ""}" id="stauto" title="${esc(titolo)}" aria-label="${esc(titolo)}">${ICO.stampante}${no ? "non installata" : ""}</button>`;
    }
    // Le scelte stanno nella memoria dell'estensione: si leggono e si seguono
    // (cambiano dalle impostazioni, dal menu ⋯, e a ogni stampa automatica).
    // Cambia solo la stampantina, al suo posto: niente ridisegno sopra chi scrive.
    seguiStampa() {
      const leggi = () => chrome.storage.local.get(["stampa", "stampaEsito"]).then((o) => {
        this.stampaAuto = { s: o.stampa || null, esito: o.stampaEsito || null };
        const w = this.root.querySelector("#stautow");
        if (w) w.innerHTML = this.chipStampa();
      }).catch(() => {});
      try {
        leggi();
        chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && (ch.stampa || ch.stampaEsito)) leggi(); });
        // l'aiutante c'è ancora? (al più ogni mezz'ora lo chiede il service worker)
        ask({ t: "stampaVerifica" });
      } catch { /* senza la memoria dell'estensione la stampa automatica non c'è: il pannello sì */ }
    }
    // ⋯ → Registra (registra.js): finché registra, «● REC» sulla pill e in
    // intestazione; il menu dice Registra, Ferma e scarica, o Scarica.
    chipRec() {
      const r = this.reg;
      return r && r.stato === "rec" && Date.now() < r.scade ? `<span class="recchip" title="Registrazione in corso: ⋯ → Ferma e scarica">● REC</span>` : "";
    }
    seguiRec() {
      const leggi = () => chrome.storage.local.get("registra").then((o) => {
        const prima = this.chipRec();
        this.reg = o.registra || null;
        if (this.chipRec() !== prima) this.render();
      }).catch(() => {});
      try { leggi(); chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.registra) leggi(); }); } catch { /* niente */ }
    }
    async apriStampanti() {
      this.menuAperto = false;
      const r = await ask({ t: "apriImpostazioni" });
      if (!(r && r.ok)) this.message = "Non riesco ad aprire le impostazioni: aprile da chrome://extensions → PS Assist → Dettagli → Opzioni.";
      this.render();
    }

    // the inline banner: a string is something that went wrong, {ok} is a
    // confirmation. Every view shows it — the panel always answers.
    notaHtml() {
      const m = this.message;
      if (this.runState) return "";
      if (typeof m === "string" && m) return `<div class="banner warn">${esc(m)}</div>`;
      if (m && typeof m.ok === "string") return `<div class="banner ok">${esc(m.ok)}</div>`;
      return "";
    }
    marcaLetto(id) {
      const held = tabStore.get(this.risKey(id), null);
      if (held && held.rows) this.segnaVisto(id, held.rows);
    }
    // Aprire un paziente vuol dire quasi sempre GUARDARE: si atterra sugli
    // Esiti. Ordinare è un tocco più in là (Richieste resta in cima), e chi
    // arriva da una scheda del pannello sceglie già dove andare.
    defaultView() {
      if (this.pageType !== "patient") return "richieste";
      // senza i link per ordinare non è la scheda di un paziente ma la lista
      // del pronto soccorso: lì si mostra l'elenco dei pazienti
      return this.entry && (this.entry.labUrl || this.entry.radioUrl) ? "esiti" : "home";
    }
    persistUi() {
      const k = this.uiKey();
      if (!k) return;
      tabStore.set(k, {
        q: this._q || "",
        qMio: !!this.quesitoMio,
        qrx: this._qrx || "",
        sel: [...this.selected.values()].map((i) => [i.res, i.code, i.label]),
        acq: this.acq || "",
        eoSel: this.eoSel || "",
        pk: this.pacchetto || "",
        pkDa: [...this.pkgDa],
        ts: Date.now(),
      });
    }
    applyAfterNav() {
      const a = tabStore.get("afterNav.v1", null);
      if (!a || a.ep !== this.episodeId || Date.now() - (a.ts || 0) > 60e3) return;
      tabStore.set("afterNav.v1", null);
      this.view = a.view; this.viewId = null; this.persistUi();
    }

    restoreUi() {
      const k = this.uiKey();
      const s = k ? tabStore.get(k, null) : null;
      if (!s || Date.now() - (s.ts || 0) > 6 * 3600e3) {
        this._q = store.get("lastQ", "") || ""; // keep the last quesito typed
        this.quesitoMio = false;   // l'ultimo quesito di un altro giro: non scritto per questo paziente
        this._qrx = "";
        this.view = this.defaultView() === "home" ? "home" : (this.view || this.defaultView());
        return;
      }
      this._q = s.q || store.get("lastQ", "") || "";
      this.quesitoMio = !!(s.q && s.qMio);
      this._qrx = s.qrx || "";
      this.eoSel = s.eoSel || "";
      this.selected = new Map((s.sel || []).map(([res, code, label]) => [this.key(res, code), { res, code, label, display: displayLabel(res, code) }]));
      // il gestionale ricarica a ogni click: il pacchetto attivo e gli esami
      // che ha messo restano com'erano
      this.pacchetto = PACCHETTI.some((p) => p.q === s.pk) ? s.pk : "";
      this.pkgDa = new Set(this.pacchetto ? (s.pkDa || []).filter((k) => this.selected.has(k)) : []);
      this.acq = s.acq || "";
      // A page load decides the view, not the stored one: opening a patient
      // lands on Esiti — quello che si va a fare, nove volte su dieci, è
      // guardare — e chi arriva da una scheda del pannello ha già scelto lui
      // dove andare (afterNav decide subito dopo).
      // (The ER worklist stays on the patient list either way.)
      this.view = this.defaultView();
      this.viewId = null;
    }
    clearOrderUi() { // after a successful run the order is placed: start clean
      this._q = "";
      this.quesitoMio = false;
      this._qrx = "";
      this.selected.clear();
      this.pacchetto = ""; this.pkgDa.clear();
      this.persistUi();
    }

    // ---- selection ----
    key(res, code) { return `${res}:${code}`; }
    isSel(res, code) { return this.selected.has(this.key(res, code)); }
    toggle(res, code) {
      if (this.acq) this.acFocus = true; // stay in the search box
      const k = this.key(res, code);
      this.pkgDa.delete(k);   // toccato a mano: da qui in poi è tuo, non del pacchetto
      if (this.selected.has(k)) this.selected.delete(k);
      else this.selected.set(k, { res, code, label: examLabel(res, code), display: displayLabel(res, code) });
      this.persistUi();
      this.render();
    }
    togglePreset(p) {
      const items = p.items;
      const allOn = items.every(([r, c]) => this.isSel(r, c));
      for (const [r, c] of items) {
        const k = this.key(r, c);
        this.pkgDa.delete(k);   // toccato a mano: non è più del pacchetto
        if (allOn) this.selected.delete(k);
        else this.selected.set(k, { res: r, code: c, label: examLabel(r, c), display: displayLabel(r, c) });
      }
      this.persistUi();
      this.render();
    }

    // ---- quesito = pacchetto di esami ----
    // Un chip-pacchetto scrive il quesito E spunta il suo pacchetto. Si
    // ricorda quali esami ha messo LUI (pkgDa): cambiando pacchetto, o
    // toccando di nuovo il chip, se ne vanno solo quelli — gli esami che c'erano
    // già (scelti a mano, o di un profilo) restano. Un chip normale scrive solo
    // il quesito, come sempre; se c'era un pacchetto lo lascia andare e i suoi
    // esami restano, ora «a mano».
    pacchettoDi(q) {
      const t = String(q || "").trim().toLowerCase();
      return PACCHETTI.find((p) => p.q.toLowerCase() === t) || null;
    }
    scegliQuesito(q) {
      const p = this.pacchettoDi(q);
      const prima = this.pkgDa;
      let mancano = [];
      this.quesitoMio = false;   // l'ha scritto un chip, non il medico: il triage resta
      if (!p) {
        this._q = q;
        this.pacchetto = ""; this.pkgDa = new Set();
      } else if (this.pacchetto === p.q) {
        // di nuovo il pacchetto attivo: via quesito e pacchetto
        for (const k of prima) this.selected.delete(k);
        this._q = ""; this.pacchetto = ""; this.pkgDa = new Set();
      } else {
        const cat = fullCatalog();
        const nuovo = new Set();
        for (const [r, c] of p.items) {
          const k = this.key(r, c);
          if (!cat[r]?.items?.[c]) { mancano.push(DISPLAY[k] || `esame ${c} (${RES_SHORT[r] || r})`); continue; }
          if (!this.selected.has(k)) {
            this.selected.set(k, { res: r, code: c, label: examLabel(r, c), display: displayLabel(r, c) });
            nuovo.add(k);
          } else if (prima.has(k)) nuovo.add(k);   // lo aveva messo il pacchetto di prima: resta del pacchetto
        }
        for (const k of prima) if (!nuovo.has(k)) this.selected.delete(k);
        this.pacchetto = p.q; this.pkgDa = nuovo; this._q = p.q;
      }
      // quello che manca dal catalogo si dice una volta sola, qui e nel Registro
      if (mancano.length) {
        const nota = `«${p.q}»: non ho aggiunto ${mancano.join(", ")} — ${mancano.length === 1 ? "non è" : "non sono"} nel catalogo di questo computer.`;
        this.log(`${now()}  ${nota}`);
        this.message = this._notaPk = nota;
      } else if (this._notaPk && this.message === this._notaPk) { this.message = null; this._notaPk = ""; }
      this.persistUi();
      this.render();
    }

    log(line) {
      this.logLines.push(line);
      if (this.logLines.length > 200) this.logLines.shift();
      tabStore.set("log." + (this.episodeId || "x"), { ts: Date.now(), lines: this.logLines });
      const el = this.root.querySelector(".log");
      if (el) { el.textContent = this.logLines.join("\n"); el.scrollTop = el.scrollHeight; }
    }

    // La striscia dice a che punto è, due righe: chi (e cosa) sopra, il
    // momento sotto. Con `ms` se ne va da sola, e `poi` dice cosa resta.
    segnala(s, { ms = 0, poi = null } = {}) {
      clearTimeout(this._tStriscia);
      this.striscia = s ? { ...s } : null;
      if (s && ms) {
        const mia = this.striscia;
        this._tStriscia = setTimeout(() => {
          if (this.striscia !== mia) return;
          this.striscia = null;
          poi?.();
          this.render();
        }, ms);
      }
      // a finestra aperta la striscia non si vede: niente ridisegno (si
      // starebbe magari scrivendo in un campo)
      if (this.collapsed) this.render();
    }
    // finito tutto (stampato): la pill torna quella di sempre
    chiudiGiro() {
      if (this.runState !== "done") return;
      this.runState = null; this.runData = null; this.message = null;
    }

    // ---- engine callbacks ----
    beginRun(state, plan) {
      // a chained second richiesta keeps the first one's steps on screen
      if (plan && plan.continuation && this.runData && this.runData.steps) state.steps.unshift(...this.runData.steps);
      this.runState = "running"; this.runData = state; this.stopFn = state.stop;
      this.pianoGiro = plan || null; this._lavoroChiuso = false;
      clearTimeout(this._tStriscia); this.striscia = null;
      // un salto di pagina deciso dal giro di prima non parte più sopra questo
      clearTimeout(this._tVai); clearTimeout(this._tRiprendi);
      this.carrelloDaAprire = null;
      this.riprova = null; this.consegnaErrore = null; this.tieneDopoErrore = null;
      this.aggiungi = false; this._daconf = null;
      this.runRipreso = !!(plan && plan.startPage === "ripresa");
      // Il giro sopravvive al cambio pagina: riprende da dov'era. Si avvisa
      // prima di uscire solo dove riprendere non si può — le catene
      // lab+radiologia, e il bookmarklet, che va ricliccato a mano.
      if (!plan || !plan.riprendibile || !hasExt()) window.addEventListener("beforeunload", this._unload);
      // …e intanto il pannello si fa piccolo: una striscia in un angolo che
      // dice a che punto è, e il gestionale resta tutto tuo. La preferenza del
      // medico NON si tocca (niente store.set): finito il giro torna com'era.
      // Solo per i giri che possono andare in sottofondo: una catena
      // lab+radiologia resta sotto gli occhi, come è sempre stata.
      if (plan && plan.riprendibile) this.collapsed = true;
      this.render();
    }
    renderRun(state) { this.runData = state; this.render(); }
    finished(state, plan) {
      // quello che è entrato in carrello, per lo stato degli esami (riga dei Pazienti, Dimissioni)
      segnaOrdineNostro((plan && plan.episodeId) || this.episodeId, state.richiestaId, state.added);
      if (plan.hold) { this.runData = state; this.render(); return; } // the chain finishes for us
      window.removeEventListener("beforeunload", this._unload);
      // L'ordine è partito: la prossima pagina riparte pulita. Ma se il giro
      // era di un ALTRO paziente (ripreso mentre guardavi altro), il quesito e
      // gli esami che stai spuntando qui non si toccano.
      if (!plan || !plan.episodeId || plan.episodeId === this.episodeId) this.clearOrderUi();
      this.runState = "done"; this.runData = state;
      const n = state.added.length;
      // (quale quesito è partito lo dice la sua riga, sotto: viewResult)
      this.message = {
        head: `✓ ${n} ${n === 1 ? "esame" : "esami"} in carrello, ${n === 1 ? "verificato" : "verificati"}`,
        body: "",
      };
      // In sottofondo la finestra non si apre mai da sola: dalla spedizione
      // alle etichette parla la striscia, e un tocco la apre con la ricevuta.
      // (Solo la catena lab+radiologia, plan.hold, resta sotto gli occhi.)
      this.cartTag = `✓ ${n} ${n === 1 ? "esame" : "esami"} in carrello`;
      const daConfermare = !!tabStore.get("confirm.v1", null);
      this.segnala({ tag: this.cartTag, tono: daConfermare ? "run" : "ok", quesito: quesitoDetto(state.quesito),
        testo: daConfermare ? "Confermo…" : plan.startPage === "ripresa" ? "Il carrello è pronto: aprilo quando vuoi" : "Apro il carrello…" });
      this.render();
      if (state.finishedListUrl) this.chiudiRichiesta(state.finishedListUrl, plan, state);
    }

    // «Svuota» dalla riga di una richiesta da confermare: il carrello è vuoto,
    // provato, e la richiesta dimenticata. La pagina si rilegge (una lettura,
    // l'elenco pulito) per mostrare il carrello vero, e la striscia lo dice.
    svuotato(state, plan) {
      window.removeEventListener("beforeunload", this._unload);
      this.runState = null; this.runData = null; this.message = null;
      const n = (state.inCarrello || []).length;
      const str = { tag: "Carrello svuotato", testo: `${n === 1 ? "1 esame tolto" : `${n} esami tolti`} · niente da confermare`,
        tono: "ok", paziente: this.runPatient || plan.patientName || "" };
      this.segnala(str);
      this.render();
      const u = state.finishedListUrl;
      if (leggibilePagina(u)) this.vaiSeLibero(u, { striscia: str, prima: () => tabStore.set(AVVISO, { ts: Date.now(), striscia: str }) });
    }

    // OGNI navigazione decisa dal programma passa di qui. Se il medico sta
    // scrivendo nel gestionale (cursore in un campo, un campo cambiato, un
    // tasto da meno di 15 secondi) non si va: la pill dice «… · tocca per il
    // carrello» e un tocco ci porta. `prima` scrive il passaggio di consegne
    // per la pagina dopo, nell'istante in cui si parte davvero (se non si
    // riesce a scriverlo, non si parte).
    vaiSeLibero(url, { striscia = null, prima = null, ms = 300 } = {}) {
      const vai = () => { if (prima && prima() === false) return; nav(url); };
      const aspetta = (perche) => {
        this.log(`${now()}  non cambio pagina da solo: ${perche} — un tocco sulla striscia apre il carrello`);
        this.carrelloDaAprire = vai;   // a finestra aperta: il bottone «Apri il carrello»
        const s = striscia || this.striscia || { tag: "", tono: "warn" };
        this.segnala({ ...s, testo: `${s.testo ? s.testo + " · " : ""}tocca per il carrello`, titolo: "tocca per il carrello", onTap: vai, onStop: null });
      };
      const ora = staScrivendo();
      if (ora) { aspetta(ora); return false; }
      // il cronometro si tiene: un giro che parte intanto lo spegne (beginRun)
      clearTimeout(this._tVai);
      this._tVai = setTimeout(() => {
        const poi = staScrivendo();   // nel frattempo ha cominciato a scrivere?
        if (poi) aspetta(poi); else vai();
      }, ms);
      return true;
    }

    // Le richieste di questo episodio mandate e mai viste confermate: dopo 2
    // minuti la pill lo dice, ambra, e un tocco apre il loro carrello. Si
    // guarda solo la pagina che il medico ha davanti — al server non si chiede
    // niente — e sul carrello di quella stessa richiesta non si dice (ci sei).
    sorvegliaConferme(appenaAperta = false) {
      clearTimeout(this._tConferme);
      const sua = param(location.href, "RICHIESTA_ID");
      const x = nonConfermateQui().find((r) => r.rid !== sua);
      if (!x) return;
      const manca = x.ts + attesaConferma() - Date.now();
      const occupata = this.runState === "running" || (this.striscia && (this.striscia.tono === "err" || this.striscia.tono === "run" || this.striscia.daStampa));
      if (manca > 0 || occupata) { this._tConferme = setTimeout(() => this.sorvegliaConferme(), Math.max(manca, 0) + (occupata ? 20e3 : 50)); return; }
      let u = "";
      try { u = new URL(x.listUrl).origin === location.origin && !/[?&](Insert|Delete)=/.test(x.listUrl) ? x.listUrl : ""; } catch { u = ""; }
      this.log(`${now()}  la richiesta ${x.rid} delle ${hhmm(x.ts)} non risulta confermata`);
      if (appenaAperta) this.collapsed = true;   // la pagina appena aperta: l'avviso si vede subito
      this.segnala({ tag: "Non confermata", tono: "warn", titolo: "tocca per il carrello",
        testo: `Richiesta ${hhmm(x.ts)} non confermata · tocca per il carrello`,
        onTap: () => (u ? nav(u) : this.apri()) });
    }

    // Ultimo passo: la conferma. Si prova a farla in sottofondo — la pagina
    // del carrello caricata davvero, in una cornice invisibile, col suo
    // bottone premuto davvero. Se il server non si lascia incorniciare, o se
    // un controllo dice di no, si va sulla pagina come si è sempre fatto: lì
    // il medico vede tutto e decide lui. Ogni pagina dopo ci arriva con la
    // striscia (AVVISO), mai con la finestra.
    async chiudiRichiesta(listUrl, plan, state) {
      const daConfermare = !!tabStore.get("confirm.v1", null);
      const tag = this.cartTag || "";
      const ep = plan?.episodeId || this.episodeId;
      const rid = state?.richiestaId || param(listUrl, "RICHIESTA_ID");
      const n = state?.added?.length || 0;
      const chi = this.runPatient || "";
      const quesito = quesitoDetto(state?.quesito);   // quale è partito: una riga nella striscia finale
      const consegna = (striscia, testo) => tabStore.set(AVVISO, {
        ts: Date.now(), striscia: { paziente: chi, ...striscia }, ...(testo ? { testo } : {}),
      });
      // Nella scheda di un ordine quello che resta da fare a mano non si fa
      // qui: lo stesso passaggio di consegne va alle schede del medico, dove
      // un tocco apre il carrello (con la ricevuta). Questa scheda si slega.
      const alMedico = (vista, striscia, testo) => this.consegnaLavoro(
        { ...vista, ...(vista.tono === "ok" && quesito ? { quesito } : {}) },
        { url: listUrl, avviso: { striscia: { paziente: chi, ...striscia }, ...(testo ? { testo } : {}) }, receipt: tabStore.get("receipt.v1", null) });
      // da qui la richiesta è da confermare: finché una pagina del paziente
      // non la mostra confermata, la si tiene d'occhio (solo numeri)
      ricordaDaConfermare(rid, ep, listUrl, n);
      if (!daConfermare) {
        if (LAVORO) {
          return alMedico({ tag, testo: "Conferma dal gestionale", tono: "ok" },
            { tag, testo: "Conferma dal gestionale", tono: "ok", quesito });
        }
        // Un giro ripreso vuol dire che stavi facendo altro: la pagina non te
        // la porto via. Il carrello è pronto, ci vai col bottone.
        if (plan && plan.startPage === "ripresa") {
          this.message = { head: this.message?.head || "", body: "Il carrello è pronto: aprilo quando vuoi." };
          this.render();
          return;
        }
        // Revisione: si va sul carrello, e lì la Conferma è quella del
        // gestionale (il suo clic arma comunque la stampa delle etichette).
        const str = daConfermare ? { tag, testo: "Confermo…", tono: "run", attesaConferma: true }
          : { tag, testo: "Conferma dal gestionale", tono: "ok", quesito };
        this.vaiSeLibero(listUrl, { ms: 400, striscia: daConfermare ? { tag, testo: "Conferma da fare", tono: "warn" } : str,
          prima: () => { consegna(str); } });
        return;
      }
      this.message = { head: this.message?.head || "", body: "Confermo in sottofondo…" };
      this.render();
      let esito = "rifiutata";
      if (LAVORO) {
        // La scheda di un ordine non usa la cornice: è già lei la pagina che
        // nessuno guarda. Va sul carrello e lì preme la Conferma vera (la
        // strada di quando il server non si lascia incorniciare, qui sotto).
        // Una cornice dentro una scheda nascosta Chrome la carica col
        // contagocce, e scadeva prima che il server avesse finito.
        this.log(`${now()}  conferma: vado sul carrello e premo lì Conferma`);
      } else {
        // Se la pagina se ne va mentre la cornice lavora, la conferma automatica
        // muore con lei: non deve ripartire da sola più tardi, su un carrello
        // aperto a mano. Resta il segno qui sopra, e la pill lo dirà.
        const abbandona = () => tabStore.set("confirm.v1", null);
        window.addEventListener("pagehide", abbandona);
        try { esito = await confermaInCornice(listUrl, { panel: this, episodeId: ep, rid }); }
        catch { esito = "rifiutata"; }
        window.removeEventListener("pagehide", abbandona);
        this.log(`${now()}  conferma in sottofondo: ${esito}`);
      }
      if (esito === "incerta") {
        // Nessuna prova dalla cornice: la pagina del paziente, riletta con pazienza.
        const prova = await provaConferma(rid, ep, { patientUrl: plan?.patientUrl, panel: this });
        if (prova) {
          let partita = false;
          try { partita = maybeAutoPrint(this, prova.doc, prova.url); } catch { partita = false; }
          esito = partita ? "stampata" : "confermata";
        }
      }
      const fine = { n, ts: Date.now() };
      if (esito === "stampata" || esito === "confermata") confermataProvata(rid);
      if (esito === "stampata") {
        // la striscia adesso è della stampa; alla fine resta il resoconto
        this.message = { head: `✓ ${confermatiTesto(fine)}`, body: "Senza passare dal carrello." };
        this.render();
        return;
      }
      if (esito === "confermata") {
        // Confermata, ma i fogli non sono partiti (un'altra stampa in corso):
        // restano armati, e partono dalla sua scheda. Niente si ricarica.
        this.message = { head: `✓ ${confermatiTesto(fine)}`, body: "Le etichette partono dalla sua scheda." };
        this.segnala({ tag: "Confermata", testo: confermatiTesto(fine), tono: "ok", quesito });
        this.render();
        return;
      }
      if (esito === "incerta") {
        // Né la cornice né la pagina del paziente la dicono confermata: per
        // il pannello NON lo è. Mai verde, e mai una seconda conferma da sola:
        // un tocco apre il carrello, e lì decide il medico.
        tabStore.set("confirm.v1", null);
        const str = { tag: "Non confermata", testo: "Controlla il carrello e premi tu Conferma", tono: "warn" };
        this.message = { head: "Conferma non verificata", body: "Il gestionale non mostra questa richiesta fra le confermate: apri il carrello, controlla e premi tu Conferma." };
        this.segnala({ tag: "Non confermata", testo: "tocca per il carrello", titolo: "tocca per il carrello", tono: "warn", paziente: chi,
          onTap: () => { consegna(str); nav(listUrl); } });
        this.render();
        return;
      }
      // Rifiutata (il server non si lascia incorniciare) o sospesa (un
      // controllo ha detto di no): si finisce sulla pagina vera, col motivo.
      const motivo = "Conferma automatica sospesa: controlla il carrello e premi tu Conferma.";
      const sospesa = { tag: "Conferma sospesa", testo: "Controlla il carrello e premi tu Conferma", tono: "warn" };
      const testo = (typeof this.message === "string" && this.message) || motivo;
      if (esito === "sospesa") tabStore.set("confirm.v1", null);
      if (this.runRipreso && !LAVORO) {
        // giro ripreso: niente salti di pagina, il carrello si apre col tocco
        // (la scheda di un ordine invece ci va: lì non c'è nessuno a cui portarla via)
        tabStore.set("confirm.v1", null);
        const aMano = esito === "rifiutata";
        this.message = { head: this.message?.head || "", body: aMano ? "Conferma da fare a mano: apri il carrello." : testo };
        const dopo = aMano ? { tag, testo: "Conferma dal gestionale", tono: "ok" } : sospesa;
        const vista = { tag: aMano ? tag : sospesa.tag, tono: "warn",
          testo: `${aMano ? "Conferma da fare a mano" : "Controlla il carrello"} · tocca per il carrello` };
        this.segnala({ ...vista, paziente: chi, titolo: "tocca per il carrello",
          onTap: () => { consegna(dopo, aMano ? null : testo); nav(listUrl); } });
        this.render();
        return;
      }
      if (esito === "sospesa") {
        this.vaiSeLibero(listUrl, { ms: 0, striscia: { ...sospesa, testo: "" }, prima: () => { consegna(sospesa, testo); } });
      } else {
        // cornice vietata, o la scheda di un ordine: la conferma la fa la
        // pagina vera, appena caricata. Se non si può partire adesso, la
        // conferma resta al medico. (Nella scheda di un ordine conferma e
        // stampa continuano da quella pagina, e le etichette arrivano lo
        // stesso al medico.)
        const confermo = { tag, testo: "Confermo…", tono: "run", attesaConferma: true };
        const parte = this.vaiSeLibero(listUrl, { ms: 0, striscia: { tag, testo: "Conferma da fare a mano", tono: "warn" },
          prima: () => { consegna(tabStore.get("confirm.v1", null) ? confermo : { tag, testo: "Conferma dal gestionale", tono: "ok" }); } });
        if (!parte) {
          tabStore.set("confirm.v1", null);
          if (LAVORO) alMedico({ tag, testo: "Conferma da fare a mano", tono: "warn" }, { tag, testo: "Conferma dal gestionale", tono: "ok" });
        }
      }
    }
    failed(state, msg, plan) {
      window.removeEventListener("beforeunload", this._unload);
      this.runState = "fail"; this.runData = state; this.message = msg;
      const riprenderà = !!tabStore.get(CORSA, null);
      // Quali esami della selezione mancano ancora davvero: mai partiti, in
      // questa richiesta o nelle gambe della catena che non sono partite.
      // «Chiudi» lascia scelti solo quelli — quelli già nel carrello no, né i
      // «da controllare». Senza la chiave di ognuno (un giro di prima di
      // questa versione) non si toglie niente: meglio come prima che a caso.
      {
        const gamba = plan && plan.legs && plan.legLabel ? plan.legs.findIndex((l) => l.label === plan.legLabel) : -1;
        const mancano = [...(state.mancanti || []), ...(gamba >= 0 ? plan.legs.slice(gamba + 1).flatMap((l) => l.items || []) : [])];
        this.tieneDopoErrore = mancano.every((x) => x && x.chiave) ? mancano.map((x) => x.chiave) : null;
      }
      // La catena lab+radiologia resta sotto gli occhi, com'è sempre stata.
      if (plan && plan.hold) {
        if (this.collapsed && !riprenderà) { this.collapsed = false; store.set("collapsed", false); }
        this.render();
        return;
      }
      // Un giro che riprenderà da solo alla pagina dopo: lo dice la striscia.
      if (riprenderà) {
        this.segnala({ tag: "Giro interrotto", testo: "Riprende alla prossima pagina", tono: "warn", paziente: this.runPatient || "" });
        this.render();
        // Nella scheda di un ordine nessuno cambia pagina: la si ricarica (un
        // indirizzo da leggere), e il giro riparte da dov'era — l'esame in
        // volo si cerca, mai si rimanda. Il tetto delle riprese vale anche qui.
        if (LAVORO && leggibilePagina(location.href)) this._tRiprendi = setTimeout(() => location.reload(), 2000);
        return;
      }
      // Errore in sottofondo: la finestra NON si apre. La striscia diventa
      // rossa e dice che cosa manca (mai partito) e che cosa è da controllare
      // (mandato, ma non visto in carrello), e la scheda va sul carrello della
      // richiesta — sul laboratorio del primo esame rimasto fuori — con una
      // semplice lettura dell'elenco: niente si manda, niente si conferma. Lì
      // il medico vede gli esami già scelti e aggiunge il resto a mano.
      tabStore.set("confirm.v1", null);
      const cosa = testoResto(msg);
      const striscia = msg.sessione
        ? { tag: "Sessione scaduta", testo: "Rifai l'accesso, poi controlla il carrello", tono: "err", paziente: this.runPatient || "" }
        : { tag: "Errore · completa a mano", testo: cosa || msg.head, tono: "err", paziente: this.runPatient || "" };
      // solo l'elenco semplice, di questo ospedale: niente che inserisca o tolga
      let listUrl = state.lastListUrl;
      try {
        if (new URL(listUrl).origin !== location.origin || /[?&](Insert|Delete)=/.test(listUrl)) listUrl = null;
        // il laboratorio del primo esame rimasto fuori, se la richiesta lo offre
        const res = state.resMancante;
        if (listUrl && res && res !== param(listUrl, "RISORSA_ID") && (param(listUrl, "RISORSE") || "").split(",").includes(res)) {
          const u = new URL(listUrl);
          u.searchParams.set("RISORSA_ID", res);
          listUrl = u.href;
        }
      } catch { listUrl = null; }
      // «↻ Riprova i mancanti» (e «Svuota il carrello»): mai dopo una sessione
      // scaduta, un episodio che non torna, un'altra scheda al lavoro — né
      // dopo uno svuotamento non riuscito: lì si finisce a mano
      this.riprova = msg.restaQui || msg.niente ? null : ricettaRiprova(state, plan);
      // «Se manca un esame, riprova a mandarlo una volta»: da solo, UNA volta
      // per ordine, dopo un elenco venuto male, e solo se niente è «da
      // controllare» (un esame mandato e non visto non si rischia due volte).
      // È «↻ Riprova i mancanti» com'è, qui, prima dell'ultima parola — mai
      // dalla pagina di un altro paziente.
      const r = this.riprova;
      if (r && msg.ritentabile && !r.ritentato && r.rid && r.mancanti.length && !r.controllare.length
        && leggibilePagina(listUrl) && this.epDiQuesta() === r.ep) return this.riprovaMancanti(listUrl);
      if (plan && plan.ritentato) this.log(`${now()}  ritentato una volta da solo: da qui decidi tu`);
      // quello che la pagina del carrello dovrà dire: il resoconto e «Riprova»
      const avviso = {
        testo: msg, striscia,
        giro: { stato: "fail", paziente: this.runPatient || "", listUrl, tiene: this.tieneDopoErrore,
          steps: (state.steps || []).map(({ label, status, note }) => ({ label, status, note })) },
        ...(this.riprova ? { riprova: this.riprova } : {}),
      };
      const consegna = () => tabStore.set(AVVISO, { ts: Date.now(), ...avviso });
      // Nella scheda di un ordine la pagina non si muove: il resoconto intero
      // va alle schede del medico, e lì «apri il carrello» lo apre.
      if (LAVORO) {
        return this.consegnaLavoro({ tag: msg.sessione ? "Sessione scaduta" : "Errore", tono: "err", sessione: !!msg.sessione,
          testo: msg.sessione ? "Rifai l'accesso, poi controlla il carrello" : msg.head || "completa a mano", quesito: cosa },
        listUrl && !msg.restaQui ? { url: listUrl, avviso } : null, "errore");
      }
      // Mai sul carrello dopo un episodio che non torna o la sessione scaduta
      // (restaQui), né se il giro ripreso ti ha trovato sulla scheda di un
      // altro paziente: quella pagina non te la porto via.
      // (epDiQuesta: la lista del PS non è la pagina di nessun paziente)
      const qui = this.epDiQuesta();
      const vai = !!listUrl && !msg.restaQui && (!this.runRipreso || (!!qui && qui === plan?.episodeId));
      // anche «Apri il carrello» porta con sé il resoconto: lì compare «Riprova»
      this.consegnaErrore = listUrl && this.riprova ? consegna : null;
      this.segnala(striscia);
      this.render();
      if (vai) {
        state.lastListUrl = listUrl;   // anche «Apri il carrello» del resoconto porta lì
        this.vaiSeLibero(listUrl, { striscia, prima: consegna });
      }
    }
    stopped(state, msg, plan) {
      window.removeEventListener("beforeunload", this._unload);
      this.runState = "stopped"; this.runData = state; this.message = msg;
      if (plan && plan.hold) {
        if (this.collapsed) { this.collapsed = false; store.set("collapsed", false); }
        this.render();
        return;
      }
      // fermato dal medico: lo dice la striscia, un tocco apre il resoconto
      const striscia = { tag: "Interrotto", testo: "L'ultimo esame potrebbe essere in carrello: controlla", tono: "warn", paziente: this.runPatient || "" };
      if (LAVORO) {
        const u = leggibilePagina(state.lastListUrl) ? state.lastListUrl : "";
        return this.consegnaLavoro({ tag: "Interrotto", testo: striscia.testo, tono: "warn", quesito: testoResto(msg) },
          u ? { url: u, avviso: { testo: msg, striscia, giro: { stato: "stopped", paziente: this.runPatient || "", listUrl: u,
            steps: (state.steps || []).map(({ label, status, note }) => ({ label, status, note })) } } } : null, "interrotto");
      }
      this.segnala(striscia);
      this.render();
    }
    stop() { this.stopFn?.(); }

    // ================================================ L'ORDINE IN SOTTOFONDO
    // ---- nella scheda dell'ordine ------------------------------------------
    // Che cosa deve dire la striscia delle altre schede mentre il giro va: lo
    // stesso che dice la striscia di questa — chi, «esame 3 di 6», il passo —
    // e che cosa è già entrato, che cosa è partito, che cosa manca ancora.
    vistaLavoro() {
      const st = this.runData;
      const nomeDi = (x) => x.display || shortLabel(x.label);
      const m = this.message && typeof this.message === "object" ? this.message : {};
      let resto = null;
      if (Array.isArray(m.mancano) || Array.isArray(m.nel)) resto = { mancano: m.mancano || [], controllare: m.controllare || [], nel: m.nel || [] };
      else if (st) {
        const dentro = st.added || [];
        const fuori = (st.ordine || this.pianoGiro?.items || []).filter((x) => !dentro.includes(x) && !x.tolto);
        // mentre si svuota il carrello, niente è sicuro: tutto da controllare
        const forse = (x) => !!st.svuotando || x.inviato || x.soloVerifica;
        resto = { nel: dentro.map(nomeDi), controllare: fuori.filter(forse).map(nomeDi), mancano: fuori.filter((x) => !forse(x)).map(nomeDi) };
      }
      const dove = { ...(st?.richiestaId ? { rid: String(st.richiestaId) } : {}), ...(st?.lastListUrl ? { listUrl: st.lastListUrl } : {}), ...(resto ? { resto } : {}) };
      if (this.runState === "running") {
        const { badgeEsami, fase } = this.statoGiro();
        return { stato: "corre", vista: { badge: badgeEsami, testo: fase, tono: "run", ferma: true }, ...dove };
      }
      // (finché l'ordine è in corso, il ⏹ c'è sempre: lo finisce, qualunque cosa stia aspettando)
      if (this.runState === "fail" && tabStore.get(CORSA, null)) return { stato: "corre", vista: { tag: "Giro interrotto", testo: "riprendo da dov'ero…", tono: "warn", ferma: true }, ...dove };
      const s = this.striscia;
      if (s) return { stato: "corre", vista: { tag: s.tag || "", badge: s.badge || "", testo: s.testo || "", tono: s.tono || "run", quesito: s.quesito || "", ferma: true }, ...dove };
      return null;
    }
    // A che punto è, per le altre schede (a ogni ridisegno, solo se cambia).
    // La risposta porta il ⏹ che questa scheda non ha ricevuto direttamente.
    pubblicaLavoro() {
      if (!LAVORO || this._lavoroChiuso || !hasExt()) return this._annuncio;
      const v = this.vistaLavoro();
      if (!v) return this._annuncio;
      const firma = JSON.stringify(v);
      if (firma === this._ultimaVista) return this._annuncio;
      this._ultimaVista = firma;
      return (this._annuncio = ask({ t: "ordineAggiorna", id: LAVORO.id, ...v }).then((r) => { if (r && r.ferma) this.fermaLavoro(); return r; }));
    }
    // Prima di ogni invio il service worker deve sapere quale esame parte: se
    // questa scheda muore adesso, quell'esame è «da controllare», mai «non mandato».
    annunciaLavoro() { this.render(); return this.pubblicaLavoro(); }
    // L'ultima parola della scheda di un ordine: com'è finita e, se c'è da fare
    // a mano, il carrello da aprire con quello che la pagina deve dire. Va alle
    // schede del medico; poi questa scheda si slega (il service worker la
    // chiude, se il medico non la sta guardando proprio adesso).
    async consegnaLavoro(vista, consegna = null, stato = "avviso") {
      if (!LAVORO || this._lavoroChiuso) return false;   // l'ultima parola si dice una volta
      const v = this.vistaLavoro() || {};
      this._lavoroChiuso = true;
      const m = { t: "ordineAggiorna", id: LAVORO.id, stato, vista, ...(consegna ? { consegna } : {}), registro: registroLavoro(this),
        ...(v.resto ? { resto: v.resto } : {}), ...(v.rid ? { rid: v.rid } : {}), ...(v.listUrl ? { listUrl: v.listUrl } : {}) };
      // il service worker che si sta svegliando può perdere la prima: una volta ancora
      if ((await ask(m)).perso) await ask(m);
      this.slegaLavoro();
      return true;
    }
    // L'ordine è finito: da qui è una scheda qualunque, e del giro non tiene
    // niente — l'esito lo mostra la striscia, come in tutte le altre.
    slegaLavoro() {
      if (!LAVORO) return;
      LAVORO = null;
      if (this.runState === "running") this.stop();
      this.dimenticaErrore();
      this.runPatient = null; this._firmaOrdine = "";
      this.stripOrdine();
      this.render();
    }
    // ⏹ dalla scheda del medico. Il giro che manda si ferma; una conferma
    // automatica non ancora cliccata non parte; un giro che stava per
    // riprendere non riprende. Quello che è già andato (la Conferma premuta)
    // non si ferma più: allora si dice di no, il fermo resta segnato al
    // service worker, e la prova o le etichette arrivano da sé. In ogni altro
    // caso l'ordine finisce qui: la coda non aspetta una scheda ferma.
    fermaLavoro() {
      if (!LAVORO) return false;
      if (this.runState === "running") { this.stop(); return true; }
      if (confermaPartita()) return false;   // la prova, o le etichette, arrivano da sé (lavoroSenzaSeguito)
      const c = tabStore.get(CORSA, null);
      const armata = !!tabStore.get("confirm.v1", null);
      clearTimeout(this._tRiprendi); clearTimeout(this._tVai);
      tabStore.set(CORSA, null);
      tabStore.set("confirm.v1", null);
      if (c) store.set(APERTA, null);   // fermato: lo dice la striscia del medico
      this.log(`${now()}  ⏹ dalla scheda del medico: ${c ? "il giro non riprende" : armata ? "la conferma automatica non parte" : "l'ordine finisce qui"}`);
      // (che cosa manca e che cosa è da controllare lo sa già il service worker: l'ultima parola prima della pagina)
      const u = [c && c.listUrl, LAVORO.listUrl].find(leggibilePagina);
      this.consegnaLavoro({ tag: "Interrotto", testo: c ? "Fermato fra una pagina e l'altra: controlla il carrello" : "Controlla il carrello e premi tu Conferma", tono: "warn" },
        u ? { url: u } : null, "interrotto");
      return true;
    }
    // La scheda di sottofondo è appena nata: si controlla che sia la pagina
    // giusta (lo stesso episodio, il link per la richiesta, o il carrello di
    // quella richiesta), si dice al service worker «parto» — una volta sola,
    // anche se la pagina si ricarica — e si fa girare il motore di sempre.
    async avviaLavoro() {
      const L = LAVORO, p = L && L.piano;
      const no = (testo) => this.consegnaLavoro({ tag: "Non partito", testo, tono: "err" }, null, "errore");
      if (!p || !Array.isArray(p.items) || !p.items.length) return no("L'ordine non è arrivato a questa scheda: niente inviato");
      if (!this.episodeId || this.episodeId !== String(p.episodeId)) return no("La scheda ha aperto un altro paziente: niente inviato");
      let base;
      if (p.startPage === "patient") {
        const entry = this.pageType === "patient" ? (p.kind === "radio" ? this.entry?.radioUrl : this.entry?.labUrl) : "";
        if (!entry) return no("Sulla pagina del paziente manca il link della richiesta: niente inviato");
        base = { ...p, entryUrl: entry };
      } else {
        const rid = String(p.richiestaId || param(L.url, "RICHIESTA_ID") || "");
        if (this.pageType !== "exam" || !rid || param(location.href, "RICHIESTA_ID") !== rid) return no("La scheda non ha aperto il carrello della richiesta: niente inviato");
        base = p.startPage === "exam" ? { ...p, examDoc: document, examUrl: location.href } : { ...p };
      }
      const r = await ask({ t: "ordineParto", id: L.id });
      if (!r || !r.ok) return;   // già partita (la pagina si è ricaricata: il giro va avanti da sé), o fermata
      this.log(`${now()}  ── scheda di sottofondo: l'ordine per ${p.patientName || "il paziente"} parte da qui ──`);
      this.startPlan({ ...base, dalLavoro: true });
    }

    // ---- nella scheda del medico -------------------------------------------
    // Si può dare l'ordine a una scheda di sottofondo? Con l'estensione, un
    // giro solo (la coppia laboratorio + radiologia resta qui), e da una
    // pagina che si riapre così com'è: quella del paziente o il carrello
    // della richiesta — l'indirizzo da cui il motore partirebbe, mai uno
    // costruito. La pagina «Nuova richiesta» ha il suo modulo vivo: resta qui.
    urlLavoro(plan) {
      if (!hasExt() || LAVORO || !this.ordiniOk) return "";
      const ep = String(plan.episodeId || "");
      const ok = (u) => (leggibilePagina(u) && param(u, "EPISODIO_ID") === ep ? u : "");
      if (plan.startPage === "patient") return urlPaziente(ep, plan.patientUrl);
      if (plan.startPage === "exam") {
        const m = examModel(plan.examDoc || document, plan.examUrl || location.href);
        return m.richiestaId ? ok(m.listUrl(m.res)) : "";
      }
      if (plan.startPage === "carrello") return ok(plan.listUrl);
      return "";
    }
    async delega(plan, url) {
      const id = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
      const pulito = (i) => ({ res: i.res, code: i.code, label: i.label, display: i.display || i.label,
        ...(i.chiave ? { chiave: i.chiave } : {}), ...(i.resCat ? { resCat: i.resCat } : {}), ...(i.alPostoDi ? { alPostoDi: i.alPostoDi } : {}),
        ...(i.soloVerifica ? { soloVerifica: true } : {}), ...(i.giaFatto ? { giaFatto: true } : {}) });
      const n = plan.items.length;
      const piano = {
        startPage: plan.startPage, items: plan.items.map(pulito), quesito: plan.quesito || "", quesitoMio: !!plan.quesitoMio,
        autoConfirm: !!plan.autoConfirm, episodeId: plan.episodeId, patientName: plan.patientName || "",
        patientUrl: plan.startPage === "patient" ? url : plan.patientUrl || "",
        kind: plan.legs && plan.legs[0] ? plan.legs[0].kind : "",
        ...(plan.richiestaId ? { richiestaId: String(plan.richiestaId) } : {}),
        ...(plan.daControllare ? { daControllare: plan.daControllare.map(pulito) } : {}),
        ...(plan.svuota ? { svuota: true } : {}), ...(plan.listUrl ? { listUrl: plan.listUrl } : {}),
        ...(plan.originali ? { originali: plan.originali.map(pulito) } : {}), ...(plan.nostri ? { nostri: plan.nostri.map(pulito) } : {}),
        ...(plan.qinfo ? { qinfo: plan.qinfo } : {}), ...(plan.ritentato ? { ritentato: true } : {}),
      };
      const chi = plan.patientName || "";
      this._delegando = true;
      this.message = null;
      this.collapsed = true;
      this.segnala({ paziente: chi, badge: n === 1 ? "1 esame" : `${n} esami`, testo: "Apro la scheda dell'ordine…", tono: "run", daOrdine: true });
      const job = { id, ep: String(plan.episodeId), paziente: chi, n, autoConfirm: !!plan.autoConfirm, url,
        rid: plan.richiestaId || param(url, "RICHIESTA_ID") || null, nomi: plan.items.map((i) => i.display || shortLabel(i.label)), piano };
      // Una risposta persa (il service worker che si sveglia) si richiede con
      // lo stesso numero: il service worker lo riconosce, l'ordine è uno.
      let r = { ok: false };
      for (let k = 0; k < 3 && !r.ok && !r.no; k++) r = await ask({ t: "ordineNuovo", job });
      this._delegando = false;
      if (r.ok) {
        this.log(`${now()}  ordine di ${n} ${n === 1 ? "esame" : "esami"} per ${chi || "il paziente"} dato a una scheda di sottofondo${r.coda ? ", in coda" : ""}`);
        // l'ordine è partito: la selezione qui riparte pulita
        if (!plan.episodeId || plan.episodeId === this.episodeId) this.clearOrderUi();
        this.ordiniAggiorna(r.ordini || this.ordini);
        this.render();
        return;
      }
      if (!r.no) {
        // il service worker non risponde: non si sa, e da qui non si manda niente
        this.segnala({ tag: "Ordine incerto", testo: "Non so se è partito: guarda il carrello prima di rifarlo", tono: "warn", paziente: chi,
          onStop: () => this.segnala(null) });
        return;
      }
      // niente scheda di sottofondo (non si apre, o la pagina non va): l'ordine lo manda questa pagina, come sempre
      this.log(`${now()}  scheda di sottofondo non disponibile (${r.why || "?"}): mando da questa pagina`);
      if (this.striscia && this.striscia.daOrdine) this.segnala(null);
      runPlan(plan, this);
    }
    // Gli ordini dal service worker. La scheda di un ordine guarda solo il
    // suo: finito, si slega; un ⏹ segnato, lo esegue. Le altre mostrano la striscia.
    ordiniAggiorna(l) {
      this.ordini = Array.isArray(l) ? l.filter((x) => x && x.id) : [];
      if (LAVORO) {
        const mio = this.ordini.find((x) => x.id === LAVORO.id);
        if (!mio || mio.worker == null) return this.slegaLavoro();   // (un ordine finito non ha più scheda)
        if (mio.ferma && !LAVORO.ferma) { LAVORO.ferma = true; this.fermaLavoro(); }
        return;
      }
      this.registriOrdini();
      this.stripOrdine();
    }
    // Il Registro della scheda di un ordine arriva con la sua ultima parola (la
    // scheda si chiude): si aggiunge, una volta, al Registro di quel paziente
    // in questa scheda — quello che «⧉ Copia» copia —, segnato come suo.
    registriOrdini() {
      const fatti = tabStore.get(REGISTRI, []) || [];
      const nuovi = this.ordini.filter((o) => Array.isArray(o.registro) && o.registro.length && o.ep && !fatti.includes(String(o.id)));
      if (!nuovi.length) return;
      for (const o of nuovi) {
        const righe = [`${now()}  ── il Registro della scheda dell'ordine ──`, ...o.registro.map((r) => `  » ${r}`)];
        if (String(o.ep) === String(this.episodeId || "")) { for (const r of righe) this.log(r); continue; }
        const k = "log." + o.ep, prima = tabStore.get(k, null);
        const lines = prima && Date.now() - (prima.ts || 0) < 2 * 3600e3 && Array.isArray(prima.lines) ? prima.lines : [];
        tabStore.set(k, { ts: Date.now(), lines: [...lines, ...righe].slice(-200) });
      }
      tabStore.set(REGISTRI, [...fatti, ...nuovi.map((o) => String(o.id))].slice(-30));
    }
    // Una striscia sola: la cosa più seria, e fra due pari la più nuova. Un
    // errore, poi un avviso da leggere (un carrello da confermare, una stampa
    // da controllare), le etichette pronte qui, quello che gira, la coda, le
    // etichette di un ordine dal telefono (aspettano un tocco, ma non coprono
    // il resto) e per ultimo un «Stampato», che dopo due minuti se ne va da
    // solo (la Ristampa resta nella sezione Stampa del paziente). Quanti
    // aspettano in coda, nel numerino. Le parole sono quelle dell'ordine
    // (`pubblico`, le scrive il service worker: le stesse sul telefono); qui ci
    // sono i bottoni. È solo una vista: non scrive niente (le azioni, sì).
    stripOrdine() {
      const tel = (x) => String(x.id).startsWith("tel");
      const grado = (x) => {
        const t = x.pubblico && x.pubblico.tono;
        return t === "err" ? 0 : x.stato === "stampa" ? (tel(x) ? 5 : 2) : t === "warn" ? 1
          : ["avvio", "corre", "stampo"].includes(x.stato) ? 3 : x.stato === "coda" ? 4 : 6;
      };
      const l = this.ordini.filter((x) => grado(x) < 6 || Date.now() - (x.agg || 0) < OK_STRISCIA);
      const fuoco = [...l].sort((a, b) => grado(a) - grado(b) || (b.agg || 0) - (a.agg || 0))[0];
      clearTimeout(this._tOk);
      if (fuoco && grado(fuoco) === 6) this._tOk = setTimeout(() => this.stripOrdine(), OK_STRISCIA - (Date.now() - (fuoco.agg || 0)) + 500);
      const mia = !!(this.striscia && this.striscia.daOrdine);
      if (!fuoco) {
        if (mia && !this._delegando) { this.segnala(null); this.sorvegliaConferme(); }
        return;
      }
      // questa scheda ha già la sua da dire: un giro suo, una stampa, un errore
      if (this.runState || (this.striscia && !mia && (this.striscia.daStampa || this.striscia.tono === "err"))) return;
      const v = fuoco.vista || {}, p = fuoco.pubblico || {};
      const coda = l.filter((x) => x.stato === "coda" && x !== fuoco).length;
      const id = fuoco.id;
      // Un tocco sulla striscia apre il TUO pannello, come sempre: questa
      // scheda resta tua, anche per ordinare a un altro paziente. Le azioni
      // dell'ordine stanno nel bottoncino accanto.
      const alCarrello = fuoco.consegna || leggibilePagina(fuoco.listUrl)
        ? { azione: { label: "apri il carrello", titolo: "Apre qui il carrello della richiesta, col resoconto (una lettura: niente si manda)", fn: () => this.ordineCarrello(fuoco) } } : {};
      const letto = { onStop: () => { this.lettoOrdine(fuoco); ask({ t: "ordineChiudi", id }).then((x) => { if (x && x.ordini) this.ordiniAggiorna(x.ordini); }); },
        titoloStop: "Chiudi l'avviso" };
      const ferma = { onStop: () => ask({ t: "ordineFerma", id }).then((x) => { if (x && x.tolto) ask({ t: "ordineControlla" }).then((y) => y && y.ordini && this.ordiniAggiorna(y.ordini)); }), ferma: true };
      const stampaQui = (label, titolo) => ({ azione: { label, titolo, fn: () => ask({ t: "ordineStampaQui", id }) } });
      const esami = (k) => (k === 1 ? "1 esame" : `${k} esami`);
      let s = { tag: p.titolo || "", testo: p.testo || "", tono: p.tono || "run", quesito: p.dettaglio || "" };
      if (fuoco.stato === "coda") s = { ...s, badge: esami(fuoco.n || 0), ...ferma, ferma: false, titoloStop: "Togli dalla coda" };
      else if (fuoco.stato === "avvio") s = { ...s, badge: esami(fuoco.n || 0), ...ferma };
      else if (fuoco.stato === "corre" && !fuoco.muto && !fuoco.ferma) {
        // il giro, come lo dice la sua scheda: chi, «esame 3 di 6», il passo
        s = { tag: v.tag || "", badge: v.badge || "", testo: v.testo || "…", tono: v.tono || "run", quesito: v.quesito || "", ...(v.ferma ? ferma : {}) };
      } else if (fuoco.stato === "corre") s = { ...s, ...(fuoco.muto ? ferma : {}) };
      // la stampa dopo la conferma, senza dialogo: ⏹ ferma i fogli che restano
      else if (fuoco.stato === "stampo") s = { ...s, ...(fuoco.ferma ? {} : ferma) };
      else if (fuoco.stato === "stampa") {
        // Le etichette pronte. Sulla pagina di un altro paziente il dialogo
        // non si apre da solo, e un ordine dal telefono mai: un tocco le stampa.
        const altro = !!this.epDiQuesta() && this.epDiQuesta() !== String(fuoco.ep);
        if (altro && s.testo === "Etichette pronte") s.testo = `Etichette di ${nomeCorto(fuoco.paziente)} pronte`;
        if (fuoco.ferma) s.quesito = "⏹ arrivato tardi: era già confermata";
        s = { ...s, ...stampaQui("Stampa", "Stampa adesso le etichette, in questa scheda") };
      } else if (fuoco.stato === "avviso") {
        // (stampato senza dialogo: i fogli restano per «Ristampa», qui)
        const ristampa = fuoco.stampa ? stampaQui("Ristampa", "Stampa di nuovo i fogli non usciti (o tutti, se sono usciti), in questa scheda") : {};
        s = { ...s, ...(fuoco.consegna ? alCarrello : ristampa), ...letto };
      } else s = { ...s, ...alCarrello, ...letto };   // errore, scheda chiusa, interrotto
      // (un ordine partito dal telefono lo dice: chi preleva va avvisato)
      if (tel(fuoco)) s.badge = s.badge ? `${s.badge} · dall'iPhone` : "dall'iPhone";
      s.paziente = fuoco.paziente || "";
      s.daOrdine = id;
      if (coda) s.badge = `${s.badge ? s.badge + " · " : ""}+${coda} in coda`;
      // la stessa striscia di prima, ancora lì: niente ridisegno
      const firma = JSON.stringify(s);
      if (mia && firma === this._firmaOrdine && this.striscia === this._strisciaOrdine) return;
      this._firmaOrdine = firma;
      this.segnala(s);
      this._strisciaOrdine = this.striscia;
    }
    // L'avviso di un ordine è letto (✕, o il carrello aperto): il segno
    // condiviso «giro rimasto a metà» di quella richiesta lo diceva già lui.
    lettoOrdine(o) {
      const a = store.get(APERTA, null);
      if (a && ((o.rid && String(a.rid || "") === String(o.rid)) || a.ep === o.ep)) store.set(APERTA, null);
    }
    // Il carrello della richiesta, in QUESTA scheda: una lettura, mai un
    // invio, col passaggio di consegne che la pagina deve mostrare (la
    // ricevuta, il resoconto e «Riprova»). L'avviso così è letto: via.
    ordineCarrello(o) {
      const c = o.consegna || null;
      const u = c && leggibilePagina(c.url) ? c.url : leggibilePagina(o.listUrl) ? o.listUrl : "";
      if (!u) return;
      if (c && c.avviso) tabStore.set(AVVISO, { ...c.avviso, ts: Date.now() });
      if (c && c.receipt) tabStore.set("receipt.v1", { ...c.receipt, ts: Date.now() });
      this.lettoOrdine(o);
      ask({ t: "ordineChiudi", id: o.id });
      nav(u);
    }

    // ---- «Svuota il carrello e ricomincia» ---------------------------------
    // Dopo un errore, sul carrello di QUELLA richiesta: si vuota il carrello
    // (col «Svuota carrello» del gestionale), si dimostra vuoto rileggendolo
    // dal server, e si rimette tutta la selezione di partenza — più quello che
    // nel carrello c'era già (aggiunto a mano, o da un giro di prima) — nella
    // stessa richiesta, come il primo giro: conferma e stampa, o solo carrello.
    svuotaQui() {
      const r = this.riprova;
      if (!r || this.runState !== "fail" || !r.rid || !(r.tutti || []).length || !r.nCarrello) return false;
      if (findEpisodeId(document, location.href) !== r.ep) return false;
      return this.pageType === "exam" && param(location.href, "RICHIESTA_ID") === r.rid;
    }
    // Il primo tocco legge il carrello vero, tutte le sezioni (solo letture),
    // e dice che cosa toglierà, per nome: «Svuoto 3 esami: EMOCROMO POC,
    // TROPONINA US, PCR?». Il secondo fa. Una riga che non si saprebbe
    // rimettere lo dice subito, e non si svuota.
    async svuotaChiedi() {
      const r = this.riprova;
      if (!this.svuotaQui() || this._svuota) return;
      const io = this._svuota = { testo: "Leggo il carrello…", legge: true };
      this.render();
      let fatto = { testo: "", ok: false };
      try {
        const { righe } = await leggiCarrello(examModel(document, location.href), { rid: r.rid, ep: r.ep });
        const { ignoti } = daRimettere(righe, r.tutti, [...(r.verdi || []), ...(r.controllare || [])]);
        const nomi = righe.map(nomeRiga);
        fatto = ignoti.length ? { testo: `Non svuoto: non saprei rimettere ${ignoti.map((x) => `«${x}»`).join(", ")}` }
          : !righe.length ? { testo: `Il carrello è vuoto: rimetto ${r.tutti.length === 1 ? "1 esame" : `${r.tutti.length} esami`}?`, ok: true }
            : { testo: `Svuoto ${nomi.length === 1 ? "1 esame" : `${nomi.length} esami`}: ${nomi.join(", ")}?`, ok: true };
      } catch (e) {
        fatto = { testo: `Non riesco a leggere il carrello: ${e?.head || e?.message || e}` };
      }
      if (this._svuota !== io) return;
      const ora = this._svuota = fatto;
      this.render();
      setTimeout(() => { if (this._svuota === ora) { this._svuota = null; this.render(); } }, 8000);
    }
    svuotaERicomincia() {
      const r = this.riprova;
      if (!this.svuotaQui()) return;
      const live = examModel(document, location.href);
      const listUrl = (live.richiestaId === r.rid && live.listUrl(live.res)) || r.listUrl;
      this.dimenticaErrore();
      this.log(`${now()}  ↺ svuoto il carrello della richiesta e rimetto la selezione: ${r.tutti.map((x) => x.display || shortLabel(x.label)).join(", ")}`);
      this.startPlan({
        startPage: "carrello", listUrl, richiestaId: r.rid, svuota: true,
        autoConfirm: r.autoConfirm, patientName: r.paziente, patientUrl: r.patientUrl,
        ...(r.qinfo ? { qinfo: r.qinfo } : {}),
        originali: r.tutti.map((x) => ({ ...x })),
        items: r.tutti.map((x) => ({ ...x })),
        // con quale codice sono entrati quelli di questo giro (un riflesso ne cambia il numero)
        nostri: [...(r.verdi || []), ...(r.controllare || [])].map((x) => ({ ...x })),
      });
    }
    // ---- La richiesta ancora da confermare, sul suo carrello ----------------
    // Riaperta più tardi (dopo «Chiudi», un ricarico, da un'altra scheda) la
    // richiesta non ha più né la ricevuta né il resoconto di un errore: la sua
    // riga ha «Conferma e stampa» e «Svuota», a due tocchi come «Svuota il
    // carrello e ricomincia». Il primo legge il carrello vero, tutte le
    // sezioni (solo letture), e dice per nome che cosa farà; il secondo lo fa.
    // Solo se la pagina ha la Conferma del gestionale: senza, la richiesta è
    // forse già confermata, e il motore non svuoterebbe comunque.
    daConfQui() {
      if (this.pageType !== "exam" || this.runState || this._delegando) return null;
      const rid = param(location.href, "RICHIESTA_ID"), ep = findEpisodeId(document, location.href);
      const live = examModel(document, location.href);
      if (!rid || !ep || String(live.richiestaId) !== rid || !live.confirmButton) return null;
      return nonConfermateQui().some((x) => x.rid === rid) ? { rid, ep, live } : null;
    }
    daConfAzioni() {
      const q = this.daConfQui();
      if (!q) return "";
      const a = this._daconf && this._daconf.rid === q.rid && !this._daconf.vuoto ? this._daconf : null;
      const titoli = {
        dcconferma: "Preme la Conferma del gestionale per questa richiesta, poi parte la stampa. Il primo tocco legge il carrello e dice che cosa conferma",
        dcsvuota: "Toglie dal carrello tutti gli esami di questa richiesta col «Svuota carrello» del gestionale, controlla che sia vuoto e la dimentica. Il primo tocco legge il carrello e dice che cosa toglie",
      };
      const lnk = (id, testo, cls = "") => `<button class="lnk${cls}" id="${id}" title="${esc(titoli[id])}"${a && !a.ok ? " disabled" : ""}>${esc(testo)}</button>`;
      // armata (o mentre legge), l'altra si toglie di mezzo: la domanda sta da sola
      if (a) return `<span class="dcaz">${lnk(a.cosa === "conferma" ? "dcconferma" : "dcsvuota", a.testo, ` chiede${a.cosa === "svuota" ? " via" : ""}`)}</span>`;
      return `<span class="dcaz">${lnk("dcconferma", "Conferma e stampa")}${lnk("dcsvuota", "Svuota")}</span>`;
    }
    async daConfTocco(cosa) {
      const a = this._daconf;
      if (a && a.cosa === cosa && a.ok) return cosa === "conferma" ? this.daConfConferma(a) : this.daConfSvuota(a);
      if (a && !a.vuoto) return;   // legge, o ha detto di no: si aspetta che torni a capo
      const q = this.daConfQui();
      if (!q) return;
      const io = this._daconf = { rid: q.rid, cosa, testo: "Leggo il carrello…" };
      this.render();
      let fatto;
      try {
        const nomi = (await leggiCarrello(q.live, { rid: q.rid, ep: q.ep })).righe.map(nomeRiga);
        const conto = nomi.length === 1 ? "1 esame" : `${nomi.length} esami`;
        // la pagina del paziente: il motore la legge prima di svuotare (che non sia confermata)
        const pu = [(tuttiPazienti().find((p) => p.ep === q.ep) || {}).url].find(leggibilePagina);
        if (!nomi.length) {
          // vuoto, riletto dal server: niente da confermare, il promemoria non serve più
          confermataProvata(q.rid);
          this.log(`${now()}  la richiesta da confermare ha il carrello vuoto: non la sorveglio più`);
          fatto = { testo: "Il carrello è vuoto: niente da confermare", vuoto: true };
        } else if (cosa === "svuota" && !pu) fatto = { testo: "Non svuoto: apri prima la pagina del paziente" };
        else fatto = { testo: `${cosa === "conferma" ? "Confermo" : "Svuoto"} ${conto}: ${nomi.join(", ")}?`, ok: true, nomi, pu };
      } catch (e) {
        fatto = { testo: `Non riesco a leggere il carrello: ${e?.head || e?.message || e}` };
      }
      if (this._daconf !== io) return;
      const ora = this._daconf = { ...io, ...fatto };
      this.render();
      setTimeout(() => { if (this._daconf === ora) { this._daconf = null; this.render(); } }, 8000);
    }
    // «Confermo 1 esame: PCR?» — sì: il clic vero sulla Conferma della pagina,
    // come quello della ricevuta. La richiesta è di PS Assist (è fra quelle da
    // confermare), quindi il gancio sul bottone arma la stampa.
    daConfConferma(a) {
      const q = this.daConfQui();
      if (!q || q.rid !== a.rid) { this._daconf = null; this.render(); return; }
      const ora = this._daconf = { rid: q.rid, cosa: "conferma", testo: "Confermo…" };
      this.render();
      // (la pagina se ne va col modulo; se restasse, la riga torna a capo)
      setTimeout(() => { if (this._daconf === ora) { this._daconf = null; this.render(); } }, 8000);
      this.log(`${now()}  conferma della richiesta rimasta da confermare: ${a.nomi.length} ${a.nomi.length === 1 ? "esame" : "esami"} · ${a.nomi.join(" · ")} · click nativo su Conferma`);
      q.live.confirmButton.click();
      // quanti esami: qui non c'è ricevuta, lo dice la lettura del primo tocco
      const p = tabStore.get("print.v1", null);
      if (p && (p.ids || []).includes(q.rid)) tabStore.set("print.v1", { ...p, n: { ...(p.n || {}), [q.rid]: a.nomi.length } });
    }
    // «Svuoto 1 esame: PCR?» — sì: il motore di «Svuota il carrello e
    // ricomincia», con niente da rimettere. Gira in questa scheda (è corto, e
    // non si riprende): provato vuoto, la richiesta si dimentica.
    daConfSvuota(a) {
      const q = this.daConfQui();
      this._daconf = null;
      if (!q || q.rid !== a.rid) { this.render(); return; }
      this.log(`${now()}  ↺ svuoto il carrello della richiesta rimasta da confermare: ${a.nomi.join(", ")} — niente da rimettere`);
      this.startPlan({ startPage: "carrello", listUrl: q.live.listUrl(q.live.res), richiestaId: q.rid,
        svuota: true, soloSvuota: true, items: [], autoConfirm: false, patientUrl: a.pu });
    }

    // «↻ Riprova i mancanti» si mostra solo dov'è sicuro: sul carrello di
    // QUELLA richiesta (il motore rilegge il carrello dal server: quelli già
    // entrati li ritrova e non li rimanda), o sulla pagina del paziente se la
    // richiesta non era ancora nata. Altrove si apre prima il carrello.
    riprovaQui() {
      const r = this.riprova;
      if (!r || this.runState !== "fail" || !(r.mancanti || []).length) return false;
      if (findEpisodeId(document, location.href) !== r.ep) return false;
      if (r.rid) return this.pageType === "exam" && param(location.href, "RICHIESTA_ID") === r.rid;
      return this.pageType === "patient" && !!(this.entry && (this.entry.labUrl || this.entry.radioUrl));
    }
    // (daSolo: l'elenco del carrello da cui ritenta il giro stesso, una volta)
    riprovaMancanti(daSolo = "") {
      const r = this.riprova;
      if (!daSolo && !this.riprovaQui()) return;
      this.dimenticaErrore();
      // senza richiesta: un giro normale, col quesito e gli esami del pannello
      if (!r.rid) { this.view = "richieste"; this.launch(r.autoConfirm); return; }
      const nomi = (l) => l.map((x) => x.display || shortLabel(x.label)).join(", ");
      const fuori = r.controllare || [];
      this.startPlan({
        ...(daSolo ? { startPage: "carrello", listUrl: daSolo } : { startPage: "exam", examDoc: document, examUrl: location.href }),
        richiestaId: r.rid, autoConfirm: r.autoConfirm, patientName: r.paziente, patientUrl: r.patientUrl,
        // quelli già in carrello si cercano soltanto: mai un secondo invio
        items: [...(r.verdi || []).map((x) => ({ ...x, soloVerifica: true, giaFatto: true })), ...r.mancanti.map((x) => ({ ...x }))],
        daControllare: fuori.map((x) => ({ ...x })),   // fuori dal giro, ma se va storto di nuovo restano in elenco
        ...(r.originali ? { originali: r.originali.map((x) => ({ ...x })) } : {}),   // per «Svuota», se si ferma ancora
        ...(r.qinfo ? { qinfo: r.qinfo } : {}),
        ...(daSolo || r.ritentato ? { ritentato: true } : {}), ...(LAVORO ? { dalLavoro: true } : {}),
      });
      this.log(`${now()}  ↻ riprovo ${daSolo ? "da solo, una volta, " : ""}i mancanti: ${nomi(r.mancanti)}${
        fuori.length ? ` — non rimando quelli da controllare: ${nomi(fuori)}` : ""}`);
    }
    // Via l'errore: la pill torna quella di sempre, e il passaggio di
    // consegne verso il carrello (e «Riprova») si dimentica.
    dimenticaErrore() {
      this.runState = null; this.runData = null; this.message = null;
      this.carrelloDaAprire = null; this.consegnaErrore = null; this.riprova = null;
      this.tieneDopoErrore = null; this._svuota = null;
      clearTimeout(this._tStriscia); this.striscia = null;
      tabStore.set(AVVISO, null);
    }
    // «Chiudi» (era «Annulla», ma non annullava niente): via il resoconto, la
    // pill torna quella di sempre, e si torna alle Richieste col quesito. La
    // richiesta rimasta a metà è ancora lì nel gestionale, da confermare: il
    // promemoria resta, e le Richieste lo dicono in una riga. Restano scelti
    // solo gli esami che mancano davvero — quelli già nel suo carrello non si
    // offrono di nuovo, così il conto sul bottone è quello vero.
    chiudiErrore() {
      const tiene = this.tieneDopoErrore;
      this.dimenticaErrore();
      this.restoreUi();
      if (Array.isArray(tiene)) {
        const resta = new Set(tiene);
        for (const k of [...this.selected.keys()]) if (!resta.has(k)) this.selected.delete(k);
        for (const k of [...this.pkgDa]) if (!this.selected.has(k)) this.pkgDa.delete(k);
      }
      // (sulla lista del PS, dove non si ordina, si resta sui Pazienti)
      this.view = this.defaultView() === "home" ? "home" : "richieste"; this.viewId = null;
      this.persistUi();
      this.render();
    }

    // ---- run starters ----
    startPlan(base) {
      if (this.runState === "running" || this._delegando) return;
      // La scheda di un ordine che gira fa solo quell'ordine: un altro, da
      // qui, si confonderebbe col suo (le etichette, l'esito).
      if (LAVORO && !base.dalLavoro) {
        this.message = `Questa scheda sta finendo l'ordine di ${LAVORO.paziente || "un paziente"}: aspetta un momento, o ordina da un'altra scheda.`;
        this.render();
        return;
      }
      // Copie: il motore traduce codici e risorse per la sede, e la selezione
      // del medico deve restare la sua (dopo un errore, «Chiudi» la ritrova).
      const items = base.items || [...this.selected.entries()].map(([k, i]) => ({ ...i, chiave: k }));
      if (!items.length && !base.soloSvuota) return;   // («Svuota» dalla riga non rimette niente)
      const episodeId = findEpisodeId(document, location.href);
      if (!episodeId) { // fail-closed: never order on an unidentifiable episode
        this.message = "Episodio non identificabile su questa pagina: usa la pagina nativa.";
        this.render();
        return;
      }
      this.log(`${now()}  ── nuova operazione ──`);
      this.message = null;
      tabStore.set("receipt.v1", null);
      // Pin the patient this run belongs to: the running/result views show
      // THIS name, never whatever the page title becomes later.
      this.runPatient = base.patientName || nomeInPagina();
      const plan = { quesito: (this._q || "").trim(), quesitoMio: !!this.quesitoMio, items, episodeId, patientName: this.runPatient, ...base,
        // la pagina che elenca le richieste confermate: serve a provare una conferma
        patientUrl: base.patientUrl || (this.pageType === "patient" ? location.href : "") };
      if ((this._q || "").trim()) rememberQuesito((this._q || "").trim());
      if (plan.legs && plan.legs.length > 1) { this.runChain(plan); return; }
      // Con l'estensione il giro lo fa una scheda di sottofondo: questa resta
      // libera. Se la scheda non si apre, lo fa questa pagina, come sempre.
      // («Svuota» dalla riga di una richiesta da confermare resta qui: è corto,
      // e un ordine senza esami da mandare non è un ordine.)
      const dove = plan.soloSvuota ? "" : this.urlLavoro(plan);
      if (dove) this.delega(plan, dove);
      else runPlan(plan, this); // fire and forget; the engine drives the UI via callbacks
    }

    // Lab and radiology cannot share a richiesta, so when both are selected we
    // build them one after the other and then walk the doctor through both
    // confirmations (and one single print flow at the end).
    async runChain(plan) {
      const done = [];
      for (let i = 0; i < plan.legs.length; i++) {
        const leg = plan.legs[i];
        const st = await runPlan({
          ...plan, hold: true, continuation: i > 0,
          entryUrl: leg.entryUrl, items: leg.items, legLabel: leg.label,
          quesito: leg.quesito ?? plan.quesito, quesitoMio: leg.quesitoMio ?? plan.quesitoMio,
        }, this);
        if (this.runState !== "running" || !st || !st.richiestaId) return; // failed/stopped: stop here
        done.push({
          rid: st.richiestaId, listUrl: st.finishedListUrl || st.lastListUrl, kind: leg.kind,
          carrelli: st.carrelli || {},
          count: st.added.length,
          lastCode: st.added.length ? st.added[st.added.length - 1].code : null,
          lastLabel: st.added.length ? st.added[st.added.length - 1].label : null,
          added: st.added.map((x) => ({ res: x.res, code: x.code, label: x.label, display: x.display || x.label,
            ...(x.alPostoDi ? { alPostoDi: x.alPostoDi } : {}) })),
          quesito: st.quesito || null,
        });
      }
      if (!done.length) return;
      // ogni richiesta della catena resta da confermare finché non lo si vede
      for (const d of done) ricordaDaConfermare(d.rid, plan.episodeId, d.listUrl, d.count);
      window.removeEventListener("beforeunload", this._unload);
      this.clearOrderUi();
      this.runState = "done";
      const total = done.reduce((n, d) => n + d.count, 0);
      this.message = { head: `✓ ${done.length} richieste, ${total} esami verificati`, body: "" };
      // il resoconto elenca gli esami di tutte e due le richieste, non solo dell'ultima
      // …e il quesito solo se è lo stesso per tutte e due (la radiologia può avere il suo)
      if (this.runData) {
        this.runData.addedTutti = done.flatMap((d) => d.added);
        this.runData.quesito = done.every((d) => JSON.stringify(d.quesito) === JSON.stringify(done[0].quesito)) ? done[0].quesito : null;
      }
      // hand the rest of the walk to the pages we are about to land on
      const first = done[0];
      tabStore.set("queue.v1", { episodeId: plan.episodeId, autoConfirm: !!plan.autoConfirm, ts: Date.now(), items: done });
      tabStore.set("receipt.v1", { richiestaId: first.rid, episodeId: plan.episodeId, ts: Date.now(), items: first.added, carrelli: first.carrelli || {}, quesito: first.quesito || null });
      if (plan.autoConfirm && first.lastCode && first.kind !== "radio") {
        tabStore.set("confirm.v1", { richiestaId: first.rid, episodeId: plan.episodeId, lastCode: first.lastCode, lastLabel: first.lastLabel, count: first.count, ts: Date.now() });
      }
      this.render();
      if (first.listUrl) this.vaiSeLibero(first.listUrl, { ms: 900, striscia: { tag: `✓ ${done.length} richieste`, testo: "Conferma dal gestionale", tono: "ok" } });
    }

    // ---- live validation (before anything is sent) ----
    computeProblems() {
      const items = [...this.selected.values()];
      const problems = { go: [], confirm: [] };
      const both = (m) => { problems.go.push(m); problems.confirm.push(m); };
      const wantsRadio = items.some((i) => RADIO_SET.includes(i.res));
      const wantsLab = items.some((i) => !RADIO_SET.includes(i.res));
      const q = (this._q || "").trim(), qrx = (this._qrx || "").trim();
      if (this.pageType === "patient") {
        if ((wantsLab && !q) || (wantsRadio && !q && !qrx)) both("Scrivi il quesito diagnostico prima di creare la richiesta.");
        if (wantsRadio && !wantsLab && !this.entry?.radioUrl) both("Link Richieste Radiologia non trovato su questa pagina.");
        if (wantsLab && !this.entry?.labUrl) both("Link Richieste Laboratorio non trovato su questa pagina.");
      } else if (this.pageType === "crea") {
        const allowed = new Set((param(location.href, "RISORSE") || "").split(",").filter(Boolean));
        if (allowed.size) {
          const cat = fullCatalog();
          const opzioni = [...allowed].map((v) => ({ value: v, label: (cat[v] && cat[v].label) || v }));
          const wrong = items.filter((i) => i.res && !risorsaQui(i, opzioni, cat));
          if (wrong.length) both(`Non ordinabili in questa richiesta: ${wrong.map((i) => i.display || shortLabel(i.label)).join(", ")}.`);
        }
        const form = document.forms.namedItem("RICHIESTACrea");
        const pageQ = (form?.elements?.namedItem("QUESITO_DIAGNOSTICO")?.value || "").trim();
        if (items.length && !pageQ && !q && !(wantsRadio && !wantsLab && qrx)) both("Scrivi il quesito diagnostico (nel pannello o nella pagina).");
      } else if (this.pageType === "exam") {
        const live = examModel(document, location.href);
        if (live.resOptions.length) {
          // lo stesso criterio del motore: un esame che in questa sede sta in
          // un'altra risorsa (per nome, o perché ha lo stesso esame) si ordina
          const cat = fullCatalog();
          const wrong = items.filter((i) => i.res && !risorsaQui(i, live.resOptions, cat));
          if (wrong.length) both(`Non ordinabili in questa richiesta: ${wrong.map((i) => i.display || shortLabel(i.label)).join(", ")}.`);
        }
      }

      return problems;
    }

    // =============================================================== VIEWS
    // Compact always-visible selection strip: plain text grouped by resource
    // ("POC: EMOGAS, EMOCROMO · URGENZE: PCT"), an ✕ appears on hover.
    selbarHtml() {
      if (!this.selected.size) return "";
      if (this.pageType === "patient" && !(this.entry && (this.entry.labUrl || this.entry.radioUrl))) return "";
      const byRes = {};   // per nome corto: Urgenze e centrale sono un gruppo solo
      for (const i of this.selected.values()) (byRes[risorsaCorta(i.res)] = byRes[risorsaCorta(i.res)] || []).push(i);
      const groups = Object.entries(byRes).map(([r, arr]) => {
        const items = arr.map((i) =>
          `<span class="selitem" title="${esc(i.label)}">${esc(i.display || shortLabel(i.label))}<button class="selx" data-unsel="${esc(this.key(i.res, i.code))}" title="Rimuovi" aria-label="Rimuovi ${esc(i.display || shortLabel(i.label))}">✕</button></span>`
        ).join(", ");
        return `<span class="selgrp">${esc(r.toUpperCase())}:</span> ${items}`;
      });
      return `<div class="selbar"><span class="selcount">${this.selected.size} SELEZIONATI</span>${groups.map((g) => `<div class="selrow">${g}</div>`).join("")}</div>`;
    }

    render() {
      const patientName = nomeInPagina();
      const ep = findEpisodeId(document, location.href);
      // keep every scroll position across re-renders (chip toggles must not
      // bounce the panel back to the top), sideways too: dopo un paziente
      // portato la mappa, la lista e le aree restano dove li hai lasciati
      const scorre = (el) => {
        const a = el.classList.contains("starbody") && el.closest("[data-area]");
        return a ? `[data-area="${CSS.escape(a.getAttribute("data-area"))}"] .starbody` : "." + ["bd", "list", "rlist", "stcanvas", "pzcoda", "pzpiede"].find((c) => el.classList.contains(c));
      };
      const keepScroll = [...this.root.querySelectorAll(".bd, .list, .rlist, .stcanvas, .pzcoda, .pzpiede, .starbody")]
        .filter((el) => el.scrollTop || el.scrollLeft).map((el) => [scorre(el), el.scrollTop, el.scrollLeft]);
      // la lista «Da fare» aperta si riapre uguale (dfRiattacca), con quello che
      // si stava scrivendo e il cursore dov'era; il menu della sveglia si chiude
      const din = this.root.querySelector("#dfin");
      if (din && this._df) { this._df.inFuoco = this.root.activeElement === din; this._df.sel = [din.selectionStart, din.selectionEnd]; }
      this.promChiudiMenu();

      let body;
      if (this.runState === "running") body = this.viewRunning();
      else if (this.runState) body = this.viewResult();
      else if (this.view === "esiti") body = this.viewEsiti();
      else if (this.view === "referto") body = this.viewEsiti();   // (non c'è più: il testo si apre negli Esiti)
      else if (this.view === "dimissioni") body = this.viewDimissioni();
      else if (this.view === "dimtesto") body = this.viewDimTesto();
      else if (this.view === "eotesto") body = this.viewEoTesto();
      else if (this.view === "dimimport") body = this.viewDimImport();
      else if (this.view === "consensi") body = this.viewConsensi();
      else if (this.view === "eo") body = this.viewEo();
      else if (this.view === "tempi") body = this.viewTempi();
      else if (this.view === "riferimenti") body = this.viewRiferimenti();
      else if (this.view === "richieste") body = this.viewIdle(patientName, ep);
      else body = this.viewHome(patientName, ep);
      // i Pazienti (la lista sopra, la stanza sotto) prendono tutta la finestra che resta
      const inStanza = this.inPazienti();

      const running = this.runState === "running";
      const { badgeEsami, fase } = this.statoGiro();
      // The panel is titled by the PATIENT it is acting on — collapsed too.
      // Dove un paziente non c'è (la lista del PS) il titolo della pagina è
      // «PRONTO SOCCORSO - LISTA»: quello non va mai dove va un nome.
      const sulPaziente = !!this.epDiQuesta();
      const who = (this.runState && this.runPatient) || (sulPaziente ? patientName : "") || APP;
      // Sei su un'altra scheda: il giro continua (le richieste portano il loro
      // episodio), ma va detto a chiare lettere di chi sono gli esami.
      const altrove = !!(this.runState && this.runPatient && patientName && this.runPatient !== patientName);
      // la striscia di quello che succede fuori dalla finestra: rossa per un
      // errore, ambra quando tocca a te
      const strWho = (this.striscia && this.striscia.paziente) || who;
      const strTono = !this.striscia ? "" : this.striscia.tono === "err" ? "err" : this.striscia.tono === "warn" ? "warn" : "";
      const chiPill = this.avvisoPill || ((this.runState || sulPaziente) ? who : "Pazienti");
      const pillInner = running
        ? `<span class="dot"></span> <span class="who">${esc(who)}</span>${badgeEsami ? ` <span class="badge">${esc(badgeEsami)}</span>` : ""}`
        : this.selected.size && !this.avvisoPill
          ? `${LOGO} <span class="who">${esc(chiPill)}</span> <span class="badge">${this.selected.size}</span>`
          : `${LOGO} <span class="who">${esc(chiPill)}</span>`;

      // whose data is on screen must be answerable at a glance, always:
      // patient in the title, episode always next to the section name.
      const inHome = !this.runState && this.view === "home";
      const section = this.runState ? "" : { richieste: "Richieste", esiti: "Esiti", referto: "Referto", dimissioni: "Dimissioni", dimtesto: "Dimissioni", dimimport: "Dimissioni", consensi: "Consensi", eo: "EO", eotesto: "EO", tempi: "Tempi", riferimenti: "Riferimenti" }[this.view] || "";
      // (i fogli di dimissione sono modelli, ma chi va a casa è questo paziente:
      // l'intestazione lo dice anche lì)
      const inDim = this.view === "dimissioni" || this.view === "dimtesto" || this.view === "dimimport";
      // accanto al nome, il secondo identificativo: età e sesso, l'episodio e
      // il posto — su ogni scheda, Dimissioni comprese: di chi sono i dati, e
      // per chi sono le azioni, sempre a colpo d'occhio
      const idp = sulPaziente && !inHome && !this.runState ? this.idPaz() : null;
      const sub = idp ? [idp.es, ep ? `ep. ${ep}` : "", idp.posto].filter(Boolean).map(esc).join(" · ") : "";
      // Il titolo è il paziente, e solo lui: dove non c'è, niente titolo — lo
      // dice la scheda accesa, e sulla lista PS la scheda Pazienti fa anche da ‹.
      // Il ‹ resta sul paziente, e dentro un referto o un foglio di dimissione.
      const indietro = !!section && (sulPaziente || ["referto", "dimtesto", "dimimport", "eotesto"].includes(this.view));
      const titolo = this.runState || (sulPaziente && !inHome) ? who : "";
      // Aperto: una finestra al centro, l'85% dello schermo (o come l'hai
      // lasciata tu). Ridotto: la pill, dove l'hai messa (in alto a destra
      // se non l'hai mai spostata).
      const ridotto = this.collapsed;
      let posStyle;
      if (ridotto) {
        const pp = this.pillPos;
        posStyle = pp && Number.isFinite(pp.left) && Number.isFinite(pp.top)
          ? `left:${Math.max(0, Math.min(window.innerWidth - 80, pp.left))}px;top:${Math.max(0, Math.min(window.innerHeight - 48, pp.top))}px;right:auto;`
          : "";
      } else {
        const g = geometriaFinestra(this.win);
        // di partenza (niente geometria tua) la misura segue lo schermo anche
        // se il browser cambia misura: il tetto è in CSS, non nel conto di adesso
        posStyle = geometriaPropria(this.win)
          ? `left:${g.x * 100}vw;top:${g.y * 100}vh;width:${g.w * 100}vw;height:${g.h * 100}vh;right:auto;`
          : `left:max(${FINESTRA.x * 100}vw,calc((100vw - ${FINESTRA_MAX_PX}px) / 2));top:${g.y * 100}vh;width:min(${FINESTRA.w * 100}vw,${FINESTRA_MAX_PX}px);height:${g.h * 100}vh;right:auto;`;
      }
      // i valori e la stanza si leggono in larghezza; il resto su una colonna comoda

      this.root.innerHTML = `
        <style>${COLORS}${PONTE_CSS}</style>
        <div class="wrap${ridotto ? "" : " win"}" style="${posStyle}">
          ${this.collapsed && !running && this.striscia ? `
            <div class="strip">
              <button class="pill run ${esc(strTono)}" id="expand" title="${esc(strWho)} — ${esc(this.striscia.titolo || (this.striscia.onTap ? "tocca per i comandi" : "tocca per aprire il pannello"))}">
                ${this.striscia.tono === "run" ? `<span class="dot"></span>` : `<span class="tick">${this.striscia.tono === "err" || this.striscia.tono === "warn" ? "!" : "✓"}</span>`}
                <span class="col">
                  <span class="l1"><b class="who">${esc(strWho)}</b>${this.striscia.tag ? ` <span class="tag">${esc(this.striscia.tag)}</span>` : ""}${
                    this.striscia.badge ? ` <span class="badge">${esc(this.striscia.badge)}</span>` : ""}</span>
                  <span class="l2">${esc(this.striscia.testo || "")}</span>
                  ${this.striscia.quesito ? `<span class="l3">${esc(this.striscia.quesito)}</span>` : ""}
                </span>
              </button>
              ${this.striscia.azione ? `<button class="strazione" id="strazione" title="${esc(this.striscia.azione.titolo || "")}">${esc(this.striscia.azione.label)}</button>` : ""}
              ${this.striscia.onStop ? (this.striscia.ferma
                ? `<button class="stopmini" id="strstop" title="Ferma l'ordine">⏹</button>`
                : `<button class="stopmini" id="strstop" title="${esc(this.striscia.titoloStop || "Annulla (Esc)")}">✕</button>`) : ""}
            </div>
          ` : this.collapsed && this.runState ? `
            <div class="strip">
              <button class="pill run ${altrove ? "alt" : this.runState === "fail" ? "err" : this.runState === "stopped" ? "warn" : ""}" id="expand" title="${esc(who)}${
                altrove ? " — stai guardando un'altra scheda" : ""} — tocca per aprire il pannello">
                ${running ? `<span class="dot"></span>` : `<span class="tick">${this.runState === "done" ? "✓" : "!"}</span>`}
                <span class="col">
                  <span class="l1"><b>${esc(who)}</b>${badgeEsami ? ` <span class="badge">${esc(badgeEsami)}</span>` : ""}</span>
                  <span class="l2">${esc(fase || (this.runState === "done" ? "fatto" : ""))}</span>
                </span>
              </button>
              ${running ? `<button class="stopmini" id="stopbtn" title="Interrompi (Esc)">⏹</button>` : ""}
            </div>
          ` : this.collapsed ? `
            <button class="pill" id="expand" title="${esc(who)}${ep ? " · episodio " + esc(ep) : ""} — ${esc(APP)}, trascina per spostare">${pillInner}${this.chipRec()}${this.promUrgente()}</button>
          ` : `
            <div class="card${inStanza ? " stanza" : ""}" role="dialog" aria-label="${esc(APP)}" tabindex="-1">
              <div class="hd" id="draghd" title="Trascina per spostare · doppio clic per rimetterla al centro">
                ${indietro ? `<button class="iconbtn" id="back" title="${
                  this.view === "referto" ? "Torna agli esiti"
                  : this.view === "dimtesto" || this.view === "dimimport" ? "Torna ai fogli di dimissione"
                  : this.view === "eotesto" ? "Torna all'esame obiettivo"
                  : "Tutti i pazienti"}" aria-label="Indietro">${ICO.indietro}</button>` : `<span class="logo">${LOGO_BLU}</span>`}${titolo ? `<b class="who">${esc(titolo)}</b>` : ""}
                ${sub ? `<span class="sub" title="${esc(who)} — episodio ${esc(ep || "?")}">${sub}</span>` : ""}
                ${idp && this.epDiQuesta() ? `<span class="hdpaz">${this.cuoreHtml(this.epDiQuesta())}${this.dfSlot(this.epDiQuesta(), undefined, "testa")}</span>` : ""}
                <span class="hsp"></span>
                ${ponteSpia()}
                <span id="stautow">${this.chipStampa()}</span>
                ${this.chipRec()}${this.chipTempo()}
                <span class="menuw">
                  <button class="iconbtn" id="menubtn" title="Altro" aria-label="Altro" aria-haspopup="true" aria-expanded="${this.menuAperto ? "true" : "false"}">${ICO.altro}</button>
                  ${this.menuAperto ? `<div class="menu" role="menu">
                    ${this.win ? `<button role="menuitem" id="wincentra" title="La finestra al centro, nella misura di partenza">Al centro</button>` : ""}
                    ${eAffiancata(this.win) ? "" : `<button role="menuitem" id="winaffianca" title="Una colonna a destra: il gestionale resta visibile a sinistra">Affianca a destra</button>`}
                    ${inStanza && !this.stanzaEdit ? `<button role="menuitem" id="stmodmenu" title="Ritocca la stanza: aggiungi, sposta e rinomina letti, sedie e aree">Modifica la stanza</button>` : ""}
                    <hr>
                    ${hasExt() ? `<button role="menuitem" id="pontemenu" title="Il pannello sull'iPhone: associa il telefono, prova la rete"><span class="mico">${ICO_TEL}</span>iPhone</button>` : ""}
                    <button role="menuitem" id="tempimenu" title="Il cronometro: misura quanto ti prende un'attività">Tempi</button>
                    <button role="menuitem" id="rifmenu" title="Can't-miss killers: per sintomo, cosa escludere per primo">Riferimenti</button>
                    ${this.view === "dimissioni" ? `<button role="menuitem" id="dimexport" title="Salva i tuoi testi in un file JSON (e negli appunti)">Esporta i fogli (JSON)</button>
                    <button role="menuitem" id="dimimport" title="Rimetti i testi di un JSON esportato">Importa i fogli…</button>` : ""}
                    <button role="menuitem" id="verbtn" title="Il Registro delle operazioni">${this.showLog ? "Nascondi il registro" : "Registro"}</button>
                    ${hasExt() ? `<button role="menuitem" id="stampanti" title="Quale stampante è l'etichettatrice e quale l'A4, per la stampa automatica">Stampanti</button>` : ""}
                    ${hasExt() ? `<button role="menuitem" id="regmenu" title="Registra le pagine, le richieste e i PDF di questa sessione, anonimizzati in uno zip che resta su questo PC finché non lo mandi tu">${
                      this.reg && this.reg.stato === "rec" ? (this.chipRec() ? "Ferma e scarica" : "Scarica la registrazione")
                      : this.reg && this.reg.stato === "fermo" && !this.reg.esportata ? "Scarica la registrazione" : "Registra"}</button>` : ""}
                    ${hasExt() ? `<button role="menuitem" id="portapri" title="L'indirizzo del portale clinico, se il pannello non compare sulla pagina dello storico">Indirizzo del portale</button>` : ""}
                    ${this.stampaPronta() ? (this.stampaAuto.s.attiva === false
                      ? `<button role="menuitem" id="stautosw" title="Ogni foglio va da solo alla sua stampante, senza dialogo">Stampa automatica: spenta · Accendi</button>`
                      : `<button role="menuitem" id="stautosw" title="I fogli tornano a passare dal dialogo di stampa">Stampa automatica: attiva · Spegni</button>`) : ""}
                    ${this.giroInCorso() ? "" : this.resetArmato() ? `<button role="menuitem" id="resetpaz" class="mrischio">Cancello tutto? Tocca di nuovo</button>`
                      : `<button role="menuitem" id="resetpaz">Reset dati pazienti</button>`}
                    ${(typeof chrome !== "undefined" && chrome.runtime?.id) && !this.giroInCorso() ? `<button role="menuitem" id="extreload" title="Dopo aver sostituito i file nella cartella dell'estensione, questo la ricarica con la nuova versione">Ricarica estensione</button>` : ""}
                    <div class="mver">${esc(APP)} ${VERSION}</div>
                  </div>` : ""}
                </span>
                <button class="iconbtn" id="collapse" title="Riduci alla pill (Esc)" aria-label="Riduci">${ICO.riduci}</button>
              </div>
              ${idp ? this.avvisiPaz(idp.ep || ep) : ""}
              ${running && this.runData?.steps?.length ? `<div class="pbar"><i style="width:${Math.round((this.runData.steps.filter((x) => x.status === "ok").length / this.runData.steps.length) * 100)}%"></i></div>` : ""}
              <div class="cap">
              ${!this.runState && inStanza && this.stanzaEdit ? `
                <div class="seg modifica" role="toolbar" aria-label="Modifica la stanza">
                  <b class="segtit">Modifica la stanza</b><span class="segdx">${this.stanzaAzioni()}</span>
                </div>` : !this.runState ? `
                <div class="seg" role="tablist">
                  ${this.pageType === "patient" && this.view !== "home" ? `
                  <button class="${this.view === "richieste" ? "on" : ""}" data-seg="richieste" data-t="Richieste">Richieste</button>
                  <button class="${this.view === "esiti" || this.view === "referto" ? "on" : ""}" data-seg="esiti" data-t="Esiti">Esiti</button>`
                  : `<button class="${inHome || !section ? "on" : ""}" data-seg="home" data-t="Pazienti">Pazienti</button>`}
                  <button class="${this.view === "eo" || this.view === "eotesto" ? "on" : ""}" data-seg="eo" data-t="EO" title="Esame obiettivo da copiare">EO</button>
                  <button class="${this.view === "consensi" ? "on" : ""}" data-seg="consensi" data-t="Consensi">Consensi</button>
                  <button class="${inDim ? "on" : ""}" data-seg="dimissioni" data-t="Dimissioni">Dimissioni</button>
                  ${(inHome || !section) && this.stanzaAzioni ? `<span class="segdx">${this.stanzaAzioni()}</span>` : ""}
                </div>` : ""}
              ${!this.runState ? this.selbarHtml() : ""}
              </div>
              <div class="bd"><div class="bdi">${this.view === "richieste" ? "" : this.notaHtml()}${this.registroHtml()}${body}</div></div>
              ${this.inPazienti() ? "" : this.stanzaSnack()}
              ${["n", "s", "e", "w", "ne", "nw", "se", "sw"].map((d) => `<div class="rz rz-${d}" data-rz="${d}"></div>`).join("")}
              <div class="rsz" id="rsz" data-rz="se" title="Trascina per ridimensionare · doppio click per la misura di partenza"></div>

            </div>
          `}
          ${this.collapsed ? ponteSpia() : ""}
        </div>`;
      this.bind();
      for (const [sel, top, left] of keepScroll) {
        const el = this.root.querySelector(sel);
        if (el) { el.scrollTop = top; el.scrollLeft = left; }
      }
      this._bordiStanza?.();   // i bordi sfumati della mappa, sullo scorrimento appena rimesso
      if (this._fuocoId && !this.root.activeElement) {
        const f = this.root.getElementById ? this.root.getElementById(this._fuocoId) : null;
        if (f && !/^(INPUT|TEXTAREA)$/.test(f.tagName)) f.focus({ preventScroll: true });
      }
      this.pubblicaLavoro();   // la scheda di sottofondo racconta a che punto è
    }

    // A che punto è il giro, in ESAMI (non in passi): «esame 2 di 6» — e che
    // cosa sta facendo adesso. Lo dice la striscia di questa scheda e, dalla
    // scheda di sottofondo, quella di tutte le altre.
    // (si contano quelli già passati: l'ordine in cui vanno non è quello della lista)
    statoGiro() {
      const running = this.runState === "running";
      const esami = (this.runData?.steps || []).filter((s) => s.esame);
      const passati = esami.filter((s) => s.status !== "pending" && s.status !== "running").length;
      const badgeEsami = !esami.length ? "" : esami.some((s) => s.status === "running") ? `esame ${passati + 1} di ${esami.length}`
        : passati ? `${passati} di ${esami.length}` : `${esami.length} ${esami.length === 1 ? "esame" : "esami"}`;
      const passo = (this.runData?.steps || []).find((s) => s.status === "running");
      const fase = running
        ? (passo ? `${passo.label}${passo.note ? " · " + passo.note : ""}` : "…")
        : typeof this.message === "string" ? this.message
          : (this.message?.ok || this.message?.head || this.message?.body || "");
      return { badgeEsami, fase };
    }

    // HOME — the patients this shift. Picking one of the OTHERS navigates to
    // their page first: the panel never shows data belonging to a patient
    // other than the page in front of you.
    // Una vista sola: sopra la lista di chi non ha ancora un posto (una riga
    // per paziente), sotto la stanza. Messo un paziente al suo posto, la lista
    // si accorcia e la stanza sale; rimesso in lista, il letto torna vuoto.
    // In Modifica la lista si toglie di mezzo: si vede tutta la pianta, e i
    // comandi stanno nella fila delle schede (stanzaAzioni()).
    viewHome(patientName) {
      const m = this.pazModello(), edit = !!this.stanzaEdit;
      // il filtro aperto resta com'era, col cursore dov'era; vuoto e lasciato, si chiude
      const cerca = this.root.querySelector("#pzcerca");
      if (cerca && this.root.activeElement === cerca) { this._filtroFuoco = true; this._filtroSel = [cerca.selectionStart, cerca.selectionEnd]; }
      else if (this._filtro === "") this._filtro = null;
      return `<div class="sec"><div class="pzunita${edit ? " edit" : ""}">
        ${edit ? "" : this.viewLista(m, patientName)}
        ${this.viewStanza(m)}
        ${edit ? "" : this.pazArchivio(m)}
        <div class="pzrimetti" data-drop="tray" aria-hidden="true">${ico('<path d="M8 12.5v-9M4 7.5l4-4 4 4"/>')}Rimetti in lista</div>
        ${this.stanzaSnack()}
      </div></div>`;
    }

    // ================================================================ STANZA
    // La mappa della stanza del PS. Letti (un paziente ciascuno) e aree senza
    // letto (corridoio, attesa: quanti ne servono); sopra, la lista, dove
    // sta chiunque non abbia un posto — un paziente non sparisce mai.
    // Di norma si spostano i PAZIENTI (trascinando, o «Sposta in…»); con
    // Modifica si disegna la STANZA, di solito una volta sola. Ogni spostamento
    // si annulla per 8 secondi. Tutto resta in questo browser: la stanza in
    // "stanza.v1" (celle intere della PIANTA, così a ogni misura è la stessa),
    // chi-sta-dove in "stanza.posti.v1" — solo episodi, mai nomi.
    // l'episodio della pagina aperta. La lista del PS non ne ha uno suo: i
    // suoi link portano quello del primo in elenco, che non è «qui».
    epDiQuesta() { return this.episodeId && this.defaultView() !== "home" ? this.episodeId : ""; }
    // Aprire un paziente dal pannello: il suo è già qui, un altro si carica
    // (e la sua pagina si apre sulla schermata scelta).
    apriPaziente(ep, go) {
      if (ep && ep === this.epDiQuesta()) return this.setView(go);
      const p = knownPatients().find((x) => x.ep === ep);
      if (!p || !p.url) return;
      tabStore.set("afterNav.v1", { ep, view: go, ts: Date.now() }); // open there, on their page
      nav(p.url);
    }
    // la schermata dei Pazienti: quella che non è nessun'altra
    inPazienti() {
      return !this.runState && !["esiti", "referto", "dimissioni", "dimtesto", "dimimport", "consensi", "eo", "eotesto", "tempi", "riferimenti", "richieste"].includes(this.view);
    }
    // In fondo alla fila delle schede, solo in Modifica: + Letto, + Sedia,
    // + Area e Fine. Si entra in Modifica dal menu «⋯».
    stanzaAzioni() {
      if (!this.inPazienti() || !this.stanzaEdit) return "";
      return `<span class="stazioni"><button type="button" class="stbtn" id="stpiuletto" title="Aggiungi un letto: un paziente">+ Letto</button><button type="button" class="stbtn" id="stpiusedia" title="Aggiungi una sedia: un paziente, in meno spazio">+ Sedia</button><button type="button" class="stbtn" id="stpiuarea" title="Aggiungi un'area senza letti (corridoio, attesa): più pazienti">+ Area</button><button type="button" class="stbtn pri" id="stfine" title="La stanza è pronta: si torna a spostare i pazienti (Esc)">Fine</button></span>`;
    }
    // La stanza com'è salvata, ripulita: celle intere dentro la pianta, niente
    // sopra un altro, nomi corti, niente doppioni. Quello che non torna (anche
    // una stanza salvata in un altro formato) si lascia fuori. Senza una
    // stanza salvata — o se non ne resta niente — quella del PS (STANZA_PS):
    // togliendo tutto, torna quella.
    stanzaSala() {
      const salvata = store.get("stanza.v1", null);
      // mai salvata: la pianta del PS. Svuotata apposta: resta vuota
      if (!salvata || typeof salvata !== "object") return { letti: STANZA_PS.letti.map((l) => ({ ...l })), aree: STANZA_PS.aree.map((a) => ({ ...a })) };
      const s = salvata;
      const { cols, rows, aw, ah } = PIANTA;
      const int = (v, min, max) => Number.isInteger(v) && v >= min && v <= max;
      const visti = new Set(), presi = [];
      const buono = (o) => typeof o.id === "string" && /^[\w-]{1,16}$/.test(o.id) && !visti.has(o.id) && visti.add(o.id);
      const posa = (q) => !presi.some((p) => troppoVicini(p, q)) && presi.push(q);
      const nome = (o, d) => String(o.nome ?? "").replace(/\s+/g, " ").trim().slice(0, 24) || d;
      const letti = [], aree = [];
      for (const l of Array.isArray(s.letti) ? s.letti : []) {
        const { w, h } = misuraLetto(l || {}), sedia = l?.forma === "sedia";
        if (letti.length >= 60 || !l || !int(l.c, 0, cols - w) || !int(l.r, 0, rows - h) || !buono(l) || !posa({ c: l.c, r: l.r, w, h })) continue;
        letti.push({ id: l.id, c: l.c, r: l.r, nome: nome(l, sedia ? "Sedia" : "Letto"), ...(sedia && { forma: "sedia" }) });
      }
      for (const a of Array.isArray(s.aree) ? s.aree : []) {
        if (aree.length >= 30 || !a || !int(a.w, aw, cols) || !int(a.h, ah, rows) || !int(a.c, 0, cols - a.w) || !int(a.r, 0, rows - a.h)
          || !buono(a) || !posa({ c: a.c, r: a.r, w: a.w, h: a.h })) continue;
        aree.push({ id: a.id, c: a.c, r: a.r, w: a.w, h: a.h, nome: nome(a, "Area") });
      }
      return { letti, aree };
    }
    // gli oggetti della stanza come rettangoli di celle
    stanzaRettangoli(sala) {
      return [...sala.letti.map((l) => ({ id: l.id, c: l.c, r: l.r, ...misuraLetto(l) })),
        ...sala.aree.map((a) => ({ id: a.id, c: a.c, r: a.r, w: a.w, h: a.h }))];
    }
    stanzaScrivi(sala) {
      if (store.set("stanza.v1", sala)) return true;
      this.message = "La stanza NON è stata salvata: la memoria di questo browser è piena o bloccata.";
      this.render();
      return false;
    }
    // Lo stesso paziente (stesso codice fiscale) con due episodi aperti: il
    // più vecchio è l'«episodio precedente» — fuori dalla stanza, in grigio.
    stanzaPrecedenti(pazienti) {
      const perCf = new Map(), out = new Set();
      for (const p of pazienti) if (String(p.pk || "").startsWith("cf:")) perCf.set(p.pk, [...(perCf.get(p.pk) || []), p]);
      const num = (p) => (/^\d+$/.test(p.ep) ? Number(p.ep) : NaN);
      for (const l of perCf.values()) {
        if (l.length < 2) continue;
        l.sort((a, b) => (Number.isNaN(num(a)) || Number.isNaN(num(b)) ? (b.ts || 0) - (a.ts || 0) : num(b) - num(a)));
        for (const p of l.slice(1)) out.add(p.ep);
      }
      return out;
    }
    // Chi sta dove. Un paziente in elenco tiene il suo posto finché non lo
    // sposti, non lo togli dall'elenco o dall'elenco non sparisce: se non lo
    // apri da 12 ore diventa grigio, ma resta dov'è. Un letto tiene un
    // paziente: se i dati ne dicono due, resta il più recente. Il posto di chi
    // non è in elenco (sessione scaduta, archiviato) aspetta un giorno che
    // torni — ma mai su un letto già preso.
    stanzaStato(pazienti, sala, precedenti) {
      const raw = store.get("stanza.posti.v1", {});
      const tutti = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
      const ora = Date.now(), perEp = new Map(pazienti.map((p) => [p.ep, p]));
      const letti = new Set(sala.letti.map((l) => l.id)), aree = new Set(sala.aree.map((a) => a.id));
      const esiste = (v) => v && (v.tipo === "letto" ? letti.has(v.id) : v.tipo === "area" && aree.has(v.id));
      const voci = Object.entries(tutti).filter(([ep]) => /^[\w.-]{1,40}$/.test(ep)).sort((a, b) => (b[1]?.ts || 0) - (a[1]?.ts || 0));
      const posti = {}, perLetto = {}, tieni = {}, preso = {};
      for (const [ep, v] of voci) {   // prima chi è in elenco: sono loro a occupare i letti
        const p = perEp.get(ep);
        if (!p || !esiste(v) || precedenti.has(ep) || (v.tipo === "letto" && perLetto[v.id])) continue;
        if (v.tipo === "letto") perLetto[v.id] = preso[v.id] = ep;
        posti[ep] = tieni[ep] = { tipo: v.tipo, id: v.id, ts: +v.ts || 0 };
      }
      for (const [ep, v] of voci) {   // poi chi non c'è
        if (perEp.has(ep) || !esiste(v) || ora - (+v.ts || 0) > PATIENTS_TTL || (v.tipo === "letto" && preso[v.id])) continue;
        if (v.tipo === "letto") preso[v.id] = ep;
        tieni[ep] = { tipo: v.tipo, id: v.id, ts: +v.ts || 0 };
      }
      if (tutti !== raw || Object.keys(tieni).length !== Object.keys(tutti).length) store.set("stanza.posti.v1", tieni);
      return { posti, perLetto };
    }
    // I nomi. «ROSSI MARIO» → «ROSSI M.»; il cognome si porta dietro le
    // particelle (DE LUCA, DELLA ROSA). Due pazienti attivi con lo stesso
    // cognome: ⚠ e il nome intero. Con lo stesso nome intero: anche le ultime
    // quattro cifre dell'episodio, «· …9001».
    stanzaNomi(pazienti, precedenti) {
      const PART = new Set(["DE", "DI", "DA", "DEL", "DELLA", "DELLE", "DELLO", "DEI", "DEGLI", "DAL", "DALLA", "DALLE", "DALLO",
        "LA", "LO", "LE", "LI", "SAN", "SANTA", "SANTO", "VAN", "VON", "MC", "MAC", "DOS", "DAS", "DU"]);
      const parti = (nome) => {
        const w = String(nome || "").trim().split(/\s+/).filter(Boolean);
        let i = 0;
        while (i < w.length - 2 && PART.has(w[i].toUpperCase())) i++;
        return { cognome: w.slice(0, i + 1).join(" "), nome: w.slice(i + 1).join(" ") };
      };
      const conta = (chiave) => {
        const c = new Map();
        for (const p of pazienti) if (!precedenti.has(p.ep)) { const k = chiave(p); if (k) c.set(k, (c.get(k) || 0) + 1); }
        return c;
      };
      const perCognome = conta((p) => normNome(parti(p.name).cognome)), perNome = conta((p) => normNome(p.name));
      return new Map(pazienti.map((p) => {
        const { cognome, nome } = parti(p.name), vivo = !precedenti.has(p.ep);
        const omonimo = vivo && perCognome.get(normNome(cognome)) > 1;
        const coda = vivo && perNome.get(normNome(p.name)) > 1 ? ` · …${String(p.ep).slice(-4)}` : "";
        const breve = !cognome ? "paziente" : omonimo || !nome ? `${cognome} ${nome}`.trim() : `${cognome} ${nome[0].toUpperCase()}.`;
        return [p.ep, { breve, lungo: p.name || "paziente", coda, omonimo }];
      }));
    }
    // Tutto quello che la lista e la stanza mostrano dei pazienti, calcolato una volta
    pazModello() {
      const pazienti = knownPatients(), sala = this.stanzaSala();
      const precedenti = this.stanzaPrecedenti(pazienti);
      const { posti, perLetto } = this.stanzaStato(pazienti, sala, precedenti);
      const nomi = this.stanzaNomi(pazienti, precedenti);
      const qui = this.epDiQuesta(), ora = Date.now();
      const info = new Map(pazienti.map((p) => [p.ep, {
        p, ...nomi.get(p.ep), qui: p.ep === qui, prec: precedenti.has(p.ep),
        spento: precedenti.has(p.ep) || ora - (p.ts || 0) > 12 * 3600e3, posto: posti[p.ep] || null,
      }]));
      const df = dfTutti();
      return { pazienti, sala, posti, perLetto, info, qui, df, prom: promTutti(df) };
    }
    nomePosto(m, i) {
      const v = i && i.posto;
      return !v ? "" : (v.tipo === "letto" ? m.sala.letti : m.sala.aree).find((o) => o.id === v.id)?.nome || "";
    }
    oraDi(ts) { return (new Date().toDateString() === new Date(ts || 0).toDateString() ? "" : "ieri ") + hhmm(ts); }
    vistoFa(ts) {
      const min = Math.max(0, Math.round((Date.now() - (ts || 0)) / 60000));
      return min < 1 ? "visto adesso" : min < 60 ? `visto ${min} min fa` : `visto ${Math.floor(min / 60)} h fa`;
    }
    // Il passaggio del mouse dice tutto: chi è, quale episodio, quando l'hai
    // aperto, da quando sta dove sta, il triage, la prima cosa da fare.
    pazTitolo(m, i, mappa) {
      const { p } = i, posto = this.nomePosto(m, i);
      const cuore = i.prec ? null : cuoreDi(statoDi(p.ep)?.vit);
      return [
        i.lungo + i.coda + (Number.isInteger(p.eta) ? `, ${p.eta} anni` : ""),
        `episodio ${p.ep} · aperto ${this.oraDi(p.ts)}`,
        posto && `in ${posto} dalle ${this.oraDi(i.posto.ts)}`,
        p.triage && `triage all'apertura: ${p.triage}`,
        cuore && `♥ ${cuore.titolo.split("\n")[0]}`,
        !i.prec && statoTitolo(statoEsami(statoDi(p.ep))),
        m.df && dfPrima(p.ep, m.df) && `Da fare: ${dfPrima(p.ep, m.df).testo}${dfAperte(p.ep, m.df).length > 1 ? ` (+${dfAperte(p.ep, m.df).length - 1})` : ""}`,
        i.omonimo && "⚠ stesso cognome di un altro paziente in elenco",
        i.prec && "Episodio precedente: di questo paziente c'è un episodio più recente",
        mappa && (i.prec ? "Un tocco lo apre" : "Un tocco apre gli esiti · trascinalo, o tasto destro: Sposta in…"),
      ].filter(Boolean).join("\n");
    }
    // a destra del nome: «questa pagina», o da quanto non lo apri (in ambra dopo 3 ore)
    pazStato(i) {
      if (i.prec) return `<span class="sttag">episodio precedente</span>`;
      if (i.qui) return `<span class="stqui">questa pagina</span>`;
      return `<span class="stvisto${Date.now() - (i.p.ts || 0) > 3 * 3600e3 ? " amb" : ""}">${this.vistoFa(i.p.ts)}</span>`;
    }
    // LISTA — chi non ha ancora un posto, una riga per paziente: triage, nome,
    // il cuore e lo stato degli esami, «Da fare» (quante, e la prima: il
    // post-it), da quanto non lo apri; ▾ lo mette nella stanza senza
    // trascinarlo, e passandoci sopra la ✕.
    // Chi è su questa pagina per primo, l'episodio precedente in fondo.
    viewLista(m, patientName) {
      const canOrder = !!(this.entry && (this.entry.labUrl || this.entry.radioUrl));
      const lista = [...m.info.values()].filter((i) => !i.posto).sort((a, b) => b.qui - a.qui || a.prec - b.prec);
      // Il nome è quello con cui il paziente è stato conosciuto. Il titolo
      // della pagina si usa solo se non ne abbiamo uno: sulla lista PS quel
      // titolo è «PRONTO SOCCORSO - LISTA», e stamparlo dove va il nome del
      // paziente è esattamente ciò che questo programma promette di non fare.
      if (m.qui && canOrder && !m.info.has(m.qui)) {
        lista.unshift({ p: { ep: m.qui, name: patientName, ts: Date.now() }, breve: patientName, lungo: patientName || "paziente",
                        coda: "", omonimo: false, qui: true, prec: false, spento: false, posto: null });
      }
      // la riga intera apre il paziente: il bottone del nome la copre tutta, e
      // gli altri comandi stanno sopra — niente bottoni dentro bottoni. Si
      // prende e si porta su un letto, una sedia o un'area, come nella stanza.
      const riga = (i) => {
        const { p } = i, tr = p.triage ? " t-" + p.triage.toLowerCase() : "", vero = m.info.has(p.ep), mobile = vero && !i.prec;
        return `
        <div class="pzrow${i.qui ? " qui" : ""}${i.prec ? " prec" : ""}"${mobile ? ` data-riga="${esc(p.ep)}"` : ""} data-cerca="${esc(normNome(i.lungo))}">
          <i class="pztr${tr}" aria-hidden="true"></i>
          <div class="pzchi">
            <button type="button" class="pzapri" data-go="esiti" data-ep="${esc(p.ep)}"${mobile ? ' aria-haspopup="menu"' : ""} title="${esc(this.pazTitolo(m, i, mobile))}">
              <span class="pznm">${i.omonimo ? `<b class="stom" aria-label="attenzione, stesso cognome di un altro paziente">⚠</b>` : ""}${esc(i.lungo)}${i.coda ? `<span class="stcoda">${esc(i.coda)}</span>` : ""}</span>${p.triage ? `<span class="stsr">, triage ${esc(p.triage)}</span>` : ""}
            </button>
            ${i.prec ? "" : this.statoPaz(p.ep)}
            ${i.prec ? "" : this.dfSlot(p.ep, m.df, "lista") + this.dfPostSlot(p.ep, m.df)}
          </div>
          ${this.pazStato(i)}
          ${mobile ? `<button type="button" class="pzmetti" data-posto="${esc(p.ep)}" aria-haspopup="menu" title="Mettilo nella stanza: scegli il letto, la sedia o l'area" aria-label="Metti ${esc(i.lungo)} nella stanza">${ico('<path d="m4.5 6.5 3.5 3.5 3.5-3.5"/>')}</button>` : ""}
          ${vero ? `<button type="button" class="pzx" data-parch="${esc(p.ep)}" title="Togli dall'elenco: va negli archiviati (si può annullare). Nel gestionale non cambia niente." aria-label="Togli ${esc(i.lungo)} dall'elenco">✕</button>` : ""}
        </div>`;
      };
      // il filtro: compare scrivendo una lettera (vedi filtroTasto)
      const filtro = this._filtro == null ? "" : `
        <div class="pzfiltro" role="search">${ico('<circle cx="7" cy="7" r="4.5"/><path d="m10.5 10.5 3 3"/>')}
          <input type="text" id="pzcerca" value="${esc(this._filtro)}" maxlength="40" placeholder="Cerca un paziente" autocomplete="off" spellcheck="false"
            aria-label="Cerca fra i pazienti: la lista si stringe, nella stanza gli altri si spengono">
          <button type="button" class="pzfx" id="pzcercax" title="Togli il filtro (Esc)" aria-label="Togli il filtro">✕</button>
        </div>`;
      const righe = lista.map(riga).join("");
      if (righe) return `${filtro}<div class="pzcoda" data-drop="tray" role="group" aria-label="In lista, senza un posto: ${lista.length}"><div class="pzvuoto pzfnone" hidden></div>${righe}</div>`;
      return filtro + (m.pazienti.length ? "" : `<div class="pzvuoto">Nessun paziente.</div>`);
    }
    // in fondo, chiusi: gli archiviati e «Svuota l'elenco» (che si annulla)
    pazArchivio(m) {
      const rigaArch = (p) => `
        <div class="pzarow">
          <span class="pzanm" title="${esc(p.name || "")}">${esc(p.name || "paziente")}</span>
          <span class="pzameta">archiviato ${esc(agoLabel(p.archTs || p.ts))}</span>
          <button type="button" class="pzabtn" data-unarch="${esc(p.ep)}" title="Riportalo fra i pazienti attivi">↩ riporta</button>
          <button type="button" class="pzabtn del" data-del="${esc(p.ep)}" title="Elimina tutto quello che il programma sa di lui">🗑</button>
        </div>`;
      const archiviati = pazientiArchiviati();
      if (!m.pazienti.length && !archiviati.length) return "";
      return `<div class="pzpiede">
        <button type="button" class="pzarchhd" id="archtog" aria-expanded="${this.mostraArch ? "true" : "false"}">Archiviati${archiviati.length ? ` <span class="stn">${archiviati.length}</span>` : ""}<span aria-hidden="true">${this.mostraArch ? "▾" : "▸"}</span></button>
        ${this.mostraArch ? `<div class="pzarch">${archiviati.map(rigaArch).join("")}
          <div class="pzhint">${archiviati.length ? "🗑 cancella tutto di quel paziente: scheda clinica, referti tenuti, «Da fare». Non si torna indietro." : "Nessun paziente archiviato."}</div>
          <button type="button" class="pzsvuota" id="stsvuota" title="Toglie tutti i pazienti dall'elenco e dalla stanza. Per 8 secondi si può annullare.">Svuota l'elenco</button>
        </div>` : ""}</div>`;
    }
    // Il paziente nella Stanza: striscia del triage, nome (⚠ se un altro ha
    // lo stesso cognome), e sotto il cuore, «questa pagina» (o «episodio
    // precedente»), gli esami e la prima cosa da fare. Da quanto non lo apri lo dice la lista; qui, dopo 12 ore, il
    // grigio. Nel letto la striscia la porta il letto, il nome sta su una riga
    // e l'episodio che lo distingue scende accanto allo stato: non si taglia mai.
    stanzaChip(m, i, inLetto) {
      const { p } = i, edit = !!this.stanzaEdit;
      const cls = ["stp", i.qui && "qui", i.prec && "prec", i.spento && "spento", !inLetto && p.triage && "tri t-" + p.triage.toLowerCase()].filter(Boolean).join(" ");
      const etichetta = `${esc(i.lungo + i.coda)}${Number.isInteger(p.eta) ? `, ${p.eta} anni` : ""}${p.triage ? `, triage ${esc(p.triage)}` : ""}${i.qui ? ", questa pagina" : i.prec ? ", episodio precedente" : ""}`;
      // Nel letto: il nome e l'età, e basta. In alto a destra, sulla riga del
      // letto, il cuore (solo l'icona) e un pallino solo, se c'è qualcosa;
      // tutto il resto nel passaggio del mouse e nella riga della lista.
      if (inLetto) {
        const nome = esc(i.breve).replace(/&#39;/g, "&#39;<wbr>");   // DELL'ACQUA va a capo dopo l'apostrofo
        const segni = i.prec ? "" : `<span class="stsegni">${this.cuoreHtml(p.ep, undefined, true)}<span class="stsegslot" data-dfseg="${esc(p.ep)}">${this.segnaleHtml(p.ep, m.df)}</span></span>`;
        return `<div class="${cls}" data-stp="${esc(p.ep)}" data-cerca="${esc(normNome(i.lungo))}" role="button" tabindex="${edit ? -1 : 0}"${i.prec ? "" : ' aria-haspopup="menu"'} title="${esc(this.pazTitolo(m, i, true))}" aria-label="${etichetta}">
        <span class="stp1">${i.omonimo ? `<b class="stom" aria-hidden="true">⚠</b>` : ""}<b class="stpn">${nome}${i.coda ? `<span class="stcoda">${esc(i.coda)}</span>` : ""}</b>${
          Number.isInteger(p.eta) ? ` <span class="steta">${p.eta}</span>` : ""}</span>${segni}</div>`;
      }
      // nell'area: sotto il nome il cuore, gli esami in breve (un pezzetto per
      // tipo, solo quello che aspetta) e il post-it, che cede per primo
      const post = i.prec ? "" : this.dfPostSlot(p.ep, m.df);
      const stato = i.prec ? `<span class="sttag">episodio precedente</span>` : i.qui ? `<span class="stqui">questa pagina</span>` : "";
      const cuore = i.prec ? "" : this.cuoreHtml(p.ep), es = i.prec ? "" : statoHtml(statoEsami(statoDi(p.ep)), { breve: true });
      const sotto = `${cuore}${stato}${es}${post}`;
      return `<div class="${cls}" data-stp="${esc(p.ep)}" data-cerca="${esc(normNome(i.lungo))}" role="button" tabindex="${edit ? -1 : 0}"${i.prec ? "" : ' aria-haspopup="menu"'} title="${esc(this.pazTitolo(m, i, true))}" aria-label="${etichetta}">
        <span class="stp1">${i.omonimo ? `<b class="stom" aria-hidden="true">⚠</b>` : ""}<b class="stpn">${esc(i.breve)}${i.coda ? `<span class="stcoda">${esc(i.coda)}</span>` : ""}</b>${i.prec ? "" : this.dfSlot(p.ep, m.df, "area")}</span>${
        sotto ? `<span class="stp2">${sotto}</span>` : ""}</div>`;
    }
    // il letto (o la sedia) vuoto: a tratto, appena accennato
    stanzaGlifo(w, cls, sedia) {
      const t = 'vector-effect="non-scaling-stroke"';
      const [vb, h, d] = sedia ? ["0 0 20 20", w, `<path ${t} d="M5 3l1.5 8v6M6.5 11h8.5v6"/>`]
        : ["0 0 30 20", Math.round(w * 2 / 3), `<path ${t} d="M2 3v15M2 14h26v4M2 10h24a2 2 0 0 1 2 2v2"/><rect ${t} x="5" y="6" width="7" height="4" rx="1.5"/>`];
      return `<svg${cls ? ` class="${cls}"` : ""} width="${w}" height="${h}" viewBox="${vb}" fill="none" stroke="#C4D0DC" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
    }
    // il nome di un letto, di una sedia o di un'area; in Modifica un tocco lo rende scrivibile
    stanzaNome(tipo, o) {
      const r = this._stanzaRinomina;
      if (this.stanzaEdit && r && r.tipo === tipo && r.id === o.id) {
        return `<input type="text" class="stnomein" maxlength="24" value="${esc(r.testo)}" spellcheck="false" autocomplete="off" aria-label="Nome ${tipo === "area" ? "dell'area" : o.forma === "sedia" ? "della sedia" : "del letto"}">`;
      }
      return this.stanzaEdit
        ? `<span class="stname" data-stnome="${tipo}" role="button" tabindex="0" title="Tocca per rinominare, trascina per spostare">${esc(o.nome)}</span>`
        : `<span class="stname">${esc(o.nome)}</span>`;
    }
    // In Modifica, sull'oggetto scelto o sotto il mouse: × lo elimina;
    // l'angolo in basso a destra allarga l'area.
    stanzaCtl(tipo, o) {
      const del = `<button type="button" class="stctl stx" data-stdel="${tipo}:${esc(o.id)}" title="Elimina ${tipo === "area" ? "l'area" : o.forma === "sedia" ? "la sedia" : "il letto"} «${esc(o.nome)}»: chi c'era torna in lista. Si può annullare." aria-label="Elimina ${esc(o.nome)}">×</button>`;
      return tipo === "letto" ? del : `${del}<span class="strsz" data-strsz="1" title="Trascina per ridimensionare l'area"></span>`;
    }
    viewStanza(m) {
      const { sala, pazienti, info, perLetto, posti } = m;
      const edit = !!this.stanzaEdit;
      const chip = (p) => this.stanzaChip(m, info.get(p.ep));
      // In Modifica la pianta intera, coi puntini: sotto il mouse niente cambia
      // misura. Fuori, solo il pezzo disegnato con una cella di margine: anche
      // una stanza piccola riempie la mappa.
      const rett = this.stanzaRettangoli(sala);
      let c0 = 0, r0 = 0, cols = PIANTA.cols, rows = PIANTA.rows;
      if (!edit && rett.length) {
        c0 = Math.min(...rett.map((q) => q.c)) - 1;
        r0 = Math.min(...rett.map((q) => q.r)) - 1;
        cols = Math.max(...rett.map((q) => q.c + q.w)) + 1 - c0;
        rows = Math.max(...rett.map((q) => q.r + q.h)) + 1 - r0;
      }
      const celle = (c, r, w, h) => `--c:${c - c0};--r:${r - r0};--w:${w};--h:${h}`;
      // la sedia è un letto più piccolo: stesse regole, un paziente
      const letto = (l) => {
        const i = perLetto[l.id] ? info.get(perLetto[l.id]) : null, sedia = l.forma === "sedia", { w, h } = misuraLetto(l);
        const cls = ["stbed", sedia && "sedia", i && "occ", i?.qui && "qui", i?.p.triage && "tri t-" + i.p.triage.toLowerCase(),
          edit && this._stanzaSel === "letto:" + l.id && "sel"].filter(Boolean).join(" ");
        return `<div class="${cls}" data-letto="${esc(l.id)}" data-drop="letto:${esc(l.id)}"${i ? ` data-occ="${esc(i.breve + i.coda)}" data-occep="${esc(i.p.ep)}" data-cerca="${esc(normNome(i.lungo))}"` : ""} role="group"
          aria-label="${esc(l.nome)}: ${i ? esc(i.lungo + i.coda) : "vuoto"}"${edit ? "" : ` title="${esc(l.nome)}${i ? "" : " — trascina qui un paziente"}"`}
          style="${celle(l.c, l.r, w, h)}">
          <div class="stbedin">${i ? `<div class="stbedhd">${this.stanzaNome("letto", l)}</div>${this.stanzaChip(m, i, true)}`
            : this.stanzaNome("letto", l) + this.stanzaGlifo(sedia ? 24 : 28, "stglifo", sedia)}</div>
          ${edit ? this.stanzaCtl("letto", l) : ""}
        </div>`;
      };
      const area = (a) => {
        const dentro = pazienti.filter((p) => posti[p.ep]?.tipo === "area" && posti[p.ep].id === a.id)
          .sort((x, y) => posti[x.ep].ts - posti[y.ep].ts);   // in ordine di arrivo: chi c'è non si sposta
        return `<div class="starea${edit && this._stanzaSel === "area:" + a.id ? " sel" : ""}" data-area="${esc(a.id)}" data-drop="area:${esc(a.id)}" role="group" aria-label="${esc(a.nome)}: ${dentro.length} ${dentro.length === 1 ? "paziente" : "pazienti"}"${edit ? "" : ` title="${esc(a.nome)} — trascina qui i pazienti"`}
          style="${celle(a.c, a.r, a.w, a.h)}">
          <div class="sthd">${this.stanzaNome("area", a)}${dentro.length ? `<span class="stn">${dentro.length}</span>` : ""}</div>
          <div class="starbody">${dentro.map(chip).join("")}</div>
          ${edit ? this.stanzaCtl("area", a) : ""}
        </div>`;
      };
      // chi non ha un posto sta nella lista, sopra (viewLista)
      return `
        <div class="stmap${edit ? " edit" : ""}" role="region" aria-label="Mappa della stanza">
          <div class="stcanvas">
            <div class="stplan" style="--cols:${cols};--rows:${rows}">${sala.letti.map(letto).join("")}${sala.aree.map(area).join("")}</div>
            ${sala.letti.length + sala.aree.length ? "" : edit
              ? `<div class="stvuota"><b>Comincia con + Letto, in alto a destra</b></div>`
              : `<div class="stvuota"><b>La stanza è vuota</b><button type="button" class="stbtn" id="stdisegna">Disegna la stanza</button><button type="button" class="stlink" id="stpianta" title="Rimette OBI, OSS e le sale d'attesa">o riprendi la pianta del PS</button></div>`}
          </div>
        </div>`;
    }
    // «Annulla» per 8 secondi dopo ogni cosa che si può rimpiangere
    stanzaSnack() {
      const a = this._stanzaAnn;
      if (!a || Date.now() > a.fino) return "";
      return `<div class="stsnack" role="status"><span>${esc(a.testo)}</span><button type="button" class="stannulla" title="Rimetti com'era">Annulla</button></div>`;
    }
    bindStanza() {
      const $ = (s) => this.root.querySelector(s);
      this._bordiStanza = null;   // vale solo per la mappa disegnata adesso
      // scrivere una lettera apre il filtro (una volta sola, per tutta la pagina)
      if (!this._filtroLegato) { this._filtroLegato = true; window.addEventListener("keydown", (e) => this.filtroTasto(e), true); }
      if (!this.inPazienti() || this.collapsed) this._filtro = null;   // fuori dai Pazienti (o ridotto) il filtro non resta appeso
      // In Modifica si entra dal menu «⋯», e si esce con Fine (o Esc); il
      // fuoco resta dove si continua.
      const modifica = (si) => () => {
        if (!si) this.stanzaSalvaBozza();
        this.stanzaEdit = si; this._stanzaRinomina = null; this._stanzaSel = null; this.menuAperto = false;
        if (si) this._filtro = null;
        this._stanzaFocus = si ? "#stpiuletto" : "#menubtn";
        this.render();
      };
      $("#stmodmenu")?.addEventListener("click", modifica(true));
      $("#stdisegna")?.addEventListener("click", modifica(true));
      // la pianta di partenza: il prossimo disegno la ripropone
      $("#stpianta")?.addEventListener("click", () => { store.del("stanza.v1"); this.render(); });
      $("#stfine")?.addEventListener("click", modifica(false));
      $("#stpiuletto")?.addEventListener("click", () => this.stanzaAggiungi("letto"));
      $("#stpiusedia")?.addEventListener("click", () => this.stanzaAggiungi("sedia"));
      $("#stpiuarea")?.addEventListener("click", () => this.stanzaAggiungi("area"));
      $(".stannulla")?.addEventListener("click", () => this.stanzaAnnulla());
      // la lista: ▾ apre «Sposta in…»; la ✕ archivia (e si annulla)
      this.root.querySelectorAll("[data-posto]").forEach((b) => b.addEventListener("click", (e) => { e.stopPropagation(); this.stanzaMenu(b.getAttribute("data-posto"), b); }));
      this.root.querySelectorAll("[data-parch]").forEach((b) => b.addEventListener("click", (e) => { e.stopPropagation(); this.stanzaArchivia(b.getAttribute("data-parch")); }));
      $("#stsvuota")?.addEventListener("click", () => this.stanzaSvuota());
      // il filtro: si scrive, la lista si stringe e la stanza spegne gli altri,
      // senza ridisegnare; Esc (o ✕) lo toglie, Invio apre l'unico che torna
      const cerca = $("#pzcerca");
      if (cerca) {
        if (this._filtroFuoco) {
          const [a, z] = this._filtroSel || [cerca.value.length, cerca.value.length];
          cerca.focus({ preventScroll: true });
          cerca.setSelectionRange(a, z);
          this._filtroFuoco = false; this._filtroSel = null;
        }
        cerca.addEventListener("input", () => { this._filtro = cerca.value; this.filtroApplica(); });
        cerca.addEventListener("keydown", (e) => {
          if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); this.filtroChiudi(); }
          else if (e.key === "Enter") { e.preventDefault(); const ep = this.filtroUnico(); if (ep) this.apriPaziente(ep, "esiti"); }
        });
      }
      $("#pzcercax")?.addEventListener("click", () => this.filtroChiudi());
      this.filtroApplica();
      const box = $(".pzunita"), map = $(".stmap");
      if (box && map) {
        box.addEventListener("pointerdown", (e) => this.stanzaPresa(e, box));
        // una riga portata via (o tenuta premuta col dito) non è anche un tocco che apre
        box.addEventListener("click", (e) => { if (this._rigaMossa && e.detail) { this._rigaMossa = false; e.preventDefault(); e.stopPropagation(); } }, true);
        map.addEventListener("click", (e) => {
          const del = e.target.closest("[data-stdel]");
          if (del) { const [tipo, id] = del.getAttribute("data-stdel").split(":"); this.stanzaElimina(tipo, id); }
        });
        // da tastiera: Invio apre il paziente (o rinomina, in Modifica); Maiusc+F10 o il tasto menu: Sposta in…
        box.addEventListener("keydown", (e) => {
          const riga = e.target.closest?.(".pzapri")?.closest(".pzrow[data-riga]");
          const chip = e.target.closest?.(".stp[data-stp]"), nome = e.target.closest?.("[data-stnome]");
          const menu = e.key === "ContextMenu" || (e.shiftKey && e.key === "F10");
          if (riga && menu) { e.preventDefault(); this.stanzaMenu(riga.getAttribute("data-riga"), riga.querySelector("[data-posto]") || riga); }
          else if (chip && !this.stanzaEdit && menu) {
            e.preventDefault();
            if (!chip.classList.contains("prec")) this.stanzaMenu(chip.getAttribute("data-stp"), chip);
          } else if (e.key === "Enter" || e.key === " ") {
            if (chip && !this.stanzaEdit) { e.preventDefault(); this.apriPaziente(chip.getAttribute("data-stp"), "esiti"); }
            else if (nome) { e.preventDefault(); this.stanzaRinomina(nome); }
          }
        });
        box.addEventListener("contextmenu", (e) => {
          if (this.stanzaEdit || e.target.closest("input")) return;
          const riga = e.target.closest(".pzrow[data-riga]");
          if (riga) { e.preventDefault(); return this.stanzaMenu(riga.getAttribute("data-riga"), riga.querySelector("[data-posto]") || riga); }
          const chip = e.target.closest(".stp[data-stp]") || e.target.closest(".stbed.occ")?.querySelector(".stp[data-stp]");
          if (!chip) return;
          e.preventDefault();
          if (!chip.classList.contains("prec")) this.stanzaMenu(chip.getAttribute("data-stp"), chip);
        });
        // stretta, la mappa può non starci in larghezza: dove si scorre solo
        // di lato, la rotella scorre di lato (finché c'è strada), e il bordo
        // sfuma dalla parte dove c'è altro
        const diLato = (el) => el?.addEventListener("wheel", (e) => {
          if (el.scrollWidth <= el.clientWidth || el.scrollHeight > el.clientHeight || Math.abs(e.deltaY) <= Math.abs(e.deltaX)) return;
          if (e.deltaY > 0 ? el.scrollLeft + el.clientWidth >= el.scrollWidth - 1 : el.scrollLeft <= 0) return;
          el.scrollLeft += e.deltaY;
          e.preventDefault();
        }, { passive: false });
        const tela = map.querySelector(".stcanvas");
        diLato(tela);
        const bordi = () => {
          tela.classList.toggle("sx", tela.scrollLeft > 1);
          tela.classList.toggle("dx", tela.scrollLeft + tela.clientWidth < tela.scrollWidth - 1);
        };
        // anche subito dopo che render() ha rimesso lo scorrimento di prima
        if (tela) { bordi(); tela.addEventListener("scroll", bordi, { passive: true }); this._bordiStanza = bordi; }
        const inp = map.querySelector(".stnomein");
        if (inp) {
          inp.focus();
          if (this._stanzaRinomina?.seleziona) { inp.select(); this._stanzaRinomina.seleziona = false; }
          else inp.setSelectionRange(inp.value.length, inp.value.length);
          inp.addEventListener("input", () => { if (this._stanzaRinomina) this._stanzaRinomina.testo = inp.value; });
          inp.addEventListener("keydown", (e) => {
            if (e.key === "Enter") { e.preventDefault(); this.stanzaChiudiNome(inp, true, true); }
            else if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); this.stanzaChiudiNome(inp, false, true); }
          });
          inp.addEventListener("blur", () => { if (inp.isConnected) this.stanzaChiudiNome(inp, true); });
        }
      }
      if (this._stanzaFocus) { const f = $(this._stanzaFocus); this._stanzaFocus = null; f?.focus(); }
    }
    // Il filtro. Una lettera scritta con i Pazienti davanti — e il cursore
    // fuori da un campo, del pannello o del gestionale — lo apre con quella
    // lettera: la lista si stringe ai nomi che tornano, nella stanza gli altri
    // si spengono. Esc (o ✕) lo toglie.
    filtroTasto(e) {
      if (e.defaultPrevented || e.ctrlKey || e.metaKey || e.altKey || e.isComposing) return;
      const esc = e.key === "Escape";
      if (!esc && !/^\p{L}$/u.test(e.key || "")) return;
      if (this.collapsed || this.stanzaEdit || this.menuAperto || this._stanzaPresa || this._stanzaMenu?.menu?.isConnected || this._promMenu?.menu?.isConnected
          || this._df || !this.root.querySelector(".pzunita")) return;
      const via = e.composedPath ? e.composedPath() : [], t = via[0];
      // dal pannello, o da nessuna parte (la finestra copre la pagina): mai da un elemento del gestionale
      if (!via.includes(this.host) && t && t !== document.body && t !== document.documentElement && t !== document) return;
      const campo = t && (/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName || "") || t.isContentEditable);
      // Esc col filtro aperto lo toglie, prima di ridurre la finestra (vedi escLocale);
      // dal campo di un promemoria, l'Esc è del campo
      if (esc) {
        if (this._filtro == null || (campo && t.id !== "pzcerca")) return;
        e.preventDefault(); e.stopPropagation();
        return this.filtroChiudi();
      }
      if (campo) return;
      e.preventDefault();
      this._filtro = (this._filtro || "") + e.key;
      this._filtroFuoco = true; this._filtroSel = null;
      this.render();
    }
    filtroChiudi() {
      this._filtro = null;
      this.render();
      this.root.querySelector(".card")?.focus({ preventScroll: true });
    }
    // sul posto, senza ridisegnare: le righe che non tornano si nascondono, i
    // pazienti della stanza che non tornano si spengono
    filtroApplica() {
      const box = this.root.querySelector(".pzunita");
      if (!box) return;
      const q = this.stanzaEdit ? "" : normNome(this._filtro || "");
      box.classList.toggle("filtra", !!q);
      let righe = 0, viste = 0;
      for (const el of box.querySelectorAll("[data-cerca]")) {
        const si = !q || el.getAttribute("data-cerca").includes(q);
        el.classList.toggle("nofiltro", !si);
        if (el.classList.contains("pzrow")) { righe++; viste += si; }
      }
      const nessuno = box.querySelector(".pzfnone");
      if (nessuno) {
        nessuno.hidden = !(q && righe && !viste);
        nessuno.textContent = `Nessuno in lista con «${(this._filtro || "").trim()}»`;
      }
    }
    // Invio nel filtro apre il paziente solo se ne torna uno: mai a caso
    filtroUnico() {
      const box = this.root.querySelector(".pzunita");
      if (!box || !normNome(this._filtro || "")) return "";
      const eps = new Set([...box.querySelectorAll(".pzrow[data-cerca]:not(.nofiltro) .pzapri[data-ep], .stp[data-cerca]:not(.nofiltro)")]
        .map((el) => el.getAttribute("data-ep") || el.getAttribute("data-stp")));
      return eps.size === 1 ? [...eps][0] : "";
    }
    // Esc appartiene a chi lo sta usando: il menu «Sposta in…» o un trascinamento
    // (il gestore di Esc della finestra lo chiede prima di ridurre il pannello)
    escLocale() {
      return !!(this._stanzaPresa || this._stanzaMenu?.menu?.isConnected || this._promMenu?.menu?.isConnected || this._df?.pop?.isConnected || this._dfPresa
        || (this._filtro != null && !this.collapsed && !this.stanzaEdit && !!this.root.querySelector("#pzcerca")));   // il filtro: lo toglie filtroTasto
    }
    // Un solo gesto alla volta. Tocco o trascinamento? Sotto i 5px col mouse
    // (10 col dito) è un tocco, per quanto duri; oltre la soglia, un
    // trascinamento. Tenere premuto col dito (mezzo secondo): «Sposta in…».
    // Esc o un annullo del browser lasciano tutto com'era.
    stanzaGesto(e, { inizia, muovi, lascia, tocco, lungo, annulla }) {
      const id = e.pointerId, sx = e.clientX, sy = e.clientY;
      const soglia = e.pointerType === "mouse" ? 5 : 10;
      let mosso = false, partito = false;
      const via = () => {
        clearTimeout(tl);
        window.removeEventListener("pointermove", mm, true);
        window.removeEventListener("pointerup", su, true);
        window.removeEventListener("pointercancel", nulla, true);
        window.removeEventListener("keydown", kd, true);
        this._stanzaPresa = false;
      };
      const nulla = () => { via(); if (partito) annulla?.(); };
      const mm = (ev) => {
        if (ev.pointerId !== id) return;
        if (ev.pointerType === "mouse" && !ev.buttons) return nulla();   // bottone mollato fuori dalla finestra
        const dx = ev.clientX - sx, dy = ev.clientY - sy;
        if (!mosso) {
          if (Math.hypot(dx, dy) < soglia) return;
          mosso = true;
          clearTimeout(tl);
          if (inizia) { partito = true; inizia(); }
        }
        if (partito) muovi(dx, dy, ev);
      };
      const su = (ev) => {
        if (ev.pointerId !== id) return;
        via();
        if (partito) lascia(ev);
        else if (!mosso) tocco?.();
      };
      const kd = (ev) => { if (ev.key === "Escape") { ev.stopPropagation(); nulla(); } };
      const tl = lungo && e.pointerType !== "mouse" ? setTimeout(() => { if (!partito) { via(); lungo(); } }, 500) : 0;
      this._stanzaPresa = true;
      window.addEventListener("pointermove", mm, true);
      window.addEventListener("pointerup", su, true);
      window.addEventListener("pointercancel", nulla, true);
      window.addEventListener("keydown", kd, true);
    }
    stanzaPresa(e, box) {
      if (e.button !== 0 || this._stanzaPresa) return;
      this._rigaMossa = false;
      // una riga della lista si prende dal nome (cioè da tutta la riga): gli
      // altri suoi comandi restano i loro, e un tocco la apre come sempre
      const riga = !this.stanzaEdit && e.target.closest(".pzrow[data-riga]");
      if (riga) return e.target.closest("button:not(.pzapri), input") ? undefined : this.stanzaTrascinaPaziente(e, box, riga, true);
      if (e.target.closest("button, input, .stsnack, .pzrow, .pzfiltro, .pzpiede")) return;
      const map = box.querySelector(".stmap");
      if (!this.stanzaEdit) {
        // un letto occupato si prende tutto: è il suo paziente che si porta
        const chip = e.target.closest(".stp[data-stp]") || e.target.closest(".stbed.occ")?.querySelector(".stp[data-stp]");
        if (!chip) return;
        const ep = chip.getAttribute("data-stp");
        // l'episodio precedente non va nella stanza: un tocco lo apre, e basta
        if (chip.classList.contains("prec")) return this.stanzaGesto(e, { tocco: () => this.apriPaziente(ep, "esiti") });
        return this.stanzaTrascinaPaziente(e, box, chip, false);
      }
      const obj = e.target.closest("[data-letto], [data-area]");
      this.stanzaSeleziona(obj, map);
      if (obj) this.stanzaTrascinaOggetto(e, map, obj, !!e.target.closest("[data-strsz]"), e.target.closest("[data-stnome]"));
    }
    // in Modifica, l'oggetto toccato per ultimo mostra i suoi comandi
    stanzaSeleziona(obj, map) {
      const k = !obj ? null : obj.hasAttribute("data-letto") ? "letto:" + obj.getAttribute("data-letto") : "area:" + obj.getAttribute("data-area");
      if (k === this._stanzaSel) return;
      this._stanzaSel = k;
      map.querySelectorAll(".sel").forEach((x) => x.classList.remove("sel"));
      obj?.classList.add("sel");
    }
    // il bersaglio sotto il puntatore: un letto, un'area o la lista
    stanzaBersaglio(x, y) {
      for (const el of this.root.elementsFromPoint(x, y)) {
        const d = el.closest?.(".pzunita [data-drop]");
        if (d) return d;
      }
      return null;
    }
    // Il paziente si porta col suo nome accanto al puntatore (in basso a
    // destra, o dall'altra parte se lì non c'è posto): non copre mai il nome
    // del letto che si mira. Il posto si scrive solo quando lo si lascia.
    // Sopra un letto occupato si legge chi torna in lista. Preso dalla
    // stanza, in cima compare «Rimetti in lista» — anche a lista vuota: il
    // letto torna vuoto. Preso dalla lista (daLista: la sua riga), va solo
    // nella stanza.
    stanzaTrascinaPaziente(e, box, chip, daLista) {
      const ep = chip.getAttribute(daLista ? "data-riga" : "data-stp");
      let copia = null, sopra = null;
      const bersaglio = (x, y) => { const t = this.stanzaBersaglio(x, y); return daLista && t?.getAttribute("data-drop") === "tray" ? null : t; };
      const segna = (el) => {
        if (el === sopra) return;
        if (sopra) { sopra.classList.remove("over"); sopra.querySelector(".stfuori")?.remove(); }
        sopra = el;
        if (!el) return;
        el.classList.add("over");
        const altro = el.getAttribute("data-occep");
        if (!altro || altro === ep) return;
        el.insertAdjacentHTML("beforeend", `<span class="stfuori">${esc(el.getAttribute("data-occ") || "")} → in lista</span>`);
        // tutta dentro la mappa: se sporge da un lato, si sposta verso l'altro
        const lab = el.lastElementChild, cv = box.querySelector(".stcanvas").getBoundingClientRect(), lr = lab.getBoundingClientRect();
        const dx = Math.max(0, cv.left + 4 - lr.left) - Math.max(0, lr.right - cv.right + 4);
        if (dx) lab.style.marginLeft = dx + "px";
      };
      const pulisci = () => { segna(null); copia?.remove(); chip.classList.remove("via"); box.classList.remove("trascino", "dastanza"); };
      // la copia resta dentro i Pazienti: fuori non si lascia niente
      const metti = (ev) => {
        const mr = box.getBoundingClientRect(), w = copia.offsetWidth, h = copia.offsetHeight;
        let x = ev.clientX - mr.left + 12, y = ev.clientY - mr.top + 12;
        if (x + w > mr.width) x = ev.clientX - mr.left - 12 - w;
        if (y + h > mr.height) y = ev.clientY - mr.top - 12 - h;
        copia.style.transform = `translate(${Math.max(0, x)}px,${Math.max(0, y)}px)`;
      };
      this.stanzaGesto(e, {
        inizia: () => {
          const i = this.pazModello().info.get(ep);
          copia = document.createElement("div");
          copia.className = "stghost";
          copia.setAttribute("aria-hidden", "true");
          copia.textContent = i ? i.breve + i.coda : chip.querySelector(".stpn, .pznm")?.textContent || "";
          box.appendChild(copia);
          chip.classList.add("via");
          box.classList.add("trascino");
          if (daLista) this._rigaMossa = true;   // il clic che segue non apre il paziente
          else box.classList.add("dastanza");
        },
        muovi: (dx, dy, ev) => {
          metti(ev);
          segna(bersaglio(ev.clientX, ev.clientY));
        },
        lascia: (ev) => {
          const t = bersaglio(ev.clientX, ev.clientY);
          pulisci();
          if (t) this.stanzaSposta(ep, t.getAttribute("data-drop"));
        },
        // la riga si apre col suo clic (anche da tastiera); il paziente nella stanza qui
        tocco: daLista ? null : () => this.apriPaziente(ep, "esiti"),
        lungo: () => {
          if (daLista) this._rigaMossa = true;
          this.stanzaMenu(ep, daLista ? chip.querySelector("[data-posto]") || chip : chip);
        },
        annulla: pulisci,
      });
    }
    // Portare un paziente: sullo stesso posto non succede niente; su un letto
    // occupato il nuovo prende il letto e chi c'era torna in lista — niente
    // scambi, che spostano qualcuno dove non l'hai deciso tu. Si annulla.
    stanzaSposta(ep, dove) {
      const [tipo, id] = String(dove || "").split(":");
      const m = this.pazModello(), i = m.info.get(ep);
      if (!i || i.prec || !["tray", "area", "letto"].includes(tipo)) return;
      const da = i.posto;
      if (tipo === "tray" ? !da : da && da.tipo === tipo && da.id === id) return;   // è già lì
      const raw = store.get("stanza.posti.v1", {});
      const posti = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
      const foto = this.stanzaFoto(), nm = (x) => x.breve + x.coda;
      const nomeDi = (t, k) => (t === "letto" ? m.sala.letti : m.sala.aree).find((o) => o.id === k)?.nome || "";
      let testo = `${nm(i)} in ${tipo === "tray" ? "lista" : nomeDi(tipo, id)}`;
      if (tipo === "tray") delete posti[ep];
      else posti[ep] = { tipo, id, ts: Date.now() };
      if (tipo === "letto") {
        // chiunque altro reclami quel letto (anche chi ora non è in elenco) lo lascia
        for (const [k, v] of Object.entries(posti)) if (k !== ep && v?.tipo === "letto" && v.id === id) delete posti[k];
        const altro = m.perLetto[id];
        if (altro && altro !== ep) testo += ` · ${nm(m.info.get(altro))} in lista`;
      }
      if (!store.set("stanza.posti.v1", posti)) { this.message = "Il posto NON è stato salvato: la memoria di questo browser è piena o bloccata."; return this.render(); }
      this.stanzaAnnullabile(testo, foto);
      this.render();
    }
    // la fotografia di prima, per «Annulla» (con l'elenco, anche i promemoria)
    stanzaFoto(conPazienti) {
      return { sala: store.get("stanza.v1", null), posti: store.get("stanza.posti.v1", null), pazienti: conPazienti ? store.get("patients.v1", null) : undefined,
               prom: conPazienti ? store.get(PROM, null) : undefined, stato: conPazienti ? store.get(STATO, null) : undefined };
    }
    stanzaAnnullabile(testo, foto) {
      clearTimeout(this._stanzaAnnT);
      this._stanzaAnn = { testo, foto, fino: Date.now() + 8000 };
      this._stanzaAnnT = setTimeout(() => { this._stanzaAnn = null; this.root.querySelector(".stsnack")?.remove(); }, 8000);
    }
    stanzaAnnulla() {
      const a = this._stanzaAnn;
      if (!a) return;
      clearTimeout(this._stanzaAnnT);
      this._stanzaAnn = null;
      if (typeof a.foto === "function") a.foto();   // un passo solo da disfare: il promemoria fatto torna
      else {
        store.set("stanza.v1", a.foto.sala);
        store.set("stanza.posti.v1", a.foto.posti);
        if (a.foto.pazienti !== undefined) store.set("patients.v1", a.foto.pazienti);
        if (a.foto.prom !== undefined) store.set(PROM, a.foto.prom);
        if (a.foto.stato !== undefined) store.set(STATO, a.foto.stato);
      }
      this.render();
    }
    // «Sposta in…»: i letti e le sedie vuoti, per nome, poi quelli occupati
    // (chi c'è torna in lista), le aree; per chi ha già un posto «Rimetti in
    // lista»; in fondo, a parte, «Da fare…» e «Togli dall'elenco» (come
    // l'icona e la ✕ della riga, che chi sta nella stanza non ha più). Col
    // tasto destro, tenendo premuto col dito, con Maiusc+F10 o dal ▾ della
    // riga. Frecce, Invio, Esc.
    stanzaMenu(ep, anchor) {
      const aperto = this._stanzaMenu;
      if (aperto && aperto.ep === ep && aperto.menu.isConnected) return;
      this.stanzaChiudiMenu();
      const m = this.pazModello(), i = m.info.get(ep), wrap = this.root.querySelector(".wrap");
      if (!i || i.prec || !wrap || !anchor?.isConnected) return;
      const qui = i.posto, attuale = (tipo, id) => !!qui && qui.tipo === tipo && qui.id === id;
      const voce = (dove, testo, det, cur) => `<button type="button" role="menuitem" class="stmi${cur ? " cur" : ""}" data-dove="${esc(dove)}"${cur ? ' aria-disabled="true"' : ""}><span>${esc(testo)}</span><small>${esc(cur ? "qui ora" : det)}</small></button>`;
      const inArea = (a) => Object.values(m.posti).filter((v) => v.tipo === "area" && v.id === a.id).length;
      const letti = [...m.sala.letti].sort((a, b) => a.nome.localeCompare(b.nome, "it", { numeric: true }));
      const gruppi = [
        letti.filter((l) => !m.perLetto[l.id]).map((l) => voce("letto:" + l.id, l.nome, "vuoto")),
        letti.filter((l) => m.perLetto[l.id]).map((l) => {
          const o = m.info.get(m.perLetto[l.id]);
          return voce("letto:" + l.id, l.nome, "al posto di " + o.breve + o.coda, attuale("letto", l.id));
        }),
        m.sala.aree.map((a) => voce("area:" + a.id, a.nome, inArea(a) ? `${inArea(a)} ${inArea(a) === 1 ? "paziente" : "pazienti"}` : "", attuale("area", a.id))),
        qui ? [voce("tray", "Rimetti in lista", "")] : [],
        [voce("dafare", "Da fare…", dfAperte(ep, m.df).length ? String(dfAperte(ep, m.df).length) : ""), voce("togli", "Togli dall'elenco", "")],
      ].filter((g) => g.length);
      const titolo = `Sposta ${i.breve + i.coda} in…`;
      wrap.insertAdjacentHTML("beforeend", `<div class="stmenu" role="menu" aria-label="${esc(titolo)}"><div class="stmenuhd" aria-hidden="true">${esc(titolo)}</div>${
        gruppi.map((g) => g.join("")).join('<div class="stmsep" role="separator"></div>')}</div>`);
      const menu = wrap.lastElementChild;
      // sotto chi l'ha aperto; se non c'è posto sotto, sopra; sempre dentro lo schermo
      const wr = wrap.getBoundingClientRect(), ar = anchor.getBoundingClientRect();
      let y = ar.bottom + 4;
      if (y + menu.offsetHeight > innerHeight - 8) y = Math.max(8, ar.top - 4 - menu.offsetHeight);
      menu.style.left = Math.max(8, Math.min(ar.left, innerWidth - menu.offsetWidth - 8)) - wr.left + "px";
      menu.style.top = y - wr.top + "px";
      const voci = () => [...menu.querySelectorAll(".stmi:not([aria-disabled])")];
      menu.addEventListener("click", (e) => {
        const b = e.target.closest(".stmi");
        if (!b || b.hasAttribute("aria-disabled")) return;
        this.stanzaChiudiMenu();
        const dove = b.getAttribute("data-dove");
        if (dove === "togli") return this.stanzaArchivia(ep);
        // «Da fare…»: la lista sotto la sua icona (nella riga, o nel letto), o sotto il paziente
        if (dove === "dafare") return this.dfApri(ep, this.dfAncora(ep) || anchor);
        // il fuoco segue il paziente: nel posto nuovo, o sulla sua riga
        this._stanzaFocus = dove === "tray" ? `.pzrow[data-riga="${CSS.escape(ep)}"] .pzapri` : `.stmap .stp[data-stp="${CSS.escape(ep)}"]`;
        this.stanzaSposta(ep, dove);
      });
      menu.addEventListener("keydown", (e) => {
        const l = voci(), k = l.indexOf(this.root.activeElement);
        if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); l[(k + (e.key === "ArrowDown" ? 1 : l.length - 1)) % l.length]?.focus(); }
        else if (e.key === "Home" || e.key === "End") { e.preventDefault(); l[e.key === "Home" ? 0 : l.length - 1]?.focus(); }
        else if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); this.stanzaChiudiMenu(true); }
        else if (e.key === "Tab") this.stanzaChiudiMenu();
      });
      const fuori = (e) => { if (!e.composedPath().includes(menu)) this.stanzaChiudiMenu(); };
      window.addEventListener("pointerdown", fuori, true);
      this._stanzaMenu = { menu, anchor, ep, fuori };
      voci()[0]?.focus();
    }
    stanzaChiudiMenu(ritorna) {
      const a = this._stanzaMenu;
      if (!a) return;
      this._stanzaMenu = null;
      window.removeEventListener("pointerdown", a.fuori, true);
      a.menu.remove();
      if (ritorna && a.anchor?.isConnected) a.anchor.focus();
    }
    // togliere dall'elenco e svuotarlo: niente conferme, si annulla
    stanzaArchivia(ep) {
      const p = knownPatients().find((x) => x.ep === ep), foto = this.stanzaFoto(true);
      if (!archiviaPaziente(ep, true)) return;
      this.stanzaAnnullabile(`${p?.name || "Paziente"}: tolto dall'elenco`, foto);
      this.render();
    }
    stanzaSvuota() {
      const foto = this.stanzaFoto(true);
      forgetPatients();
      store.set("stanza.posti.v1", {});   // anche i posti e i promemoria: l'elenco riparte da zero
      store.set(PROM, {});
      store.set(STATO, {});
      this.dfChiudi();
      this.mostraArch = false;
      this.stanzaAnnullabile("Elenco svuotato", foto);
      this.render();
    }
    // In Modifica: si spostano letti, sedie e aree (o si allarga un'area dall'angolo)
    // di cella in cella, sempre dentro la pianta. Dove finirebbe sopra un
    // altro si fa rosso e, lasciato lì, torna com'era. Un tocco fermo sul nome
    // lo rende scrivibile.
    stanzaTrascinaOggetto(e, map, obj, allarga, nome) {
      const plan = map.querySelector(".stplan");
      const tipo = obj.hasAttribute("data-letto") ? "letto" : "area";
      const id = obj.getAttribute("data-" + tipo);
      const sala = this.stanzaSala(), o = (tipo === "letto" ? sala.letti : sala.aree).find((x) => x.id === id);
      if (!plan || !o) return;
      const { cols, rows, aw, ah } = PIANTA;
      const u = plan.getBoundingClientRect().width / cols;   // in Modifica la pianta è intera
      const altri = this.stanzaRettangoli(sala).filter((x) => x.id !== id);
      const lim = (v, a, b) => Math.max(a, Math.min(b, v));
      const { w: w0, h: h0 } = tipo === "letto" ? misuraLetto(o) : o;
      let q = { c: o.c, r: o.r, w: w0, h: h0 }, ok = true;
      this.stanzaGesto(e, {
        inizia: () => { obj.classList.add("drag"); map.classList.add("trascino"); },
        muovi: (dx, dy) => {
          const dc = Math.round(dx / u), dr = Math.round(dy / u);
          q = allarga
            ? { c: o.c, r: o.r, w: lim(w0 + dc, aw, cols - o.c), h: lim(h0 + dr, ah, rows - o.r) }
            : { c: lim(o.c + dc, 0, cols - w0), r: lim(o.r + dr, 0, rows - h0), w: w0, h: h0 };
          ok = !altri.some((x) => troppoVicini(x, q));
          for (const k of ["c", "r", "w", "h"]) obj.style.setProperty("--" + k, q[k]);
          obj.classList.toggle("bad", !ok);
        },
        lascia: () => {
          if (!ok || (q.c === o.c && q.r === o.r && q.w === w0 && q.h === h0)) return this.render();
          // si riparte da quella salvata adesso: un nome appena scritto (salvato uscendo dal campo) resta
          const ora = this.stanzaSala(), x = (tipo === "letto" ? ora.letti : ora.aree).find((y) => y.id === id);
          if (!x) return this.render();
          x.c = q.c; x.r = q.r;
          if (tipo === "area") { x.w = q.w; x.h = q.h; }
          if (this.stanzaScrivi(ora)) this.render();
        },
        tocco: () => { if (nome) this.stanzaRinomina(nome); },
        annulla: () => this.render(),
      });
    }
    stanzaRinomina(nomeEl) {
      const obj = nomeEl.closest("[data-letto], [data-area]");
      if (!obj) return;
      const tipo = nomeEl.getAttribute("data-stnome"), id = obj.getAttribute("data-" + tipo);
      const o = (tipo === "letto" ? this.stanzaSala().letti : this.stanzaSala().aree).find((q) => q.id === id);
      if (!o) return;
      this._stanzaRinomina = { tipo, id, testo: o.nome, seleziona: true };
      this._stanzaSel = tipo + ":" + id;
      this.render();
    }
    // Invio o uscire dal campo salvano, Esc lascia il nome di prima.
    stanzaChiudiNome(inp, salva, tasto) {
      const r = this._stanzaRinomina;
      if (!r) return;
      this._stanzaRinomina = null;
      const sala = this.stanzaSala();
      const o = (r.tipo === "letto" ? sala.letti : sala.aree).find((q) => q.id === r.id);
      if (!o) return this.render();
      const nuovo = inp.value.replace(/\s+/g, " ").trim().slice(0, 24);
      if (salva && nuovo && nuovo !== o.nome) {
        o.nome = nuovo;
        if (!this.stanzaScrivi(sala)) return;
      }
      if (tasto) {   // da tastiera: si ridisegna e si resta sul nome
        this.render();
        return [...this.root.querySelectorAll("[data-stnome]")].find((s) => s.closest(`[data-${r.tipo}]`)?.getAttribute(`data-${r.tipo}`) === r.id)?.focus();
      }
      // uscendo col mouse NON si ridisegna: il clic che ha tolto il fuoco deve arrivare
      const t = document.createElement("template");
      t.innerHTML = this.stanzaNome(r.tipo, o);
      if (inp.isConnected) inp.replaceWith(t.content.firstChild);
    }
    // il nome che si stava scrivendo, quando si esce da Modifica senza Invio
    stanzaSalvaBozza() {
      const r = this._stanzaRinomina;
      if (!r) return;
      this._stanzaRinomina = null;
      const nuovo = String(r.testo || "").replace(/\s+/g, " ").trim().slice(0, 24);
      const sala = this.stanzaSala(), o = (r.tipo === "letto" ? sala.letti : sala.aree).find((q) => q.id === r.id);
      if (o && nuovo && nuovo !== o.nome) { o.nome = nuovo; store.set("stanza.v1", sala); }
    }
    // Il primo posto libero per il nuovo arrivato: riga per riga dall'angolo in
    // alto a sinistra, meglio se con una cella d'aria intorno.
    stanzaPostoLibero(sala, w, h) {
      const presi = this.stanzaRettangoli(sala);
      for (const g of [1, 0]) {
        for (let r = 0; r + h <= PIANTA.rows; r++) {
          for (let c = 0; c + w <= PIANTA.cols; c++) if (!presi.some((q) => troppoVicini(q, { c, r, w, h }, g))) return { c, r };
        }
      }
      return null;
    }
    // tipo: "letto", "sedia" o "area"; la sedia è un letto con forma: "sedia"
    stanzaAggiungi(tipo) {
      const sala = this.stanzaSala(), area = tipo === "area", sedia = tipo === "sedia";
      const lista = area ? sala.aree : sala.letti.filter((l) => (l.forma === "sedia") === sedia);
      if ((area ? sala.aree : sala.letti).length >= (area ? 30 : 60)) { this.message = area ? "Al massimo 30 aree." : "Al massimo 60 fra letti e sedie."; return this.render(); }
      // un'area nasce 8 × 5; se non ci sta, piccola quanto può
      const { w: lw, h: lh } = misuraLetto({ forma: tipo });
      const misure = area ? [[8, 5], [PIANTA.aw, PIANTA.ah]] : [[lw, lh]];
      let p = null, w = 0, h = 0;
      for (const [mw, mh] of misure) if ((p = this.stanzaPostoLibero(sala, mw, mh))) { w = mw; h = mh; break; }
      const piena = "La stanza è piena: togli o sposta qualcosa.";
      if (!p) { this.message = piena; return this.render(); }
      if (this.message === piena) this.message = null;
      let id;
      do id = Math.random().toString(36).slice(2, 8); while (!id || sala.letti.some((o) => o.id === id) || sala.aree.some((o) => o.id === id));
      // il nome segue quello dell'ultimo: dopo «Box 1» viene «Box 2», dopo «B3» «B4»
      const ultimo = /^(.*?)(\d+)$/.exec(lista[lista.length - 1]?.nome || "");
      const base = ultimo ? ultimo[1] : area ? "Area " : sedia ? "Sedia " : "Letto ";
      const usati = new Set(lista.map((o) => o.nome.toLowerCase()));
      let n = ultimo ? +ultimo[2] + 1 : 1;
      while (usati.has(`${base}${n}`.toLowerCase())) n++;
      const nome = `${base}${n}`.slice(0, 24);
      if (area) sala.aree.push({ id, c: p.c, r: p.r, w, h, nome });
      else sala.letti.push({ id, c: p.c, r: p.r, nome, ...(sedia && { forma: "sedia" }) });
      if (!this.stanzaScrivi(sala)) return;
      const k = area ? "area" : "letto";
      this._stanzaRinomina = { tipo: k, id, testo: nome, seleziona: true };   // appena messo, si battezza
      this._stanzaSel = k + ":" + id;
      this.render();
    }
    stanzaElimina(tipo, id) {
      const sala = this.stanzaSala();
      const o = (tipo === "letto" ? sala.letti : sala.aree).find((x) => x.id === id);
      if (!o) return;
      const foto = this.stanzaFoto();
      if (tipo === "letto") sala.letti = sala.letti.filter((x) => x.id !== id);
      else sala.aree = sala.aree.filter((x) => x.id !== id);
      if (this._stanzaRinomina?.id === id) this._stanzaRinomina = null;
      if (!this.stanzaScrivi(sala)) return;
      // chi ci stava torna fra i da sistemare (lo farebbe comunque la pulizia: qui si vede subito)
      const posti = store.get("stanza.posti.v1", {}) || {};
      for (const [ep, v] of Object.entries(posti)) if (v?.tipo === tipo && v.id === id) delete posti[ep];
      store.set("stanza.posti.v1", posti);
      this.stanzaAnnullabile(tipo === "area" ? `Eliminata l'area ${o.nome}` : o.forma === "sedia" ? `Eliminata la sedia ${o.nome}` : `Eliminato il letto ${o.nome}`, foto);
      this.render();
    }

    // Il Registro si apre col numero di versione in fondo, che ora c'è su ogni
    // schermata: dopo un banner rosso è lì che si va a vedere cos'è successo,
    // e due ‹ di distanza erano due di troppo.
    registroHtml() {
      if (!this.showLog) return "";
      return `<details class="reg" open><summary>Registro <button class="mini" id="copylog" title="Copia il registro negli appunti (il quesito viene omesso)">⧉ Copia</button></summary><div class="log" aria-live="polite">${esc(this.logLines.join("\n"))}</div></details>`;
    }

    viewIdle(patientName, ep) {
      const cat = fullCatalog();
      // On the ER worklist (no patient open) nothing can be ordered: show no
      // exams at all rather than a picker that would dead-end.
      const canOrder = this.pageType === "exam" || this.pageType === "crea" ||
        (this.pageType === "patient" && !!(this.entry && (this.entry.labUrl || this.entry.radioUrl)));
      if (!canOrder) {
        const extra = this.viewPrint();
        return `${extra}<div class="hint" style="margin:2px 0 0">Apri un paziente per creare richieste.</div>`;
      }
      // i tre pacchetti sempre in testa, poi gli ultimi quesiti usati
      const quesiti = [...PACCHETTI.map((p) => p.q), ...store.get("quesiti", QUESITI_DEFAULT).filter((q) => !this.pacchettoDi(q))].slice(0, 6);
      const canOneClick = this.pageType === "patient" || this.pageType === "crea";

      // Receipt banner: the moment of decision on the landing page must show
      // the full verified accounting, not just what this list happens to show.
      // …e quale quesito è partito, in una riga: quello del triage o il tuo.
      let receiptSec = "";
      let receipt = null;
      let live = null;
      if (this.pageType === "exam") {
        live = examModel(document, location.href);
        receipt = freshReceipt(live.richiestaId);
        if (receipt) {
          const n = receipt.items.length;
          const qd = quesitoDetto(receipt.quesito);
          receiptSec = `
            <div class="banner ok"><b>✓ ${n} ${n === 1 ? "esame" : "esami"} in carrello, ${n === 1 ? "verificato" : "verificati"}</b>${
              qd ? `<span class="qline">${esc(qd)}</span>` : ""}</div>`;
        }
      }

      // Una richiesta di questo paziente mandata e non ancora confermata (dopo
      // «Chiudi», o lasciata in revisione): una riga discreta, e un tocco porta
      // al suo carrello. Quella della ricevuta qui sopra lo dice già da sé.
      // Sul SUO carrello (la prima, se ce ne sono altre) la riga ha le sue due
      // azioni, «Conferma e stampa» e «Svuota»: riaperta più tardi la
      // richiesta non ha più né ricevuta né resoconto, e senza di loro era un
      // vicolo cieco — i bottoni del gestionale stanno sotto la finestra.
      let daConfSec = "";
      {
        const sua = this.pageType === "exam" ? param(location.href, "RICHIESTA_ID") : null;
        const aperte = nonConfermateQui().filter((x) => !(receipt && x.rid === String(receipt.richiestaId)));
        const x = aperte.find((y) => y.rid === sua) || aperte[0];
        if (x) {
          let u = "";
          try { u = x.listUrl && new URL(x.listUrl).origin === location.origin && !/[?&](Insert|Delete)=/.test(x.listUrl) ? x.listUrl : ""; } catch { u = ""; }
          const qui = !!sua && sua === x.rid;
          const quanti = x.n ? ` (${x.n} ${x.n === 1 ? "esame" : "esami"})` : "";
          const az = qui ? this.daConfAzioni() : "";
          daConfSec = `<div class="daconf${az ? " az" : ""}"><i class="ddot"></i><span>${qui ? `Questa richiesta${quanti} è ancora da confermare` : `Richiesta delle ${esc(hhmm(x.ts))}${quanti} ancora da confermare`}${
            aperte.length > 1 ? ` · e altre ${aperte.length - 1}` : ""}</span>${
            // (sulla sua pagina ma su una sezione senza la Conferma: il carrello dov'è)
            az || (u && (!qui || param(u, "RISORSA_ID") !== param(location.href, "RISORSA_ID")) ? `<button class="lnk" id="apridaconf" data-url="${esc(u)}">apri il carrello</button>` : "")}</div>`;
        } else if (this._daconf?.vuoto && this._daconf.rid === sua) {
          // letta vuota dal server e dimenticata: la riga lo dice, poi se ne va
          daConfSec = `<div class="daconf"><i class="ddot"></i><span>${esc(this._daconf.testo)}</span></div>`;
        }
      }

      const quesitoSec = canOneClick ? `
        <div class="sec">
          <div class="lbl">Quesito diagnostico</div>
          <div class="qrow">
            <input id="q" type="text" placeholder="Es. dolore toracico in atto…" value="${esc(this._q || "")}">
            <div class="qchips">${quesiti.map((q) => {
              const pk = this.pacchettoDi(q);
              if (!pk) return `<button class="chip q" data-q="${esc(q)}">${esc(q)}</button>`;
              const on = this.pacchetto === pk.q;
              // quanti esami porta: quelli che questo computer ha in catalogo
              const quanti = pk.items.filter(([r, c]) => cat[r]?.items?.[c]).length;
              return `<button class="chip q pk ${on ? "on" : ""}" data-q="${esc(q)}" aria-pressed="${on}" title="${on ? "Tocca di nuovo per togliere quesito e pacchetto" : "Scrive il quesito e spunta: "}${esc(on ? "" : pk.items.map(([r, c]) => displayLabel(r, c)).join(", "))}">${esc(q)}<span class="pkn">&nbsp;· ${quanti}</span></button>`;
            }).join("")}</div>
          </div>
        </div>` : "";

      // On the exam page show what is already in the cart on THIS resource,
      // plus (from the receipt) what was verified on other resources. Un
      // emogas entrato nella versione di sempre perché qui la «- NEW» non c'è
      // lo dice accanto al nome: «al posto di EGA VENOSA NEW».
      let cartSec = "";
      if (this.pageType === "exam" && live) {
        const inCart = live.exams.filter((e) => e.isDel);
        const here = new Set(inCart.map((e) => e.code));
        const elsewhere = receipt ? receipt.items.filter((i) => i.res !== live.res && !here.has(i.code)) : [];
        const alPosto = (res, code) => (receipt ? receipt.items.find((i) => String(i.res) === String(res) && String(i.code) === String(code)) : null)?.alPostoDi || "";
        const nota = (al) => (al ? `<small class="alposto">al posto di ${esc(al)}</small>` : "");
        cartSec = `
          <div class="sec">
            <div class="lbl">Già nel carrello — ${esc(live.res ? risorsaCorta(live.res) : "?")} (${inCart.length})</div>
            <div class="chips">
              ${inCart.map((e) => `<span class="chip cart">${esc(shortLabel(e.label))}${nota(alPosto(live.res, e.code))}</span>`).join("") || `<span class="hint">Ancora nessun esame su questa risorsa.</span>`}
              ${elsewhere.map((i) => `<span class="chip ghosted" title="verificato su ${esc(risorsaCorta(i.res))}">${esc(i.display || shortLabel(i.label))} · ${esc(risorsaCorta(i.res))} ✓${nota(i.alPostoDi)}</span>`).join("")}
            </div>
          </div>`;
      }

      const pendingSec = this.pending ? `
        <button class="btn confirm" id="goqueued" style="margin-bottom:12px">→ Conferma ${esc(this.pending.next.kind === "radio" ? "la radiologia" : "il laboratorio")} (${this.pending.next.count})</button>` : "";
      const n = this.selected.size;
      // La Conferma del gestionale, dalla ricevuta: il bottone che conclude.
      // Il bottone che fa uscire gli esami dice per chi: «Conferma per ROSSI M. · 68 M · 6 esami»
      const perChi = this.idBreve();
      const confermaOra = receipt && live && live.confirmButton
        ? `<div class="btnrow"><button class="btn primary" id="confirmnow" title="Preme la Conferma del gestionale per questa richiesta, poi parte la stampa">${esc(perChi ? `Conferma per ${perChi}` : "Conferma e stampa")}</button></div>` : "";

      // La ricevuta mostra il carrello e un bottone solo. La griglia degli
      // esami resta dietro «+ aggiungi»: aggiungere ancora è l'eccezione.
      if (receipt && !this.aggiungi && !n) {
        const nota = this.notaHtml();
        return `
          ${pendingSec}
          ${daConfSec}
          ${receiptSec}
          ${cartSec}
          <button class="lnk piu" id="aggiungi" title="Aggiungi altri esami a questa richiesta">+ aggiungi</button>
          ${nota || confermaOra ? `<div class="commit">${nota}${confermaOra}</div>` : ""}
        `;
      }

      // Un gruppo per laboratorio, col suo nome corto: dentro, prima i
      // profili rapidi di quel laboratorio, poi gli esami uno per uno. Nel
      // gruppo RX c'è il quesito della radiologia, che non è quello del lab.
      const gruppi = {};
      const gruppo = (r) => (gruppi[RES_SHORT[r] || r] = gruppi[RES_SHORT[r] || r] || { profili: [], esami: [] });
      PRESETS.forEach((p, i) => {
        if (!p.items.every(([r, c]) => cat[r]?.items?.[c])) return;
        const on = p.items.every(([r, c]) => this.isSel(r, c));
        gruppo(p.items[0][0]).profili.push(`<button class="chip preset ${on ? "on" : ""}" data-preset="${i}">${esc(p.name)}</button>`);
      });
      // accanto al nome, in grigio, quando è già stato fatto (l'ora della
      // richiesta) o da quanto aspetta: un doppione si vede prima di spuntarlo
      const ultimi = this.ultimiEsami();
      for (const [r, c] of SINGLES) {
        if (!cat[r]?.items?.[c]) continue;
        const on = this.isSel(r, c), ult = this.suffissoEsame(ultimi, examLabel(r, c));
        gruppo(r).esami.push(`<button class="opt ${on ? "on" : ""}" data-res="${esc(r)}" data-code="${esc(c)}" title="${esc(examLabel(r, c))} — ${esc(RES_SHORT[r] || r)}${ult ? `\n${esc(ult.titolo)}` : ""}"><span class="box">✓</span><span class="nm">${esc(displayLabel(r, c))}</span>${ult ? ult.html : ""}</button>`);
      }
      const qrxHtml = canOneClick
        ? `<input id="qrx" class="qrx" type="text" placeholder="Quesito RX — se vuoto, quello sopra" value="${esc(this._qrx || "")}">` : "";
      const singles = Object.entries(gruppi).map(([nome, g]) => `
        <div class="grouphdr">${esc(nome)}</div>
        ${nome === RES_SHORT[RES.RX] ? qrxHtml : ""}
        ${g.profili.length ? `<div class="gchips">${g.profili.join("")}</div>` : ""}
        ${g.esami.join("")}`).join("");

      // Un bottone solo: «Conferma e stampa · N esami». «solo carrello» (che
      // si ferma sul carrello e lascia la Conferma a te) è un link accanto.
      const nTxt = n === 1 ? "1 esame" : `${n} esami`;
      const twoLegs = this.pageType === "patient" &&
        [...this.selected.values()].some((i) => RADIO_SET.includes(i.res)) &&
        [...this.selected.values()].some((i) => !RADIO_SET.includes(i.res));
      const confirmLabel = `${perChi ? `Conferma per ${perChi}` : "Conferma e stampa"}${!n ? "" : twoLegs ? ` · 2 richieste, ${nTxt}` : ` · ${nTxt}`}`;

      const problems = this.computeProblems();
      // sulla ricevuta, finché non scegli niente, il bottone resta la Conferma del gestionale
      const bottoni = !n && confermaOra ? confermaOra : `
          <div class="btnrow">
            <button class="btn primary" id="goconfirm" title="Aggiunge e verifica gli esami, preme Conferma e avvia la stampa" ${n && !problems.confirm.length ? "" : "disabled"}>${esc(confirmLabel)}</button>
            <button class="lnk" id="go" title="Aggiunge e verifica gli esami e si ferma sul carrello: la Conferma la premi tu nel gestionale" ${n && !problems.go.length ? "" : "disabled"}>solo carrello</button>
          </div>`;
      return `
        ${pendingSec}
        ${daConfSec}
        ${receiptSec}
        ${quesitoSec}
        ${cartSec}
        <div class="sec acsec">${this.viewBrowse(cat)}</div>
        <div class="sec">
          <div class="lbl">Esami</div>
          <div class="grid">${singles}</div>
        </div>
        ${this.viewPrint()}

        <div class="commit">
          ${this.notaHtml()}
          <div id="problems">${problems.go[0] ? `<div class="problem">${esc(problems.go[0])}</div>` : ""}</div>
          ${bottoni}
        </div>
      `;
    }

    // Patient page: reprint any richiesta's PDFs (labels → label printer,
    // exam list → normal printer) through the sequential wizard.
    viewPrint() {
      if (this.pageType !== "patient") return "";
      const map = printModel(document, location.href);
      const rids = richiesteStampabili(map);
      if (!rids.length) return "";
      // (con una richiesta sola, la sua riga basta)
      const ultime = rids.length > 1 ? ultimeRichieste(map) : [];
      const receipt = freshReceipt(null);
      const hot = receipt && map[receipt.richiestaId] ? receipt.richiestaId : null;
      const rows = rids.slice(0, 6).map((rid) => {
        const m = printMeta(map, rid);
        const exams = m.exams.join(", ");
        return `<button class="prow ${rid === hot ? "hot" : ""}" data-print="${esc(rid)}" title="Richiesta ${esc(rid)} — ${esc(printLabelFor(map, rid))}">
          <span class="pline1">🖨 <b>${esc(m.when || "richiesta " + rid)}</b> <small>${esc(printLabelFor(map, rid))}</small></span>
          ${exams ? `<span class="pline2">${esc(exams)}</span>` : ""}
        </button>`;
      }).join("");
      return `
        <div class="sec">
          <div class="lbl">Stampa</div>
          ${ultime.length ? `<button class="lnk ultima" id="stultima" title="${esc(ultime.map((r) => printMeta(map, r).when || "richiesta " + r).join(" e "))}">Stampa l'ultima richiesta</button>` : ""}
          <div class="rlist">${rows}</div>

        </div>`;
    }

    // I referti che gli Esiti mostrano: quelli di laboratorio no — dicono quello
    // che la tabella dei Valori dice già, e in mezzo agli altri facevano
    // perdere l'ECG e la radiologia. Salvare, resettare e contare guardano
    // solo questi.
    refertiMostrati() {
      return this.esiti.filter((e) => e.kind === "referto" && refertoTipo(e) !== "lab");
    }
    // …ma solo dove la tabella dei Valori li può mostrare: c'è una tabella, o
    // c'è da dove leggerla (estensione e portale). Altrimenti — bookmarklet,
    // niente portale — un referto di laboratorio è l'unico posto dove quei
    // valori si vedono: resta, raccolto sotto «Laboratorio (N)». Un esito
    // finale non sparisce mai.
    refertiLab() {
      const tabella = !!(this.storico && this.storico.righe && this.storico.righe.length)
        || this.esiti.some((e) => e.kind === "valori" && ((tabStore.get(this.risKey(e.id), null) || {}).rows || []).length);
      if (tabella || this.conPortale()) return [];
      return this.esiti.filter((e) => e.kind === "referto" && refertoTipo(e) === "lab");
    }
    // I referti che «Salva i referti» (nel menu ⋯, solo estensione) può ancora
    // tenere: sulla schermata Esiti, quelli non ancora salvati.
    refertiDaSalvare() {
      if (this.view !== "esiti" || !hasExt() || this.runState) return [];
      return this.refertiMostrati().filter((e) => !(this.refCache || {})[e.id]);
    }
    // Un giro di esami che sta mandando (o che riprende dopo un cambio pagina):
    // ricaricare l'estensione adesso lo ucciderebbe a metà.
    giroInCorso() {
      // (anche un ordine che manda o aspetta le etichette in un'altra scheda)
      return this.runState === "running" || !!tabStore.get(CORSA, null)
        || this.ordini.some((x) => ORDINE_APERTO.has(x.stato));
    }

    // Values are fetched once per accesso and kept for the tab, so reopening
    // is instant; ↻ pulls them again while the lab is still completing.
    // ESITI — one chronological list: values we can read, and reported PDFs.
    // Row = open it (values expand / PDF opens). The 2-line preview under a
    // saved row is its own target: it opens the full values screen.
    // La tabella degli Esiti: i prelievi letti in QUESTA scheda del browser
    // (sempre, anche senza estensione) più la scheda clinica in archivio
    // quando è di questo paziente — il portale, e i prelievi letti altrove.
    // Una tabella sola: per gruppo, una colonna a prelievo, il più recente a
    // sinistra. Non c'è più una riga per richiesta da aprire.
    datiEsiti() {
      let dati = normalizzaStorico(this.storico || null);
      for (const e of this.esiti) {
        if (e.kind !== "valori") continue;
        const v = tabStore.get(this.risKey(e.id), null);
        const t = v && v.rows ? prelievoComeTabella(risMeta(e), v.rows, v.cf || "", v.scartate) : null;
        // la scheda in archivio ha già questi prelievi: la fusione non cambia
        // niente. Se l'archivio manca (o non ha risposto) restano in tabella.
        if (t) dati = fondiStorico(t, dati);
      }
      return dati && dati.righe && dati.righe.length ? dati : null;
    }

    // «↺ Reset»: si dimentica tutto quello che si era letto di questo
    // paziente — i prelievi in questa scheda del browser e la scheda clinica
    // in archivio — e si ricomincia da «⭳ Carica i valori». I segni del
    // medico restano: sono suoi, e ritrovano le stesse celle.
    resetValori() {
      const ep = this.episodeId || "x";
      for (const k of [...tabStore.keys(`ris.${ep}.`), ...tabStore.keys(`visto.${ep}.`)]) tabStore.del(k);
      this.rottiTab.clear();
      if (hasExt()) ask({ t: "delStorico", chiave: this.chiavePaz(), ep: this.episodeId, nome: this.nomePaziente() || "" }).catch(() => {});
      this.storico = null; this.storicoAltri = ""; this.storicoDaConfermare = false;
      this.esiti = esitiModel(document, location.href);   // le righe «già letti» se ne vanno coi loro valori
      this.log(`${now()}  valori azzerati: si rileggono da zero`);
      this.message = { ok: "Valori dimenticati." };
      this.render();
    }

    // Gli Esiti sotto gli occhi del medico (la finestra aperta): da qui in poi
    // niente è più «nuovo» nella riga dei Pazienti. I valori nuovi non ancora
    // segnati «Letto» restano, e dicono quanti sono fuori range (il pallino rosso).
    segnaEsitiVisti(nuovi, fuori) {
      const ep = this.epDiQuesta();
      if (!ep) return;
      const guarda = !this.collapsed && !this.runState, ora = Date.now();
      const s = statoDi(ep) || {};
      const v = s.valori || {};
      if (v.nuovi === nuovi && v.fuori === fuori && (!guarda || ora - (s.esitiVisto || 0) < 15e3)) return;
      scriviStato(ep, (x) => ({ ...x, valori: { nuovi, fuori }, ...(guarda ? { esitiVisto: ora } : {}) }));
    }
    viewEsiti() {
      const open = new Set(tabStore.get(this.refKey(), []));
      const cached = this.refCache || {};
      const busy = this.refBusy || {};
      const prelievi = this.esiti.filter((e) => e.kind === "valori");
      const referti = this.refertiMostrati();
      const lab = this.refertiLab();
      const st = this.datiEsiti();
      this.nColEsiti = st ? st.date.length : 0;
      // con l'estensione e il link dello storico, il portale è una fonte anche
      // quando nel gestionale non c'è niente da leggere (tutto già refertato)
      const conPortale = this.conPortale();
      // la tabella del portale è arrivata: allora non c'è più niente «da leggere»
      const dalPortale = !!(this.storico && (this.storico.periodo || this.storico.paziente?.idMPI));
      if (!prelievi.length && !referti.length && !lab.length && !st && !conPortale && !richiesteInAttesa(document).length) return `<div class="hint">Nessun esito per questo paziente.</div>`;

      // ---- valori: cosa è cambiato dall'ultima lettura, colonna per colonna
      // si parte dalle COLONNE della tabella: ognuna porta l'accesso da cui
      // viene, così due prelievi allo stesso minuto non si rubano i marchi
      const nov = new Map();
      let nNov = 0, nFuori = 0;
      for (const d of st ? st.date : []) {
        if (!d.id) continue;
        const v = tabStore.get(this.risKey(d.id), null);
        const n = v && v.rows ? this.novita(d.id, v.rows) : null;
        if (n && n.size) {
          nov.set(chiaveCol(d), n); nNov += n.size;
          nFuori += v.rows.filter((r) => n.has(valKey(r.nome)) && outOfRange(r.valore, r.range)).length;
        }
      }
      this.segnaEsitiVisti(nNov, nFuori);
      const vivi = prelievi.filter((e) => !e.storico).length;
      const daLeggere = this.daLeggere().length;
      const rotti = prelievi.filter((e) => this.rottiTab.has(e.id));
      // letti, ma senza una data e ora nel gestionale: non possono diventare
      // una colonna, e non devono sparire in silenzio
      const senzaData = prelievi.filter((e) => {
        const v = tabStore.get(this.risKey(e.id), null);
        if (!v || !v.rows || !v.rows.length) return false;
        const t = prelievoComeTabella(risMeta(e), v.rows, "");
        return !!t && t.date[0].ignota;
      });
      const ra = this._refreshAll;
      const t = st ? this.tabellaStorico(st, nov, leggiSegni(this.chiaveNota())) : null;
      const chi = st ? [st.paziente?.cognome, st.paziente?.nome].filter(Boolean).join(" ") : "";
      const sotto = this._sotto;
      // «Carica i valori» / «Aggiorna»: una volta sola. Senza tabella è il
      // bottone grande al posto della tabella; con la tabella è un piccolo
      // «Aggiorna» nella riga del titolo.
      const puoiLeggere = !!(vivi || conPortale);
      const primaLettura = conPortale ? !dalPortale : daLeggere === vivi;
      const etLeggi = ra ? `↻ ${ra.done}/${ra.total}…` : sotto ? "↻ storico…" : primaLettura ? "⭳ Carica i valori" : "↻ Aggiorna";
      const titLeggi = sotto ? "Leggo lo storico del portale in una scheda di sottofondo: si chiude da sola."
        : primaLettura ? `Legge i valori${conPortale ? ": lo storico del portale — tutti i prelievi, refertati e no — in una scheda di sottofondo, e le finestre Risultati del gestionale se serve" : " dal gestionale, un prelievo alla volta"}${
          daLeggere && !conPortale ? ` (${daLeggere} ${daLeggere === 1 ? "prelievo ancora da leggere" : "prelievi ancora da leggere"})` : ""}`
        : "Rilegge tutti i prelievi ancora aperti, uno alla volta";
      const grande = puoiLeggere && !t;
      // letti ma senza data e ora: il perché sta nel passaggio del mouse, non in due righe
      const infoSenzaData = senzaData.length ? `<span class="infochip" tabindex="0" title="${esc(
        `Di ${senzaData.length === 1 ? "un prelievo" : `${senzaData.length} prelievi`} la pagina non dà data e ora, né nel campo nascosto né nella riga: ${
          senzaData.length === 1 ? "è la colonna" : "sono le colonne"} ?, in fondo a destra (${senzaData.map((e) => shortLabel(e.label)).join(", ")}). I valori ci sono tutti; il Registro dice cosa c'era scritto al posto dell'ora.`)}">? ${
        senzaData.length === 1 ? "1 senza ora" : `${senzaData.length} senza ora`}</span>` : "";
      // in attesa, dal diario della pagina: ciò che è stato chiesto e non è ancora refertato
      const attese = richiesteInAttesa(document);
      const attesaLab = attese.filter((x) => x.tipo === "lab");
      const rigaAttesa = (x) => `<div class="wuwait" title="${esc(`Chiesto ${x.when || "(ora ignota)"}: ${x.esami.join(", ")}${x.parziale ? " — risultati parziali nella finestra Risultati" : " — non ancora refertato"}`)}">
          <span class="wuclock" aria-hidden="true">⏳</span><b>${esc(attesaDa(x.ts) || x.when || "—")}</b>
          <span class="wuwlab">${esc(x.esami.join(", "))}</span>
          <span class="wuwq">${x.parziale ? "parziale" : "richiesto"}${x.when && attesaDa(x.ts) ? ` ${esc(x.when.slice(-5))}` : ""}</span>
        </div>`;
      const valori = `
        <section class="sec wusec wulab" aria-label="Laboratorio">
          <div class="lbl wuh"><span class="wut"${t ? ` title="Tocca un valore per segnarlo: giallo, poi arancio, poi via"` : ""}>Lab</span>${t ? `<span class="wucnt"> (${righeTabella(st.righe).length} esami · ${t.nCol} prelievi)</span>` : ""}
            ${puoiLeggere && !grande ? `<button class="mini" id="risall" ${ra || sotto ? "disabled" : ""} title="${esc(titLeggi)}">${esc(etLeggi)}</button>` : ""}
            ${t ? `<button class="mini" id="storfiltro">${this.soloAlterati ? "tutti" : "solo alterati"}</button>` : ""}
            ${t || prelievi.some((e) => tabStore.get(this.risKey(e.id), null)) ? `<button class="mini" id="valreset" title="Dimentica i valori letti e la scheda in archivio di questo paziente: ⭳ Carica i valori li rilegge da zero">↺ Reset</button>` : ""}
            ${infoSenzaData}
          </div>
          ${grande ? `<div class="carica"><button type="button" class="grande" id="risall" ${ra || sotto ? "disabled" : ""} title="${esc(titLeggi)}">${esc(etLeggi)}</button></div>` : ""}
          ${attesaLab.length ? `<div class="wuwaits">${attesaLab.map(rigaAttesa).join("")}</div>` : ""}
          ${this.notaPortale && !sotto ? `<div class="hint" title="Si legge da solo aprendo il link «Storico Dati Clinici»">Storico del portale non letto: ${esc(this.notaPortale)}.</div>` : ""}
          ${rotti.length ? `<div class="hint" title="Il Registro dice perché">${rotti.length === 1 ? "1 prelievo non letto" : `${rotti.length} prelievi non letti`} (${
            esc(rotti.map((e) => e.when).filter(Boolean).join(", "))}): <b>↻ Aggiorna</b> riprova.</div>` : ""}
          ${t ? `${this.avvisoNomi(righeTabella(st.righe), st.scartate)}${t.nRighe ? t.html
            : `<div class="hint">Tutti nel range.</div>`}${this.piedeStorico(st, t.legenda)}` : ""}
          ${this.storico && (this.storico.periodo || this.storico.paziente?.idMPI) ? `<div class="hint">Storico del portale di <b>${esc(chi || "—")}</b> · identità confermata <b>${esc(this.storicoVia || "dal nome")}</b>.</div>`
            : this.storicoAltri ? `<div class="hint">Storico del portale di <b>${esc(this.storicoAltri)}</b>, non di questo paziente: non mostrato.</div>`
            : this.storicoDaConfermare ? `<div class="hint" title="Il codice fiscale sta nella finestra Risultati">Storico del portale con questo nome: serve il codice fiscale, <b>⭳ Carica i valori</b>.</div>` : ""}
          ${!t && !grande && !attesaLab.length && !prelievi.length && !conPortale ? `<div class="wuvuoto">${lab.length ? "Nei referti del laboratorio, in fondo." : "Nessun valore."}</div>` : ""}
        </section>`;

      // ---- ECG e Imaging: i referti, uno per riga; il testo si apre lì sotto
      const visti = refertiVisti(this.episodeId);
      const nuovoRef = (e) => !visti.has(e.id);
      const riga = (e) => {
        const coda = !!(this.refCoda && this.refCoda.has(e.id));
        const state = busy[e.id] === true ? "busy" : coda ? "coda" : typeof busy[e.id] === "string" ? "err" : cached[e.id] ? "saved" : open.has(e.id) ? "open" : "";
        const why = typeof busy[e.id] === "string" ? busy[e.id] : coda ? "in fila: al massimo due scaricamenti insieme" : "";
        const tipo = refertoTipo(e);
        const testo = this.testoDi(e);
        const aperto = this.espanso === e.id;
        const leggibile = tipo === "rx" || tipo === "ecg" || !!testo;
        // l'anteprima: la prima riga del testo che dice qualcosa (mai di un altro paziente)
        const anteprima = testo && testo.stato === "testo" ? anteprimaReferto(testo.righe)
          : testo && testo.stato === "altro" ? "di un altro paziente: non mostrato" : testo && testo.stato === "macchina" ? "solo il tracciato" : "";
        const stato = state === "busy" ? "leggo…" : coda ? "in fila" : state === "err" ? "non letto" : "";
        const corpo = !aperto ? "" : !testo ? `<div class="wutxt"><div class="wunote">${state === "busy" || coda ? "Leggo il referto…" : state === "err" ? `Non letto: ${esc(why)}` : "—"}</div></div>`
          : testo.stato === "altro" ? `<div class="wutxt"><div class="wualtro" role="alert">Referto di un altro paziente: non mostrato.</div></div>`
          : testo.stato === "macchina" ? `<div class="wutxt"><div class="wunote">Solo il tracciato della macchina: nessun referto scritto.</div>
              <div class="wuact"><button type="button" class="mini" id="apripdf">↗ PDF</button></div></div>`
          : `<div class="wutxt">${testo.verificato ? "" : `<div class="wuver" title="Nel PDF non c'è un codice fiscale (né nome e data di nascita) da confrontare col paziente">intestazione non verificata</div>`}
              <div class="reftxt">${testo.righe.map((r) => `<div class="rt">${esc(r)}</div>`).join("")}</div>
              <div class="wuact"><button type="button" class="mini" id="copytxt">⧉ Copia</button><button type="button" class="mini" id="apripdf">↗ PDF</button></div></div>`;
        return `<div class="wuitem${aperto ? " aperto" : ""}">
          <div class="wuline">
            <button class="rrow ${esc(state)}${testo && testo.stato === "altro" ? " altro" : ""}" data-esito="${esc(e.id)}" data-kind="referto" aria-expanded="${aperto ? "true" : "false"}" title="${esc(e.label)}${why ? " — " + esc(why) : ""}">
              <span class="rdot ${esc(state)}"></span>
              <span class="rwhen">${esc(e.when)}</span>
              <span class="rmain"><span class="rlab">${esc(shortLabel(e.label))}</span>${anteprima ? `<span class="wuex">${esc(anteprima)}</span>` : ""}</span>
              ${nuovoRef(e) ? `<span class="wunew" title="Non ancora aperto">nuovo</span>` : ""}
              ${stato ? `<span class="wust">${esc(stato)}</span>` : ""}
              <span class="rgo" aria-hidden="true">${leggibile ? (aperto ? "▾" : "▸") : "↗"}</span>
            </button>
            <button type="button" class="wupdf" data-pdf="${esc(e.id)}" title="${cached[e.id] ? "Apri il PDF salvato su questo computer" : "Apri il PDF dal gestionale"}">↗ PDF</button>
          </div>
          ${corpo}
        </div>`;
      };
      const perTipo = (tp) => referti.filter((e) => refertoTipo(e) === tp);
      const attesaTipo = (tp) => attese.filter((x) => x.tipo === tp);
      const sezione = (tp, nome, cls) => {
        const righe = perTipo(tp), ws = attesaTipo(tp);
        return `<section class="sec wusec ${cls}" aria-label="${esc(nome)}">
          <div class="lbl wuh"><span class="wut">${esc(nome)}</span>${righe.length ? `<span class="wucnt"> (${righe.length})</span>` : ""}</div>
          ${ws.length ? `<div class="wuwaits">${ws.map(rigaAttesa).join("")}</div>` : ""}
          ${righe.length ? `<div class="rlist">${righe.map(riga).join("")}</div>` : ws.length ? "" : `<div class="wuvuoto">Nessuno.</div>`}
        </section>`;
      };
      const altri = perTipo("altro"), attesaAltri = attesaTipo("altro");
      const docAltri = altri.length || attesaAltri.length ? `<section class="sec wusec wualtri" aria-label="Altri documenti">
          <div class="lbl wuh"><span class="wut">Altri documenti</span>${altri.length ? `<span class="wucnt"> (${altri.length})</span>` : ""}</div>
          ${attesaAltri.length ? `<div class="wuwaits">${attesaAltri.map(rigaAttesa).join("")}</div>` : ""}
          ${altri.length ? `<div class="rlist">${altri.map(riga).join("")}</div>` : ""}
        </section>` : "";
      // i referti di laboratorio che la tabella non può mostrare: chiusi, ma ci sono
      const docsLab = lab.length ? `
        <details class="sec reflab" id="reflab"${this.labAperto ? " open" : ""}>
          <summary class="lbl" title="Referti del laboratorio: senza la tabella dei valori, i risultati finali sono qui">Laboratorio (${lab.length})</summary>
          <div class="rlist">${lab.map(riga).join("")}</div>
        </details>` : "";

      // ---- la riga in cima: prima i valori fuori range, poi quanti sono nuovi
      const fuori = fuoriRangeUltimi(st);
      const nRefNuovi = referti.filter(nuovoRef).length;
      const nNuovi = nNov + nRefNuovi;
      const chip = (x) => `<span class="wuv"><b>${esc(x.sigla)}</b> <span class="wuval">${esc(x.v)}${x.stato < 0 ? "↓" : "↑"}</span>${
        x.prima ? `<span class="wuprima"> (${esc(x.prima.v)}${x.prima.quando ? ` alle ${esc(x.prima.quando)}` : ""})</span>` : ""}</span>`;
      const MAXV = 6;
      const salva = this._salva;
      const daSalvare = this.refertiDaSalvare();
      const nSaved = referti.filter((e) => cached[e.id]).length;
      const strumenti = [
        salva ? `<span class="wuprog" role="status">Salvo i referti ${salva.fatti}/${salva.totale}…</span>`
          : daSalvare.length ? `<button type="button" class="mini" id="refsave" title="Tiene una copia di ${daSalvare.length === 1 ? "questo referto" : `questi ${daSalvare.length} referti`} su questo computer (due alla volta) e ne legge il testo">⭳ Salva i referti (${daSalvare.length})</button>` : "",
        (nSaved || referti.some((e) => open.has(e.id))) && !salva ? `<button type="button" class="mini" id="refreset" title="Dimentica i referti salvati e il loro testo">↺</button>` : "",
        this.diagnosi ? `<button type="button" class="mini" id="refdiag" title="Copia com'è fatto il documento che non si è lasciato leggere (senza numeri), da mandare a chi fa il pannello">⧉ Diagnosi</button>` : "",
      ].filter(Boolean).join("");
      const sep = `<span class="wusep" aria-hidden="true">·</span>`;
      const sommario = `<div class="wusum">
          <div class="wusumv">${fuori.length ? fuori.slice(0, MAXV).map(chip).join(sep)
            + (fuori.length > MAXV ? `${sep}<span class="wupiu" title="${esc(fuori.slice(MAXV).map((x) => `${x.sigla} ${x.v}`).join(", "))}">+${fuori.length - MAXV}</span>` : "")
            : st ? `<span class="wuok">Valori nel range</span>` : ""}${
            nNuovi ? `${fuori.length || st ? sep : ""}<button type="button" class="wunuovi" id="letto" title="${esc([
              nNov ? `${nNov} ${nNov === 1 ? "valore nuovo" : "valori nuovi"} dall'ultima lettura` : "",
              nRefNuovi ? `${nRefNuovi} ${nRefNuovi === 1 ? "referto non ancora aperto" : "referti non ancora aperti"}` : ""].filter(Boolean).join(" · "))} — un tocco: visti">${nNuovi} ${nNuovi === 1 ? "nuovo" : "nuovi"}</button>` : ""}</div>
          ${strumenti ? `<div class="wutools">${strumenti}</div>` : ""}
        </div>`;
      return `<div class="esiti wu">${sommario}<div class="esgrid">${valori}<div class="wucol">${sezione("ecg", "ECG", "wuecg")}${sezione("rx", "Imaging", "wuimg")}${docAltri}</div></div>${docsLab}</div>`;
    }

    // The multi-day table: exams down, draws across, newest first. It is read
    // from the portal page, never asked to the server.
    // UNA sola tabella, per il pannello e per il testo copiato: due
    // sorgenti che disegnano «la stessa» tabella finiscono sempre per
    // divergere, e la differenza la scopre il medico.
    tabellaStorico(st, nov = null, segni = {}) {
      const col = st.date.map((d, i) => ({ ...d, i })).reverse();   // il più recente a sinistra
      const righe = righeTabella(st.righe);   // niente doppioni, e «Neu 4.0 (56%)»: una riga, non due
      const ambS = sigleAmbigue(righe);
      const inatteso = (r) => !siglaCurata(r.nome) || ambS.has(chiaveAmbigua(r));
      const simboli = new Map();   // esame → segno, uno per tutta la tabella
      const gruppi = raggruppaStorico(righe)
        .map((g) => ({ ...g, righe: g.righe.filter((r) => !this.soloAlterati || r.valori.some((v) => v.v && v.stato)) }))
        .filter((g) => g.righe.length);

      const rigaEsame = (r) => {
        const p = provenienze(r, simboli);
        const um = unitaChiara((r.valori.find((v) => v && v.um) || {}).um || "", r.nome);
        const celle = col.map((c) => {
          const v = r.valori[c.i] || { v: "", stato: 0 };
          if (!v.v) return `<td class="vuoto">·</td>`;
          const sg = p.segno(v);
          const daChi = String(v.esame || r.esame || "").trim();
          // la novità (analita nuovo, valore cambiato dall'ultima lettura)
          // viaggia su un canale suo: lo sfondo, mai il colore del testo
          const n = nov && nov.get(chiaveCol(c))?.get(valKey(r.nome));
          const tip = [v.um, v.range, sg && daChi ? "fatto con " + daChi : "",
                       n === "nuovo" ? "nuovo dall'ultima lettura" : n === "cambiato" ? "aggiornato dall'ultima lettura" : ""].filter(Boolean).join(" · ");
          // il segno del medico (un tocco giallo, due arancio) vive sulla
          // cella: «colonna|analita», la stessa identità con cui la tabella
          // fonde i prelievi, così sopravvive a ogni ridisegno
          const cella = chiaveCol(c) + "|" + valKey(r.nome) + (eEga(r.esame) ? "|ega" : "") + (!r.mnem && r.nome === r.esame ? "|#" + (r.pos ?? 0) : "");
          const segno = segni[cella] === 2 ? " marca2" : segni[cella] === 1 ? " marca1" : "";
          return `<td class="${v.stato ? "fuori" : ""}${v.parziale ? " parz" : ""}${n === "nuovo" ? " nuovo" : n === "cambiato" ? " agg" : ""}${segno}" data-cella="${esc(cella)}"${
            tip ? ` title="${esc(tip)}${v.parziale ? " · parziale" : ""}"` : v.parziale ? ` title="parziale"` : ""
          }><span class="val">${esc(v.v)}${v.stato ? (v.stato < 0 ? "↓" : "↑") : ""}${
            sg ? `<i class="prov" title="${esc(daChi ? "fatto con " + daChi + (p.solita ? " — gli altri con " + p.solita : "") : "")}">${esc(sg)}</i>` : ""
          }</span>${v.pct ? `<span class="pct"> (${esc(v.pct)}%)</span>` : ""}</td>`;
        }).join("");
        const etichetta = inatteso(r)
          ? String(r.nome).replace(/\s+/g, " ").trim() + (eEga(r.esame) && ambS.has(chiaveAmbigua(r)) ? " (EGA)" : "")
          : sigla(r.nome);
        return `<tr><th class="stn${inatteso(r) ? " grezza" : ""}" title="${esc(r.nome)}${
          r.esame && r.esame !== r.nome ? " — " + esc(r.esame) : ""}${r.mnem ? " · " + esc(r.mnem) : ""}">${
          esc(etichetta)}${um ? `<span class="stum"> (${esc(um)})</span>` : ""}</th>${celle}</tr>`;
      };

      const corpo = gruppi.map((g) => {
        // niente conteggio dei fuori norma sulla riga di sezione: tanti sono
        // insignificanti, e il numero distrae da quelli che contano
        return `<tr class="stsez"><th class="stn">${esc(g.nome)}</th><td colspan="${col.length}"></td></tr>${g.righe.map(rigaEsame).join("")}`;
      }).join("");

      // In cima a ogni colonna: se il prelievo è di oggi basta l'ora; se è di
      // un altro giorno la data (27/08), con l'ora sotto in piccolo. Si legge
      // per confronto, e «quale giorno» conta solo quando non è questo.
      const d0 = new Date();
      const oggi = `${String(d0.getDate()).padStart(2, "0")}/${String(d0.getMonth() + 1).padStart(2, "0")}/${d0.getFullYear()}`;
      const testa = `<tr><th class="stn">Esame</th>${col.map((c, i) => {
        const diOggi = c.data === oggi;
        const cima = c.ignota ? "?" : diOggi ? c.ora || "oggi" : c.data.slice(0, 5);
        const sotto = c.ignota ? "ora ignota" : diOggi ? "" : c.ora;
        const tip = [c.ignota ? "Il gestionale non dà data e ora per questo prelievo" : c.label, c.titolo].filter(Boolean).join(" · ");
        return `<th class="${i === 0 && !c.ignota ? "ultima" : ""}" title="${esc(tip)}">${esc(cima)}<span class="sth">${esc(sotto)}</span></th>`;
      }).join("")}</tr>`;
      const nRighe = gruppi.reduce((n, g) => n + g.righe.length, 0);
      const legenda = [...simboli].map(([esame, segno]) => ({ segno, esame }));
      return {
        html: `<div class="stwrap"><table class="sttab"><thead>${testa}</thead><tbody>${corpo}</tbody></table></div>`,
        legenda, nRighe, nCol: col.length,
      };
    }

    // La legenda dei segni + la nota sui valori parziali: sotto la tabella,
    // scritta, non solo in un tooltip che su un portatile non si vede.
    piedeStorico(st, legenda) {
      const parz = st.righe.some((r) => r.valori.some((v) => v.parziale));
      // una riga sola; l'elenco intero degli esami nel passaggio del mouse
      const pezzi = legenda.map((l) => {
        const tutti = String(l.esame).split(/,\s*/).filter(Boolean);
        return `<span title="${esc("fatto con " + l.esame)}"><b>${esc(l.segno)}</b> con ${esc(tutti[0] || l.esame)}${tutti.length > 1 ? ` +${tutti.length - 1}` : ""}</span>`;
      });
      if (parz) pezzi.push(`<span title="Il laboratorio non ha finito"><i>corsivo</i>: parziale</span>`);
      return pezzi.length ? `<div class="hint stleg">${pezzi.join(" · ")}</div>` : "";
    }

    // The table read on the portal page comes back through the extension. It
    // is shown ONLY if it belongs to the patient on screen: everywhere else
    // in this program the identity is checked before the data is used, and a
    // table of values is the last place to make an exception.
    // Fra le schede in memoria, quella di QUESTO paziente. L'identità la
    // decide il pannello, non il service worker: le regole stanno in un posto
    // solo. Le altre schede non vengono nemmeno chieste.
    async schedaMia() {
      const r = await ask({ t: "getStorico" });
      const indice = (r && r.ok && r.indice) || [];
      if (!indice.length) { this.storicoAltri = ""; return null; }
      const titolo = nomeInPagina();
      const mio = this.cfEpisodio();
      const scelta = scegliScheda(indice, mio, titolo, this.episodeId);
      this.storicoVia = scelta && scelta.ep && String(scelta.ep) === String(this.episodeId)
        ? "dal paziente da cui l'hai aperta"
        : scelta && scelta.cf && mio ? "dal codice fiscale" : "dal nome";
      // C'è una scheda con questo nome ma non gliela si può attribuire perché
      // di questo paziente non conosciamo ancora il codice fiscale: lo si
      // dice, invece di far sparire un bottone senza spiegazioni.
      this.storicoDaConfermare = !scelta && !mio
        && indice.some((v) => v.cf && !v.ep && combaciaNome(titolo, v.paziente));

      if (!scelta) {
        // Le schede degli altri pazienti in memoria sono la norma: ognuno visto
        // nelle ultime 24 ore ha la sua, e dirlo a ogni paziente nuovo suonava
        // come uno scambio di pazienti. Lo si dice solo quando dal portale è
        // appena arrivato uno storico (dieci minuti) che non è di questo
        // paziente: è lì che il medico se lo aspettava, e deve sapere perché
        // non c'è. Se la scheda porta QUESTO nome non è «di un altro
        // paziente»: manca solo la prova che sia sua, e si dice diversamente.
        const dalPortale = (v) => !!(v.paziente?.idMPI || v.paziente?.cognome);
        // (una scheda senza codice fiscale col suo stesso nome non è «di un
        // altro»: non la si può attribuire, ma nemmeno accusare)
        const appena = indice.filter((v) => dalPortale(v) && Date.now() - (v.letto || 0) < 10 * 60e3
            && !(!v.cf && combaciaNome(titolo, v.paziente)))
          .sort((a, b) => (b.letto || 0) - (a.letto || 0))[0];
        this.storicoAltri = this.storicoDaConfermare || !appena ? ""
          : [appena.paziente.cognome, appena.paziente.nome].filter(Boolean).join(" ") || "un paziente che la pagina non nomina";
        return null;
      }
      const pieno = await ask({ t: "getStorico", chiave: scelta.chiave });
      return pieno && pieno.ok ? pieno.dati : null;
    }

    // E anche il testo di un referto letto: la scheda di un paziente è tutto
    // quello che il programma sa di lui, non solo i numeri.
    async archiviaReferto(e, righe) {
      if (!hasExt() || !righe || !righe.length) return;
      const chiave = this.chiavePaz();
      if (!chiave || chiave === "nome:") return;
      segnaChiave(this.episodeId, chiave);
      const vuota = {
        paziente: { idMPI: "", cognome: "", nome: nomeInPagina() },
        cf: this.cfEpisodio() || "", periodo: "", date: [], righe: [], scartate: [], letto: Date.now(),
      };
      await mettiInScheda(chiave, null, (vecchio) => {
        const base = vecchio || vuota;
        const referti = (base.referti || []).filter((r) => r.id !== e.id);
        referti.unshift({ id: e.id, quando: e.when || "", titolo: shortLabel(e.label || ""),
                          sistema: e.sistema || "", testo: righe.slice(0, 200).join("\n").slice(0, 20000) });
        return { ...base, referti: referti.slice(0, 40), letto: Date.now() };
      });
    }

    // Ogni prelievo letto entra anche nella scheda clinica del paziente, così
    // quello che il pannello sa di lui sta in un posto solo: la tabella del
    // portale e le finestre Risultati del gestionale, parziali comprese.
    async archiviaPrelievo(e, rows, cf, scartate) {
      if (!hasExt() || !rows || !rows.length) return;
      const t = prelievoComeTabella(risMeta(e), rows, cf, scartate);
      if (!t) return;
      const chiave = chiaveArchivio(t);
      if (!chiave || chiave === "nome:") return;
      segnaChiave(this.episodeId, chiave);
      await mettiInScheda(chiave, t);
    }

    // Chi è questo paziente, per la nota: il codice fiscale se i prelievi
    // ce l'hanno detto, altrimenti il nome della pagina. Cambia da nome a
    // codice fiscale appena i valori arrivano — e la nota lo segue.
    // Il titolo della pagina è il nome del paziente SOLO dove c'è davvero un
    // paziente: sulla lista del reparto quel titolo è «PRONTO SOCCORSO -
    // LISTA», e prenderlo per un nome è come attribuire una nota, un tempo o
    // una scheda a un paziente che non esiste.
    // ============================================================ IDENTITÀ
    // Chi è il paziente di questa pagina, con il secondo identificativo:
    // nome, età e sesso, episodio, posto. Le azioni che escono dal pannello
    // (Conferma, Copia, Stampa) lo nominano: «ROSSI M. · 68 M».
    idPaz() {
      const ep = this.epDiQuesta() || (this.pageType !== "patient" ? this.episodeId || "" : "");
      const p = ep ? tuttiPazienti().find((x) => x.ep === ep) : null;
      const nome = this.nomePaziente() || (this.pageType !== "patient" && ep ? nomeInPagina() : "") || p?.name || "";
      const an = anagraficaPagina(document);
      const eta = Number.isInteger(an.eta) ? an.eta : p?.eta;
      const es = [Number.isInteger(eta) ? String(eta) : "", an.sesso || p?.sesso || ""].filter(Boolean).join(" ");
      return { ep, nome, breve: nomeBreve(nome), es, posto: ep ? this.postoDi(ep) : "" };
    }
    // «ROSSI M. · 68 M», o «» se il nome non c'è
    idBreve() {
      const i = this.idPaz();
      return i.breve ? [i.breve, i.es].filter(Boolean).join(" · ") : "";
    }
    postoDi(ep) {
      const raw = store.get("stanza.posti.v1", {});
      const v = raw && typeof raw === "object" ? raw[ep] : null;
      if (!v) return "";
      const sala = this.stanzaSala();
      return ((v.tipo === "letto" ? sala.letti : sala.aree) || []).find((o) => o.id === v.id)?.nome || "";
    }
    // Allergie e Attenzione del gestionale, sotto il nome, parola per parola:
    // dalla pagina se ci sono, se no da quella del paziente letta poco fa. Mai
    // «nessuna»: non lette è non lette.
    avvisiPaz(ep) {
      const qui = this.pageType === "patient" ? { allergie: allergiePagina(document), attenzione: attenzionePagina(document) } : null;
      const st = statoDi(ep);
      const a = qui && (qui.allergie || qui.attenzione) ? qui : st && st.anag ? st.anag : null;
      const all = a && a.allergie;
      const pezzi = [];
      if (!all) pezzi.push(`<span class="idall nl">Allergie: non lette</span>`);
      else if (all.nega) pezzi.push(`<span class="idall nega" title="Allergie, dal gestionale: Nega/Non riferisce">Allergie: nega</span>`);
      else if (all.testo) pezzi.push(`<span class="idall ros" title="${esc("Allergie: " + all.testo)}">Allergie: ${esc(all.testo)}</span>`);
      const att = (a && a.attenzione) || [];
      if (att.length) pezzi.push(`<span class="idatt" title="${esc("Attenzione: " + att.join(" · "))}">Attenzione: ${esc(att.join(" · "))}</span>`);
      return pezzi.length ? `<div class="idriga">${pezzi.join("")}</div>` : "";
    }
    // Per le Richieste: esame per esame (il nome del catalogo, identico), le
    // ore delle richieste già tornate e la più vecchia ancora in attesa.
    ultimiEsami() {
      const st = this.episodeId ? statoEsami(statoDi(this.episodeId)) : null;
      const m = new Map();
      if (!st) return m;
      for (const e of st.esami) {
        const k = chiaveEsame(e.label), x = m.get(k) || { fatti: [], attesa: 0, inAttesa: false, fatto: false };
        if (e.fatto) { x.fatto = true; if (e.ts) x.fatti.push(e.ts); }
        else { x.inAttesa = true; if (e.ts && (!x.attesa || e.ts < x.attesa)) x.attesa = e.ts; }
        m.set(k, x);
      }
      m.vecchio = st.vecchio; m.letto = st.letto;
      return m;
    }
    // «· 11:40, 14:30», «· in attesa 40′»; letto da più di mezz'ora: «· letto 11:02»
    suffissoEsame(m, label) {
      const x = m.get(chiaveEsame(label));
      if (!x) return null;
      const ora = Date.now(), pezzi = [];
      if (x.fatti.length) pezzi.push(x.fatti.sort((a, b) => a - b).slice(-3).map(hhmm).join(", "));
      else if (x.fatto) pezzi.push("fatto");
      if (x.inAttesa) pezzi.push(x.attesa && !m.vecchio ? `in attesa ${attesaTesto(minDa(x.attesa, ora))}` : "in attesa");
      if (m.vecchio && m.letto) pezzi.push(`letto ${hhmm(m.letto)}`);
      const testo = pezzi.join(" · ");
      const titolo = `${x.fatti.length ? `Già fatto: richieste delle ${x.fatti.map(hhmm).join(", ")}` : x.fatto ? "Già fatto" : ""}${
        x.inAttesa ? `${x.fatti.length || x.fatto ? " · " : ""}in attesa${x.attesa ? ` dalle ${hhmm(x.attesa)}` : ""}` : ""}${m.letto ? ` · letto alle ${hhmm(m.letto)}` : ""}`;
      return { html: `<span class="ult${m.vecchio ? " vecchio" : ""}">${esc(testo)}</span>`, titolo };
    }
    // la riga di stato di un paziente (Pazienti, letto): in testa il cuore dei parametri vitali, poi gli esami
    statoPaz(ep, breve = false) {
      return this.cuoreHtml(ep) + statoHtml(statoEsami(statoDi(ep)), { breve });
    }

    nomePaziente() {
      const puoOrdinare = !!(this.entry && (this.entry.labUrl || this.entry.radioUrl));
      return this.pageType === "patient" && puoOrdinare ? nomeInPagina() : "";
    }

    // La chiave del paziente di questa pagina: una sola, usata dalla nota,
    // dalla scheda clinica e dai referti tenuti — così «elimina questo
    // paziente» sa esattamente cosa togliere.
    chiavePaz() {
      const cf = this.cfEpisodio();
      if (cf) return "cf:" + cf;
      const n = normNome(this.nomePaziente());
      return n ? "nome:" + n : "";
    }
    // La chiave passa da «nome:» a «cf:» nel momento in cui i valori portano
    // il codice fiscale. I segni fatti prima devono SEGUIRE il paziente, non
    // restare indietro (e non riaffiorare su un omonimo): li si sposta.
    chiaveNota() {
      const k = this.chiavePaz();
      if (!k.startsWith("cf:")) return k;
      const vecchia = "nome:" + normNome(this.nomePaziente());
      if (vecchia !== "nome:") migraSegni(vecchia, k);
      // «elimina paziente» deve trovare anche questa chiave, con o senza estensione
      segnaChiave(this.episodeId, k);
      return k;
    }
    // ============================================================== DA FARE
    // L'icona «Da fare» di un paziente: le spunte tonde e quante voci sono
    // aperte; ambra 15 minuti prima di un promemoria, rossa quando è passato.
    // Un tocco apre la lista lì dov'è. Il passaggio del mouse le dice tutte.
    dfIcona(ep, tutti = dfTutti(), dove = "lista", ora = Date.now()) {
      const aperte = dfAperte(ep, tutti), n = aperte.length;
      const prossimo = aperte.filter((x) => x.t != null).sort((a, b) => a.t - b.t)[0];
      const b = prossimo ? promBanda(prossimo.t, ora) : "";
      const riga = (x) => (x.t != null ? promRiga(x, ora) : x.testo);
      const tit = n ? `Da fare (${n}):\n${aperte.map(riga).join("\n")}` : "Da fare: niente — un tocco per aggiungere";
      const det = `${n ? `${n} ${n === 1 ? "aperta" : "aperte"}` : "niente"}${prossimo ? ` · ${promRiga(prossimo, ora)}` : ""}`;
      return `<button type="button" class="dfic${b ? " " + b : ""}${n ? "" : " vuota"}" data-df="${esc(ep)}" data-dove="${esc(dove)}" aria-haspopup="dialog" aria-expanded="${
        this._df?.ep === ep && this._df.dove === dove ? "true" : "false"}" title="${esc(tit)}" aria-label="${esc("Da fare: " + det)}">${ICO.dafare}${n ? `<b>${n}</b>` : ""}</button>`;
    }
    // Il post-it: la prima voce aperta, nell'ordine scelto dal medico
    dfPost(ep, tutti = dfTutti()) {
      const x = dfPrima(ep, tutti);
      return x ? `<span class="dfpost">${x.t != null ? `<b>${esc(hhmm(x.t))}</b> ` : ""}${esc(x.testo)}</span>` : "";
    }
    // l'icona, e il post-it, ognuno nel suo posto: si rifanno da soli (dfMetti)
    dfSlot(ep, tutti, dove) {
      return `<span class="dfslot" data-dfslot="${esc(ep)}" data-dove="${esc(dove)}">${this.dfIcona(ep, tutti, dove)}</span>`;
    }
    dfPostSlot(ep, tutti) {
      return `<span class="dfpslot" data-dfp="${esc(ep)}">${this.dfPost(ep, tutti)}</span>`;
    }
    // il pallino del letto (esami e «Da fare» insieme): si rifà da solo anche lui (dfMetti)
    segnaleHtml(ep, tutti = dfTutti(), ora = Date.now()) {
      return segnaleLetto(statoEsami(statoDi(ep), ora), dfAperte(ep, tutti), ora);
    }
    // Il cuore dei parametri vitali (vedi PARAMETRI VITALI): rosso o ambra,
    // vuoto con le ore se la riga è vecchia. Un impulso solo, la prima volta
    // che compare in questa scheda; poi fermo.
    cuoreHtml(ep, ora = Date.now(), soloIcona = false) {
      const c = cuoreDi(statoDi(ep)?.vit, ora);
      if (!c) return "";
      // l'impulso dura un secondo da quando il cuore è comparso: un ridisegno
      // in quel secondo lo continua (il ritardo negativo), non lo ricomincia
      let pulsa = -1;
      if (!c.vecchio) {
        const visti = tabStore.get("cuori.v1", {}) || {}, v = visti[ep], adesso = Date.now();
        if (!v || v.k !== c.chiave) { visti[ep] = { k: c.chiave, t: adesso }; tabStore.set("cuori.v1", visti); pulsa = 0; }
        else if (adesso - v.t < 1000) pulsa = Math.max(0, adesso - v.t);
      }
      const cosa = c.livello === "ros" ? "parametri vitali critici" : "parametri vitali: NEWS2 5–6";
      return `<span class="cuore ${c.livello}${c.vecchio ? " vecchio" : ""}${pulsa >= 0 ? " pulsa" : ""}"${pulsa > 0 ? ` style="animation-delay:-${pulsa}ms"` : ""} role="img" aria-label="${
        esc(cosa + (c.vecchio ? `, misurati ${c.ore} ore fa` : ""))}" title="${esc(c.titolo)}">${c.vecchio ? (soloIcona ? "♡" : `♡ ${c.ore}h`) : "♥"}</span>`;
    }

    // Sulla pill ridotta, e solo quando tocca: il promemoria più urgente fra
    // i pazienti in elenco, a 10 minuti o meno, o già passato. Se è di un
    // altro paziente lo dice — «−3m Ferrari · RX polso» — perché accanto al
    // nome di chi hai davanti un tempo muto si legge come suo. Un tocco: ✓ Fatto,
    // +15′ o Apri (il paziente).
    promUrgenti(ora = Date.now()) {
      const tutti = promTutti();
      if (!Object.keys(tutti).length) return [];
      const arch = new Set(pazientiArchiviati().map((p) => p.ep)), noti = new Map(tuttiPazienti().map((p) => [p.ep, p]));
      return Object.entries(tutti).filter(([ep]) => !arch.has(ep))
        .flatMap(([ep, l]) => l.map((p) => ({ ...p, ep, nome: noti.get(ep)?.name || (ep === this.epDiQuesta() && this.nomePaziente()) || "" })))
        .filter((p) => promAllarme(p.t, ora)).sort((a, b) => a.t - b.t);
    }
    promUrgenteTesto(u, ora = Date.now()) {
      const chi = u.ep === this.epDiQuesta() ? "" : cognomeTitolo(u.nome) || "ep. " + u.ep;
      return `${promTempo(u.t, ora)}${chi ? " " + chi : ""} · ${u.testo}`;
    }
    promUrgente(ora = Date.now()) {
      const urg = this.promUrgenti(ora);
      if (!urg.length) return "";
      const u = urg[0], piu = urg.length - 1;
      const dove = (p) => `${p.nome || "episodio " + p.ep} · ${p.testo}`;
      const tit = `${urg.map(dove).join("\n")}\nUn tocco: fatto, 15 minuti in più, o apri il paziente`;
      return `<span class="prurg" role="button" tabindex="0" data-prurg="${esc(u.ep)}" data-prid="${esc(u.id)}" aria-haspopup="menu" title="${esc(tit)}" aria-label="${
        esc("Promemoria urgente: " + this.promUrgenteTesto(u, ora))}">${ICO.sveglia}<span class="prurgt">${esc(this.promUrgenteTesto(u, ora))}</span>${piu ? `<span class="prurgp">+${piu}</span>` : ""}</span>`;
    }
    // Il segno sulla pill ridotta rifatto SUL POSTO (il tempo che passa, un
    // promemoria fatto): lo stesso elemento finché è lo stesso promemoria,
    // così il suo menu aperto non perde l'àncora.
    promSegno(ora = Date.now()) {
      const pill = this.root.querySelector("#expand.pill:not(.run)");
      if (!pill) return;
      const prima = pill.querySelector(".prurg"), nuovo = this.promUrgente(ora);
      const m = this._promMenu;
      if (!nuovo) {
        prima?.remove();
        if (m && m.urg && !m.annulla) this.promChiudiMenu();
        return;
      }
      const t = document.createElement("template");
      t.innerHTML = nuovo;
      const n = t.content.firstElementChild;
      if (prima && prima.getAttribute("data-prid") === n.getAttribute("data-prid") && prima.getAttribute("data-prurg") === n.getAttribute("data-prurg")) {
        prima.title = n.title; prima.setAttribute("aria-label", n.getAttribute("aria-label"));
        prima.innerHTML = n.innerHTML;
        return;
      }
      if (m && m.urg && !m.annulla) this.promChiudiMenu();
      if (prima) prima.replaceWith(n); else pill.appendChild(n);
    }
    // ✓ Fatto · +15′ · Apri, per il promemoria del segno sulla pill
    promMenuSegno(anchor) {
      this.promChiudiMenu();
      const ep = anchor.getAttribute("data-prurg"), id = anchor.getAttribute("data-prid");
      const wrap = this.root.querySelector(".wrap"), u = this.promUrgenti().find((x) => x.ep === ep && x.id === id);
      if (!u || !wrap) return;
      const mio = ep === this.epDiQuesta(), noto = tuttiPazienti().find((x) => x.ep === ep);
      wrap.insertAdjacentHTML("beforeend", `<div class="prmenu prmini" role="menu" aria-label="${esc("Promemoria: " + this.promUrgenteTesto(u))}">
        <div class="prmhd" title="${esc(promRiga(u, Date.now()))}"><b>${esc(this.promUrgenteTesto(u))}</b></div>
        <div class="prmrow">
          <button type="button" role="menuitem" class="prmb ok" data-pu="fatto" title="Fatto: lo tolgo (si può annullare)">✓ Fatto</button>
          <button type="button" role="menuitem" class="prmb" data-pu="piu" title="Rimanda di 15 minuti">+15′</button>
          ${mio || noto?.url ? `<button type="button" role="menuitem" class="prmb" data-pu="apri" title="${mio ? "Apri il pannello" : "Apri " + esc(u.nome || "il paziente")}">Apri</button>` : ""}
        </div></div>`);
      const menu = wrap.lastElementChild;
      this.promPosiziona(menu, anchor, wrap);
      const chiudi = (ritorna) => this.promChiudiMenu(ritorna);
      menu.addEventListener("click", (e) => {
        const b = e.target.closest("[data-pu]");
        if (!b) return;
        const az = b.getAttribute("data-pu");
        if (az === "fatto") {
          const p = promTogli(ep, id);
          if (!p) return chiudi();
          // sulla pill ridotta non c'è dove mostrare «Annulla»: lo porta il menu, 8 secondi
          menu.innerHTML = `<div class="prmrow"><span class="prmq">Fatto: ${esc(p.testo)}</span><button type="button" class="prmb" data-pu="annulla">Annulla</button></div>`;
          menu.dataset.fatto = JSON.stringify(p);
          this._promMenu.annulla = true;
          this._promMenu.timer = setTimeout(() => { if (this._promMenu?.menu === menu) chiudi(); }, 8000);
          menu.querySelector("button")?.focus({ preventScroll: true });
          this.promSegno();
          // senza il segno la pill si stringe (e si sposta, ancorata a destra): il menu la segue
          const pill = this.root.querySelector("#expand");
          if (pill) this.promPosiziona(menu, pill, wrap);
        } else if (az === "annulla") {
          try { promRimetti(ep, JSON.parse(menu.dataset.fatto)); } catch { /* niente */ }
          chiudi(); this.promSegno();
        } else if (az === "piu") {
          promRinvia(ep, id); chiudi(); this.promSegno();
        } else if (az === "apri") {
          chiudi();
          if (mio) this.apri(); else this.apriPaziente(ep, "esiti");
        }
      });
      menu.addEventListener("keydown", (e) => { if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); chiudi(true); } });
      menu.addEventListener("focusout", (e) => { if (e.relatedTarget && !menu.contains(e.relatedTarget) && e.relatedTarget !== anchor) chiudi(); });
      const fuori = (e) => { const via = e.composedPath(); if (!via.includes(menu) && !via.includes(anchor)) chiudi(); };
      window.addEventListener("pointerdown", fuori, true);
      this._promMenu = { menu, anchor, ep, fuori, urg: true };
      menu.querySelector("button")?.focus({ preventScroll: true });
    }
    // sotto l'àncora; se sotto non c'è posto, sopra; sempre dentro lo schermo
    promPosiziona(menu, anchor, wrap) {
      const wr = wrap.getBoundingClientRect(), ar = anchor.getBoundingClientRect();
      let y = ar.bottom + 6;
      if (y + menu.offsetHeight > innerHeight - 8) y = Math.max(8, ar.top - 6 - menu.offsetHeight);
      menu.style.left = Math.max(8, Math.min(ar.left, innerWidth - menu.offsetWidth - 8)) - wr.left + "px";
      menu.style.top = y - wr.top + "px";
    }
    // Ogni 30 secondi le icone «Da fare» rifanno i conti SUL POSTO (il colore,
    // le voci spuntate da 5 minuti che se ne vanno): niente ridisegno, così
    // non si ruba il fuoco e non si disturba chi scrive.
    promTick() {
      const ora = Date.now(), tutti = dfTutti(ora);
      const eps = new Set([...this.root.querySelectorAll("[data-dfslot], [data-dfp], [data-dfseg]")].map((s) => s.getAttribute("data-dfslot") || s.getAttribute("data-dfp") || s.getAttribute("data-dfseg")));
      for (const ep of eps) this.dfMetti(ep, tutti, ora);
      if (this._df?.pop?.isConnected) this.dfLista(tutti, ora);
      this.promSegno(ora);
    }
    // l'icona e il post-it di un paziente rifatti sul posto, dappertutto
    dfMetti(ep, tutti = dfTutti(), ora = Date.now()) {
      const e = CSS.escape(ep);
      for (const slot of this.root.querySelectorAll(`[data-dfslot="${e}"]`)) {
        const dove = slot.getAttribute("data-dove") || "lista", b = slot.querySelector(".dfic");
        const t = document.createElement("template");
        t.innerHTML = this.dfIcona(ep, tutti, dove, ora);
        const n = t.content.firstElementChild;
        if (!b) { slot.replaceChildren(n); continue; }
        // lo stesso bottone: il fuoco (e l'àncora della lista aperta) restano
        b.className = n.className; b.title = n.title; b.setAttribute("aria-label", n.getAttribute("aria-label"));
        b.setAttribute("aria-expanded", n.getAttribute("aria-expanded")); b.innerHTML = n.innerHTML;
      }
      for (const slot of this.root.querySelectorAll(`[data-dfp="${e}"]`)) slot.innerHTML = this.dfPost(ep, tutti);
      for (const slot of this.root.querySelectorAll(`[data-dfseg="${e}"]`)) slot.innerHTML = this.segnaleHtml(ep, tutti, ora);
    }
    promClic(e) {
      const segno = e.target.closest?.("[data-prurg]");
      if (segno) {
        const aperto = this._promMenu?.anchor === segno && this._promMenu.menu.isConnected;
        return aperto ? this.promChiudiMenu(true) : this.promMenuSegno(segno);
      }
      const ic = e.target.closest?.("[data-df]");
      if (ic && !ic.closest(".dfpop")) {
        e.stopPropagation?.();
        const ep = ic.getAttribute("data-df");
        const aperto = this._df && this._df.ep === ep && this._df.anchor === ic && this._df.pop.isConnected;
        return aperto ? this.dfChiudi(true) : this.dfApri(ep, ic);
      }
    }
    // La lista, in una piccola finestra sotto l'icona (sopra, se sotto non
    // c'è posto): le voci con la spunta tonda, il loro orario se ce l'hanno, e
    // in fondo il campo su una riga per aggiungerne una. Esc, o un clic
    // fuori, la chiudono; niente si salva a parte: ogni gesto è già salvato.
    dfApri(ep, anchor, { fuoco = true, testo = "" } = {}) {
      this.dfChiudi();
      this.promChiudiMenu();
      this.stanzaChiudiMenu?.();
      const wrap = this.root.querySelector(".wrap");
      if (!ep || !wrap || !anchor?.isConnected) return;
      const p0 = tuttiPazienti().find((x) => x.ep === ep);
      const nome = p0?.name || (ep === this.epDiQuesta() ? this.nomePaziente() : "");
      wrap.insertAdjacentHTML("beforeend", `<div class="dfpop" role="dialog" aria-label="Da fare${nome ? " · " + esc(nome) : ""}">
        <div class="dfhd"><b>Da fare</b>${nome ? `<span> · ${esc(nome)}</span>` : ""}</div>
        <ul class="dfl" aria-label="Voci: Alt+↑ e Alt+↓ le spostano"></ul>
        <div class="dfadd"><input type="text" class="dfin" id="dfin" maxlength="160" autocomplete="off" spellcheck="false" value="${esc(testo)}"
          placeholder="Aggiungi…" title="Con un'ora (11:30 tropo, tra 2h ECG) è un promemoria" aria-label="Aggiungi: una cosa da fare; con un'ora (11:30 tropo, tra 2h ECG) è un promemoria" aria-describedby="dfhint">
          <span class="dfhint" id="dfhint" aria-live="polite"></span></div>
        <span class="dfsr" aria-live="polite"></span>
      </div>`);
      const pop = wrap.lastElementChild;
      const fuori = (ev) => { const via = ev.composedPath(); if (!via.includes(pop) && !via.includes(this._df?.anchor)) this.dfChiudi(); };
      window.addEventListener("pointerdown", fuori, true);
      this._df = { ep, dove: anchor.getAttribute("data-dove") || "", pop, anchor, fuori, testo };
      anchor.setAttribute("aria-expanded", "true");
      this.dfLista();
      this.promPosiziona(pop, anchor, wrap);
      const inp = pop.querySelector("#dfin");
      // per riaprirla uguale dopo un ridisegno: il fuoco era qui dentro?
      pop.addEventListener("focusin", () => { if (this._df?.pop === pop) this._df.inFuoco = true; });
      pop.addEventListener("focusout", (ev) => { if (this._df?.pop === pop && ev.relatedTarget && !pop.contains(ev.relatedTarget)) this._df.inFuoco = false; });
      pop.addEventListener("click", (ev) => {
        const ck = ev.target.closest(".dfck"), piu = ev.target.closest("[data-dfpiu]");
        if (ck) {
          const li = ck.closest(".dfi"), id = li.getAttribute("data-id"), si = ck.getAttribute("aria-checked") !== "true";
          dfSpunta(ep, id, si);
          this.dfDopo(id, si ? "Fatta: se ne va fra 5 minuti" : "Di nuovo da fare");
        } else if (piu) {
          promRinvia(ep, piu.getAttribute("data-dfpiu"));
          this.dfDopo(piu.getAttribute("data-dfpiu"), "Rimandata di 15 minuti");
        }
      });
      pop.addEventListener("keydown", (ev) => {
        if (ev.key === "Escape") { ev.preventDefault(); ev.stopPropagation(); return this.dfChiudi(true); }
        const li = ev.target.closest?.(".dfi");
        if (li && ev.altKey && (ev.key === "ArrowUp" || ev.key === "ArrowDown")) {
          ev.preventDefault();
          const l = dfDi(ep), i = l.findIndex((x) => x.id === li.getAttribute("data-id")), a = i + (ev.key === "ArrowUp" ? -1 : 1);
          if (i < 0 || a < 0 || a >= l.length) return;
          dfSposta(ep, l[i].id, a);
          this.dfDopo(l[i].id, `Spostata: ${a + 1}ª di ${l.length}`);
        }
      });
      // trascinare dalla maniglia ⋮⋮, col mouse o col dito
      pop.addEventListener("pointerdown", (ev) => { const g = ev.target.closest(".dfgrip"); if (g) this.dfTrascina(ev, g.closest(".dfi")); });
      inp.addEventListener("input", () => { if (this._df) this._df.testo = inp.value; this.dfSuggerisci(inp); });
      inp.addEventListener("keydown", (ev) => {
        if (ev.key !== "Enter") return;
        ev.preventDefault();
        if (!inp.value.trim()) return;
        const x = dfAggiungi(ep, inp.value);
        const h = pop.querySelector(".dfhint");
        if (!x) {
          h.textContent = dfAperte(ep).length >= PROM_MAX ? `Al massimo ${PROM_MAX} voci aperte per paziente` : "Non salvata: la memoria del browser è piena o bloccata";
          h.classList.add("ko");
          return;
        }
        inp.value = ""; this._df.testo = "";
        this.dfDopo(null, x.t != null ? `Aggiunta, alle ${promOra(x.t, Date.now())}` : "Aggiunta");
      });
      this.dfSuggerisci(inp);
      if (fuoco) { inp.focus({ preventScroll: true }); inp.setSelectionRange(inp.value.length, inp.value.length); }
    }
    // sotto il campo, mentre si scrive: se c'è un'ora, quando sarà
    dfSuggerisci(inp) {
      const h = inp.parentElement?.querySelector(".dfhint");
      if (!h) return;
      const p = inp.value.trim() ? leggiPromemoria(inp.value, Date.now(), DF_LUNGO) : null;
      h.classList.remove("ko");
      h.textContent = p ? `promemoria: ${promRiga({ t: p.t, testo: "" }, Date.now())}` : "";
    }
    dfVoce(x, ora) {
      const b = x.t != null && !x.fatto ? promBanda(x.t, ora) : "";
      return `<li class="dfi${x.fatto ? " fatto" : ""}" data-id="${esc(x.id)}">
        <span class="dfgrip" aria-hidden="true" title="Trascina per spostarla (o Alt+↑ / Alt+↓)">⋮⋮</span>
        <button type="button" class="dfck" role="checkbox" aria-checked="${x.fatto ? "true" : "false"}" aria-keyshortcuts="Alt+ArrowUp Alt+ArrowDown"
          aria-label="${esc(x.testo + (x.t != null ? ", alle " + promOra(x.t, ora) : ""))}" title="${x.fatto ? "Fatta: un tocco la riapre (se ne va fra 5 minuti)" : "Un tocco quando è fatta"}"></button>
        <span class="dftx">${esc(x.testo)}</span>
        ${x.t != null ? `<span class="dft${b ? " " + b : ""}" title="${esc(promRiga(x, ora))}">${esc(promOra(x.t, ora))}</span>` : ""}
        ${x.t != null && !x.fatto ? `<button type="button" class="dfpiu" data-dfpiu="${esc(x.id)}" title="Rimanda di 15 minuti" aria-label="Rimanda ${esc(x.testo)} di 15 minuti">+15′</button>` : ""}
      </li>`;
    }
    dfLista(tutti = dfTutti(), ora = Date.now()) {
      const d = this._df, ul = d?.pop?.querySelector(".dfl");
      if (!ul || this._dfPresa) return;
      const l = dfDi(d.ep, tutti);
      const html = l.length ? l.map((x) => this.dfVoce(x, ora)).join("") : "";
      if (ul._firma === html) return;   // niente di cambiato: il fuoco resta dov'è
      // rifatta: il fuoco torna sulla stessa voce, se c'è ancora
      const f = this.root.activeElement?.closest?.(".dfi")?.getAttribute("data-id"), suCk = !!this.root.activeElement?.classList?.contains("dfck");
      ul.innerHTML = html;
      ul._firma = html;
      if (f) (ul.querySelector(`.dfi[data-id="${CSS.escape(f)}"] ${suCk ? ".dfck" : ".dfpiu"}`) || ul.querySelector(`.dfi[data-id="${CSS.escape(f)}"] .dfck`) || d.pop.querySelector("#dfin"))?.focus({ preventScroll: true });
    }
    // dopo un gesto: la lista, l'icona e il post-it rifatti, il fuoco dov'era
    dfDopo(id, detto) {
      const d = this._df;
      if (!d) return;
      const tutti = dfTutti();
      this.dfLista(tutti);
      this.dfMetti(d.ep, tutti);
      const sr = d.pop.querySelector(".dfsr");
      if (sr && detto) sr.textContent = detto;
      const f = id ? d.pop.querySelector(`.dfi[data-id="${CSS.escape(id)}"] .dfck`) : d.pop.querySelector("#dfin");
      (f || d.pop.querySelector("#dfin"))?.focus({ preventScroll: true });
    }
    // Trascinare una voce: oltre i 4 px (10 col dito) la voce segue il
    // puntatore e le altre le fanno posto; lasciata, l'ordine si salva. Esc,
    // o un annullo del browser, la rimettono dov'era.
    dfTrascina(e, li) {
      const d = this._df;
      if (!d || !li || e.button !== 0) return;
      e.preventDefault();
      const ul = li.parentElement, id = li.getAttribute("data-id"), y0 = e.clientY, soglia = e.pointerType === "mouse" ? 4 : 10;
      let partito = false;
      this._dfPresa = true;
      const mm = (ev) => {
        if (!partito && Math.abs(ev.clientY - y0) < soglia) return;
        ev.preventDefault();
        if (!partito) { partito = true; li.classList.add("presa"); ul.classList.add("trascino"); }
        const altre = [...ul.querySelectorAll(".dfi")].filter((x) => x !== li);
        const prima = altre.find((x) => { const r = x.getBoundingClientRect(); return ev.clientY < r.top + r.height / 2; });
        if (prima) { if (li.nextElementSibling !== prima) ul.insertBefore(li, prima); } else if (ul.lastElementChild !== li) ul.appendChild(li);
      };
      const fine = (salva) => {
        window.removeEventListener("pointermove", mm, true);
        window.removeEventListener("pointerup", su, true);
        window.removeEventListener("pointercancel", via, true);
        window.removeEventListener("keydown", kd, true);
        this._dfPresa = false;
        li.classList.remove("presa"); ul.classList.remove("trascino");
        if (!partito) return;
        const a = [...ul.querySelectorAll(".dfi")].indexOf(li);
        if (salva) dfSposta(d.ep, id, a);
        ul._firma = "";   // l'ordine sullo schermo l'ha cambiato il trascinamento: si rifà comunque
        this.dfDopo(id, salva ? `Spostata: ${a + 1}ª` : "");
      };
      const su = () => fine(true), via = () => fine(false);
      const kd = (ev) => { if (ev.key === "Escape") { ev.preventDefault(); ev.stopPropagation(); fine(false); } };
      window.addEventListener("pointermove", mm, true);
      window.addEventListener("pointerup", su, true);
      window.addEventListener("pointercancel", via, true);
      window.addEventListener("keydown", kd, true);
    }
    dfChiudi(ritorna) {
      const d = this._df;
      if (!d) return;
      this._df = null;
      window.removeEventListener("pointerdown", d.fuori, true);
      d.pop.remove();
      const a = d.anchor?.isConnected ? d.anchor : this.root.querySelector(`[data-df="${CSS.escape(d.ep)}"][data-dove="${CSS.escape(d.dove)}"]`);
      a?.setAttribute("aria-expanded", "false");
      if (ritorna) a?.focus();
    }
    // il pannello si è ridisegnato con la lista aperta: si riapre, uguale, sotto la sua icona
    dfRiattacca() {
      const d = this._df;
      if (!d || d.pop.isConnected) return;
      const scriveva = !this.root.activeElement && d.inFuoco;
      window.removeEventListener("pointerdown", d.fuori, true);
      this._df = null;
      const a = this.dfAncora(d.ep, d.dove);
      if (!a || this.collapsed) return;
      this.dfApri(d.ep, a, { fuoco: scriveva, testo: d.testo || "" });
      const inp = scriveva && d.sel ? this.root.querySelector("#dfin") : null;
      if (inp) inp.setSelectionRange(...d.sel);
    }
    // sotto cosa si apre la lista di un paziente: la sua icona dove si vede
    // (quella chiesta, se c'è), se no il paziente nella stanza
    dfAncora(ep, dove = "") {
      const e = CSS.escape(ep), vede = (el) => !!el && el.getClientRects().length > 0;
      const ic = [...this.root.querySelectorAll(`[data-df="${e}"]`)].filter(vede);
      return ic.find((x) => x.getAttribute("data-dove") === dove) || ic[0]
        || [...this.root.querySelectorAll(`.stmap .stp[data-stp="${e}"]`)].find(vede) || null;
    }
    promChiudiMenu(ritorna) {
      const a = this._promMenu;
      if (!a) return;
      this._promMenu = null;
      clearTimeout(a.timer);
      window.removeEventListener("pointerdown", a.fuori, true);
      a.menu.remove();
      if (ritorna && a.anchor?.isConnected) a.anchor.focus();
    }

    // l'impronta del codice fiscale di QUESTO episodio, presa dai prelievi
    // che il pannello ha già letto: nessuna richiesta in più
    cfEpisodio() {
      for (const k of tabStore.keys(`ris.${this.episodeId || "x"}.`)) {
        const v = tabStore.get(k, null);
        if (v && v.cf) return v.cf;
      }
      return "";
    }

    // Il link «Storico Dati Clinici» di QUESTA pagina, come ce l'ha il
    // gestionale: mai un indirizzo costruito.
    linkStorico() {
      const a = document.querySelector('a[href*="MODALITA=CLINICA"]');
      if (!a) return "";
      try { const u = new URL(a.href, location.href); return u.origin === location.origin ? u.href : ""; } catch { return ""; }
    }
    // «⭳ Carica i valori» apre anche lo storico del portale, in una scheda di
    // sottofondo che si chiude da sola: la stessa pagina che si apre col link,
    // letta come sempre. Se non arriva, lo si dice — e il link a mano resta.
    async storicoInSottofondo() {
      if (!hasExt() || this._sotto || !this.episodeId || !this.nomePaziente()) return;
      const url = this.linkStorico();
      if (!url) { this.log(`${now()}  portale: su questa pagina non c'è il link «Storico Dati Clinici»`); return; }
      this._sotto = { t0: Date.now() };
      this.render();
      let s = { esito: "" };
      try {
        const r = await ask({ t: "apriStoricoSotto", url, ep: this.episodeId, nome: this.nomePaziente() });
        if (!r || !r.ok) { s = { esito: "rifiutato", why: r && r.why }; return; }
        // la tabella si scorre a passi (il portale disegna solo le colonne in
        // vista): con tanti prelievi ci vuole un po'
        while (Date.now() - this._sotto.t0 < 60000) {
          await sleep(800);
          s = await ask({ t: "esitoSotto", tabId: r.tabId });
          if (!s || !s.ok || (s.esito !== "attesa" && s.esito !== "lettura")) break;
        }
      } finally {
        this._sotto = null;
        // ancora «in lettura» allo scadere: quello che è arrivato è arrivato
        if (s && s.esito === "lettura") s = { ...s, esito: "letto" };
        if (s && s.esito === "letto") {
          this.log(`${now()}  storico del portale letto in sottofondo: ${s.esami} esami · ${s.prelievi} prelievi`);
          this.notaPortale = "";
          await this.caricaStorico();
        } else {
          const perche = {
            login: "il portale chiede di entrare", tempo: "la tabella non è comparsa in 30 secondi",
            altrove: "il portale si è aperto a un indirizzo che l'estensione non conosce (aggiungi l'indirizzo del portale)",
            nonportale: "il link dello storico non ha aperto il portale",
            altro: "il portale ha aperto un altro paziente: non lo attribuisco", chiusa: "la scheda del portale è stata chiusa",
            rifiutato: (s && s.why) || "non aperto",
          }[s && s.esito] || "nessuna risposta";
          this.log(`${now()}  storico del portale in sottofondo: ${perche}`);
          this.notaPortale = perche;
        }
        this.render();
      }
      return !!(s && s.esito === "letto");
    }

    // «⭳ Carica i valori». Lo storico del portale ha TUTTI i valori del
    // laboratorio, refertati e no: basta quello, una pagina sola. Le finestre
    // Risultati — una richiesta per prelievo — si leggono solo se il portale
    // non si può leggere: senza estensione, senza link, o se non ha risposto.
    async caricaValori() {
      if (!this.conPortale()) return this.reloadTuttiValori();
      const letto = await this.storicoInSottofondo();
      if (!letto) {
        this.log(`${now()}  leggo i prelievi dalle finestre Risultati, uno alla volta`);
        return this.reloadTuttiValori();
      }
    }
    conPortale() { return hasExt() && !!this.nomePaziente() && !!this.linkStorico(); }

    async caricaStorico() {
      if (this.pageType !== "patient" || !hasExt()) return;
      const prima = (this.storico?.letto || 0) + "|" + this.storicoAltri;
      // schedaMia() ha già deciso l'identità: qui non si ricontrolla, o la
      // regola finirebbe scritta in due posti e prima o poi in due modi
      const dati = await this.schedaMia();
      // rifiutare è giusto, rifiutare in silenzio no: il medico quella tabella
      // l'ha letta un minuto prima e deve sapere perché non è qui
      this.storico = dati && dati.righe ? dati : null;
      if (this.storico) this.storicoAltri = "";
      // si ridisegna solo se è cambiato qualcosa, e mai sopra una schermata in
      // cui si sta scrivendo: tornare su questa scheda non deve costare il cursore
      if ((this.storico?.letto || 0) + "|" + this.storicoAltri === prima) return;
      if (this.view === "dimtesto" || this.view === "dimimport" || this.view === "eotesto") return;
      if (this.root.activeElement && ["dfin", "riffiltro"].includes(this.root.activeElement.id)) return;
      this.render();
    }

    async refreshRefCache() {
      const ids = this.refertiMostrati().map((e) => e.id);
      if (!hasExt() || !ids.length) return;
      const r = await ask({ t: "listRef", ep: this.episodeId, ids });
      if (r && r.ok) { this.refCache = r.cached || {}; this.render(); this.estraiSalvati(); }
    }

    // Il testo dei PDF già salvati si legge SEMPRE, dalla copia su questo
    // computer: nessuna richiesta a nessuno, uno alla volta, appena si sa che
    // ci sono. Così il medico non deve toccare un referto per leggerlo.
    async estraiSalvati() {
      if (!hasExt() || this._estraggo) return;
      this._estraggo = true;
      try {
        for (const e of this.refertiMostrati()) {
          if (!(this.refCache || {})[e.id] || tabStore.get(this.txtKey(e.id), null) || this.refBusy?.[e.id] === true) continue;
          const g = await ask({ t: "getRef", id: e.id, ep: this.episodeId }).catch(() => null);
          if (!(g && g.ok && g.data)) continue;
          await this.leggiTesto(e, bufDaB64(g.data)).catch(() => null);
          this.render();
        }
      } finally { this._estraggo = false; }
    }

    // Chi è il paziente di questa pagina, per confrontarlo col referto: il
    // codice fiscale del riquadro (o l'impronta di quello dei prelievi), il
    // nome e la data di nascita. Niente di questo si tiene.
    identitaPaz() {
      const cf = this.pageType === "patient" ? cfInRiquadro(document) : "";
      return { cf, cfImp: this.cfEpisodio() || (cf ? impronta(cf) : ""), nome: this.nomePaziente(), nascita: nascitaInPagina(document) };
    }

    // Dal PDF al testo, e prima di tutto: di chi è. Un PDF intestato a un altro
    // paziente non lascia il suo testo, e la sua copia non resta sotto questo
    // referto.
    async leggiTesto(e, buf) {
      const letto = await testoPdf(buf);
      const righe = letto.righe;
      if (!righe.length) return { vuoto: true, letto };
      const id = identitaReferto(righe, this.identitaPaz());
      if (id.esito === "altro") {
        tabStore.set(this.txtKey(e.id), { ts: Date.now(), altro: true });
        if (hasExt()) {
          await ask({ t: "delRef", id: e.id, ep: this.episodeId }).catch(() => {});
          const c = { ...(this.refCache || {}) };
          delete c[e.id];
          this.refCache = c;
        }
        this.log(`${now()}  ${shortLabel(e.label)}: il PDF è intestato a un altro paziente (${id.via}): testo non mostrato, copia tolta`);
        return { altro: true, letto };
      }
      tabStore.set(this.txtKey(e.id), { ts: Date.now(), righe });
      // nella scheda del paziente va quello che si mostra: di un ECG, il referto scritto
      const mostra = refertoTipo(e) === "ecg" ? refertoScrittoEcg(righe).righe : righe;
      if (mostra.length) this.archiviaReferto(e, mostra);
      this.log(`${now()}  ${shortLabel(e.label)}: testo letto (${righe.length} righe, ${letto.lettore}${letto.motivo ? `; ${letto.motivo}` : ""}${id.esito === "ok" ? `; intestazione verificata: ${id.via}` : "; intestazione non verificata"})`);
      return { righe, letto };
    }

    // Cosa si mostra di un referto letto. L'identità si ricontrolla a ogni
    // disegno: il codice fiscale del paziente può arrivare dopo il testo.
    testoDi(e) {
      const t = tabStore.get(this.txtKey(e.id), null);
      if (!t) return null;
      if (t.altro) return { stato: "altro" };
      const righe = t.righe || [];
      const id = identitaReferto(righe, this.identitaPaz());
      if (id.esito === "altro") return { stato: "altro" };
      const verificato = id.esito === "ok";
      if (refertoTipo(e) === "ecg") {
        const s = refertoScrittoEcg(righe);
        return s.righe.length ? { stato: "testo", righe: s.righe, verificato } : { stato: "macchina", verificato };
      }
      return { stato: "testo", righe, verificato };
    }

    // In fila per scaricare: al massimo due insieme (un tocco e «Salva» stanno
    // nella stessa fila). Chi aspetta lo dice la sua riga.
    inFila(e, fn) {
      this.refCoda = this.refCoda || new Set();
      this.refCoda.add(e.id);
      this.render();
      return scaricaRef(async () => {
        this.refCoda.delete(e.id);
        this.refBusy = { ...(this.refBusy || {}), [e.id]: true };
        this.render();
        return await fn();
      }).finally(() => this.refCoda.delete(e.id));
    }

    // Il PDF di un referto: la copia salvata se c'è; se no lo si prende — dal
    // portale se il sistema sta là, se no dal gestionale (e, non riuscendo,
    // dal service worker) — e lo si tiene. Lo chiama solo un gesto del medico:
    // un tocco sul referto o «Salva i referti». Mai da solo.
    async scaricaReferto(e) {
      const id = e.id, ep = this.episodeId, pk = this.chiavePaz();
      if (hasExt() && (this.refCache || {})[id]) {
        const g = await ask({ t: "getRef", id, ep });
        if (g && g.ok && g.data) return { buf: bufDaB64(g.data), salvato: true };
      }
      let buf = null;
      try {
        // un sistema che si è già visto stare nel portale (ECG, RIS) ci va
        // diretto: chiedere di nuovo il link al gestionale solo per scoprire
        // che rimanda là sarebbe una richiesta in più
        if (nelPortale(e)) return { buf: await this.refertoDalPortale(e), salvato: true };
        buf = await (await fetchPdf(e.url, {})).blob.arrayBuffer();
      } catch (err) {
        if (err?.name === "AbortError" || !hasExt()) throw err;
        if (err && err.portale) {
          segnaPortale(e);
          return { buf: await this.refertoDalPortale(e), salvato: true };
        }
        // dal pannello no: ci prova il service worker, e se neanche lui il
        // perché dei due tentativi resta sul pallino e nella diagnosi
        const r = await ask({ t: "cacheRef", id, url: e.url, ep, pk });
        const g = r && r.ok ? await ask({ t: "getRef", id, ep }) : null;
        if (!(g && g.ok && g.data)) {
          err.diag = `${err.diag ? `${err.diag} · ` : ""}service worker: ${(r && r.why) || "non riuscito"}`;
          throw err;
        }
        this.refCache = { ...(this.refCache || {}), [id]: r.size || 1 };
        return { buf: bufDaB64(g.data), salvato: true };
      }
      if (!hasExt()) return { buf, salvato: false };
      const res = await ask({ t: "cacheRef", id, ep, pk, data: bufB64(buf), size: buf.byteLength });
      if (res && res.ok) {
        this.refCache = { ...(this.refCache || {}), [id]: res.size || 1 };
        return { buf, salvato: true };
      }
      return { buf, salvato: false, perche: `memoria: ${(res && res.why) || "non riuscito"}` };
    }

    // Il perché di un referto non letto: sul pallino, nella diagnosi e nel Registro.
    refertoRotto(e, err) {
      const why = `${(err && (err.head || err.message)) || "non letto"}${err && err.body ? ` — ${err.body}` : ""}${err && err.diag ? ` [${err.diag}]` : ""}`;
      this.refBusy = { ...(this.refBusy || {}), [e.id]: why };
      this.diagnosi = { cosa: `referto ${shortLabel(e.label)} (${e.sistema || "?"})`, url: e.url, html: (err && err.html) || "", diag: why, quando: now() };
      this.log(`${now()}  ${shortLabel(e.label)}: referto non letto (${why})`);
    }

    // «⭳ Salva i referti» e «⭳ Carica i valori»: quelli non ancora salvati
    // (mai il laboratorio), due alla volta con una pausa a caso prima di
    // ognuno, e di ognuno si legge subito il testo (dalla copia appena presa).
    // Il pannello non salva MAI da solo: lo decide il medico, con uno di
    // questi bottoni o con un tocco su un referto.
    async saveAllReferti() {
      if (!hasExt() || this._salva) return;   // due clic non sono due salvataggi
      const todo = this.refertiMostrati().filter((e) => !(this.refCache || {})[e.id]
        && this.refBusy?.[e.id] !== true && !(this.refCoda && this.refCoda.has(e.id)));
      if (!todo.length) return;
      this._salva = { fatti: 0, totale: todo.length };
      this.refBusy = this.refBusy || {};
      const pausa = () => sleep(PAUSA_REF[0] + Math.random() * (PAUSA_REF[1] - PAUSA_REF[0]));
      try {
        await Promise.all(todo.map((e) => this.inFila(e, () => pausa().then(() => this.scaricaReferto(e))).then(async (r) => {
          if (!r.salvato) {
            this.refBusy[e.id] = r.perche || "non salvato";
            this.log(`${now()}  referto non salvato (${shortLabel(e.label)}): ${this.refBusy[e.id]}`);
            return;
          }
          this.refBusy[e.id] = false;
          if (!tabStore.get(this.txtKey(e.id), null)) await this.leggiTesto(e, r.buf).catch(() => null);
        }, (err) => this.refertoRotto(e, err)).finally(() => {
          if (this._salva) this._salva.fatti++;
          this.render();
        })));
      } finally {
        // senza il finally una sola eccezione spegneva «Salva» per tutta la
        // vita della scheda, e i pallini restavano a girare
        this._salva = null;
        this.render();
      }
    }

    // dopo i valori, i referti: i già salvati (anche da un'altra scheda) no
    async caricaReferti() {
      if (!hasExt() || this._salva) return;
      await this.refreshRefCache().catch(() => {});
      return this.saveAllReferti();
    }

    txtKey(id) { return `reftxt.${this.episodeId || "x"}.${id}`; }

    // Il referto sta nel portale (ECG, radiologia): si apre col link del
    // gestionale — lo stesso clic del medico — in una scheda DIETRO. Là la
    // pagina lo scarica e lo mostra da sé, e lo script del portale ne passa
    // una copia; la scheda si chiude. Nessuna richiesta nostra.
    async refertoDalPortale(e) {
      // con chi è e cosa si è chiesto: là, fra i PDF che il portale mostra, si tiene il suo
      const chi = this.identitaPaz();
      const r = await ask({ t: "apriRefertoSotto", url: e.url, id: e.id, ep: this.episodeId, pk: this.chiavePaz(),
        nome: chi.nome, cfImp: chi.cfImp, nascita: chi.nascita, titolo: shortLabel(e.label || "") });
      if (!r || !r.ok) throw new StopError("Portale non aperto", (r && r.why) || "estensione non raggiungibile");
      this.log(`${now()}  ${shortLabel(e.label)}: lo apro nel portale, in una scheda dietro`);
      const fine = Date.now() + 45e3;
      let s = null;
      while (Date.now() < fine) {
        await sleep(900);
        s = await ask({ t: "esitoSotto", tabId: r.tabId });
        if (!s || !s.ok || (s.esito !== "attesa" && s.esito !== "lettura")) break;
      }
      if (!s || !s.ok || s.esito !== "letto") {
        const perche = {
          login: "il portale chiede di entrare: aprilo una volta e fai l'accesso",
          tempo: "il portale non l'ha mostrato in tempo", attesa: "il portale non l'ha mostrato in tempo",
          nonportale: "il link non ha portato al portale (sessione del gestionale?)",
          nonTrovato: "il portale l'ha aperto, ma il PDF non si vede da qui",
          altro: "il portale ha mostrato solo referti di un altro paziente: non tenuti",
          chiusa: "la scheda del portale è stata chiusa", altrove: "la scheda del portale è andata altrove",
        }[s && s.esito] || (s && s.esito) || "nessuna risposta dall'estensione";
        const x = new StopError("Referto non letto dal portale", perche);
        if (s && s.diag) x.diag = s.diag;
        throw x;
      }
      const g = await ask({ t: "getRef", id: e.id, ep: this.episodeId });
      if (!(g && g.ok && g.data)) throw new StopError("Referto letto ma non ritrovato", "riprova");
      this.refCache = { ...(this.refCache || {}), [e.id]: Math.round(g.data.length * 3 / 4) || 1 };
      return Uint8Array.from(atob(g.data), (c) => c.charCodeAt(0)).buffer;
    }

    // Un tocco su un referto lo apre LÌ, sotto la sua riga: il testo di
    // radiologia ed ECG (dell'ECG solo il referto scritto). Se non c'è ancora,
    // il tocco è il gesto che lo prende: in fila (due alla volta), lo tiene e
    // ne legge il testo. Un secondo tocco lo richiude. Gli altri documenti,
    // senza testo, si aprono nella loro scheda; il PDF è sempre a un tocco
    // (↗ PDF), anche quando il testo non esce.
    async espandi(id) {
      const e = this.esiti.find((x) => x.id === id);
      if (!e) return;
      segnaVisti(this.episodeId, [id]);
      if (this.espanso === id) { this.espanso = null; this.render(); return; }
      const tipo = refertoTipo(e);
      const testo = tabStore.get(this.txtKey(id), null);
      // non letto la volta scorsa: il documento si apre, invece del testo che non c'è
      if (!testo && typeof this.refBusy?.[id] === "string") return this.openReferto(id);
      if (!testo && tipo !== "rx" && tipo !== "ecg") return this.openReferto(id);
      this.espanso = id;
      this.render();
      if (testo || this.refBusy?.[id] === true || (this.refCoda && this.refCoda.has(id))) return;
      try {
        const r = await this.inFila(e, () => this.scaricaReferto(e));
        const l = await this.leggiTesto(e, r.buf);
        this.refBusy[id] = false;
        if (l.vuoto) {
          // I referti sono PDF di testo: se il testo non esce lo sbaglio è del
          // lettore. Si apre il PDF, e la diagnosi dice com'è fatto (la
          // struttura, mai il contenuto) per correggerlo.
          const diag = `${l.letto.motivo ? `${l.letto.motivo} · ` : ""}${pdfDiag(r.buf)}`;
          this.diagnosi = { cosa: `referto ${shortLabel(e.label)} (${e.sistema || "?"})`, url: e.url, html: "", diag, quando: now() };
          this.log(`${now()}  ${shortLabel(e.label)}: testo non letto — si apre il PDF (⧉ Diagnosi) [${diag}]`);
          if (this.espanso === id) this.espanso = null;
          this.render();
          return this.openReferto(id);
        }
      } catch (err) {
        // Non letto: si dice perché (sul pallino e nel Registro) e il
        // documento si apre lo stesso, con lo stesso tocco — non al secondo.
        this.refertoRotto(e, err);
        if (this.espanso === id) this.espanso = null;
        this.render();
        return this.openReferto(id);
      }
      this.render();
    }

    // The list shows only WHAT, never the text: at discharge the doctor knows
    // which sheet he wants, and reading it here would only cost him a scroll.
    // «Aperti»: prima di scrivere la dimissione, una riga sola con quello che
    // è ancora aperto — esami in attesa (con l'ora della richiesta), referti
    // non arrivati o non visti, promemoria, valori segnati o nuovi fuori
    // range. Solo quando c'è qualcosa, non blocca niente, e dice di quando è
    // la lettura. Copre quello che il pannello sa: la pagina del paziente e
    // gli ordini partiti da qui («ordinati da qui» se la pagina non l'ha letta).
    apertiHtml() {
      const ep = this.epDiQuesta();
      if (!ep) return "";
      const st = statoEsami(statoDi(ep));
      const voci = [];
      if (st) {
        for (const e of st.esami.filter((x) => !x.fatto).sort((a, b) => (a.ts || 0) - (b.ts || 0))) {
          voci.push(`${frase(e.label)}${e.tipo === "lab" ? "" : " non refertato"}${e.ts ? ` (${hhmm(e.ts)})` : ""}`);
        }
        for (const e of st.nuovi) if (e.tipo !== "lab") voci.push(`${frase(e.label)}: referto da leggere`);
      }
      const daFare = dfAperte(ep).length;
      if (daFare) voci.push(`Da fare: ${daFare}`);
      const segnati = Object.keys(leggiSegni(this.chiaveNota())).length;
      if (segnati) voci.push(segnati === 1 ? "1 valore segnato" : `${segnati} valori segnati`);
      if (st && st.valoriFuori) voci.push(`${st.valoriFuori === 1 ? "1 valore nuovo" : `${st.valoriFuori} valori nuovi`} fuori range, non letti`);
      if (!voci.length) return "";
      const MAX = 8, vedi = voci.length > MAX ? [...voci.slice(0, MAX - 1), `e altri ${voci.length - MAX + 1}`] : voci;
      const coda = [st && st.soloQui && st.esami.length ? "ordinati da qui" : "", st && st.letto ? `letto alle ${hhmm(st.letto)}` : ""].filter(Boolean);
      return `<div class="aperti" role="status" title="${esc(voci.join("\n"))}"><b>Aperti:</b> ${vedi.map(esc).join(" · ")}${
        coda.length ? ` <span class="apl">· ${esc(coda.join(" · "))}</span>` : ""}</div>`;
    }
    viewDimissioni() {
      const tutte = dimissioni();
      const chiavi = Object.keys(tutte);
      // I fogli rivisti stanno in cima, gli altri sotto una riga che lo dice:
      // così si vede a colpo d'occhio dove si è già messo mano.
      let stacco = false;
      const righe = chiavi.map((k) => {
        const d = tutte[k];
        let sep = "";
        if (!d.mio && !d.rivisto && !stacco && chiavi.some((x) => tutte[x].rivisto)) {
          stacco = true;
          sep = `<div class="dsep"><span>non ancora rivisti</span></div>`;
        }
        const n = d.testo.split("\n").filter((r) => r.trim()).length;
        const segno = d.mio ? `<span class="dtuo" title="Un foglio scritto da te">tuo</span>`
          : d.aggiornato ? `<span class="dmod agg" title="L'originale è cambiato dopo la tua modifica">⟳</span>`
          : d.modificato ? `<span class="dmod" title="Testo modificato da te">•</span>` : "";
        return `${sep}
        <div class="drow">
          <button class="dcopia" data-dcopy="${esc(k)}" title="Copia negli appunti il foglio «${esc(d.nome)}»"
                  aria-label="Copia il foglio ${esc(d.nome)}">
            <span class="dnome">${esc(d.nome)}${segno}</span>
            <span class="dmeta">${n} righe</span><span class="dico">⧉</span>
          </button>
          <button class="dbtn" data-dedit="${esc(k)}" title="Modifica il testo di «${esc(d.nome)}»"
                  aria-label="Modifica il foglio ${esc(d.nome)}">✎</button>
        </div>`;
      }).join("");
      // le deleghe per il ritiro si danno a chi va a casa: stanno qui, in cima
      const ritiro = CONSENSI.filter((c) => c.gruppo === "ritiro");
      return `
        ${this.apertiHtml()}
        ${ritiro.length ? `
        <div class="sec">
          <div class="lbl" title="${esc(this.notaModuli())}">Moduli per il ritiro (${ritiro.length})</div>
          <div class="mlist">${ritiro.map((c) => this.rigaModulo(c)).join("")}</div>
        </div>` : ""}
        <div class="sec">
          <div class="lbl">Fogli di dimissione (${chiavi.length})</div>
          <div class="dlist">${righe}
            <button type="button" class="dnuovo" id="dimnuovo" title="Scrivi un foglio tuo: resta in cima all'elenco, su questo computer"><span class="dplus" aria-hidden="true">+</span>Nuovo foglio di dimissione</button>
          </div>
        </div>`;
    }

    // The editor keeps a draft in tabStore at every keystroke: the EHR retitles
    // the page (which re-renders the panel) and reloads it under the doctor's
    // hands, and a rewritten sheet must never die to something he did not do.
    dimDraftKey(k) { return "dimdraft." + k; }
    viewDimTesto() {
      const k = this.viewId;
      // un foglio nuovo non è ancora nell'elenco: nasce vuoto, nome compreso
      const nuovo = k === DIM_NUOVO;
      const d = nuovo ? { nome: "", testo: "", mio: true, nuovo: true } : dimissioni()[k];
      if (!d) return `<div class="hint">Testo non disponibile.</div>`;
      const bozza = tabStore.get(this.dimDraftKey(k), null);
      const testo = bozza && typeof bozza.testo === "string" ? bozza.testo : d.testo;
      const nome = bozza && typeof bozza.nome === "string" ? bozza.nome : d.nome;
      const bottoni = `
            <button class="mini" id="dimcopy" title="Copia questo testo senza salvarlo">⧉ Copia</button>
            <button class="mini" id="dimsave" title="${nuovo ? "Aggiungi questo foglio ai tuoi" : "Tieni questo testo per le prossime dimissioni"}">✓ Salva</button>
            ${d.modificato && !nuovo ? `<button class="mini" id="dimreset" title="${d.mio ? "Elimina questo foglio" : "Butta le tue modifiche e riprendi l'originale"}">${d.mio ? "✕ Elimina" : "↺ Originale"}</button>` : ""}`;
      // i fogli tuoi si possono anche rinominare; quelli del pannello no
      const testa = d.mio
        ? `<div class="dhd"><input class="dtit" id="dimnome" type="text" maxlength="60" value="${esc(nome)}" spellcheck="false" autocomplete="off"
             placeholder="Nome del foglio — es. Lombalgia acuta" aria-label="Nome del foglio">${bottoni}</div>`
        : `<div class="lbl">${esc(d.nome)}${bottoni}</div>`;
      return `
        <div class="sec">
          ${testa}
          ${d.aggiornato ? `<div class="banner warn">L'originale è cambiato dopo la tua modifica: ↺ Originale per la versione nuova.</div>` : ""}
          ${!nuovo && (testo !== d.testo || nome !== d.nome) ? `<div class="banner ok">Bozza non salvata.</div>` : ""}
          <textarea class="dedit" id="dimarea" spellcheck="false" aria-label="Testo del foglio ${esc(nome || "nuovo")}"
            placeholder="Terapia, controlli, quando tornare">${esc(testo)}</textarea>
          <div class="hint">Niente dati del paziente: è un modello.</div>
        </div>`;
    }

    // Un tocco apre il modulo e la finestra di stampa. I PDF sono dentro
    // l'estensione: nessuna richiesta al server, funziona anche offline.
    // Fine turno: una pagina HTML da guardare o stampare, raggruppata per
    // paziente, coi totali per attività. Come per l'editor dei fogli, si apre
    // anche in una scheda: un download che il browser rifiuta non deve
    // lasciare le mani vuote.
    esportaTempi() {
      const chiusi = tempi().filter((t) => t.fine).sort((a, b) => a.inizio - b.inizio);
      if (!chiusi.length) return;
      const perPaz = new Map(), perTit = new Map();
      for (const t of chiusi) {
        const k = t.paz || "(senza paziente)";
        if (!perPaz.has(k)) perPaz.set(k, []);
        perPaz.get(k).push(t);
        perTit.set(t.titolo, (perTit.get(t.titolo) || 0) + durata(t));
      }
      const tot = chiusi.reduce((n, t) => n + durata(t), 0);
      const riga = (t) => `<tr><td>${esc(t.titolo)}</td><td class="n">${esc(mmss(durata(t)))}</td><td class="n">${esc(oraDi(t.inizio))}</td><td class="n">${esc(oraDi(t.fine))}</td></tr>`;
      const html = `<!doctype html><html lang="it"><head><meta charset="utf-8">
<title>Tempi ${esc(giornoDi(chiusi[0].inizio))}</title><style>
  body{font:14px/1.5 -apple-system,"Segoe UI",Roboto,Arial,sans-serif;color:#151E27;background:#fff;margin:0;padding:28px 22px 60px}
  h1{font-size:22px;margin:0 0 4px} .sub{color:#5D6E7E;font-size:13px;margin-bottom:22px}
  h2{font-size:15px;margin:22px 0 6px;padding-bottom:4px;border-bottom:1px solid #DBE3EA;display:flex;justify-content:space-between}
  table{border-collapse:collapse;width:100%;max-width:760px} td,th{padding:4px 8px;border-bottom:1px solid #EDF1F6;text-align:left}
  th{font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:#8397A8}
  .n{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap} .tot{font-weight:700}
  @media print{body{padding:0}}
</style></head><body>
<h1>Tempi — ${esc(giornoDi(chiusi[0].inizio))}</h1>
<p class="sub">${chiusi.length} attività · totale <b>${esc(mmss(tot))}</b> · dalle ${esc(oraDi(chiusi[0].inizio))} alle ${esc(oraDi(chiusi[chiusi.length - 1].fine))}</p>
<h2>Per attività</h2>
<table><tbody>${[...perTit.entries()].sort((a, b) => b[1] - a[1])
  .map(([k, v]) => `<tr><td>${esc(k)}</td><td class="n tot">${esc(mmss(v))}</td><td class="n">${Math.round((v / tot) * 100)}%</td></tr>`).join("")}</tbody></table>
${[...perPaz.entries()].map(([paz, l]) => `<h2><span>${esc(paz)}</span><span class="tot">${esc(mmss(l.reduce((n, t) => n + durata(t), 0)))}</span></h2>
<table><thead><tr><th>Attività</th><th class="n">Durata</th><th class="n">Inizio</th><th class="n">Fine</th></tr></thead>
<tbody>${l.map(riga).join("")}</tbody></table>`).join("")}
</body></html>`;
      // UN solo Blob: prima se ne creavano due per lo stesso testo e il secondo
      // non veniva mai liberato, quindi restava in memoria per tutta la scheda
      const u = URL.createObjectURL(new Blob([html], { type: "text/html" }));
      let file = false;
      try {
        const a = document.createElement("a");
        a.href = u; a.download = `tempi-${new Date(chiusi[0].inizio).toISOString().slice(0, 10)}.html`;
        document.documentElement.appendChild(a); a.click(); a.remove();
        file = true;
      } catch { /* la scheda qui sotto resta */ }
      openTab(u, "_blank");
      setTimeout(() => URL.revokeObjectURL(u), 60000);
      this.message = { ok: file ? "Tempi esportati: file nei download, e aperti in una scheda." : "Tempi aperti in una scheda: da lì Ctrl+S o Ctrl+P." };
      this.render();
    }

    // Riferimenti: la tabella dei «can't-miss killers», da consultare al
    // volo. Scrivendo si filtra (anche in italiano: «cefalea», «sincope»).
    viewRiferimenti() {
      const q = this.rifFiltro || "";
      const gruppi = RIFERIMENTI.gruppi.map((g) => {
        const righe = g.voci.map(([chi, cosa, ita]) => `
          <div class="rifr" data-rif="${esc([chi, cosa, ita].join(" "))}"${q && !rifCombacia([chi, cosa, ita].join(" "), q) ? " hidden" : ""}>
            <b>${esc(chi)}</b><span>${g.freccia ? `<i aria-hidden="true">→</i> ` : ""}${esc(cosa)}</span>
          </div>`).join("");
        return `<div class="rifg"><div class="lbl">${esc(g.titolo)}</div><div class="rift">${righe}</div></div>`;
      }).join("");
      return `
        <div class="sec rif">
          <div class="rifanc">${esc(RIFERIMENTI.ancora)}</div>
          <input id="riffiltro" type="search" autocomplete="off" spellcheck="false" value="${esc(q)}"
                 placeholder="Filtra: chest, cefalea, sincope, anziano…" aria-label="Filtra i riferimenti">
          ${gruppi}
          <div class="rifvuoto" hidden>Niente per «<span></span>».</div>
          <div class="rifpiede">${esc(RIFERIMENTI.piede)}</div>
        </div>`;
    }
    // filtra senza ridisegnare: il campo tiene il cursore
    rifFiltra() {
      const q = this.rifFiltro || "";
      let quante = 0;
      this.root.querySelectorAll(".rifg").forEach((g) => {
        let qui = 0;
        g.querySelectorAll(".rifr").forEach((r) => {
          const si = !q || rifCombacia(r.getAttribute("data-rif") || "", q);
          r.hidden = !si; if (si) qui++;
        });
        g.hidden = !qui; quante += qui;
      });
      const vuoto = this.root.querySelector(".rifvuoto");
      if (vuoto) { vuoto.hidden = !!quante; vuoto.querySelector("span").textContent = q; }
    }

    viewTempi() {
      const t = tempoInCorso();
      const chiusi = tempi().filter((x) => x.fine).sort((a, b) => b.inizio - a.inizio);
      const chi = this.nomePaziente();
      const preset = TITOLI.map((x) => `<button class="tpre" data-avvia="${esc(x)}">${esc(x)}</button>`).join("");
      const tot = chiusi.reduce((n, x) => n + durata(x), 0);
      const righe = chiusi.slice(0, 40).map((x) => `
        <div class="trow">
          <span class="tt">${esc(x.titolo)}</span>
          <span class="tp">${esc(x.paz || "—")}</span>
          <span class="td">${esc(mmss(durata(x)))}</span>
          <span class="to">${esc(oraDi(x.inizio))}–${esc(oraDi(x.fine))}</span>
          <button class="tdel" data-scorda="${esc(x.id)}" title="Togli questa riga">✕</button>
        </div>`).join("");
      return `
        <div class="sec">
          ${t ? `
            <div class="tnow">
              <span class="tbig">${esc(mmss(durata(t)))}</span>
              <span class="tlab">${esc(t.titolo)}${t.paz ? ` · ${esc(t.paz)}` : ""}</span>
              <button class="btn primary" id="tstop2">⏹ Ferma</button>
            </div>` : `
            <div class="lbl">Cosa stai facendo${chi ? ` · ${esc(chi)}` : ""}</div>
            <div class="tpres">${preset}</div>
            <div class="tlibero">
              <input id="tlib" placeholder="…oppure scrivilo" maxlength="60" aria-label="Attività">
              <button class="mini" id="tavvia">▶ Avvia</button>
            </div>`}
          <div class="lbl" title="Si salva l'istante di inizio, non i secondi passati: ricaricare la pagina o riavviare il browser non cambia il conto. Restano una settimana, su questo computer.">Registrati (${chiusi.length})${chiusi.length ? `<button class="mini" id="texp">⬇ Esporta</button><span class="ttot">totale ${esc(mmss(tot))}</span>` : ""}</div>
          <div class="tlist">${righe}</div>
        </div>`;
    }

    // EO — un tocco copia l'esame obiettivo generale. Sotto, una tendina con
    // le aggiunte per caso: sceglierne una la copia subito, e la lascia
    // scritta qui perché si veda cosa è finito negli appunti.
    viewEo() {
      const voci = eoVoci();
      const basi = Object.entries(voci).filter(([, v]) => v.gruppo === "base");
      const sel = voci[this.eoSel] ? this.eoSel : "";
      const scelta = sel ? voci[sel] : null;
      const opz = (gruppo, etichetta) => {
        const l = Object.entries(voci).filter(([, v]) => v.gruppo === gruppo);
        if (!l.length) return "";
        return `<optgroup label="${esc(etichetta)}">${l.map(([k, v]) =>
          `<option value="${esc(k)}"${k === sel ? " selected" : ""}>${esc(v.nome)}${v.modificato ? " •" : ""}</option>`).join("")}</optgroup>`;
      };
      if (!Object.keys(voci).length) return `<div class="hint">Modelli di EO non disponibili in questa versione.</div>`;
      return `
        <div class="sec">
          <div class="lbl">Esame obiettivo</div>
          ${basi.map(([k, b]) => `
            <div class="drow">
              <button class="dcopia" data-eocopy="${esc(k)}" title="Copia negli appunti: ${esc(b.nome)}"
                      aria-label="Copia ${esc(b.nome)}">
                <span class="dnome">${esc(b.nome)}${b.aggiornato ? `<span class="dmod agg" title="L'originale è cambiato dopo la tua modifica">⟳</span>` : b.modificato ? `<span class="dmod" title="Testo modificato da te">•</span>` : ""}</span>
                <span class="dmeta">${esc(b.meta)}</span><span class="dico">⧉</span>
              </button>
              <button class="dbtn" data-eoedit="${esc(k)}" title="Riscrivi: ${esc(b.nome)}" aria-label="Modifica ${esc(b.nome)}">✎</button>
            </div>`).join("")}
          <div class="lbl" title="Prima l'EO generale, poi l'aggiunta del caso: due incollate. ✎ riscrive un testo per le volte successive (• = riscritto da te). I testi sono uguali per tutti i pazienti: quello che riguarda questo paziente si scrive in cartella.">Aggiungi per caso</div>
          <select class="res" id="eocaso" aria-label="Aggiunta di esame obiettivo da copiare">
            <option value="">Scegli…</option>
            ${opz("casi", "Casi")}
            ${opz("frasi", "Frasi pronte")}
          </select>
          <div class="drow eoazione" ${scelta ? "" : "hidden"}>
            <button class="dcopia" data-eocopy="${esc(sel)}" id="eoricopia" title="Copia di nuovo questo testo">
              <span class="dnome">Copia di nuovo</span><span class="dico">⧉</span>
            </button>
            <button class="dbtn" data-eoedit="${esc(sel)}" id="eoedit" title="Riscrivi questo testo" aria-label="Modifica questo testo">✎</button>
          </div>
          <div class="eotxt" id="eotxt" ${scelta ? "" : "hidden"}>${esc(scelta ? scelta.testo : "")}</div>
        </div>`;
    }

    // Riscrivere un testo dell'EO: come un foglio di dimissione. La bozza si
    // tiene a ogni tasto, perché il gestionale ridisegna la pagina sotto le mani.
    eoDraftKey(k) { return "eodraft." + k; }
    viewEoTesto() {
      const k = this.viewId;
      const v = eoVoci()[k];
      if (!v) return `<div class="hint">Testo non disponibile.</div>`;
      const bozza = tabStore.get(this.eoDraftKey(k), null);
      const testo = bozza && typeof bozza.testo === "string" ? bozza.testo : v.testo;
      return `
        <div class="sec">
          <div class="lbl">${esc(v.nome)}
            <button class="mini" id="eocopia" title="Copia questo testo senza salvarlo">⧉ Copia</button>
            <button class="mini" id="eosave" title="Tieni questo testo per le prossime volte">✓ Salva</button>
            ${v.modificato ? `<button class="mini" id="eoreset" title="Butta le tue modifiche e riprendi l'originale">↺ Originale</button>` : ""}
          </div>
          ${v.aggiornato ? `<div class="banner warn">L'originale è cambiato dopo la tua modifica: ↺ Originale per la versione nuova.</div>` : ""}
          ${testo !== v.testo ? `<div class="banner ok">Bozza non salvata.</div>` : ""}
          <textarea class="dedit" id="eoarea" spellcheck="false" aria-label="Testo di ${esc(v.nome)}">${esc(testo)}</textarea>
          <div class="hint">Niente dati del paziente: è un modello.</div>
        </div>`;
    }

    // Un modulo in elenco: un tocco lo apre e parte la stampa. Lo stesso per i
    // consensi e per i moduli della dimissione.
    rigaModulo(c) {
      return `<button class="crow" data-cons="${esc(c.k)}" title="${esc(c.esteso)}">
          <span class="cnome">${esc(c.nome)}</span>
          ${c.pagine > 1 ? `<span class="cpag" title="Esce così tanta carta">${esc(String(c.pagine))} pagine</span>` : ""}
          <span class="cgo">🖨 apri e stampa</span>
        </button>`;
    }
    notaModuli() {
      return hasExt()
        ? "I moduli sono dentro l'estensione: si aprono anche se il gestionale è lento o giù, e nessuna richiesta esce dal computer."
        : "Servono i moduli dell'estensione: con il preferito (bookmarklet) questa sezione non ha i PDF.";
    }

    // Solo i consensi da firmare. Le deleghe per il ritiro (esami, referto RX,
    // cartella e CD) si danno al paziente quando va a casa: stanno nella
    // schermata Dimissioni, dove servono.
    viewConsensi() {
      const consensi = CONSENSI.filter((c) => !c.gruppo);
      return `
        <div class="sec">
          <div class="lbl" title="${esc(this.notaModuli())}">Moduli di consenso (${consensi.length})</div>
          <div class="dlist">${consensi.map((c) => this.rigaModulo(c)).join("")}</div>
        </div>`;
    }

    // Import is a paste screen, not a window.prompt: a 20 KB JSON in a
    // one-line browser dialog cannot be read, checked or corrected.
    viewDimImport() {
      return `
        <div class="sec">
          <div class="lbl">Importa i fogli
            <button class="mini" id="dimimpok">⤒ Importa</button>
          </div>
          <textarea class="dedit" id="dimimparea" spellcheck="false"
                    placeholder="Incolla qui il JSON esportato con ⬇ JSON" aria-label="JSON dei fogli di dimissione"></textarea>
          <div class="hint">Entrano solo i testi diversi dagli originali: gli altri restano come sono.</div>
        </div>`;
    }

    async openReferto(id) {
      const r = this.esiti.find((x) => x.id === id);
      if (!r) return;
      segnaVisti(this.episodeId, [id]);
      if ((this.refCache || {})[id] && hasExt()) {          // saved copy → instant, no server
        const got = await ask({ t: "getRef", id, ep: this.episodeId });
        if (got && got.ok && got.data) {
          if (await this.vediReferto(r, bufDaB64(got.data))) return;
          const bin = atob(got.data);
          const arr = new Uint8Array(bin.length);
          for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
          const url = URL.createObjectURL(new Blob([arr], { type: "application/pdf" }));
          openTab(url, "_blank");
          setTimeout(() => URL.revokeObjectURL(url), 60000);
          return;
        }
      }
      const name = "psaRef_" + String(id).replace(/\W/g, ""); // else its own tab, reused on re-click
      const w = openTab("", name);
      if (!w) { this.message = "Consenti i popup per aprire i referti."; this.render(); return; }
      let blank = true;
      try { blank = !w.location.href || w.location.href === "about:blank"; } catch { blank = false; }
      if (blank) w.location.href = r.url;
      try { w.focus(); } catch { /* ignore */ }
      const open = new Set(tabStore.get(this.refKey(), []));
      open.add(id);
      tabStore.set(this.refKey(), [...open]);
      this.render();
      // Qui prima si rileggeva il PDF per tenerne una copia: una seconda
      // richiesta per un documento che è già sullo schermo del medico. Per
      // tenerne una copia c'è «⬇ Salva referti», che è una cosa che si chiede.
    }

    // Un referto salvato si apre nel visore dell'estensione, dalla copia su
    // questo computer: anche senza testo, mai di un altro paziente.
    async vediReferto(e, buf) {
      let t = this.testoDi(e);
      if (!t) {
        const l = await this.leggiTesto(e, buf).catch(() => null);
        t = l && l.altro ? { stato: "altro" } : this.testoDi(e);
      }
      if (t && t.stato === "altro") {
        this.message = "Referto di un altro paziente: non mostrato.";
        this.render();
        return true;
      }
      const lib = await pdfjsPronto().catch(() => null);
      if (!lib) return false;
      return apriVisore(lib, buf, [this.nomePaziente(), shortLabel(e.label), e.when].filter(Boolean).join(" · "));
    }

    resetArmato() { return Date.now() - (this._resetArmato || 0) < 6000; }
    async resetDatiPazienti() {
      if (this.giroInCorso()) return;
      azzeraPazienti();
      if (hasExt()) await ask({ t: "resetPazienti" }).catch(() => null);
      this.dimenticaTutto();
      this.message = { ok: "Fatto." };
      this.render();
    }
    // quello che il pannello tiene in mente, oltre la memoria
    dimenticaTutto() {
      this.storico = null; this.storicoAltri = ""; this.storicoDaConfermare = false; this.notaPortale = "";
      this.refCache = {}; this.refBusy = {}; this.espanso = null; this.diagnosi = null;
      this.rottiTab.clear(); this.logLines = [];
      this.esiti = esitiModel(document, location.href);
    }

    async resetReferti() {
      for (const id of tabStore.get(this.refKey(), [])) {
        try { openTab("", "psaRef_" + String(id).replace(/\W/g, ""))?.close(); } catch { /* ignore */ }
      }
      tabStore.set(this.refKey(), []);
      if (hasExt()) await ask({ t: "clearRef" });
      for (const k of tabStore.keys(`reftxt.${this.episodeId || "x"}.`)) tabStore.del(k);   // il testo veniva da quelle copie
      this.refCache = {}; this.refBusy = {}; this.espanso = null;
      this.render();
    }

    // Copy the log for reporting. The quesito is the only clinical text that
    // can end up in it, so it is masked out before leaving the page.
    async copyLog() {
      const head = [`PS Assist ${VERSION} · pagina ${this.pageType}`, `${navigator.userAgent}`, `${new Date().toLocaleString("it-IT")}`, ""].join("\n");
      const text = head + this.logLines.join("\n").replace(/(quesito[^:]*:\s*)"[^"]*"/gi, '$1"…"');
      const ok = await copiaTesto(text);
      const b = this.root.querySelector("#copylog");
      segnaCopia(b, ok);
    }

    // full values of one accesso, inside the panel
    // Two things the doctor must never discover by himself: a name this
    // program does not know (its abbreviation would be a guess) and a row it
    // refused to read. Both are declared, with the names, and nothing is
    // hidden — the values are all on screen anyway.
    avvisoNomi(rows, scartate) {
      const inattesi = nomiInattesi(rows);
      const amb = sigleAmbigue(rows);
      const doppi = (rows || []).filter((r) => r.nome && amb.has(chiaveAmbigua(r))).map((r) => r.nome).filter((n, i, a) => a.indexOf(n) === i);
      const persi = (scartate || []).filter((x) => x && x.nome);
      // due nomi che si abbrevierebbero uguale sono GIÀ scritti per esteso in
      // tabella: non meritano un avviso a ogni emocromo, solo l'elenco «quali»
      if (!inattesi.length && !persi.length) return "";
      const pezzi = [];
      if (inattesi.length) pezzi.push(`${inattesi.length} ${inattesi.length === 1 ? "nome non in elenco" : "nomi non in elenco"}`);
      if (persi.length) pezzi.push(`${persi.length} ${persi.length === 1 ? "riga non letta" : "righe non lette"}`);
      const elenco = [
        inattesi.length ? "Non in elenco: " + inattesi.join(", ") : "",
        doppi.length ? "Stessa abbreviazione: " + doppi.join(", ") : "",
        persi.length ? "Non lette: " + persi.map((x) => `${x.nome} = ${x.valore}`).join(" · ") : "",
      ].filter(Boolean).join("\n");
      return `<div class="avvnomi" title="${esc((inattesi.length ? "Scritti per esteso e sottolineati: di questi non conosco la sigla.\n" : "") + elenco)}">
          <span class="avvi">!</span><span>${esc(pezzi.join(" · "))}</span>
          <button class="avvb" id="avvnomi" type="button">${this.mostraNomi ? "nascondi" : "quali"}</button>
        </div>${this.mostraNomi ? `<div class="avvlista">${esc(elenco)}</div>` : ""}`;
    }

    async openEsito(id) { return this.espandi(id); }

    // One tap re-reads EVERY open draw, paced one request at a time: the manual
    // rehearsal of a future automatic refresh — same read, same honesty (an
    // empty or dead page never replaces values already held). Reported draws
    // (storico) are skipped: their page no longer answers.
    async reloadTuttiValori() {
      if (this._refreshAll) return;
      const targets = this.esiti.filter((e) => e.kind === "valori" && !e.storico);
      if (!targets.length) return;
      this._refreshAll = { done: 0, total: targets.length };
      this.refBusy = this.refBusy || {};
      for (const e of targets) this.refBusy[e.id] = true;
      this.render();
      let cambiati = 0;
      try {
      for (const e of targets) {
        const key = this.risKey(e.id);
        const prima = JSON.stringify((tabStore.get(key, null) || {}).rows || []);
        try {
          const mai = !tabStore.get(this.vistoKey(e.id), null);
          const rows = await this.leggiPrelievo(e, { baseline: mai });
          this.rottiTab.delete(e.id);
          if (rows && JSON.stringify(rows) !== prima) cambiati++;
          // una riga nel Registro per prelievo: quando la tabella non torna,
          // qui si vede cosa è stato letto e cosa non ha una data per entrarci
          const inTabella = rows && rows.length ? prelievoComeTabella(risMeta(e), rows, "") : null;
          this.log(`${now()}  ${e.when || "senza data"} · ${shortLabel(e.label)}: ${rows ? rows.length : 0} valori${
            inTabella ? ` → colonna ${inTabella.date[0].ignota ? "«?» (il gestionale non dà data e ora)" : inTabella.date[0].label}` : ""}`);
        } catch (err) {
          this.rottiTab.add(e.id);   // lo dice la schermata, non solo il Registro
          this.log(`${now()}  ${shortLabel(e.label)}: valori non aggiornati (${err?.head || err?.message || err})`);
        }
        this.refBusy[e.id] = false;
        this._refreshAll.done++;
        this.render();
        await sleep(PACE_MS).catch(() => {});
      }
      } finally {
        // come per «Salva referti»: senza il finally «↻ Aggiorna» resta
        // disabilitato per sempre alla prima eccezione
        this._refreshAll = null;
        for (const e of targets) this.refBusy[e.id] = false;
      }
      const letti = targets.filter((e) => !this.rottiTab.has(e.id)).length;
      this.log(`${now()}  letti ${letti} prelievi su ${targets.length}${cambiati ? `, ${cambiati} con valori nuovi` : ", nessun valore nuovo"}`);
      this.render();
    }

    // Values ready before he asks: the 2-line preview is the point of Esiti.
    // UNA lettura di un prelievo, usata da tutti: aprirlo, rileggerlo,
    // ↻ Aggiorna, e il precarico. Prima erano quattro copie della stessa
    // sequenza con quattro politiche d'errore diverse — ed è da lì che
    // veniva un prelievo rotto riletto a ogni ricarico di pagina.
    async leggiPrelievo(e, { baseline = false } = {}) {
      const key = this.risKey(e.id);
      const { doc } = await fetchDoc(e.url, {});
      const { rows, scartate } = parseRisultati(doc);
      const cf = cfImpronta(doc);
      // una finestra che non risponde più non cancella quello che sapevamo
      if (!rows.length && (tabStore.get(key, null) || {}).rows?.length) {
        this.log(`${now()}  la finestra Risultati non risponde più: tengo i valori già letti`);
        return null;
      }
      tabStore.set(key, { ts: Date.now(), rows, scartate, cf, meta: risMeta(e) });
      // in scheda PRIMA di rileggerla, o la riga «Storico» negli Esiti
      // comparirebbe solo alla prossima visita. Un archivio che fallisce non
      // è un prelievo non letto: i valori sono già qui sopra.
      await this.archiviaPrelievo(e, rows, cf, scartate).catch((err) => this.log(`${now()}  prelievo non archiviato (${err?.message || err})`));
      if (baseline) this.segnaVisto(e.id, rows);   // prima lettura: è il riferimento
      // coi valori arriva il codice fiscale: adesso la scheda clinica del
      // portale si può attribuire (o escludere) con certezza — e il prelievo
      // appena letto è già dentro
      this.caricaStorico();
      return rows;
    }

    // Aprire un paziente NON legge niente. I valori si leggono quando li
    // chiedi: aprendo un prelievo, o col bottone «Carica i valori» che li
    // prende tutti, uno alla volta. Un clic su un paziente non è una
    // richiesta di leggere il laboratorio.
    daLeggere() {
      return this.esiti.filter((x) => x.kind === "valori"
        && !tabStore.get(this.risKey(x.id), null) && !this.rottiTab.has(x.id));
    }

    // Le risorse di QUESTA sede, lette dalla pagina: i link «Richieste
    // Laboratorio/Radiologia» (paziente), l'indirizzo (nuova richiesta), la
    // tendina (esami). Vuoto = non si sa, e allora si mostra tutto.
    risorseQui() {
      const ids = new Set();
      const da = (u) => (param(u || "", "RISORSE") || "").split(",").filter(Boolean).forEach((x) => ids.add(x));
      if (this.pageType === "patient") { da(this.entry?.labUrl); da(this.entry?.radioUrl); }
      else da(location.href);
      if (this.pageType === "exam") examModel(document, location.href).resOptions.forEach((o) => ids.add(o.value));
      return ids;
    }

    viewBrowse(cat) {
      const q = (this.acq || "").trim().toUpperCase();
      let drop = "";
      if (q.length >= 2) {
        // I nomi che si dicono in reparto non sono quelli del laboratorio:
        // «PCR» è «PROTEINA C REATTIVA», che scrivendo PCR non si trovava —
        // e restava solo la PCR POC.
        const alias = ALIAS_RICERCA[q] || [];
        // solo le risorse di questa sede: senza, ogni esame compariva due
        // volte, una per sede, con un codice che qui non vale
        // (se di questa sede il catalogo non conosce ancora niente, si mostra
        // tutto: meglio un doppione che una ricerca vuota)
        const noti = [...this.risorseQui()].filter((r) => cat[r]);
        const qui = new Set(noti);
        const hits = [];
        for (const [res, v] of Object.entries(cat)) {
          if (qui.size && !qui.has(res)) continue;
          for (const [code, label] of Object.entries(v.items || {})) {
            const L = label.toUpperCase();
            const perAlias = alias.some((x) => L.startsWith(x));
            if (perAlias || L.includes(q)) hits.push({ res, code, label, perAlias, poc: ePoc(label) || ePoc(v.label) });
          }
        }
        // Le Urgenze sono un sottomenu del laboratorio centrale: lo stesso
        // esame stava due volte, identico, una riga per ciascuno. Una sola:
        // quella delle Urgenze, come la ordinano i pacchetti («PT PTT
        // Fantoli» = Urgenze) — o quella già scelta, se è l'altra.
        {
          const uno = new Map();
          for (const h of hits) {
            const k = `${risorsaCorta(h.res, cat)}|${normEsame(h.label)}`;
            const c = uno.get(k);
            const meglio = !c || (this.isSel(h.res, h.code) && !this.isSel(c.res, c.code))
              || (this.isSel(h.res, h.code) === this.isSel(c.res, c.code) && ordineRisorsa(h.res, cat) < ordineRisorsa(c.res, cat));
            if (meglio) uno.set(k, h);
          }
          const tenuti = new Set(uno.values());
          for (let i = hits.length - 1; i >= 0; i--) if (!tenuti.has(hits[i])) hits.splice(i, 1);
        }
        // prima il nome che il medico intendeva, e fra quelli il laboratorio
        // prima del POC; poi chi comincia con quello che ha scritto
        const rango = (h) => (h.perAlias ? 0 : 1) * 10 + (h.poc ? 1 : 0);
        hits.sort((a, b) => rango(a) - rango(b)
          || a.label.toUpperCase().indexOf(q) - b.label.toUpperCase().indexOf(q)
          || ordineRisorsa(a.res, cat) - ordineRisorsa(b.res, cat)
          || a.label.localeCompare(b.label));
        drop = `<div class="acdrop">${
          hits.slice(0, 12).map((h) => `<button class="acitem ${this.isSel(h.res, h.code) ? "on" : ""}" data-res="${esc(h.res)}" data-code="${esc(h.code)}" title="${esc(h.label)}">
            <span class="acnm">${esc(h.label)}</span><span class="actag">${esc(risorsaCorta(h.res, cat))}</span></button>`).join("")
          || `<div class="acempty">Nessun esame trovato</div>`}</div>`;
      }
      return `<div class="ac"><input id="acq" type="search" autocomplete="off" placeholder="altri esami…" value="${esc(this.acq || "")}">${drop}</div>`;
    }

    viewRunning() {
      const steps = this.runData?.steps || [];
      const total = steps.length;
      const doneN = steps.filter((s) => s.status === "ok").length;
      const stepHtml = steps.map((s) => `
        <div class="step ${esc(s.status === "pending" ? "" : s.status)}">
          <span class="ic">${s.status === "ok" ? "✓" : s.status === "running" ? "⟳" : s.status === "fail" ? "✕" : s.status === "skipped" ? "–" : "·"}</span>
          <span>${esc(s.label)}</span><small>${esc(s.note || "")}</small>
        </div>`).join("");
      const qui = nomeInPagina();
      return `
        ${this.runPatient ? `<div class="idline" style="margin-top:0">Operazione per <b>${esc(this.runPatient)}</b></div>` : ""}
        ${this.runPatient && qui && qui !== this.runPatient ? `<div class="banner warn">Stai guardando <b>${esc(qui)}</b>: questi esami sono di <b>${esc(this.runPatient)}</b> e vanno alla sua richiesta.</div>` : ""}
        <div class="sec"><div class="lbl">In corso — passo ${Math.min(doneN + 1, total)} di ${total}</div><div class="steps">${stepHtml}</div></div>
        <details class="reg" open><summary>Registro <button class="mini" id="copylog" title="Copia il registro negli appunti (il quesito viene omesso)">⧉ Copia</button></summary><div class="log" aria-live="polite">${esc(this.logLines.join("\n"))}</div></details>
        <div class="commit">
          <button class="btn stop" id="stopbtn">INTERROMPI (Esc)</button>
  
        </div>
      `;
    }

    // Il resoconto, corto: il motivo, gli elenchi che servono per finire
    // (Mancano / Da controllare / Nel carrello) e un'azione sola — «↻ Riprova
    // i mancanti» o «Apri il carrello» — più «Chiudi». I passi e il Registro
    // stanno insieme sotto «Dettagli», chiuso: si aprono quando servono.
    viewResult() {
      const ok = this.runState === "done";
      const cls = ok ? "ok" : this.runState === "stopped" ? "warn" : "err";
      const m = this.message || {};
      const head = typeof m === "string" ? "" : m.head;
      const bodyTxt = typeof m === "string" ? m : m.body;
      const steps = (this.runData?.steps || []).map((s) => `
        <div class="step ${esc(s.status === "pending" ? "" : s.status)}">
          <span class="ic">${s.status === "ok" ? "✓" : s.status === "fail" ? "✕" : s.status === "skipped" ? "–" : "·"}</span>
          <span>${esc(s.label)}</span><small>${esc(s.note || "")}</small>
        </div>`).join("");
      const listUrl = this.runData?.finishedListUrl || this.runData?.lastListUrl;
      // già sul carrello di quella richiesta (ci ha portato l'errore): niente bottone per andarci
      const giaQui = !!listUrl && this.pageType === "exam" && param(listUrl, "RICHIESTA_ID") === param(location.href, "RICHIESTA_ID");
      // dopo un errore: rifare i mancanti si può solo dov'è sicuro (riprovaQui)
      const riprova = this.riprovaQui() ? this.riprova.mancanti.length : 0;
      // un errore si chiude; un giro che riprenderà da solo no (lì resta «Torna al pannello»)
      const chiudi = this.runState === "fail" && !tabStore.get(CORSA, null);
      // quale quesito è partito, in una riga (giro riuscito)
      const qd = ok ? quesitoDetto(this.runData?.quesito) : "";
      // Fermato a metà: che cosa manca, che cosa va guardato e che cosa c'è
      // già in carrello — l'elenco che serve per finire.
      const nel = (typeof m === "object" && m.nel) || [], mancano = (typeof m === "object" && m.mancano) || [];
      const controllare = (typeof m === "object" && m.controllare) || [];
      const gruppo = (lbl, chips, extra = "") => chips.length
        ? `<div class="sec"><div class="lbl">${lbl} (${chips.length})</div><div class="chips">${chips.join("")}</div>${extra}</div>` : "";
      const nomi = (l, c) => l.map((x) => `<span class="chip ${c}">${esc(x)}</span>`);
      const alPosto = (x) => (x.alPostoDi ? `<small class="alposto">al posto di ${esc(x.alPostoDi)}</small>` : "");
      const liste = ok
        ? gruppo("Nel carrello", (this.runData?.addedTutti || this.runData?.added || []).map((x) => `<span class="chip nel">${esc(x.display || shortLabel(x.label))}${alPosto(x)}</span>`))
        : gruppo("Mancano", nomi(mancano, "manca"))
          + gruppo("Da controllare", nomi(controllare, "controlla"), `<div class="hint">${riprova
            ? "Mandati, ma non visti in carrello: «Riprova» non li rimanda — guardali nel carrello prima."
            : "Mandati, ma non visti in carrello: guarda se ci sono prima di aggiungerli — mai due volte."}</div>`)
          + gruppo("Nel carrello", nomi(nel, "nel"));
      return `
        <div class="banner ${cls}">${head ? `<b>${esc(head)}</b>` : ""}${esc(bodyTxt || "")}${qd ? `<span class="qline">${esc(qd)}</span>` : ""}</div>
        ${liste}
        <details class="dett"><summary>Dettagli</summary>
          <div class="steps">${steps}</div>
          <div class="reghd">Registro <button class="mini" id="copylog" title="Copia il registro negli appunti (il quesito viene omesso)">⧉ Copia</button></div>
          <div class="log" aria-live="polite">${esc(this.logLines.join("\n"))}</div>
        </details>
        <div class="commit">
          ${riprova ? `<button class="btn primary" id="riprova" title="${this.riprova.rid
            ? "Manda solo gli esami mai partiti, in questa stessa richiesta: quelli già in carrello non si rimandano"
            : "Nessuna richiesta era nata: rifà il giro da capo, con gli stessi esami"}">↻ Riprova i mancanti (${riprova})</button>`
            : (listUrl || this.carrelloDaAprire) && !giaQui && (!ok || this.runRipreso || this.carrelloDaAprire) ? `<button class="btn primary" id="openlist">${
            ok ? "Apri il carrello" : "Apri il carrello e controlla"}</button>` : ""}
          ${this.svuotaQui() ? `<button class="btn ghost${this._svuota?.ok ? " armato" : ""}" id="svuota" ${this._svuota && !this._svuota.ok ? "disabled" : ""} title="Toglie dal carrello tutti gli esami di questa richiesta col «Svuota carrello» del gestionale, controlla che sia vuoto e rimette tutto: la selezione e quello che c'era già">${esc(this._svuota?.testo || "Svuota il carrello e ricomincia")}</button>` : ""}
          ${chiudi ? `<button class="btn ghost" id="chiudi" title="Chiude il resoconto e torna alle Richieste: restano scelti solo gli esami che mancano. La richiesta a metà resta da confermare.">Chiudi</button>`
            : `<button class="btn ghost" id="reset">Torna al pannello</button>`}
        </div>
      `;
    }

    // Ridurre alla pill e riaprire. Ridurre chiude anche il menu e la
    // Modifica della stanza; il fuoco va sulla pill (e al riaprire sul titolo),
    // così la tastiera non finisce nel gestionale coperto.
    riduci() {
      if (this.collapsed) return;
      this.collapsed = true; this.menuAperto = false; this.stanzaEdit = false;
      store.set("collapsed", true);
      // la striscia di un ordine in sottofondo torna subito, non al prossimo aggiornamento
      if (!LAVORO && this.ordini.length) { this._firmaOrdine = ""; this.stripOrdine(); }
      this.render();
      this.root.querySelector("#expand")?.focus({ preventScroll: true });
    }
    apri() {
      this.collapsed = false; this.avvisoPill = "";
      // aperta la finestra, la striscia ha detto quello che doveva
      if (this.striscia && !this.striscia.onTap) { clearTimeout(this._tStriscia); this.striscia = null; }
      store.set("collapsed", false);
      this.render();
      this.root.querySelector(".card")?.focus({ preventScroll: true });   // la tastiera nel pannello, non nel gestionale coperto
    }
    // Copiato un testo da incollare nel gestionale (EO, dimissioni, referto):
    // la finestra si toglie di mezzo da sola, la pill dice che è pronto.
    dopoCopia(ok) {
      if (!ok || this.collapsed || this.runState) return;
      setTimeout(() => {
        if (this.collapsed || this.runState) return;
        // di chi è quello che stai per incollare: «✓ Copiato · ROSSI M.»
        const chi = this.idPaz().breve;
        this.avvisoPill = chi ? `✓ Copiato · ${chi}` : "✓ Copiato · incolla";
        this.riduci();
        setTimeout(() => { if (this.avvisoPill) { this.avvisoPill = ""; if (this.collapsed) this.render(); } }, 5000);
      }, 650);
    }

    // Trascinare: la pill (ridotta) si sposta dove vuoi e resta lì; la
    // finestra (aperta) si sposta intera dall'intestazione. Un clic vero
    // sulla pill la apre comunque; il doppio clic sull'intestazione rimette
    // la finestra al centro.
    attachDrag(el) {
      el.addEventListener("pointerdown", (e) => {
        if (e.button !== 0 || e.target.closest(".iconbtn, .tchip, .menuw, button:not(#expand), input, a, [data-rz], [data-prurg]")) return;
        try { el.setPointerCapture(e.pointerId); } catch { /* niente */ }
        const wrap = this.root.querySelector(".wrap");
        const r = wrap.getBoundingClientRect();
        const sx = e.clientX, sy = e.clientY, ox = r.left, oy = r.top;
        const finestra = wrap.classList.contains("win");
        let moved = false;
        const mm = (ev) => {
          if (!ev.buttons) return up();   // il bottone è stato lasciato fuori dalla finestra
          if (!moved && Math.abs(ev.clientX - sx) + Math.abs(ev.clientY - sy) < 5) return;
          moved = true;
          const vw = window.innerWidth, vh = window.innerHeight;
          if (finestra) {
            const g = geometriaFinestra(this.win);
            this.win = geometriaFinestra({ ...g, x: (ox + ev.clientX - sx) / vw, y: (oy + ev.clientY - sy) / vh });
            wrap.style.left = this.win.x * 100 + "vw";
            wrap.style.top = this.win.y * 100 + "vh";
          } else {
            this.pillPos = {
              left: Math.max(0, Math.min(vw - 80, ox + ev.clientX - sx)),
              top: Math.max(0, Math.min(vh - 48, oy + ev.clientY - sy)),
            };
            wrap.style.left = this.pillPos.left + "px";
            wrap.style.top = this.pillPos.top + "px";
            wrap.style.right = "auto";
          }
        };
        const up = () => {
          window.removeEventListener("pointermove", mm, true);
          window.removeEventListener("pointerup", up, true);
          window.removeEventListener("pointercancel", up, true);
          if (moved) {
            if (finestra) store.set("win.v1", this.win); else store.set("pillpos.v1", this.pillPos);
            this._justDragged = true;
            setTimeout(() => { this._justDragged = false; }, 0);
          }
        };
        window.addEventListener("pointermove", mm, true);
        window.addEventListener("pointerup", up, true);
        window.addEventListener("pointercancel", up, true);
      });
    }

    // Ridimensionare da ogni bordo e da ogni angolo, come una finestra vera.
    attachResize(el) {
      el.addEventListener("pointerdown", (e) => {
        if (e.button !== 0) return;
        e.preventDefault(); e.stopPropagation();
        const d = el.getAttribute("data-rz") || "se";
        try { el.setPointerCapture(e.pointerId); } catch { /* niente */ }
        const wrap = this.root.querySelector(".wrap");
        const r = wrap.getBoundingClientRect();
        const sx = e.clientX, sy = e.clientY;
        const mm = (ev) => {
          if (!ev.buttons) return up();
          const vw = window.innerWidth, vh = window.innerHeight;
          const dx = ev.clientX - sx, dy = ev.clientY - sy;
          let { left, top, width, height } = r;
          if (d.includes("e")) width = r.width + dx;
          if (d.includes("s")) height = r.height + dy;
          if (d.includes("w")) { width = r.width - dx; left = r.left + dx; }
          if (d.includes("n")) { height = r.height - dy; top = r.top + dy; }
          // mai più piccola del minimo: il bordo che si tira si ferma lì
          if (width < 380) { if (d.includes("w")) left -= 380 - width; width = 380; }
          if (height < 320) { if (d.includes("n")) top -= 320 - height; height = 320; }
          this.win = geometriaFinestra({ x: left / vw, y: top / vh, w: Math.min(width, vw) / vw, h: Math.min(height, vh) / vh });
          wrap.style.left = this.win.x * 100 + "vw"; wrap.style.top = this.win.y * 100 + "vh";
          wrap.style.width = this.win.w * 100 + "vw"; wrap.style.height = this.win.h * 100 + "vh";
        };
        const up = () => {
          window.removeEventListener("pointermove", mm, true);
          window.removeEventListener("pointerup", up, true);
          window.removeEventListener("pointercancel", up, true);
          store.set("win.v1", this.win);
        };
        window.addEventListener("pointermove", mm, true);
        window.addEventListener("pointerup", up, true);
        window.addEventListener("pointercancel", up, true);
      });
    }

    bind() {
      const $ = (s) => this.root.querySelector(s);
      $("#expand")?.addEventListener("click", (e) => {
        if (e.target.closest?.("[data-prurg]")) return;   // il segno del promemoria ha il suo menu
        // aprire la striscia di un giro in corso è un gesto di adesso, non una
        // preferenza: finito il giro il pannello torna com'era
        if (this.runState === "running") { this.collapsed = false; this.render(); return; }
        if (this._justDragged) return; // it was a drag, not a click
        // durante la stampa la striscia porta i suoi comandi, non il pannello
        if (this.striscia && this.striscia.onTap) { this.striscia.onTap(); return; }
        this.apri();
      });
      $("#strstop")?.addEventListener("click", () => this.striscia?.onStop?.());
      // (il bottone non tiene il fuoco, e il pannello non glielo ridà: col fuoco
      // nel pannello certi aggiornamenti aspettano — la spia del Ponte, per esempio)
      $("#strazione")?.addEventListener("click", (e) => { this._fuocoId = null; e.currentTarget.blur(); this.striscia?.azione?.fn?.(); });
      $("#collapse")?.addEventListener("click", () => this.riduci());
      $("#menubtn")?.addEventListener("click", (e) => { e.stopPropagation(); this.menuAperto = !this.menuAperto; this._resetArmato = 0; this.render(); });
      // due tocchi: il primo chiede, il secondo (entro pochi secondi) cancella
      $("#resetpaz")?.addEventListener("click", (e) => {
        e.stopPropagation();
        if (!this.resetArmato()) { this._resetArmato = Date.now(); this.render(); return; }
        this._resetArmato = 0; this.menuAperto = false;
        this.resetDatiPazienti();
      });
      // due posizioni pronte: al centro (85%), o in colonna a destra col gestionale visibile
      const metti = (g) => { this.win = g; store.set("win.v1", g); this.menuAperto = false; this.render(); };
      $("#wincentra")?.addEventListener("click", () => metti(null));
      $("#winaffianca")?.addEventListener("click", () => metti({ ...AFFIANCA }));
      this.root.querySelectorAll("[data-rz]").forEach((el) => this.attachResize(el));
      // doppio clic sull'angolo o sull'intestazione: di nuovo al centro, all'85%
      const alCentro = (e) => { e.stopPropagation(); this.win = null; store.set("win.v1", null); this.render(); };
      $("#rsz")?.addEventListener("dblclick", alCentro);
      const hd = $("#draghd");
      if (hd) {
        this.attachDrag(hd);
        hd.addEventListener("dblclick", (e) => { if (!e.target.closest("button")) alCentro(e); });
      }
      const pill = $("#expand");
      if (pill) this.attachDrag(pill);
      $("#stopbtn")?.addEventListener("click", () => this.stop());
      $("#reset")?.addEventListener("click", () => {
        this.runState = null; this.runData = null; this.message = null; this.carrelloDaAprire = null; this.render();
      });
      // «Svuota il carrello e ricomincia»: un tocco legge il carrello e chiede, il secondo fa
      $("#svuota")?.addEventListener("click", () => (this._svuota?.ok ? this.svuotaERicomincia() : this.svuotaChiedi()));
      $("#chiudi")?.addEventListener("click", () => this.chiudiErrore());
      $("#riprova")?.addEventListener("click", () => this.riprovaMancanti());
      $("#openlist")?.addEventListener("click", () => {
        if (this.carrelloDaAprire) return this.carrelloDaAprire();   // la navigazione rimandata, col suo passaggio di consegne
        const u = this.runData?.finishedListUrl || this.runData?.lastListUrl;
        if (!u) return;
        if (this.runState === "fail") this.consegnaErrore?.();   // il resoconto (e «Riprova») viaggia col carrello
        nav(u);
      });

      $("#back")?.addEventListener("click", () => this.setView(
        this.view === "referto" ? "esiti"
        : this.view === "dimtesto" || this.view === "dimimport" ? "dimissioni"
        : this.view === "eotesto" ? "eo"
        : "home"));
      this.root.querySelectorAll("[data-seg]").forEach((b) => b.addEventListener("click", () => this.setView(b.getAttribute("data-seg"))));
      $("#archtog")?.addEventListener("click", () => { this.mostraArch = !this.mostraArch; this.render(); });
      this.root.querySelectorAll("[data-unarch]").forEach((b) => b.addEventListener("click", () => {
        archiviaPaziente(b.getAttribute("data-unarch"), false);
        this.render();
      }));
      this.root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => {
        // un tasto che cancella davvero chiede una volta, e non di nascosto
        if (b.dataset.sicuro !== "1") {
          b.dataset.sicuro = "1"; b.textContent = "cancello?";
          setTimeout(() => { if (b.isConnected && b.dataset.sicuro === "1") { b.dataset.sicuro = ""; b.textContent = "🗑"; } }, 4000);
          return;
        }
        const ep = b.getAttribute("data-del");
        const p = pazientiArchiviati().find((x) => x.ep === ep);
        eliminaPaziente(ep, p?.pk || "", p?.name || "");
        this.message = { ok: `Eliminato tutto di ${p?.name || "quel paziente"}.` };
        this.render();
      }));
      $("#verbtn")?.addEventListener("click", () => { this.showLog = !this.showLog; this.menuAperto = false; this.render(); });
      // il ponte: la pagina dell'iPhone, e «Scollega» dall'intestazione
      $("#pontemenu")?.addEventListener("click", () => { this.menuAperto = false; this.render(); ask({ t: "ponteApri" }); });
      $("#ponteoff")?.addEventListener("click", (e) => { e.stopPropagation(); ask({ t: "ponteScollega" }); });
      $("#risall")?.addEventListener("click", () => this.caricaValori().catch(() => {}).then(() => this.caricaReferti()));
      // «Letto»: da qui in poi le novità si contano da adesso, per tutti i prelievi
      $("#letto")?.addEventListener("click", () => {
        for (const e of this.esiti) if (e.kind === "valori") this.marcaLetto(e.id);
        segnaVisti(this.episodeId, this.refertiMostrati().map((e) => e.id));   // e i referti nuovi: visti
        this.render();
      });
      $("#apripdf")?.addEventListener("click", () => { if (this.espanso) this.openReferto(this.espanso); });
      this.root.querySelectorAll("[data-pdf]").forEach((b) => b.addEventListener("click", () => this.openReferto(b.getAttribute("data-pdf"))));
      $("#portapri")?.addEventListener("click", async () => {
        this.menuAperto = false;
        const r = await ask({ t: "apriImpostazioni" }).catch(() => null);
        this.message = r && r.ok
          ? { ok: "Incolla l'indirizzo del portale nella pagina che si è aperta." }
          : "Non riesco ad aprire le impostazioni: aprile da chrome://extensions → PS Assist → Dettagli → Opzioni.";
        this.render();
      });
      // un tocco su un valore lo segna (giallo → arancio → niente): si cambia
      // la cella sul posto, senza ridisegnare, così la tabella non scatta
      const tabella = this.root.querySelector(".sttab");
      if (tabella) tabella.addEventListener("click", (ev) => {
        const td = ev.target?.closest?.("td[data-cella]");
        if (!td) return;
        const stato = (td.classList.contains("marca2") ? 2 : td.classList.contains("marca1") ? 1 : 0) + 1;
        const prossimo = stato > 2 ? 0 : stato;
        if (!scriviSegno(this.chiaveNota(), td.getAttribute("data-cella"), prossimo)) {
          // un salvataggio rifiutato si dice, non si finge
          this.message = "Il browser non ha accettato il segno: memoria piena o bloccata.";
          this.render();
          return;
        }
        td.classList.remove("marca1", "marca2");
        if (prossimo) td.classList.add("marca" + prossimo);
      });
      const filtra = () => { this.soloAlterati = !this.soloAlterati; this.render(); };
      $("#storfiltro")?.addEventListener("click", filtra);
      $("#avvnomi")?.addEventListener("click", () => { this.mostraNomi = !this.mostraNomi; this.render(); });
      $("#valreset")?.addEventListener("click", () => this.resetValori());
      $("#refdiag")?.addEventListener("click", async () => {
        const b = this.root.querySelector("#refdiag");
        segnaCopia(b, await copiaTesto(diagnosiTesto(this.diagnosi)));
      });
      this.root.querySelectorAll("[data-dcopy]").forEach((b) => b.addEventListener("click", async () => {
        const d = dimissioni()[b.getAttribute("data-dcopy")];
        if (!d) return;
        const ico = b.querySelector(".dico");
        let ok = false;
        ok = await copiaTesto(d.testo);
        this.dopoCopia(ok);
        b.classList.toggle("fatto", ok);
        if (ico) ico.textContent = ok ? "✓ copiato" : "✗ non riuscito";
        setTimeout(() => {
          if (!b.isConnected) return;
          b.classList.remove("fatto");
          if (ico) ico.textContent = "⧉";
        }, 1800);
      }));
      // EO: la riga copia, la tendina copia scegliendo. In tutti e due i casi
      // il testo scelto resta scritto sotto, così si vede cosa si è preso.
      const eoFatto = (b, ok) => {
        const ico = b.querySelector(".dico");
        b.classList.toggle("fatto", ok);
        if (ico) ico.textContent = ok ? "✓ copiato" : "✗ non riuscito";
        setTimeout(() => {
          if (!b.isConnected) return;
          b.classList.remove("fatto");
          if (ico) ico.textContent = "⧉";
        }, 1800);
      };
      this.root.querySelectorAll("[data-eocopy]").forEach((b) => b.addEventListener("click", async () => {
        const v = eoVoci()[b.getAttribute("data-eocopy")];
        if (!v) return;
        const ok = await copiaTesto(v.testo);
        eoFatto(b, ok);
        this.dopoCopia(ok);
      }));
      $("#eocaso")?.addEventListener("change", async (ev) => {
        const k = ev.target.value;
        this.eoSel = k || "";
        const v = eoVoci()[k];
        const txt = this.root.querySelector("#eotxt");
        const riga = this.root.querySelector(".eoazione");
        const btn = this.root.querySelector("#eoricopia");
        if (txt) { txt.textContent = v ? v.testo : ""; txt.hidden = !v; }
        if (riga) riga.hidden = !v;
        if (btn) btn.setAttribute("data-eocopy", k || "");
        this.root.querySelector("#eoedit")?.setAttribute("data-eoedit", k || "");
        if (!v) return;
        this.persistUi();
        if (btn) { const ok = await copiaTesto(v.testo); eoFatto(btn, ok); this.dopoCopia(ok); }
      });
      this.root.querySelectorAll("[data-dedit]").forEach((b) => b.addEventListener("click", () => this.setView("dimtesto", b.getAttribute("data-dedit"))));
      // EO: ✎ apre il testo, che si riscrive come un foglio di dimissione
      this.root.querySelectorAll("[data-eoedit]").forEach((b) => b.addEventListener("click", () => {
        const k = b.getAttribute("data-eoedit");
        if (k && eoVoci()[k]) this.setView("eotesto", k);
      }));
      const eoArea = this.root.querySelector("#eoarea");
      if (eoArea) eoArea.addEventListener("input", () => tabStore.set(this.eoDraftKey(this.viewId), { ts: Date.now(), testo: eoArea.value }));
      $("#eocopia")?.addEventListener("click", async () => {
        const ok = await copiaTesto(eoArea ? eoArea.value : "");
        segnaCopia(this.root.querySelector("#eocopia"), ok);
        this.dopoCopia(ok);
      });
      $("#eosave")?.addEventListener("click", () => {
        const v = eoVoci()[this.viewId];
        if (!eoArea || !v) return;
        if (!eoArea.value.trim()) { this.message = "Il testo è vuoto: non lo salvo."; this.render(); return; }
        const scritto = salvaEo(this.viewId, eoArea.value);
        tabStore.set(this.eoDraftKey(this.viewId), null);
        this.setView("eo", null, scritto
          ? { ok: `«${v.nome}» salvato: sarà questo il testo copiato d'ora in poi.` }
          : `«${v.nome}» NON salvato: la memoria di questo browser è piena o bloccata.`);
      });
      $("#eoreset")?.addEventListener("click", (ev) => {
        const b = ev.currentTarget, v = eoVoci()[this.viewId] || {};
        // un tocco non deve poter buttare un testo scritto dal medico
        if (b.dataset.sicuro !== "1") {
          const etichetta = b.textContent;
          b.dataset.sicuro = "1"; b.textContent = "Confermi?";
          setTimeout(() => { if (b.isConnected && b.dataset.sicuro === "1") { b.dataset.sicuro = ""; b.textContent = etichetta; } }, 4000);
          return;
        }
        const scritto = ripristinaEo(this.viewId);
        tabStore.set(this.eoDraftKey(this.viewId), null);
        this.setView("eo", null, scritto ? { ok: `«${v.nome || "Testo"}» riportato all'originale.` } : "Non ripristinato: la memoria di questo browser è bloccata.");
      });
      // every keystroke goes into the tab's draft: a re-render, a page change
      // or a mis-click can no longer throw away a rewritten sheet
      const area = this.root.querySelector("#dimarea");
      const inNome = this.root.querySelector("#dimnome");
      const bozza = () => tabStore.set(this.dimDraftKey(this.viewId), { ts: Date.now(), testo: area ? area.value : "", ...(inNome ? { nome: inNome.value } : {}) });
      if (area) area.addEventListener("input", bozza);
      if (inNome) {
        inNome.addEventListener("input", bozza);
        inNome.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); area?.focus(); } });
        if (!inNome.value && !this.root.activeElement) inNome.focus();   // un foglio nuovo comincia dal nome
      }
      $("#dimnuovo")?.addEventListener("click", () => this.setView("dimtesto", DIM_NUOVO));
      $("#dimcopy")?.addEventListener("click", async () => {
        const b = this.root.querySelector("#dimcopy");
        let ok = false;
        ok = await copiaTesto(area ? area.value : "");
        segnaCopia(b, ok);
        this.dopoCopia(ok);
      });
      $("#dimsave")?.addEventListener("click", () => {
        const nuovo = this.viewId === DIM_NUOVO;
        const tutte = dimissioni();
        const d = nuovo ? { nome: "", mio: true } : tutte[this.viewId];
        if (!area || !d) return;
        const nome = inNome ? inNome.value.replace(/\s+/g, " ").trim().slice(0, 60) : d.nome;
        const no = (m) => { bozza(); this.message = m; this.render(); };
        if (!nome) return no("Dai un nome al foglio: è quello che vedrai nell'elenco.");
        if (!area.value.trim()) return no("Il testo è vuoto: non lo salvo.");
        // due righe con lo stesso nome, nell'elenco, non si distinguono
        if (Object.entries(tutte).some(([k, x]) => k !== this.viewId && x.nome.trim().toLowerCase() === nome.toLowerCase())) {
          return no(`C'è già un foglio «${nome}»: scegli un altro nome.`);
        }
        let k = this.viewId;
        if (nuovo) do k = "mio-" + Math.random().toString(36).slice(2, 8); while (tutte[k] || DIMISSIONI[k]);
        const scritto = salvaDimissione(k, nome, area.value);
        tabStore.set(this.dimDraftKey(this.viewId), null);
        this.log(`${now()}  foglio di dimissione «${nome}» ${nuovo ? "aggiunto" : "aggiornato"}`);
        // never say "saved" when the browser refused to write it
        this.setView("dimissioni", null, !scritto
          ? `«${nome}» NON salvato: la memoria di questo browser è piena o bloccata.`
          : nuovo ? { ok: `«${nome}» aggiunto ai tuoi fogli, in cima all'elenco.` }
          : { ok: `«${nome}» salvato: sarà questo il testo copiato d'ora in poi.` });
      });
      $("#dimreset")?.addEventListener("click", (ev) => {
        const b = ev.currentTarget;
        const d = dimissioni()[this.viewId] || {};
        const etichetta = b.textContent;
        // one tap must not be able to destroy a text the doctor wrote
        if (b.dataset.sicuro !== "1") {
          b.dataset.sicuro = "1";
          b.textContent = d.mio ? "Elimino?" : "Confermi?";
          setTimeout(() => { if (b.isConnected && b.dataset.sicuro === "1") { b.dataset.sicuro = ""; b.textContent = etichetta; } }, 4000);
          return;
        }
        const nome = d.nome || this.viewId;
        const scritto = ripristinaDimissione(this.viewId);
        tabStore.set(this.dimDraftKey(this.viewId), null);
        this.setView("dimissioni", null, !scritto
          ? `«${nome}» non ${d.mio ? "eliminato" : "ripristinato"}: la memoria di questo browser è bloccata.`
          : d.mio ? { ok: `«${nome}» eliminato.` } : { ok: `«${nome}» riportato al testo originale.` });
      });
      $("#dimexport")?.addEventListener("click", async () => {
        const tutte = dimissioni();
        const mie = store.get(dimKey, {});
        const dati = {};
        for (const [k, v] of Object.entries(tutte)) {
          dati[k] = { nome: v.nome, testo: v.testo };
          // carry the fingerprint of the original this version was forked from,
          // so a re-import keeps knowing when the original moves
          if (mie[k] && mie[k].base) dati[k].base = mie[k].base;
        }
        const testo = JSON.stringify({ app: APP, versione: VERSION, salvato: new Date().toISOString(), dimissioni: dati }, null, 1);
        // the file where downloads are allowed, the clipboard everywhere else:
        // the doctor must end up with the text in his hands either way
        let file = false, appunti = false;
        try {
          const url = URL.createObjectURL(new Blob([testo], { type: "application/json" }));
          const a2 = document.createElement("a");
          a2.href = url; a2.download = "dimissioni.json";
          document.documentElement.appendChild(a2); a2.click(); a2.remove();
          setTimeout(() => URL.revokeObjectURL(url), 20000);
          file = true;
        } catch { /* clipboard below */ }
        appunti = await copiaTesto(testo);
        this.menuAperto = false;
        this.message = file || appunti
          ? { ok: file && appunti ? "Fogli salvati: dimissioni.json e negli appunti." : file ? "Fogli salvati: dimissioni.json." : "Fogli negli appunti." }
          : "Esportazione non riuscita.";
        this.render();
      });
      $("#tapri")?.addEventListener("click", () => this.setView("tempi"));
      $("#tempimenu")?.addEventListener("click", () => { this.menuAperto = false; this.setView("tempi"); });
      $("#rifmenu")?.addEventListener("click", () => { this.menuAperto = false; this.setView("riferimenti"); this.root.querySelector("#riffiltro")?.focus(); });
      $("#riffiltro")?.addEventListener("input", (e) => { this.rifFiltro = e.target.value; this.rifFiltra(); });
      const ferma = () => { fermaTempo(); this.render(); };
      $("#tstop")?.addEventListener("click", ferma);
      $("#tstop2")?.addEventListener("click", ferma);
      const avvia = (titolo) => {
        if (!String(titolo || "").trim()) return;
        avviaTempo(titolo, this.nomePaziente(), this.episodeId);
        this.setView("tempi");
      };
      this.root.querySelectorAll("[data-avvia]").forEach((b) =>
        b.addEventListener("click", () => avvia(b.getAttribute("data-avvia"))));
      $("#tavvia")?.addEventListener("click", () => avvia(this.root.querySelector("#tlib")?.value));
      $("#tlib")?.addEventListener("keydown", (e) => { if (e.key === "Enter") avvia(e.target.value); });
      this.root.querySelectorAll("[data-scorda]").forEach((b) =>
        b.addEventListener("click", () => { scordaTempo(b.getAttribute("data-scorda")); this.render(); }));
      $("#texp")?.addEventListener("click", () => this.esportaTempi());
      this.root.querySelectorAll("[data-cons]").forEach((b) => b.addEventListener("click", () => {
        const c = CONSENSI.find((x) => x.k === b.getAttribute("data-cons"));
        const url = c && urlConsenso(c);
        if (!url) { this.message = "I moduli ci sono solo con l'estensione."; this.render(); return; }
        this.log(`${now()}  modulo «${c.nome}» aperto per la stampa`);
        avviaStampa([{ name: c.nome, printer: "stampante normale", url, diretto: true }],
          { title: c.nome, panel: this, ep: this.episodeId, paziente: this.nomePaziente() });
      }));
      $("#dimimport")?.addEventListener("click", () => { this.menuAperto = false; this.setView("dimimport"); });
      $("#dimimpok")?.addEventListener("click", () => {
        const ta = this.root.querySelector("#dimimparea");
        const testo = (ta && ta.value || "").trim();
        if (!testo) { this.message = "Incolla prima il JSON esportato."; this.render(); return; }
        let dims = null;
        try {
          const dati = JSON.parse(testo);
          dims = dati && dati.dimissioni && typeof dati.dimissioni === "object" ? dati.dimissioni : dati;
        } catch (e) {
          this.message = `JSON non valido: ${e.message}`; this.render(); return;
        }
        if (!dims || typeof dims !== "object") { this.message = "Questo file non contiene fogli di dimissione."; this.render(); return; }
        const mie = store.get(dimKey, {});
        let n = 0, uguali = 0, saltati = 0;
        for (const [k, v] of Object.entries(dims)) {
          if (k === "__proto__" || k === "constructor" || k === "prototype") continue;
          if (!dimValido(v) || v.testo.length > 40000 || k.length > 80) { saltati++; continue; }
          const orig = DIMISSIONI[k];
          // a text identical to the shipped one is NOT a change: importing it
          // as an override would freeze that sheet at today's wording forever
          if (orig && v.testo.trim() === orig.testo.trim()) { delete mie[k]; uguali++; continue; }
          if (!(k in mie) && Object.keys(mie).length >= 40) { saltati++; continue; }
          mie[k] = {
            nome: String(v.nome || (orig && orig.nome) || k).slice(0, 80),
            testo: v.testo,
            base: typeof v.base === "string" && v.base ? v.base : (orig ? impronta(orig.testo) : ""),
          };
          n++;
        }
        if (!n && !uguali) { this.message = "Nessun testo valido in questo JSON."; this.render(); return; }
        const scritto = store.set(dimKey, mie);
        this.log(`${now()}  importati ${n} fogli di dimissione`);
        const coda = [uguali ? `${uguali} già uguali all'originale` : "", saltati ? `${saltati} ignorati` : ""].filter(Boolean).join(", ");
        this.setView("dimissioni", null, scritto
          ? { ok: `${n === 1 ? "Importato 1 foglio" : `Importati ${n} fogli`}${coda ? ` (${coda})` : ""}.` }
          : "Import NON salvato: la memoria di questo browser è piena o bloccata.");
      });
      $("#copytxt")?.addEventListener("click", async () => {
        const e = this.esiti.find((x) => x.id === this.espanso);
        const t = e ? this.testoDi(e) : null;
        if (!t || t.stato !== "testo") return;   // mai il testo di un altro paziente
        let ok = false;
        ok = await copiaTesto([`${e.when} · ${shortLabel(e.label)}${this.nomePaziente() ? ` · ${this.nomePaziente()}` : ""}`, ...t.righe].join("\n"));
        const b = this.root.querySelector("#copytxt");
        segnaCopia(b, ok);
        this.dopoCopia(ok);
      });
      this.root.querySelectorAll("[data-go]").forEach((b) => b.addEventListener("click", (ev) => {
        ev.stopPropagation();   // Richieste sits inside the card, which is itself a [data-go]
        this.apriPaziente(b.getAttribute("data-ep"), b.getAttribute("data-go"));
      }));
      $("#goqueued")?.addEventListener("click", () => { if (this.pending) goToQueued(this.pending); });
      $("#confirmnow")?.addEventListener("click", () => {
        // native click → server confirm → print handoff (armed at boot)
        const live = examModel(document, location.href);
        live.confirmButton?.click();
      });
      // la ricevuta tiene la griglia chiusa: «+ aggiungi» la apre
      $("#aggiungi")?.addEventListener("click", () => { this.aggiungi = true; this.render(); });
      // la richiesta ancora da confermare: un tocco porta al suo carrello (una lettura)
      $("#apridaconf")?.addEventListener("click", (e) => { const u = e.currentTarget.getAttribute("data-url"); if (u) nav(u); });
      // …e sul suo carrello, le sue due azioni (a due tocchi)
      $("#dcconferma")?.addEventListener("click", () => this.daConfTocco("conferma"));
      $("#dcsvuota")?.addEventListener("click", () => this.daConfTocco("svuota"));
      // la stampa automatica: le impostazioni (anche dalla stampantina in
      // intestazione, che si ridisegna da sola: l'ascolto sta sul suo posto) e l'interruttore
      $("#stampanti")?.addEventListener("click", () => this.apriStampanti());
      $("#regmenu")?.addEventListener("click", async () => {
        this.menuAperto = false;
        const r = this.reg;
        const t = r && r.stato === "rec" ? "registraFerma" : r && r.stato === "fermo" && !r.esportata ? "registraScarica" : "registraVia";
        const x = await ask({ t });
        this.message = !(x && x.ok) ? "Il registratore non risponde: ricarica l'estensione e riprova."
          : t === "registraVia" ? { ok: "Registro questa sessione (al più 60 minuti): resta su questo PC. Quando hai finito: ⋯ → Ferma e scarica." } : "";
        this.render();
      });
      $("#stautow")?.addEventListener("click", (e) => { if (e.target.closest("#stauto")) this.apriStampanti(); });
      $("#stautosw")?.addEventListener("click", () => {
        const s = { ...this.stampaAuto.s, attiva: this.stampaAuto.s.attiva === false };
        this.stampaAuto = { ...this.stampaAuto, s };
        this.menuAperto = false;
        chrome.storage.local.set({ stampa: s }).catch(() => {});
        this.render();
      });
      $("#extreload")?.addEventListener("click", () => {
        if (this.giroInCorso()) return;   // un giro a metà non si uccide
        try { chrome.runtime.sendMessage("psassist-reload"); } catch { /* not the extension build */ }
      });
      const qEl = $("#q");
      // scritto a mano nella casella: è il quesito del medico, e vale anche sopra quello del triage
      qEl?.addEventListener("input", () => { this._q = qEl.value; this.quesitoMio = true; this.persistUi(); this.refreshCommit(); });
      const qrxEl = $("#qrx");
      qrxEl?.addEventListener("input", () => { this._qrx = qrxEl.value; this.persistUi(); this.refreshCommit(); });
      this.root.querySelectorAll("[data-q]").forEach((b) => b.addEventListener("click", () => {
        const q = b.getAttribute("data-q");
        // un pacchetto (o un pacchetto da lasciare) cambia anche gli esami: si ridisegna
        if (this.pacchettoDi(q) || this.pacchetto) { this.scegliQuesito(q); this.root.querySelector("#q")?.focus(); return; }
        qEl.value = q; this._q = qEl.value; this.quesitoMio = false; this.persistUi(); this.refreshCommit(); qEl.focus();
      }));
      this.root.querySelectorAll("[data-preset]").forEach((b) => b.addEventListener("click", () => this.togglePreset(PRESETS[+b.getAttribute("data-preset")])));
      this.root.querySelectorAll(".chip[data-code], .opt[data-code]").forEach((b) => b.addEventListener("click", () => this.toggle(b.getAttribute("data-res"), b.getAttribute("data-code"))));
      this.root.querySelectorAll(".acitem[data-code]").forEach((b) => b.addEventListener("click", () => {
        this.toggle(b.getAttribute("data-res"), b.getAttribute("data-code"));
      }));
      this.root.querySelectorAll("[data-unsel]").forEach((b) => b.addEventListener("click", () => { this.selected.delete(b.getAttribute("data-unsel")); this.persistUi(); this.render(); }));
      const ac = $("#acq");
      if (ac) {
        ac.addEventListener("input", () => { this.acq = ac.value; this.acFocus = true; this.render(); });
        ac.addEventListener("keydown", (e) => {
          if (e.key === "Enter") {
            const first = this.root.querySelector(".acitem[data-code]");
            if (first) { e.preventDefault(); this.toggle(first.getAttribute("data-res"), first.getAttribute("data-code")); }
          } else if (e.key === "Escape") { e.stopPropagation(); this.acq = ""; this.render(); }
        });
        if (this.acFocus) { ac.focus(); ac.setSelectionRange(ac.value.length, ac.value.length); }
      }
      $("#go")?.addEventListener("click", () => this.launch(false));
      $("#goconfirm")?.addEventListener("click", () => this.launch(true));
      this.root.querySelectorAll("[data-print]").forEach((b) => b.addEventListener("click", () => {
        const rid = b.getAttribute("data-print");
        const jobs = printJobsFor(printModel(document, location.href), rid);
        avviaStampa(jobs, { panel: this, title: `Richiesta ${rid}.`, ep: this.episodeId, paziente: this.nomePaziente(), url: location.href });
      }));
      $("#stultima")?.addEventListener("click", () => {
        const map = printModel(document, location.href);
        const ids = ultimeRichieste(map);
        avviaStampa(fogliDi(map, ids), { panel: this, title: `${ids.length > 1 ? "Richieste" : "Richiesta"} ${ids.join(" e ")}.`,
          ep: this.episodeId, paziente: this.nomePaziente(), url: location.href });
      });
      this.root.querySelectorAll("[data-esito]").forEach((b) => b.addEventListener("click", () =>
        this.openEsito(b.getAttribute("data-esito"))));
      $("#refreset")?.addEventListener("click", () => this.resetReferti());
      $("#reflab")?.addEventListener("toggle", (e) => { this.labAperto = e.target.open; });
      $("#refsave")?.addEventListener("click", () => this.saveAllReferti());
      $("#copylog")?.addEventListener("click", (e) => { e.preventDefault(); this.copyLog(); });
      this.bindStanza();
      this.dfRiattacca();   // la lista «Da fare» rimasta aperta
    }

    // Patch only the commit zone while the doctor types (a full re-render
    // would steal the textarea focus at every keystroke).
    refreshCommit() {
      const problems = this.computeProblems();
      const go = this.root.querySelector("#go");
      const goc = this.root.querySelector("#goconfirm");
      const n = this.selected.size;
      if (go) go.disabled = !n || !!problems.go.length;
      if (goc) goc.disabled = !n || !!problems.confirm.length;
      const box = this.root.querySelector("#problems");
      if (box) box.innerHTML = problems.go[0] ? `<div class="problem">${esc(problems.go[0])}</div>` : "";
    }

    launch(autoConfirm) {
      // Belt over the live validation braces: recompute and refuse loudly.
      const problems = this.computeProblems();
      const blocking = autoConfirm ? problems.confirm : problems.go;
      if (blocking.length) { this.message = blocking[0]; this.render(); return; }
      const items = [...this.selected.entries()].map(([k, i]) => ({ ...i, chiave: k }));   // copie (vedi startPlan)
      if (!items.length) return;

      const base = { autoConfirm, quesitoMio: !!this.quesitoMio };
      if (this.pageType === "patient") {
        const lab = items.filter((i) => !RADIO_SET.includes(i.res));
        const radio = items.filter((i) => RADIO_SET.includes(i.res));
        const legs = [];
        // ognuna col suo quesito: la radiologia ha il suo, se è scritto. Il
        // quesito RX si scrive solo a mano (non ha chip): scritto, è del medico
        const q = (this._q || "").trim(), suoRx = (this._qrx || "").trim(), qrx = suoRx || q;
        if (lab.length) legs.push({ kind: "lab", label: "laboratorio", items: lab, entryUrl: this.entry?.labUrl, quesito: q, quesitoMio: !!this.quesitoMio });
        if (radio.length) legs.push({ kind: "radio", label: "radiologia", items: radio, entryUrl: this.entry?.radioUrl, quesito: qrx, quesitoMio: suoRx ? true : !!this.quesitoMio });
        if (legs.some((l) => !l.entryUrl)) { this.message = "Link di apertura richiesta non trovato su questa pagina."; this.render(); return; }
        base.startPage = "patient";
        base.legs = legs;
        base.entryUrl = legs[0].entryUrl;
        base.items = legs[0].items;
        base.quesito = legs[0].quesito;
        base.quesitoMio = legs[0].quesitoMio;
      } else if (this.pageType === "crea") {
        const form = document.forms.namedItem("RICHIESTACrea");
        if (!form) { this.message = "Form della richiesta non trovato."; this.render(); return; }
        base.startPage = "crea";
        // una richiesta di radiologia prende il quesito RX, se è scritto
        if (items.every((i) => RADIO_SET.includes(i.res)) && (this._qrx || "").trim()) { base.quesito = this._qrx.trim(); base.quesitoMio = true; }
        base.creaForm = form;
        base.creaUrl = location.href;
      } else {
        base.startPage = "exam";
        base.examDoc = document;
        base.examUrl = location.href;
      }
      this.startPlan(base);
    }
  }

  // ------------------------------------------------ richieste da confermare
  // Una richiesta mandata e non ancora confermata non deve sparire dalla
  // memoria di nessuno. Prima della conferma in sottofondo (e alla fine di un
  // giro in revisione) se ne annotano SOLO i numeri — richiesta, episodio,
  // indirizzo del carrello, ora, quanti esami: mai un nome — e ogni pagina di
  // quell'episodio guarda: se fra le richieste con i fogli da stampare la sua
  // non c'è ancora dopo 2 minuti, la pill lo dice. Al server non si chiede
  // niente per questo: si guarda la pagina che il medico ha aperto. Vista
  // confermata, la si dimentica; dopo 12 ore, anche.
  const DA_CONFERMARE = "daConfermare.v1";
  const DA_CONFERMARE_TTL = 12 * 3600e3;
  const attesaConferma = () => Number(store.get("attesaConferma.ms", 0)) || 120e3;   // i test la accorciano
  function daConfermare() {
    const l = store.get(DA_CONFERMARE, []);
    return (Array.isArray(l) ? l : []).filter((x) => x && x.rid && x.ep && Date.now() - (x.ts || 0) < DA_CONFERMARE_TTL);
  }
  function ricordaDaConfermare(rid, ep, listUrl, n) {
    if (!rid || !ep) return;
    const l = daConfermare().filter((x) => x.rid !== String(rid));
    l.push({ rid: String(rid), ep: String(ep), listUrl: listUrl || "", ts: Date.now(), n: n || 0 });
    store.set(DA_CONFERMARE, l.slice(-20));
  }
  function confermataProvata(rid) {
    const l = daConfermare();
    if (l.some((x) => x.rid === String(rid))) store.set(DA_CONFERMARE, l.filter((x) => x.rid !== String(rid)));
  }
  // quelle di questo episodio ancora senza prova, la più vecchia per prima;
  // quelle che questa pagina dimostra confermate si dimenticano qui
  function nonConfermateQui(doc = document, url = location.href) {
    const ep = findEpisodeId(doc, url);
    const tutte = daConfermare();
    if (!ep || !tutte.length) return [];
    const stampabili = printModel(doc, url);
    const restano = tutte.filter((x) => !(x.ep === ep && stampabili[x.rid]));
    if (restano.length !== (store.get(DA_CONFERMARE, []) || []).length) store.set(DA_CONFERMARE, restano);
    return restano.filter((x) => x.ep === ep).sort((a, b) => a.ts - b.ts);
  }

  // La prova che una richiesta è confermata, quando la pagina dopo il clic
  // non l'ha data: la pagina del paziente — quella che elenca le richieste
  // confermate coi loro fogli da stampare. Solo letture, mai un invio, mai un
  // secondo clic. Il gestionale può metterci qualche secondo a elencarla:
  // prima di dire «non confermata» la si rilegge (CONFIRM_WAITS).
  async function provaConferma(rid, ep, { patientUrl = "", panel = null } = {}) {
    // solo l'indirizzo di una pagina da leggere: mai quello di un modulo inviato
    const leggibile = (x) => { try { return !!x && new URL(x).origin === location.origin && !/[?&](ccsForm|Insert|Delete|Update)=/i.test(x); } catch { return false; } };
    const qui = findEpisodeId(document, location.href) === ep && classify(document) === "patient" ? location.href : "";
    const u = [qui, patientUrl, (tuttiPazienti().find((p) => p.ep === ep) || {}).url].find(leggibile) || "";
    if (!rid || !ep || !u) return null;
    for (let k = 0; ; k++) {
      try {
        const { doc, url } = await fetchDoc(u);
        if (classify(doc) === "login" || findEpisodeIdInDoc(doc) !== ep) break;
        if (printModel(doc, url)[rid]) {
          leggiStatoPagina(ep, doc);   // la pagina letta comunque: lo stato degli esami si aggiorna
          panel?.log(`${now()}  la pagina del paziente la elenca coi suoi fogli: confermata`);
          return { doc, url };
        }
      } catch (e) {
        panel?.log(`${now()}  controllo della conferma non riuscito: ${e?.head || e?.message || e}`);
      }
      if (k >= CONFIRM_WAITS.length) break;
      panel?.log(`${now()}  la pagina del paziente non la elenca ancora: la rileggo fra ${CONFIRM_WAITS[k] / 1000} s`);
      await sleep(CONFIRM_WAITS[k]);
    }
    panel?.log(`${now()}  la pagina del paziente non la elenca: NON confermata`);
    return null;
  }

  // ------------------------------------------------ native-confirm handoff
  // La conferma senza guardare la pagina.
  //
  // La pagina del carrello viene caricata DAVVERO — stessa sessione, stesso
  // modulo, stesso bottone — solo dentro una cornice invisibile invece che
  // davanti agli occhi. Il clic è quello vero sul bottone del gestionale, e i
  // byte che partono sono gli stessi: la codifica del modulo la fa il browser,
  // non noi. Cambia solo che il medico non deve stare a guardare il LIS.
  //
  // La cornice gira SENZA script (`allow-forms allow-same-origin`, mai
  // `allow-scripts` né `allow-top-navigation`): così il codice della pagina non
  // può portarsi via la scheda del medico, e non serve — l'invio di un modulo
  // lo fa il browser. Se il server vieta di essere incorniciato, il documento
  // non è leggibile: ce ne accorgiamo e si torna a fare come prima.
  //
  // Fallisce sempre CHIUSA: qualunque intoppo lascia la conferma al medico.
  // E «confermata» si dice solo con una PROVA: una pagina dello stesso
  // episodio che elenca i fogli da stampare di questa richiesta. Un errore del
  // server, il carrello di nuovo, il tempo scaduto — tutto il resto è
  // «incerta», e incerta non è mai verde.
  const FRAME_MS = 25000;
  function confermaInCornice(listUrl, { panel, episodeId, rid }) {
    return new Promise((resolve) => {
      const f = document.createElement("iframe");
      f.setAttribute("sandbox", "allow-forms allow-same-origin");
      f.setAttribute("aria-hidden", "true");
      f.style.cssText = "position:fixed;left:-10000px;top:0;width:1024px;height:768px;border:0;visibility:hidden";
      let fatto = false, fase = "carico", tid = 0;
      const chiudi = (esito) => {
        if (fatto) return;
        fatto = true;
        clearTimeout(tid);
        try { f.remove(); } catch { /* già via */ }
        resolve(esito);
      };
      const cronometro = () => { clearTimeout(tid); tid = setTimeout(() => chiudi(fase === "carico" ? "rifiutata" : "incerta"), FRAME_MS); };
      cronometro();

      f.addEventListener("load", () => {
        let doc = null, url = "";
        try { doc = f.contentDocument; url = f.contentWindow.location.href; } catch { doc = null; }
        // Una cornice appena inserita emette un `load` per la sua pagina vuota,
        // prima ancora di caricare la nostra: quello non è il carrello.
        // (Un indirizzo che non si lascia nemmeno leggere, invece, è la pagina
        // d'errore di un server che non si lascia incorniciare: qui sotto.)
        if (url === "about:blank") return;
        // Non leggibile: prima del clic vuol dire che il server non si lascia
        // incorniciare (è la strada di prima, e si prende quella); dopo il
        // clic, che non si può sapere com'è andata.
        if (!doc || !doc.documentElement) return chiudi(fase === "carico" ? "rifiutata" : "incerta");

        if (fase === "carico") {
          let cliccato = false;
          try { cliccato = maybeAutoConfirm(panel, doc, url); }
          catch (e) { panel?.log(`${now()}  conferma in sottofondo interrotta: ${e?.message || e}`); }
          // Al carrello manca una riga che deve avere: lo si ricarica (una
          // lettura dell'elenco pulito) e i controlli ripartono da capo.
          if (cliccato && cliccato.rileggi) {
            clearTimeout(tid);
            tid = setTimeout(() => { if (!fatto) { cronometro(); f.src = listUrl; } }, cliccato.rileggi);
            return;
          }
          // Nessun clic vuol dire che un controllo ha detto di no: la pagina
          // va mostrata al medico, che decide lui.
          if (!cliccato) return chiudi("sospesa");
          fase = "confermo";
          panel?.render();
          return;
        }
        // Seconda pagina: quella dopo la conferma. È la prova solo se è di
        // questo episodio e porta i fogli di QUESTA richiesta — e allora i
        // fogli si prendono da lì.
        const suo = findEpisodeIdInDoc(doc);
        if (!rid || !suo || suo !== episodeId || !printModel(doc, url)[rid]) {
          panel?.log(`${now()}  dopo la conferma: "${snippet(doc).slice(0, 80)}" — nessuna prova che sia confermata`);
          return chiudi("incerta");
        }
        let stampata = false;
        try { stampata = maybeAutoPrint(panel, doc, url); } catch { stampata = false; }
        chiudi(stampata ? "stampata" : "confermata");
      });
      f.addEventListener("error", () => chiudi(fase === "carico" ? "rifiutata" : "incerta"));
      document.documentElement.appendChild(f);
      f.src = listUrl;
    });
  }

  // Il giro che la navigazione ha interrotto: riprende da dov'era, su
  // qualunque pagina del gestionale il medico sia finito. Quello che era IN
  // VOLO si cerca in carrello e non si rimanda mai — l'unica cosa che la
  // pagina morendo si porta via è la RISPOSTA, non l'ordine.
  function riprendiCorsa(panel) {
    const c = tabStore.get(CORSA, null);
    if (!c) return false;
    const daFare = (c.involo ? 1 : 0) + (c.restanti || []).length;   // roba ancora aperta: i soli «fatti» non bastano
    const scaduta = Date.now() - (c.ts || 0) > CORSA_TTL;
    const troppe = (c.riprese || 0) >= CORSA_MAX;
    if (scaduta || troppe || !c.listUrl || !c.ep || !daFare) {
      tabStore.set(CORSA, null);
      if (daFare && (scaduta || troppe)) {
        panel.message = `Il giro su ${c.paziente || "questo paziente"} era rimasto a metà da troppo tempo: apri il carrello e controlla.`;
        panel.render();
      }
      return false;
    }
    // Il giro di un ordine in sottofondo riprende solo nella sua scheda e solo
    // finché il service worker lo conosce. Una scheda ripristinata dopo che il
    // browser è caduto (l'appunto sopravvive, l'ordine no), o la copia di una
    // scheda duplicata, non lo finisce di nascosto: lo lascia, e il segno
    // condiviso «giro rimasto a metà» resta per la prima pagina del medico.
    if (c.ordine && !(LAVORO && LAVORO.id === c.ordine)) {
      tabStore.set(CORSA, null);
      panel.log(`${now()}  l'appunto è di un ordine che non c'è più: non lo riprendo`);
      panel.message = `Il giro di esami su ${c.paziente || "un paziente"} si era fermato a metà (era una scheda d'ordine): non lo riprendo. Apri il carrello e controlla.`;
      panel.render();
      return false;
    }
    if (!presidioLibero(c.rid, null)) {
      // Qualcuno ci sta già lavorando: quasi sempre questa stessa scheda
      // duplicata, che si è portata dietro l'appunto. Non si manda niente e non
      // si butta via niente: se fra poco quel presidio scade, la pagina dopo
      // riprende. (Cambiando pagina il presidio si molla subito, quindi questo
      // non scatta per una navigazione normale.)
      panel.log(`${now()}  un'altra scheda sta già mandando gli esami di questa richiesta: da qui, niente`);
      panel.message = "Un'altra scheda sta finendo questo giro di esami: da qui non mando niente.";
      panel.render();
      return false;
    }
    const items = [];
    // Quello che era già in carrello prima dell'interruzione rientra nel giro:
    // si ricontrolla (mai si rimanda) così la ricevuta finale parla della
    // richiesta intera, non solo del pezzo dopo la navigazione.
    for (const f of c.fatti || []) items.push({ ...f, soloVerifica: true, giaFatto: true });
    if (c.involo) items.push({ ...c.involo, soloVerifica: true });
    for (const r of c.restanti || []) items.push({ ...r });
    panel.runPatient = c.paziente || "";
    // Il conto delle riprese si scrive PRIMA di ripartire: se anche questa
    // ripresa muore subito, il tetto vale lo stesso e non si ricomincia in
    // eterno a ogni ricaricamento.
    tabStore.set(CORSA, { ...c, ts: Date.now(), riprese: (c.riprese || 0) + 1 });
    panel.log(`${now()}  ── riprendo il giro dopo il cambio pagina: ${items.length} da sistemare ──`);
    runPlan({
      startPage: "ripresa", listUrl: c.listUrl, items,
      episodeId: c.ep, autoConfirm: !!c.autoConfirm, quesito: c.quesito || "", qinfo: c.qinfo || null,
      patientName: c.paziente || "", riprese: (c.riprese || 0) + 1, ...(c.ritentato ? { ritentato: true } : {}),
      ...(Array.isArray(c.originali) ? { originali: c.originali } : {}),
      ...(c.patientUrl ? { patientUrl: c.patientUrl } : {}),
    }, panel);
    return true;
  }

  // «2 esami non sono stati mandati, 1 è da controllare»: il segno di un giro
  // rimasto a metà, detto giusto — quello in volo non è mai «non mandato».
  const contoRimasto = (quanti, forse) => [
    quanti ? (quanti === 1 ? "1 esame non è stato mandato" : `${quanti} esami non sono stati mandati`) : "",
    forse ? (forse === 1 ? `1 ${quanti ? "" : "esame "}è da controllare` : `${forse} ${quanti ? "" : "esami "}sono da controllare`) : "",
  ].filter(Boolean).join(", ").replace(/\s+/g, " ");
  // Un giro rimasto a metà che NESSUNO riprenderà (scheda chiusa, browser
  // caduto, sessione scaduta): l'appunto vive nella scheda e se n'è andato con
  // lei, ma il segno condiviso no. Lo si dice, una volta, e lo si toglie —
  // a meno che lo dica già la striscia di un ordine di quel paziente.
  function avvisaGiroAbbandonato(panel, ordini = []) {
    const a = store.get(APERTA, null);
    if (!a || !(a.quanti || a.forse)) return false;
    const eta = Date.now() - (a.ts || 0);
    if (eta > APERTA_TTL) { store.set(APERTA, null); return false; }
    // fresco = c'è una scheda che ci sta ancora lavorando: non è abbandonato
    if (eta < 60e3 || tabStore.get(CORSA, null)) return false;
    if (ordini.some((x) => x.ep === a.ep)) return false;
    store.set(APERTA, null);
    panel.message = `Un giro di esami su ${a.paziente || "un paziente"} è rimasto a metà: ${contoRimasto(a.quanti, a.forse)}. Apri la sua richiesta e controlla.`;
    panel.collapsed = false;   // un avviso chiuso nella pill non lo legge nessuno
    panel.render();
    return true;
  }

  // Il carrello di una sola risorsa, la Conferma che invia la richiesta
  // intera: si clicca solo se ogni controllo dice sì. Ogni no scrive il suo
  // perché nel Registro. Un carrello a cui manca una riga che deve avere
  // (l'elenco arriva monco, o in ritardo) si rilegge — `{ rileggi: ms }`: chi
  // chiama ricarica l'elenco pulito, e i controlli ripartono da capo — al
  // massimo CONFIRM_WAITS volte; tutto il resto sospende subito.
  function maybeAutoConfirm(panel, doc = document, url = location.href) {
    const flag = tabStore.get("confirm.v1", null);
    if (!flag) return false;
    const no = (perche, { rileggi = false, messaggio = "" } = {}) => {
      const k = flag.riletture || 0;
      if (rileggi && k < CONFIRM_WAITS.length) {
        tabStore.set("confirm.v1", { ...flag, riletture: k + 1 });
        panel?.log(`${now()}  auto-conferma: ${perche} — rileggo il carrello fra ${CONFIRM_WAITS[k] / 1000} s`);
        return { rileggi: CONFIRM_WAITS[k] };
      }
      tabStore.set("confirm.v1", null);
      if (panel) {
        panel.log(`${now()}  auto-conferma sospesa: ${perche}`);
        if (messaggio) { panel.message = messaggio; panel.render(); }
      }
      return false;
    };
    const aMano = "La Conferma invia la richiesta intera — controlla il carrello e premila tu sulla pagina.";
    if (Date.now() - (flag.ts || 0) > CONFIRM_FLAG_TTL) return no("il segno della conferma è scaduto");

    const model = examModel(doc, url);
    const ep = findEpisodeId(doc, url);
    if (!model.form || !model.richiestaId) { panel?.log(`${now()}  auto-conferma: questa pagina non è il carrello`); return false; }
    // The flag is tab-scoped, so a mismatching richiesta here is stale: drop it.
    if (model.richiestaId !== flag.richiestaId || (flag.episodeId && ep && ep !== flag.episodeId)) return no(`questo carrello è di un'altra richiesta (${model.richiestaId})`);
    const ultimo = `«${shortLabel(flag.lastLabel || "") || flag.lastCode}» (${flag.lastCode})`;
    if (!model.inCart(flag.lastCode)) {
      return no(`${ultimo} non è nel carrello di questa pagina`, { rileggi: true,
        messaggio: `Conferma automatica sospesa: ${ultimo} non compare nel carrello. ${aMano}` });
    }
    // Anti wrong-exam check also at the last gate before an irreversible act.
    if (flag.lastLabel) {
      const liveRow = model.exams.find((e) => e.code === flag.lastCode && e.isDel);
      const norm = (s) => (s || "").replace(/\s+/g, " ").trim().toUpperCase();
      if (!liveRow || norm(liveRow.label) !== norm(flag.lastLabel)) {
        return no(`la riga ${flag.lastCode} oggi si chiama «${liveRow ? liveRow.label : "?"}»`, { messaggio: `Conferma automatica sospesa: ${ultimo} in carrello ha un altro nome. ${aMano}` });
      }
    }
    if (!model.confirmButton) return no("nella pagina non c'è il bottone Conferma");
    const inCart = model.exams.filter((e) => e.isDel);
    const cartPreview = inCart.slice(0, 5).map((e) => shortLabel(e.label));
    if (inCart.length > 5) cartPreview.push(`+${inCart.length - 5} altri`);
    // The native Conferma submits the WHOLE richiesta, not this run's
    // additions. This page shows only the CURRENT resource's cart rows, so the
    // honest comparison is per-resource against the receipt: a row in the cart
    // that this run did not add (a leftover from an earlier attempt) means the
    // click would confirm more than the banner says — refuse, human decides.
    const receipt = tabStore.get("receipt.v1", null);
    // Senza ricevuta non si può dire «nel carrello c'è solo quello che ho
    // aggiunto io» — e la Conferma nativa invia la richiesta INTERA. Non
    // poter controllare non è come aver controllato: si ferma, e preme il
    // medico. (Prima di questa riga il controllo veniva semplicemente
    // saltato e la conferma partiva lo stesso.)
    if (!receipt || receipt.richiestaId !== model.richiestaId || !Array.isArray(receipt.items)) {
      return no("ricevuta assente o di un'altra richiesta", { messaggio: `Conferma automatica sospesa: non risulta cosa è stato aggiunto in questa corsa. ${aMano}` });
    }
    {
      // Questa pagina mostra il carrello di UNA risorsa sola, ma la Conferma
      // invia la richiesta intera. Quindi si controlla risorsa per risorsa:
      // quella davanti agli occhi dal vivo, le altre col carrello che il run
      // ha visto quando le ha visitate. Una riga che non abbiamo aggiunto,
      // su qualunque risorsa, sospende: decide una persona.
      const perRes = new Map();
      for (const i of receipt.items) {
        const r = String(i.res);
        perRes.set(r, (perRes.get(r) || new Set()).add(String(i.code)));
      }
      const carrelli = receipt.carrelli || {};
      const guai = [];
      let vistiQui = 0, soloMancaQui = true;   // (solo righe che mancano dalla pagina davanti: quelle si rileggono)
      for (const [res, attesi] of perRes) {
        const visti = res === model.res
          ? inCart.map((e) => String(e.code))
          : (Array.isArray(carrelli[res]) ? carrelli[res].map(String) : null);
        if (res === model.res) vistiQui = visti.length;
        if (!visti) { guai.push(`${risorsaCorta(res)}: carrello non visto`); soloMancaQui = false; continue; }
        const estranei = visti.filter((c) => !attesi.has(c));
        if (estranei.length || visti.length !== attesi.size) {
          guai.push(`${risorsaCorta(res)}: ${visti.length} nel carrello, ${attesi.size} aggiunti${estranei.length ? ` (estranei ${estranei.join(", ")})` : ""}`);
          if (estranei.length || res !== model.res) soloMancaQui = false;
        }
      }
      if (guai.length) {
        return no(`${guai.join("; ")} (${vistiQui} esami su questa risorsa)`, { rileggi: soloMancaQui,
          messaggio: `Conferma automatica sospesa: ${guai.join("; ")}. ${aMano}` });
      }
    }
    tabStore.set("confirm.v1", null); // consume immediately: a reload must never re-trigger the countdown

    // The doctor already chose "+ Conferma": that click was the decision, and
    // every gate above has passed (episode, richiesta, last exam present under
    // its right name, cart identical to the receipt for this resource).
    // Confirm now — a countdown here was dead time, not safety.
    panel?.log(`${now()}  conferma automatica: ${flag.count} ${flag.count === 1 ? "esame" : "esami"} · ${cartPreview.join(" · ")} · click nativo su Conferma`);
    // Quando la pagina non è quella davanti agli occhi, la stampa va armata
    // qui: il gancio sul bottone vive solo sulla pagina vera.
    if (doc !== document) {
      const prec = tabStore.get("print.v1", null);
      const fresco = prec && prec.episodeId === (ep || "") && Date.now() - (prec.ts || 0) < PRINT_FLAG_TTL;
      tabStore.set("print.v1", { ids: [...new Set([...(fresco ? prec.ids || [] : []), model.richiestaId])], episodeId: ep || "", ts: Date.now(),
        n: { ...(fresco ? prec.n || {} : {}), [model.richiestaId]: receipt.items.length },
        q: { ...(fresco ? prec.q || {} : {}), ...(receipt.quesito ? { [model.richiestaId]: receipt.quesito } : {}) } });
      const q = tabStore.get("queue.v1", null);
      if (q && q.items) {
        const restano = q.items.filter((it) => it.rid !== model.richiestaId);
        tabStore.set("queue.v1", restano.length ? { ...q, items: restano, ts: Date.now() } : null);
      }
    }
    model.confirmButton.click(); // native click → server confirm → label print flow
    return true;
  }

  // ============================================================ PDF → TESTO
  // Radiology and ECG reports are PDFs whose text can be recovered: the fonts
  // carry their own ToUnicode map, so glyph codes can be translated exactly
  // instead of guessed. (Laboratory reports cannot: they are drawn one glyph
  // at a time with a subset font and no map — those stay documents to open.)
  async function estraiTestoPdf(bytes) {
    // NB: TextDecoder("latin1") is windows-1252 in the browser and rewrites
    // bytes 0x80-0x9F — which corrupts every compressed stream. One byte, one
    // code unit, by hand.
    const byteStr = (u8) => {
      let out = "";
      for (let i = 0; i < u8.length; i += 0x8000) out += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
      return out;
    };
    const lat = byteStr(bytes instanceof ArrayBuffer ? new Uint8Array(bytes) : bytes);
    const objs = new Map();
    for (const m of lat.matchAll(/(\d+)\s+\d+\s+obj\b([\s\S]*?)endobj/g)) objs.set(Number(m[1]), m[2]);
    if (!objs.size) return [];

    // The browser only decompresses asynchronously, so the whole extraction is
    // async: zlib-wrapped first (what PDFs use), raw deflate as a fallback.
    const inflate = async (grezzo) => {
      const buf = new Uint8Array(grezzo.length);
      for (let i = 0; i < grezzo.length; i++) buf[i] = grezzo.charCodeAt(i) & 0xff;
      for (const modo of ["deflate", "deflate-raw"]) {
        try {
          const ds = new DecompressionStream(modo);
          const out = new Response(new Blob([buf]).stream().pipeThrough(ds));
          return new TextDecoder("latin1").decode(await out.arrayBuffer());
        } catch { /* try the next mode */ }
      }
      return null;
    };
    const streamOf = async (body) => {
      const i = body.indexOf("stream");
      if (i < 0) return null;
      let a = i + 6;
      if (body[a] === "\r") a++;
      if (body[a] === "\n") a++;
      const e = body.lastIndexOf("endstream");
      if (e < 0 || e <= a) return null;
      // exact length when the dictionary states it (a trailing newline would
      // make the decompressor reject the whole stream), else trim it by hand
      const len = /\/Length\s+(\d+)/.exec(body.slice(0, i));
      const grezzo = len && a + Number(len[1]) <= e
        ? body.slice(a, a + Number(len[1]))
        : body.slice(a, e).replace(/\r?\n$/, "");
      if (!/\/FlateDecode/.test(body.slice(0, i))) return grezzo;
      return await inflate(grezzo);
    };

    const hexToStr = (h) => {
      let out = "";
      for (let i = 0; i + 3 < h.length + 1; i += 4) out += String.fromCharCode(parseInt(h.slice(i, i + 4), 16));
      return out;
    };
    const parseCMap = (txt) => {
      const map = new Map();
      const cs = /begincodespacerange([\s\S]*?)endcodespacerange/.exec(txt);
      const primo = cs && /<([0-9A-Fa-f]{2,})>/.exec(cs[1]);
      map.byteLen = primo ? Math.max(1, Math.floor(primo[1].length / 2)) : 1;
      for (const b of txt.matchAll(/beginbfchar([\s\S]*?)endbfchar/g)) {
        for (const m of b[1].matchAll(/<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>/g)) map.set(parseInt(m[1], 16), hexToStr(m[2]));
      }
      for (const b of txt.matchAll(/beginbfrange([\s\S]*?)endbfrange/g)) {
        for (const m of b[1].matchAll(/<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>/g)) {
          const lo = parseInt(m[1], 16), hi = parseInt(m[2], 16), dst = parseInt(m[3], 16);
          for (let c = lo; c <= hi && c - lo < 4096; c++) map.set(c, String.fromCharCode(dst + (c - lo)));
        }
      }
      return map;
    };
    const cmapDiOggetto = new Map();
    for (const [num, body] of objs) {
      const tu = /\/ToUnicode\s+(\d+)\s+0\s+R/.exec(body);
      if (!tu) continue;
      const src = objs.get(Number(tu[1]));
      const txt = src && await streamOf(src);
      if (txt) cmapDiOggetto.set(num, parseCMap(txt));
    }
    const fonts = new Map();
    for (const [, body] of objs) {
      for (const m of body.matchAll(/\/(F\d+)\s+(\d+)\s+0\s+R/g)) {
        const cm = cmapDiOggetto.get(Number(m[2]));
        if (cm) fonts.set(m[1], cm);
      }
    }

    let content = "";
    for (const [, body] of objs) {
      if (!/\/Type\s*\/Page[^s]/.test(body)) continue;
      const c = /\/Contents\s+(\d+)\s+0\s+R/.exec(body);
      if (c && objs.has(Number(c[1]))) content += ((await streamOf(objs.get(Number(c[1])))) || "") + "\n";
    }
    if (!content.trim()) {
      let best = "";
      for (const [, body] of objs) {
        const t = (await streamOf(body)) || "";
        if ((t.match(/T[jJ]/g) || []).length > (best.match(/T[jJ]/g) || []).length) best = t;
      }
      content = best;
    }
    if (!content.trim()) return [];

    // la matrice del testo per intero: (a b c d) dice in che direzione si
    // scrive — un ECG in orizzontale è ruotato di 90° — e Td si muove in quella
    let cm = null, x = 0, y = 0, ma = 1, mb = 0, mc = 0, md = 1;
    const items = [];
    const unesc = (t) => t.replace(/\\([nrtbf()\\])/g, (m, c) => ({ n: "\n", r: "\r", t: "\t", b: "\b", f: "\f" }[c] || c))
      .replace(/\\([0-7]{1,3})/g, (m, o) => String.fromCharCode(parseInt(o, 8)));
    const decode = (t) => {
      if (!cm) return t;
      const n = cm.byteLen || 1;
      let out = "";
      for (let i = 0; i < t.length; i += n) {
        let code = 0;
        for (let k = 0; k < n && i + k < t.length; k++) code = (code << 8) | (t.charCodeAt(i + k) & 0xff);
        const u = cm.get(code);
        out += u !== undefined ? u : (n === 1 ? t[i] : "");
      }
      return out;
    };
    // strings come either literal — (testo) — or hexadecimal — <00520041>
    const daHex = (h) => {
      const pulito = h.replace(/[^0-9A-Fa-f]/g, "");
      let out = "";
      for (let i = 0; i + 1 < pulito.length; i += 2) out += String.fromCharCode(parseInt(pulito.slice(i, i + 2), 16));
      return out;
    };
    // BT resets the text matrix: without this the Td offsets of every block
    // pile up and the lines come out in the wrong order.
    const re = /\bBT\b|\/(F\d+)[^\S\n]+[\d.]+\s+Tf|([\d.-]+)\s+([\d.-]+)\s+T[dD]|([\d.-]+\s+){4}([\d.-]+)\s+([\d.-]+)\s+Tm|\((?:\\.|[^()\\])*\)\s*Tj|<[0-9A-Fa-f\s]*>\s*Tj|\[[\s\S]*?\]\s*TJ/g;
    for (const m of content.matchAll(re)) {
      const t = m[0];
      if (t === "BT") { x = 0; y = 0; ma = 1; mb = 0; mc = 0; md = 1; continue; }
      // cambiare font azzera la mappa: un font senza ToUnicode va letto
      // grezzo, non con la tabella di un altro font (i caratteri cambierebbero)
      if (t.startsWith("/F")) { const nf = t.slice(1).split(/\s/)[0]; cm = fonts.has(nf) ? fonts.get(nf) : null; continue; }
      if (/Tm$/.test(t)) { const n = t.trim().split(/\s+/).map(parseFloat); [ma, mb, mc, md, x, y] = n; continue; }
      if (/T[dD]$/.test(t)) { const n = t.trim().split(/\s+/).map(parseFloat); x += n[0] * ma + n[1] * mc; y += n[0] * mb + n[1] * md; continue; }
      if (/Tj$/.test(t)) {
        const grezzo = t.trim().startsWith("<")
          ? daHex(t.slice(t.indexOf("<") + 1, t.lastIndexOf(">")))
          : unesc(t.slice(t.indexOf("(") + 1, t.lastIndexOf(")")));
        items.push({ x, y, ma, mb, s: decode(grezzo) });
        continue;
      }
      let s2 = "";
      for (const p of t.matchAll(/\((?:\\.|[^()\\])*\)|<[0-9A-Fa-f\s]*>/g)) {
        s2 += decode(p[0][0] === "<" ? daHex(p[0].slice(1, -1)) : unesc(p[0].slice(1, -1)));
      }
      items.push({ x, y, ma, mb, s: s2 });
    }
    if (!items.length) return [];

    // rebuild lines from the coordinates: same y is the same line — y e x nel
    // sistema della scrittura (ruotato come il testo), una direzione alla volta
    const QUARTI = [[1, 0], [0, 1], [-1, 0], [0, -1]];
    const perVerso = new Map();
    for (const it of items) {
      const q = ((Math.round(Math.atan2(it.mb || 0, it.ma || 0) / (Math.PI / 2)) % 4) + 4) % 4;
      const [c, sn] = QUARTI[q];
      if (!perVerso.has(q)) perVerso.set(q, []);
      perVerso.get(q).push({ s: it.s, x: it.x * c + it.y * sn, y: -it.x * sn + it.y * c });
    }
    const righe = [];
    for (const gruppo of perVerso.values()) {
    gruppo.sort((a, b) => (Math.abs(a.y - b.y) > 2 ? b.y - a.y : a.x - b.x));
    let cur = null;
    for (const it of gruppo) {
      if (!it.s) continue;
      if (!cur || Math.abs(cur.y - it.y) > 2) { cur = { y: it.y, parts: [] }; righe.push(cur); }
      cur.parts.push(it);
    }
    }
    return righe.map((l) => {
      const passi = [];
      for (let i = 1; i < l.parts.length; i++) {
        const dx = l.parts[i].x - l.parts[i - 1].x, n = Math.max(1, l.parts[i - 1].s.length);
        if (dx > 0) passi.push(dx / n);
      }
      passi.sort((a, b) => a - b);
      const unita = passi.length ? passi[Math.floor(passi.length / 2)] : 6;
      let out = "", prev = null;
      for (const p of l.parts) {
        if (prev) {
          const dx = p.x - prev.x;
          if (dx > unita * Math.max(1, prev.s.length) * 0.7 && !/\s$/.test(out) && !/^\s/.test(p.s)) out += " ";
        }
        out += p.s; prev = p;
      }
      return out.replace(/\s+/g, " ").trim();
    }).filter(Boolean);
  }

  // pdf.js (Mozilla) è il lettore vero: cifratura, oggetti compressi, font
  // con nomi qualsiasi, testo dentro i moduli — tutto quello che il lettore
  // qui sopra non sa. Sta dentro l'estensione e si carica nella scheda solo
  // la prima volta che serve (il service worker lo mette nel mondo isolato
  // del pannello, mai nella pagina). Senza estensione resta il lettore di casa.
  let pdfjsInArrivo = null;
  function pdfjsPronto() {
    if (globalThis.pdfjsLib?.getDocument && globalThis.pdfjsWorker?.WorkerMessageHandler) return Promise.resolve(globalThis.pdfjsLib);
    if (!hasExt()) return Promise.resolve(null);
    return pdfjsInArrivo = pdfjsInArrivo || ask({ t: "pdfjs" }).then((r) => {
      const lib = r && r.ok && globalThis.pdfjsLib?.getDocument ? globalThis.pdfjsLib : null;
      if (!lib) pdfjsInArrivo = null;   // si riprova al prossimo referto
      return lib;
    });
  }

  // Il visore dei referti salvati: il PDF disegnato da pdf.js sopra la pagina,
  // chi · esame · quando in testa. ✕ (o Esc) e si torna agli Esiti.
  function apriVisore(lib, buf, titolo) {
    document.getElementById("psassist-visore")?.remove();
    const host = document.createElement("div");
    host.id = "psassist-visore";
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `<style>
      :host { all: initial; }
      * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, "Segoe UI", Roboto, Arial, sans-serif; }
      .vfondo { position: fixed; inset: 0; z-index: 2147483647; background: rgba(9,42,74,.45); display: flex; padding: 2vh 2vw; }
      .vis { display: flex; flex-direction: column; width: min(980px, 100%); margin: 0 auto; background: #fff;
             border-radius: 12px; overflow: hidden; box-shadow: 0 12px 40px rgba(9,42,74,.35); }
      .vhd { display: flex; align-items: center; gap: 10px; padding: 9px 10px 9px 16px; border-bottom: 1px solid #D9E2EC; color: #16232E; }
      .vtit { flex: 1; min-width: 0; font-size: 14px; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .vx { border: 0; background: #EEF3F8; color: #16232E; border-radius: 8px; width: 34px; height: 34px; font-size: 15px; cursor: pointer; }
      .vx:hover { background: #DCE6F0; }
      .vpag { flex: 1; overflow: auto; background: #E9EEF3; padding: 14px; display: flex; flex-direction: column; align-items: center; gap: 14px; }
      canvas { display: block; max-width: 100%; background: #fff; box-shadow: 0 2px 8px rgba(9,42,74,.18); }
      .verr { color: #B3261E; font-size: 13px; }
    </style>
    <div class="vfondo"><div class="vis" role="dialog" aria-modal="true" aria-label="${esc(titolo)}">
      <div class="vhd"><b class="vtit" title="${esc(titolo)}">${esc(titolo)}</b><button class="vx" id="vchiudi" title="Chiudi (Esc)" aria-label="Chiudi">✕</button></div>
      <div class="vpag"></div>
    </div></div>`;
    document.documentElement.appendChild(host);
    let doc = null;
    const tasto = (ev) => { if (ev.key === "Escape") { ev.stopPropagation(); ev.preventDefault(); chiudi(); } };
    const chiudi = () => {
      window.removeEventListener("keydown", tasto, true);
      host.remove();
      if (doc) Promise.resolve(doc.destroy()).catch(() => {});
    };
    window.addEventListener("keydown", tasto, true);
    root.getElementById("vchiudi").addEventListener("click", chiudi);
    root.querySelector(".vfondo").addEventListener("click", (ev) => { if (ev.target === ev.currentTarget) chiudi(); });
    root.getElementById("vchiudi").focus();
    const pag = root.querySelector(".vpag");
    (async () => {
      // (i font: quelli del PDF, o — se non ci sono — quelli di sistema, per disegnare)
      doc = await lib.getDocument({ data: new Uint8Array(buf).slice(), isEvalSupported: false, disableFontFace: false,
        useSystemFonts: true, useWorkerFetch: false, disableAutoFetch: true, disableStream: true, verbosity: 0 }).promise;
      const dpr = window.devicePixelRatio || 1;
      for (let n = 1; n <= doc.numPages && host.isConnected; n++) {
        const p = await doc.getPage(n);
        const largo = Math.max(320, pag.clientWidth - 28);
        const vp = p.getViewport({ scale: (largo / p.getViewport({ scale: 1 }).width) * dpr });
        const c = document.createElement("canvas");
        c.width = Math.floor(vp.width); c.height = Math.floor(vp.height);
        c.style.width = `${Math.floor(vp.width / dpr)}px`;
        c.setAttribute("aria-label", `Pagina ${n}`);
        pag.appendChild(c);
        await p.render({ canvasContext: c.getContext("2d"), viewport: vp }).promise;
      }
    })().catch(() => { if (host.isConnected) pag.insertAdjacentHTML("beforeend", `<div class="verr">PDF non disegnato.</div>`); });
    return true;
  }

  // Pezzi di testo con la loro posizione → righe: stessa linea di base, stessa
  // riga; dentro la riga da sinistra a destra, con uno spazio dove c'è un buco.
  // La direzione la dice la matrice INTERA del pezzo (t = [a b c d e f]), non
  // solo il punto (e, f): un ECG in orizzontale su una pagina verticale scrive
  // ruotato di 90°, e leggendo solo (e, f) le righe uscivano a pezzi, mescolate.
  // Ogni pezzo si riporta nel sistema della sua scrittura (u lungo la riga, v
  // verso l'alto della riga); i pezzi con la stessa direzione stanno insieme.
  function righeDaPezzi(pezzi) {
    const QUARTI = [[1, 0], [0, 1], [-1, 0], [0, -1]];
    const gruppi = new Map();
    for (const q of pezzi) {
      if (!q.s) continue;
      const t = Array.isArray(q.t) && q.t.length >= 6 ? q.t : null;
      const quarto = t && (t[0] || t[1]) ? ((Math.round(Math.atan2(t[1], t[0]) / (Math.PI / 2)) % 4) + 4) % 4 : 0;
      const [c, sn] = QUARTI[quarto];
      const x = q.x ?? (t ? t[4] : 0), y = q.y ?? (t ? t[5] : 0);
      if (!gruppi.has(quarto)) gruppi.set(quarto, []);
      gruppi.get(quarto).push({ ...q, x: x * c + y * sn, y: -x * sn + y * c });
    }
    return [...gruppi.values()].flatMap(righeDritte);
  }
  function righeDritte(pezzi) {
    const righe = [];
    for (const p of pezzi.filter((q) => q.s).sort((a, b) => b.y - a.y)) {
      const r = righe[righe.length - 1];
      if (r && Math.abs(r.y - p.y) <= Math.max(2, Math.min(r.h, p.h) * 0.4)) r.parti.push(p);
      else righe.push({ y: p.y, h: p.h, parti: [p] });
    }
    return righe.map((r) => {
      let out = "", prev = null;
      for (const p of r.parti.sort((a, b) => a.x - b.x)) {
        if (prev && !/\s$/.test(out) && !/^\s/.test(p.s) && p.x - (prev.x + prev.w) > Math.max(prev.h, p.h) * 0.2) out += " ";
        out += p.s; prev = p;
      }
      return out.replace(/\s+/g, " ").trim();
    }).filter(Boolean);
  }

  async function testoPdfjs(lib, bytes) {
    // una COPIA: pdf.js si prende il buffer che gli si passa, e questo serve
    // ancora intero per tenere il PDF
    const doc = await lib.getDocument({
      data: new Uint8Array(bytes).slice(), isEvalSupported: false, disableFontFace: true,
      useSystemFonts: false, useWorkerFetch: false, disableAutoFetch: true, disableStream: true, verbosity: 0,
    }).promise;
    try {
      const righe = [];
      for (let n = 1; n <= doc.numPages; n++) {
        const { items } = await (await doc.getPage(n)).getTextContent();
        righe.push(...righeDaPezzi(items.map((it) => {
          const t = it.transform || [1, 0, 0, 1, 0, 0];
          return { x: t[4], y: t[5], t, w: it.width || 0, h: Math.hypot(t[2], t[3]) || it.height || 10, s: it.str || "" };
        })));
      }
      return righe;
    } finally { Promise.resolve(doc.destroy()).catch(() => {}); }
  }

  // Il testo di un referto: pdf.js se c'è, il lettore di casa se no (o se
  // pdf.js non ne cava niente). Dice anche chi l'ha letto, o perché nessuno.
  async function testoPdf(bytes) {
    let motivo = "";
    const lib = await pdfjsPronto().catch(() => null);
    if (lib) {
      try {
        const righe = await testoPdfjs(lib, bytes);
        if (righe.length) return { righe, lettore: "pdf.js" };
        motivo = "pdf.js: nessun testo";
      } catch (e) { motivo = `pdf.js: ${(e && (e.name || "errore"))}${e && e.message ? ` ${String(e.message).slice(0, 80)}` : ""}`; }
    } else if (hasExt()) motivo = "pdf.js non caricato";
    const righe = await estraiTestoPdf(bytes).catch(() => []);
    return { righe, lettore: "lettore di casa", motivo };
  }

  // Com'è fatto un PDF, senza una parola di quello che c'è scritto: versione,
  // cifratura, oggetti compressi, font e codifiche, filtri, immagini, chi l'ha
  // prodotto. È quello che serve per capire perché il testo non esce.
  function pdfDiag(bytes) {
    try {
      const u8 = bytes instanceof ArrayBuffer ? new Uint8Array(bytes) : bytes;
      let t = "";
      for (let i = 0; i < u8.length; i += 0x8000) t += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
      const conta = (re) => (t.match(re) || []).length;
      const tipi = (re) => [...new Set([...t.matchAll(re)].map((m) => m[1]))].slice(0, 6).join(",") || "—";
      const enc = /\/Encrypt\s+(\d+)\s+\d+\s+R/.exec(t);
      const encObj = enc ? (new RegExp(`\\b${enc[1]}\\s+\\d+\\s+obj([\\s\\S]{0,400}?)endobj`).exec(t) || [])[1] || "" : "";
      const vr = encObj ? `V${(/\/V\s+(\d)/.exec(encObj) || [])[1] || "?"}/R${(/\/R\s+(\d)/.exec(encObj) || [])[1] || "?"}${/\/AESV[23]/.test(encObj) ? " AES" : ""}` : "";
      const leggibile = (re) => { const m = re.exec(t); return m && /^[\x20-\x7E]{2,60}$/.test(m[1]) ? m[1] : ""; };
      const prod = leggibile(/\/Producer\s*\(([^)]{2,60})\)/);   // il programma, non l'autore
      return [
        `PDF ${(/%PDF-(\d\.\d)/.exec(t) || [])[1] || "?"} ${Math.round(u8.length / 1024)}KB`,
        enc ? `cifrato ${vr}` : "non cifrato",
        `ObjStm ${conta(/\/Type\s*\/ObjStm/g)}`,
        `pagine ${conta(/\/Type\s*\/Page(?!s)/g) || "?"}`,
        `font ${tipi(/\/Subtype\s*\/(Type0|TrueType|Type1|Type3|MMType1)\b/g)}`,
        `encoding ${tipi(/\/Encoding\s*\/([A-Za-z0-9-]+)/g)}`,
        `ToUnicode ${conta(/\/ToUnicode\b/g)}`,
        `filtri ${tipi(/\/Filter\s*\[?\s*\/([A-Za-z0-9]+)/g)}`,
        `immagini ${conta(/\/Subtype\s*\/Image\b/g)}`,
        `moduli ${conta(/\/Subtype\s*\/Form\b/g)}`,
        prod ? `prodotto da «${prod}»` : "",
      ].filter(Boolean).join(" · ");
    } catch (e) { return `diagnosi PDF non riuscita (${e && e.message})`; }
  }

  // ------------------------------------------------ DI CHI È QUESTO REFERTO
  // Ogni testo di referto passa di qui prima di essere mostrato: il codice
  // fiscale scritto nel PDF (o nome + data di nascita) contro il paziente
  // della pagina. «altro» = il testo non si mostra; «ignota» = si mostra, con
  // «intestazione non verificata»; «ok» = si mostra.
  //   paz: { cf (in chiaro, dal riquadro), cfImp (impronta, dai prelievi), nome, nascita "gg/mm/aaaa" }
  function identitaReferto(righe, paz) {
    const p = paz || {};
    const testo = (righe || []).join("\n").toUpperCase();
    const norm = (t) => String(t || "").toUpperCase().normalize("NFD").replace(/[̀-ͯ]/g, "")
      .replace(/[^A-Z0-9 ]+/g, " ").trim().replace(/\s+/g, " ");
    const cfMio = String(p.cf || "").toUpperCase();
    const cfs = [...new Set(testo.match(/\b[A-Z]{6}[0-9LMNPQRSTUV]{2}[A-Z][0-9LMNPQRSTUV]{2}[A-Z][0-9LMNPQRSTUV]{3}[A-Z]\b/g) || [])];
    const giorno = (g, m, a) => {
      const aa = Number(a) < 100 ? Number(a) : Number(a) % 100;
      return `${String(Number(g)).padStart(2, "0")}/${String(Number(m)).padStart(2, "0")}/${String(aa).padStart(2, "0")}`;
    };
    const nascitaMia = (/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})$/.exec(String(p.nascita || "").trim()) || []).slice(1);
    const mia = nascitaMia.length === 3 ? giorno(...nascitaMia) : "";
    // la data di nascita dentro un codice fiscale (il secolo non c'è)
    const nascitaCf = (cf) => {
      const n = (t) => Number(t.replace(/[LMNPQRSTUV]/g, (c) => "LMNPQRSTUV".indexOf(c)));
      const mese = "ABCDEHLMPRST".indexOf(cf[8]) + 1, g = n(cf.slice(9, 11)) % 40;
      return mese && g ? giorno(g, mese, n(cf.slice(6, 8))) : "";
    };
    if (cfs.length) {
      if (cfs.some((c) => (cfMio && c === cfMio) || (p.cfImp && impronta(c) === p.cfImp))) return { esito: "ok", via: "codice fiscale" };
      if (cfMio || p.cfImp) return { esito: "altro", via: "codice fiscale" };
      // il codice del paziente non lo sappiamo ancora: ma la data di nascita dentro il codice sì
      if (mia && cfs.every((c) => nascitaCf(c) && nascitaCf(c) !== mia)) return { esito: "altro", via: "data di nascita nel codice fiscale" };
    }
    const parole = norm(p.nome).split(" ").filter((x) => x.length >= 2);
    const tutto = " " + norm(testo) + " ";
    const nomeC = parole.length > 0 && parole.every((x) => tutto.includes(" " + x + " "));
    // un nome scritto con la sua etichetta («Paziente: BIANCHI ANNA») che non ha niente del nostro
    // (con i due punti: «Paziente collaborante» nel corpo del referto non è un nome)
    const etich = /\b(?:PAZIENTE|COGNOME E NOME|NOMINATIVO|ASSISTITO)\s*:\s*([A-ZÀ-Ü' ]{4,60})/.exec(testo);
    if (etich && parole.length) {
      const sue = norm(etich[1]).split(" ").filter((x) => x.length >= 3);
      if (sue.length && !sue.some((x) => parole.includes(x))) return { esito: "altro", via: "nome" };
    }
    const dn = /(?:NAT[OA]\b[^\n]{0,40}?\bIL|DATA\s+(?:DI\s+)?NASCITA|NASCITA|D\.\s?N\.)\s*[:.]?\s*(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})/.exec(testo);
    if (dn && mia) {
      const sua = giorno(dn[1], dn[2], dn[3]);
      if (sua !== mia) return { esito: "altro", via: "data di nascita" };
      if (nomeC) return { esito: "ok", via: "nome e data di nascita" };
    }
    return { esito: "ignota", via: "" };
  }

  // ECG: si mostra SOLO il referto scritto dal cardiologo, mai le frasi e le
  // misure della macchina (FC, PR, QRS, QTc, assi, «interpretazione
  // automatica»…). Il referto scritto sta sotto la sua intestazione («Referto»,
  // «Conclusioni», «Commento»…) fino alla firma. Senza intestazione: se ci sono
  // misure è il tracciato della macchina, e un referto scritto non c'è; se non
  // ce ne sono è un documento scritto, e lo si mostra.
  function refertoScrittoEcg(righe) {
    const tutte = (righe || []).map((r) => String(r || "").trim()).filter(Boolean);
    // ciò che scrive solo la macchina: derivazioni, misure in tabella, «automatica»
    const struttura = (r) => /^(?:I|II|III|aVR|aVL|aVF|V[1-6])(?:\s+(?:I|II|III|aVR|aVL|aVF|V[1-6]))*$/i.test(r)
      || /interpretazione automatica|analisi automatica|referto automatico|non confermat|unconfirmed|computerizzat|\bmisure\b|\bmeasurements?\b/i.test(r)
      || /^(?:FC|HR|PR|QRS|QTc?[BF]?|QT\/QTc|RR|P\/QRS\/T|Assi?|Axis|Frequenza(?:\s+ventricolare)?|Vent\.?\s*rate)\b\s*[:=]?\s*[-\d]/i.test(r)
      || /\d\s*(?:mm\/s|mm\/mv|hz)(?![a-z])/i.test(r);
    // …e una misura qualsiasi: dice che il PDF è il tracciato (non conta dentro il referto scritto)
    const macchina = (r) => struttura(r) || /\d\s*(?:ms|msec|bpm|b\/min|battiti\/min|\/min|°)(?![a-z])/i.test(r);
    const testa = /^(?:referto(?:\s+(?:medico|cardiologico))?|refertazione|conclusion[ei]|commento|giudizio|diagnosi|interpretazione\s+(?:medica|del\s+medico|cardiologica|clinica))\s*(?::\s*(.*))?$/i;   // da sola sulla riga, o con i due punti: «Referto elettrocardiografico» in testa al tracciato non lo è
    const firma = /^(?:firmato|firma\b|il\s+medico|medico\s+refertante|refertato\s+da|validato|dott\.?(?:ssa)?\s|dr\.?\s|data(?:\s+e\s+ora)?\s+(?:di\s+)?refert)/i;
    for (let i = 0; i < tutte.length; i++) {
      const m = testa.exec(tutte[i]);
      if (!m || /automatic/i.test(tutte[i])) continue;
      const out = [];
      if (m[1] && !struttura(m[1])) out.push(m[1]);
      for (let k = i + 1; k < tutte.length && !firma.test(tutte[k]); k++) if (!struttura(tutte[k])) out.push(tutte[k]);
      if (out.length) return { righe: out, soloMacchina: false };
    }
    if (tutte.some(macchina)) return { righe: [], soloMacchina: true };
    return { righe: tutte, soloMacchina: false };
  }

  // Il portale può mostrare più di un PDF (quello rimasto aperto prima, poi il
  // nostro): non si tiene il primo che passa, ma quello che è di QUESTO
  // paziente e, a parità, quello che nomina l'esame chiesto; a parità ancora,
  // l'ultimo arrivato. Un PDF di un altro paziente non si sceglie mai.
  //   candidati: [{ righe }] · chi: { cf, cfImp, nome, nascita, titolo }
  function scegliPdfReferto(candidati, chi) {
    const parole = String((chi && chi.titolo) || "").toUpperCase().replace(/\([^)]*\)/g, " ")
      .split(/[^A-Z0-9À-Ü]+/).filter((x) => x.length >= 3 && !/^\d+$/.test(x));
    let meglio = -1, punti = -Infinity, altri = 0;
    (candidati || []).forEach((c, i) => {
      const id = identitaReferto(c.righe, chi);
      if (id.esito === "altro") { altri++; return; }
      const t = (c.righe || []).join(" ").toUpperCase();
      const p = (id.esito === "ok" ? 4 : 1) + Math.min(2, parole.filter((x) => t.includes(x)).length) + (c.righe && c.righe.length ? 0 : -1);
      if (p >= punti) { punti = p; meglio = i; }
    });
    return { i: meglio, altri };
  }

  // Al massimo N scaricamenti insieme: gli altri aspettano il loro turno, in
  // ordine. Un tocco su un referto e «Salva» passano dalla stessa fila.
  function codaLimitata(max) {
    let attivi = 0;
    const attesa = [];
    const avanti = () => {
      while (attivi < max && attesa.length) {
        const j = attesa.shift();
        attivi++;
        Promise.resolve().then(j.fn).then(j.ok, j.ko).finally(() => { attivi--; avanti(); });
      }
    };
    const metti = (fn) => new Promise((ok, ko) => { attesa.push({ fn, ok, ko }); avanti(); });
    metti.stato = () => ({ attivi, inCoda: attesa.length });
    return metti;
  }

  // ============================================================ PRINT WIZARD
  // Sequential printing of the richiesta PDFs: labels first (label printer),
  // then the exam list (normal printer). A web page cannot pick a printer or
  // skip the dialog: that takes the Windows helper (stampa automatica, above).
  // Without it this is the most automatic legal flow; Chrome's dialog
  // remembers recent destinations, so switching printer is one click.
  // Mentre un PDF arriva non c'è niente davanti: a che punto è lo dice la pill
  // — o, senza pannello (o col pannello aperto), un riquadrino nell'angolo.
  // Arrivato il PDF compare la scheda di sempre: il PDF in anteprima e la
  // stampante su cui va. È il controllo di un'occhiata, e dice quale
  // stampante scegliere. Da quella cornice, visibile, si apre subito il
  // dialogo di stampa; chiuso il dialogo si passa da soli al documento dopo,
  // e la scheda si toglie finché quello non arriva.
  let wizardOpen = false;
  const cosaStampo = (job) => /^etichett/i.test(job.name) ? "le etichette"
    : /^lista esami/i.test(job.name) ? "la lista esami"
    : /^prenotazione/i.test(job.name) ? "la prenotazione RX"
    : `«${job.name}»`;

  // «6 esami confermati 14:32»: il resoconto che resta sulla pill
  // (per l'ordine in sottofondo senza l'ora: la dice com'è finita la stampa)
  const confermati = (fine) => (fine.n ? `${fine.n} ${fine.n === 1 ? "esame confermato" : "esami confermati"}` : "Richiesta confermata");
  const confermatiTesto = (fine) => `${confermati(fine)} ${hhmm(fine.ts || Date.now())}`;

  // La STAMPA AUTOMATICA. Con l'aiutante di Windows installato (la cartella
  // stampa/ dello zip) e le due stampanti scelte nelle impostazioni, ogni
  // foglio va da solo alla sua: le etichette all'etichettatrice, il resto
  // (liste, prenotazioni, consensi) all'A4. Niente dialogo, e niente davanti:
  // la stampa la fa il service worker, col motore dell'ordine in sottofondo
  // (bg.js, ordStampaFogli: ogni foglio annotato prima di partire, una volta
  // sola), e i PDF glieli dà una scheda sua, aperta dietro sulla pagina del
  // paziente. Il medico può andare dove vuole subito. La striscia dice «Stampo
  // … su …», poi com'è andata: «Stampato su», «Mandato a» (è nella coda di
  // Windows), «Esito sconosciuto» (può essere uscito: mai un secondo foglio da
  // solo), «NON stampate». Solo un foglio che non è partito per un no detto
  // (`motivo`) torna qui, alla scheda col dialogo. Spenta, non configurata,
  // col bookmarklet: la scheda di sempre.
  async function stampaAutomatica() {
    if (!hasExt()) return null;
    try {
      const s = (await chrome.storage.local.get("stampa")).stampa;
      return s && s.attiva !== false && s.etichette && s.a4 ? s : null;
    } catch { return null; }
  }
  // Ogni stampa che il pannello fa parte da qui. `ep`, `paziente`: di chi
  // sono i fogli (la striscia lo dice, anche altrove).
  async function avviaStampa(jobs, opzioni = {}) {
    if (!jobs.length) return;
    if (!jobs.some((j) => j.motivo) && await stampaAutomatica() && await stampaAltrove(jobs, opzioni)) return;
    openPrintWizard(jobs, opzioni);
  }
  // I fogli al service worker. Un no detto (spenta per lui, la scheda dei
  // PDF che non si apre): false, e la scheda col dialogo. Nessuna risposta
  // (tre volte, con lo stesso numero: una stampa sola): non si sa se è
  // partita — mai un dialogo da solo, lo si dice con «Ristampa».
  async function stampaAltrove(jobs, opzioni) {
    const { panel = null, tag = "Stampa", fine = null, title = "" } = opzioni;
    const ep = String(opzioni.ep || "");
    const job = { id: `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`, ep, tag,
      paziente: opzioni.paziente || (tuttiPazienti().find((p) => p.ep === ep) || {}).name || "",
      url: urlPaziente(ep, opzioni.url), fine, riassunto: fine ? confermati(fine) : title.replace(/\.$/, ""),
      quesito: fine ? quesitoDetto(fine.quesito) || "" : "",
      jobs: jobs.map(({ name, printer, url, diretto }) => ({ name, printer, url, ...(diretto ? { diretto: true } : {}) })) };
    let r = { ok: false };
    for (let k = 0; k < 3 && !r.ok && !r.no; k++) r = await ask({ t: "ordineFogli", job });
    if (r.no) return false;
    panel?.log(`${now()}  ${jobs.map((j) => j.name).join(", ")}: alla stampa automatica, senza anteprima${r.ok ? "" : " — il service worker non risponde"}`);
    if (!panel) return true;
    // la striscia è della stampa: si vede (anche dal pannello aperto) e il giro finito lascia il posto
    panel.chiudiGiro();
    if (panel.striscia && !panel.striscia.daOrdine) panel.segnala(null);
    panel.collapsed = true;
    if (r.ok) panel.ordiniAggiorna(r.ordini || panel.ordini);
    else panel.segnala({ tag, testo: "Esito della stampa sconosciuto: controlla la stampante", tono: "warn", paziente: job.paziente,
      azione: { label: "Ristampa", titolo: "Stampa di nuovo, dal dialogo", fn: () => openPrintWizard(jobs, opzioni) } });
    panel.render();
    return true;
  }
  function openPrintWizard(jobs, opzioni = {}) {
    const { title = "", onClose, panel = null, tag = "Stampa", fine = null } = opzioni;
    let ultimaDiag = null;   // l'ultimo visualizzatore non catturato, per «⧉ Diagnosi»
    if (wizardOpen || !jobs.length) return;
    wizardOpen = true;
    // di chi sono i fogli: «ROSSI M. · 68 M», sulla striscia e in testa alla scheda
    const { chi, testata } = (() => {
      const ep = String(opzioni.ep || ""), p = ep ? tuttiPazienti().find((x) => x.ep === ep) : null;
      const nome = opzioni.paziente || p?.name || "", b = nomeBreve(nome);
      const es = [Number.isInteger(p?.eta) ? String(p.eta) : "", p?.sesso || ""].filter(Boolean).join(" ");
      const c = b ? [b, es].filter(Boolean).join(" · ") : "";
      // un titolo che porta già il nome intero lo tiene, con età e sesso accanto
      const t = nome && title.includes(nome) ? title.replace(nome, [nome, es].filter(Boolean).join(" · ")) : [c, title].filter(Boolean).join(" · ");
      return { chi: c, testata: t };
    })();

    const wrap = document.createElement("div");
    wrap.id = "psassist-print";
    const root = wrap.attachShadow({ mode: "open" });
    document.documentElement.appendChild(wrap);

    let i = 0;
    let attempts = 0;
    let blobUrl = null;
    let timer = null;
    let gen = 0;               // il caricamento in corso: uno saltato non deve stampare al posto del dopo
    // Chiudere (✕, Esc) deve fermare davvero la caccia al PDF: senza questo il
    // medico annullava, la catena continuava a chiedere al server, e una
    // seconda stampa poteva partire mentre la prima era ancora in giro.
    // Anche «Avanti» ferma quella del documento che si salta.
    let ctlDoc = null;
    let cur = null;            // il documento in anteprima: { f, printed, apertoIl, avanzato }
    let tuttiChiesti = true;   // ogni documento ha avuto la sua stampa
    let daSola = false;        // si è andati avanti da soli, a dialogo chiuso: stampato o annullato, non si sa
    let chiuso = false;
    let staccaStampa = () => {};   // toglie l'ascolto del dialogo di stampa del documento in corso

    const CSS = `${COLORS}
      .ps[hidden], .back[hidden], .pw[hidden] { display: none; }
      /* mentre il PDF arriva, senza pill: un riquadrino nell'angolo */
      .ps { position: fixed; top: 10px; right: 10px; z-index: 2147483647; display: flex; align-items: center; gap: 8px;
            max-width: min(380px, 82vw); background: #0B5CAD; color: #fff; border-radius: 12px; padding: 7px 8px 7px 11px;
            font-size: 12px; box-shadow: 0 4px 14px rgba(9,42,74,.22); cursor: pointer; }
      .ps .dot { width: 8px; height: 8px; border-radius: 50%; background: #7FD1A8; flex: none; animation: psaPulse 1.2s ease-in-out infinite; }
      .ps .pst { min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .ps .psx { border: 0; background: rgba(255,255,255,.18); color: #fff; border-radius: 999px; width: 24px; height: 24px; cursor: pointer; flex: none; }
      /* arrivato il PDF: la scheda al centro, il PDF in anteprima */
      .back { position: fixed; inset: 0; background: rgba(9,42,74,.45); z-index: 2147483646; }
      .pw { position: fixed; top: 4vh; left: 50%; transform: translateX(-50%); z-index: 2147483647;
            width: min(720px, 94vw); background: #fff; border-radius: 16px; overflow: hidden;
            box-shadow: 0 18px 48px rgba(9,42,74,.4); font-size: 13.5px; color: #16232E;
            display: flex; flex-direction: column; max-height: 92vh; }
      .pwhd { display: flex; align-items: center; flex-wrap: wrap; gap: 6px 10px; padding: 12px 16px; background: #0B5CAD; color: #fff; }
      .pwhd b { font-size: 14.5px; }
      .pwhd .pwtit { font-size: 12px; opacity: .85; }
      .pwhd .dest { margin-left: auto; background: #FFF7E6; color: #8a4b03; border-radius: 999px; padding: 4px 12px; font-weight: 700; font-size: 12.5px; }
      .pwbody { flex: 1; min-height: 320px; background: #E8EEF4; }
      .pwbody iframe { width: 100%; height: 56vh; border: 0; display: block; background: #fff; }
      .pwmsg { padding: 40px 20px; text-align: center; color: #5B6B7A; }
      .pwft { padding: 12px 16px; display: flex; gap: 8px; align-items: center; border-top: 1px solid #E3E8EF; flex-wrap: wrap; }
      .pwbtn { border: 0; border-radius: 10px; padding: 11px 16px; font-weight: 700; font-size: 13.5px; cursor: pointer; }
      .pwbtn:disabled { opacity: .45; cursor: default; }
      .pwbtn.next { background: #177245; color: #fff; }
      .pwbtn.next:hover { background: #125c37; }
      .pwbtn.re { background: #0B5CAD; color: #fff; }
      .pwbtn.re:hover:enabled { background: #094a8c; }
      .pwbtn.ghost { background: #F4F8FB; color: #16232E; border: 1px solid #C4D0DC; }
      .pwbtn.exit { background: transparent; color: #B3261E; border: 1px solid #E9BAB6; margin-left: auto; }
      /* quando la cattura non riesce, l'unica strada che funziona si vede */
      .pwbtn.grande { font-size: 15px; padding: 13px 22px; box-shadow: 0 3px 12px rgba(11,92,173,.35); }
      .pwhint { width: 100%; font-size: 11.5px; color: #5B6B7A; }
      .pwerr { margin: 12px 16px 0; background: #FBEBEA; border: 1px solid #E9BAB6; color: #7c1a14; border-radius: 10px; padding: 10px 12px; font-size: 12.5px; }
      .pwavv { margin: 12px 16px 0; background: #FFF7E6; border: 1px solid #F0D49A; color: #6b3d02; border-radius: 10px; padding: 8px 12px; font-size: 12.5px; }
    `;
    root.innerHTML = `<style>${CSS}</style><div class="ps" role="status" hidden></div><div class="back" hidden></div>
      <div class="pw" role="dialog" aria-label="Stampa documenti" hidden><div class="pwhd"></div><div class="pwguaio"></div><div class="pwbody"></div><div class="pwft"></div></div>`;
    const ps = root.querySelector(".ps"), back = root.querySelector(".back"), pw = root.querySelector(".pw");
    const testa = pw.querySelector(".pwhd"), guaio = pw.querySelector(".pwguaio"), corpo = pw.querySelector(".pwbody"), piede = pw.querySelector(".pwft");

    const conto = () => (jobs.length > 1 ? `${Math.min(i + 1, jobs.length)}/${jobs.length}` : "");
    // La scheda (col velo) si vede o no. Il riquadrino serve solo senza pill,
    // e solo quando la scheda non c'è.
    const vedi = (si) => {
      pw.hidden = back.hidden = !si;
      if (!(panel && panel.collapsed)) ps.hidden = si;
    };
    // A che punto è: nella pill se il pannello è ridotto, altrimenti nel
    // riquadrino. Un tocco lì mostra la scheda; ✕ (o Esc) annulla.
    const stato = (testo, tono = "run") => {
      wrap.dataset.testo = testo;
      if (panel && panel.collapsed) {
        ps.hidden = true;
        panel.segnala({ tag, badge: conto(), testo, tono, daStampa: true, onTap: () => vedi(true), onStop: () => chiudi(false) });
        return;
      }
      ps.hidden = !pw.hidden;
      ps.innerHTML = `<span class="dot"></span><span class="pst"><b>${esc(tag)}${conto() ? " " + esc(conto()) : ""}</b>${chi ? ` · ${esc(chi)}` : ""} · ${esc(testo)}</span><button class="psx" title="Annulla la stampa (Esc)" aria-label="Annulla la stampa">✕</button>`;
      ps.querySelector(".psx").onclick = (e) => { e.stopPropagation(); chiudi(false); };
      ps.onclick = () => vedi(true);
    };
    const nota = (html) => { const h = piede.querySelector(".pwhint"); if (h) h.innerHTML = html; };
    const scegli = () => `Scegli <b>${esc(jobs[i].printer)}</b> nel dialogo di stampa.`;

    // Testata e comandi della scheda: quale documento, su quale stampante, e
    // i bottoni di sempre. Un verbo per pulsante, un'icona per verbo (prima ce
    // n'erano cinque, e «Avanti» e «Salta» facevano la stessa cosa). Il corpo
    // — l'anteprima — non si tocca: rimettere la cornice la ricaricherebbe.
    // `avviso`: una riga che dice perché questo documento passa dal dialogo
    // (la stampa automatica non ci è riuscita).
    const comandi = ({ err = "", viewer = false, avviso = "" } = {}) => {
      const job = jobs[i];
      const nextLbl = i + 1 < jobs.length ? `→ Avanti (${i + 2} di ${jobs.length})` : "✓ Fine";
      testa.innerHTML = `<b>Stampa ${i + 1} di ${jobs.length} — ${esc(job.name)}</b>${testata ? `<span class="pwtit">${esc(testata)}</span>` : ""}<span class="dest">→ ${esc(job.printer)}</span>`;
      guaio.innerHTML = err ? `<div class="pwerr">${esc(err)}</div>` : avviso ? `<div class="pwavv">${esc(avviso)}</div>` : "";
      piede.innerHTML = `
        ${viewer
          ? `<button class="pwbtn re grande" id="pwtab" title="Apre il documento in una scheda: da lì Ctrl+P">↗&nbsp; Apri e stampa</button>`
          : `<button class="pwbtn re" id="pwre" title="Riapre la finestra di stampa del browser" ${cur ? "" : "disabled"}>🖨&nbsp; Stampa</button>`}
        <button class="pwbtn next" id="pwnext" title="${i + 1 < jobs.length ? "Passa al documento successivo" : "Chiude: hai stampato tutto"}">${nextLbl}</button>
        ${viewer ? "" : `<button class="pwbtn ghost" id="pwtab" title="Se la stampa non parte, aprilo in una scheda">↗&nbsp; Scheda</button>`}
        ${viewer && ultimaDiag ? `<button class="pwbtn ghost" id="pwdiag" title="Copia com'è fatto il visualizzatore (senza numeri), da mandare a chi fa il pannello">⧉&nbsp; Diagnosi</button>` : ""}
        <button class="pwbtn exit" id="pwexit" title="Chiude senza stampare il resto (Esc)">✕&nbsp; Chiudi</button>
        <div class="pwhint">${viewer
          ? `Questo documento non si lascia stampare da qui: <b>↗ Apri e stampa</b>, poi Ctrl+P → <b>${esc(job.printer)}</b>, e qui «→ Avanti».`
          : err ? "" : scegli()}</div>`;
      piede.querySelector("#pwre")?.addEventListener("click", () => { if (cur && cur.f.isConnected) stampa(cur); });
      piede.querySelector("#pwnext").onclick = advance;
      piede.querySelector("#pwexit").onclick = () => chiudi(false);
      piede.querySelector("#pwtab").onclick = () => openTab(job.url, "_blank"); // user-activated → not popup-blocked
      piede.querySelector("#pwdiag")?.addEventListener("click", async () => {
        const b = piede.querySelector("#pwdiag");
        segnaCopia(b, await copiaTesto(diagnosiTesto(ultimaDiag)));
      });
    };

    const chiudi = (finito) => {
      if (chiuso) return;
      chiuso = true;
      wizardOpen = false;
      ctlDoc?.abort();
      staccaStampa();
      clearTimeout(timer);
      if (blobUrl) URL.revokeObjectURL(blobUrl);
      window.removeEventListener("keydown", onKey, true);
      wrap.remove();
      if (panel) {
        const tutto = finito && tuttiChiesti;
        // «Stampato» solo se lo si sa: il medico è andato avanti lui,
        // documento per documento. Chiuso il dialogo il browser non dice se
        // ha stampato o annullato, e allora è «Stampa finita», con «Ristampa».
        const certo = tutto && !daSola;
        if (fine) {
          // Una richiesta confermata: la pill ne resta il resoconto finché non
          // fai altro — quanti esami, a che ora — e se i fogli non sono usciti
          // tutti (annullato, saltato, non scaricato), «Ristampa» li rifà
          // (con la stampa automatica, senza dialogo: un foglio che non era
          // partito ci riprova).
          panel.segnala({ tag: !tutto ? "Stampa non finita" : certo ? "Stampato" : "Stampa finita",
            testo: confermatiTesto(fine), tono: "ok", quesito: quesitoDetto(fine.quesito),
            azione: certo ? null : { label: "Ristampa", titolo: "Stampa di nuovo etichette e lista esami",
              fn: () => avviaStampa(jobs.map(({ motivo, ...j }) => j), opzioni) } });
        } else if (finito && panel.collapsed) {
          // una stampa chiesta a mano: la pill lo dice per qualche secondo
          panel.segnala({ tag, testo: certo ? "✓ Stampato" : "✓ Stampa finita", tono: "ok" }, { ms: 4000, poi: () => panel.chiudiGiro() });
        } else if (panel.striscia && panel.striscia.daStampa) panel.segnala(null);
      }
      onClose?.();
    };
    const onKey = (e) => { if (e.key === "Escape") { e.stopPropagation(); chiudi(false); } };
    window.addEventListener("keydown", onKey, true);

    // Il dialogo non si è aperto (o si è chiuso all'istante: stampa non
    // disponibile su quel PC): non si salta niente, «🖨 Stampa» lo riapre.
    const nonParte = () => {
      wrap.dataset.stato = "mano";
      nota(`La finestra di stampa non si è aperta? <b>🖨 Stampa</b> la riapre — scegli <b>${esc(jobs[i].printer)}</b>.`);
      stato("Stampa: serve un tuo clic", "warn");
    };
    // La stampa del documento in anteprima: il dialogo del browser, dalla sua
    // cornice.
    const stampa = (c) => {
      c.printed = true;
      c.apertoIl = Date.now();
      attempts++;
      wrap.dataset.printAttempts = String(attempts);
      wrap.dataset.stato = "stampo";
      nota(scegli());
      stato(`Stampo ${cosaStampo(jobs[i])}`);
      try { c.f.contentWindow.print(); }
      catch { nonParte(); return; }
      guardaDialogo(c);
    };
    // Il PDF lo stampa il visore di Chrome, e quel visore «afterprint» non lo
    // manda né alla cornice né alla pagina: in Chrome vero si restava ad
    // aspettare «→ Avanti». Il dialogo di stampa però, finché è aperto, si
    // prende il fuoco: fuoco perso dopo la stampa = dialogo aperto, fuoco
    // tornato = dialogo chiuso, e si va avanti da soli. Solo se il fuoco c'era
    // quando è partita la stampa: altrimenti un dialogo non si distingue da
    // un'altra finestra, e resta «→ Avanti» (o l'afterprint, dove arriva).
    const guardaDialogo = (c) => {
      clearInterval(c.vigile);
      if (!document.hasFocus()) return;
      let aperto = false;
      c.vigile = setInterval(() => {
        if (cur !== c || c.avanzato || !c.f.isConnected) { clearInterval(c.vigile); return; }
        if (!document.hasFocus()) aperto = true;
        else if (aperto) { clearInterval(c.vigile); c.dopo?.(); }
      }, 250);
    };

    const advance = () => {
      clearTimeout(timer);
      staccaStampa();
      if (!cur || !cur.printed) tuttiChiesti = false;
      cur = null;
      ctlDoc?.abort();
      if (blobUrl) { URL.revokeObjectURL(blobUrl); blobUrl = null; }
      i++;
      if (i >= jobs.length) return chiudi(true);
      load();
    };

    const load = async () => {
      const mio = ++gen;
      const job = jobs[i];
      cur = null;
      ctlDoc = new AbortController();
      const segnale = ctlDoc.signal;
      // quello che si sta stampando, leggibile da fuori (i test)
      wrap.dataset.doc = `Stampa ${i + 1} di ${jobs.length} — ${job.name}`;
      wrap.dataset.printer = job.printer;
      wrap.dataset.stato = "carico";
      // Mentre arriva il PDF, niente davanti: la scheda si toglie (via anche
      // l'anteprima di prima) e la si vede solo chiedendola con un tocco.
      vedi(false);
      corpo.innerHTML = `<div class="pwmsg">Carico il PDF…</div>`;
      comandi();
      stato(`Aspetto ${cosaStampo(job)}…`);
      try {
        // un modulo di consenso è un file dell'estensione, non una pagina del
        // gestionale: si prende così com'è, senza la catena same-origin
        const { blob, via } = job.diretto
          ? { blob: await (await fetch(job.url, { signal: segnale })).blob(), via: "estensione" }
          : await fetchPdf(job.url, { signal: segnale });
        if (mio !== gen || chiuso) return;
        panel?.log(`${now()}  ${job.name}: PDF ottenuto${via ? " via " + via : ""}`);
        blobUrl = URL.createObjectURL(blob);
        const f = document.createElement("iframe");
        f.title = `Anteprima — ${job.name}`;
        const c = cur = { f, printed: false, apertoIl: 0, avanzato: false, vigile: 0, dopo: null };
        // Chiuso il dialogo di stampa si passa al documento dopo da soli: è
        // quello che il medico farebbe premendo «→ Avanti», e con
        // l'etichettatrice davanti non ha una mano libera. Il browser non dice
        // se ha stampato o annullato — dice solo che il dialogo si è chiuso —
        // quindi si va avanti in tutt'e due i casi, una volta sola per
        // documento. Un dialogo che si chiude PRIMA di essersi aperto davvero
        // (stampa non disponibile) non fa saltare niente: lo dice la scheda.
        const dopoStampa = () => {
          if (c.avanzato || cur !== c || !f.isConnected || !c.printed) return;
          if (Date.now() - c.apertoIl < 500) { nonParte(); return; }
          c.avanzato = true; daSola = true;
          staccaStampa();
          panel?.log(`${now()}  ${job.name}: finestra di stampa chiusa, passo al documento dopo`);
          clearTimeout(timer);
          timer = setTimeout(advance, 300);
        };
        c.dopo = dopoStampa;
        staccaStampa();   // resti del documento precedente
        window.addEventListener("afterprint", dopoStampa);
        staccaStampa = () => {
          clearInterval(c.vigile);
          window.removeEventListener("afterprint", dopoStampa);
          try { f.contentWindow?.removeEventListener("afterprint", dopoStampa); } catch { /* cornice già andata */ }
        };
        // il cronometro va SEMPRE dentro `timer`, e la stampa parte solo se
        // quella cornice è ancora quella in anteprima: «Avanti» ne lasciava
        // uno orfano, che stampava il documento dopo al posto di questo
        const once = () => { if (!c.printed && cur === c && f.isConnected) stampa(c); };
        f.addEventListener("load", () => {
          try { f.contentWindow?.addEventListener("afterprint", dopoStampa); } catch { /* cornice già andata */ }
          clearTimeout(timer); timer = setTimeout(once, 350);
        });
        timer = setTimeout(once, 1500); // headless/viewer-less fallback
        f.src = blobUrl;      // prima di inserirla: un solo «load», quello del PDF
        corpo.replaceChildren(f);
        // («🖨 Stampa» adesso ha un documento; un foglio che la stampa
        // automatica non ha fatto uscire dice perché passa dal dialogo)
        comandi(job.motivo ? { avviso: `Stampa automatica non riuscita: ${job.motivo}. Dal dialogo, stavolta.` } : {});
        wrap.dataset.stato = "pronto";
        vedi(true);
        stato(`Stampo ${cosaStampo(job)}`);
      } catch (e) {
        if (e?.name === "AbortError" || mio !== gen || chiuso) return;
        // This endpoint is a viewer we can't safely turn into a Blob. Don't
        // auto-open (a popup after the async fetch is blocked for lack of user
        // activation) — offer a big button the doctor clicks, which carries
        // activation and always opens the tab. The sequence still advances.
        // Non tutto quello che fallisce è «un visualizzatore»: una sessione
        // scaduta, un HTTP 500 o una risposta fuori dall'ospedale finivano
        // sotto quella scritta, e «Apri e stampa» apriva la pagina di login.
        const suo = e instanceof ViewerError;
        if (suo && e.html) {
          ultimaDiag = { cosa: `stampa ${job.name}`, url: job.url, html: e.html, diag: e.diag, quando: now() };
          if (panel) panel.diagnosi = ultimaDiag;
        }
        panel?.log(`${now()}  ${job.name}: PDF non catturato — ${suo ? `visualizzatore${e.diag ? " [" + e.diag + "]" : ""}` : `${e?.head || e?.message || e}`}`);
        corpo.innerHTML = suo
          ? `<div class="pwmsg">Premi <b>↗ Apri e stampa</b> qui sotto, poi <b>Ctrl+P → ${esc(job.printer)}</b>,<br>torna qui e premi «→ Avanti».</div>`
          : `<div class="pwmsg">Questo documento non è stato scaricato. Risolvi il problema qui sopra e riprova la stampa dal pannello.</div>`;
        comandi({
          viewer: suo,
          err: suo ? `Questo documento non si lascia catturare (è un visualizzatore).${e?.diag ? " [" + e.diag + "]" : ""}`
            : `${e?.head || "Non riuscito"}${e?.body ? " — " + e.body : ""}`,
        });
        wrap.dataset.stato = "mano";
        vedi(true);
        stato(suo ? "Apri e stampa: serve un tuo clic" : "Documento non scaricato", "warn");
      }
    };

    load();
  }

  // Le richieste di PS Assist: quelle su cui il motore ha lavorato in questa
  // scheda (NOSTRE), quelle in cui ha mandato esami (daConfermare, in ogni
  // scheda), quella della sua ricevuta. Una richiesta fatta tutta a mano nel
  // gestionale non è fra queste: confermata col suo bottone, non stampa niente da sola.
  const NOSTRE = "richieste.nostre.v1";
  const segnaNostra = (rid) => { if (rid) tabStore.set(NOSTRE, [...(tabStore.get(NOSTRE, []) || []).filter((x) => x !== String(rid)), String(rid)].slice(-20)); };
  const richiestaNostra = (rid) => !!rid && ((tabStore.get(NOSTRE, []) || []).includes(String(rid))
    || daConfermare().some((x) => x.rid === String(rid)) || String(tabStore.get("receipt.v1", null)?.richiestaId || "") === String(rid));

  // Post-confirm print handoff: armed when the native Conferma button is
  // clicked (both by the doctor and by the auto-confirm countdown) on a
  // richiesta of PS Assist, consumed by the first subsequent page that lists
  // this richiesta's print links — the post-confirm page if it has them,
  // otherwise the patient page.
  function armPrintOnConfirm(model, episodeId) {
    if (!model.form || !model.richiestaId) return;
    const arm = () => {
      if (!richiestaNostra(model.richiestaId)) return;
      const q = tabStore.get("queue.v1", null);
      if (q && q.items) { // this richiesta is done: drop it from the walk
        const left = q.items.filter((it) => it.rid !== model.richiestaId);
        tabStore.set("queue.v1", left.length ? { ...q, items: left, ts: Date.now() } : null);
      }
      const prev = tabStore.get("print.v1", null);
      const fresco = prev && prev.episodeId === episodeId && Date.now() - (prev.ts || 0) < PRINT_FLAG_TTL;
      const ids = [...new Set([...(fresco ? prev.ids || [] : []), model.richiestaId])]; // lab + radiology land in ONE flow
      // quanti esami: lo sa la ricevuta di questa richiesta; senza, il conto non si inventa
      const rc = tabStore.get("receipt.v1", null);
      const n = { ...(fresco ? prev.n || {} : {}) };
      // …e quale quesito è partito: lo ripete il resoconto finale
      const qs = { ...(fresco ? prev.q || {} : {}) };
      if (rc && rc.richiestaId === model.richiestaId && Array.isArray(rc.items)) {
        n[model.richiestaId] = rc.items.length;
        if (rc.quesito) qs[model.richiestaId] = rc.quesito;
      }
      tabStore.set("print.v1", { ids, episodeId, ts: Date.now(), n, q: qs });
    };
    for (const name of ["Update", "Update1"]) {
      const b = model.form.elements.namedItem(name);
      if (b && (b.type || "").toLowerCase() === "submit") b.addEventListener("click", arm, true);
    }
  }

  // After confirming one richiesta of a lab+radiology pair, the server drops us
  // on the patient page: carry on to the one still to confirm.
  function nextQueued(episodeId) {
    const q = tabStore.get("queue.v1", null);
    if (!q || !q.items || !q.items.length) return null;
    if (Date.now() - (q.ts || 0) > QUEUE_TTL) { tabStore.set("queue.v1", null); return null; }
    if (!episodeId || (q.episodeId && q.episodeId !== episodeId)) return null; // fail closed
    return { q, next: q.items[0] };
  }

  function goToQueued(entry, vai = nav) {
    const { q, next } = entry;
    tabStore.set("receipt.v1", { richiestaId: next.rid, episodeId: q.episodeId, ts: Date.now(), items: next.added || [], carrelli: next.carrelli || {}, quesito: next.quesito || null });
    if (q.autoConfirm && next.lastCode && next.kind !== "radio") {
      tabStore.set("confirm.v1", { richiestaId: next.rid, episodeId: q.episodeId, lastCode: next.lastCode, lastLabel: next.lastLabel, count: next.count, ts: Date.now() });
    }
    tabStore.set("queue.v1", { ...q, items: q.items.map((it, i) => (i ? it : { ...it, nav: true })), ts: Date.now() });
    vai(next.listUrl);
  }

  function maybeAutoPrint(panel, doc = document, url = location.href) {
    const flag = tabStore.get("print.v1", null);
    if (!flag) return false;
    // never print for an episode other than the page in front of the user
    const here = findEpisodeId(doc, url);
    if (!here || (flag.episodeId && flag.episodeId !== here)) return false;
    if (Date.now() - (flag.ts || 0) > PRINT_FLAG_TTL) { tabStore.set("print.v1", null); return false; }
    const map = printModel(doc, url);
    const ids = (flag.ids || [flag.richiestaId]).filter((id) => map[id]);
    if (!ids.length) return false; // this page doesn't list them yet — keep waiting
    // group by printer ACROSS the confirmed richieste: labels, then lists,
    // then radiology bookings — one uninterrupted flow
    const jobs = fogliDi(map, ids);
    ids.forEach(confermataProvata);   // in pagina coi suoi fogli: confermata, non c'è più da sorvegliarla
    if (!jobs.length) return false;
    // il resoconto che resta sulla pill: quanti esami, e quando
    const conti = ids.map((id) => (flag.n || {})[id]);
    const fine = { n: conti.every((x) => x > 0) ? conti.reduce((a, b) => a + b, 0) : 0, ts: flag.ts || Date.now(),
      quesito: ids.map((id) => (flag.q || {})[id]).find(Boolean) || null };
    // La scheda di un ordine non apre il dialogo di stampa: lì non c'è
    // nessuno. Le etichette si stampano dove sta il medico — le consegna il
    // service worker, a una scheda sola (gli indirizzi sono quelli letti da
    // questa pagina) — o, con la stampa automatica, le stampa lui (vedi
    // consegnaFogli). Solo quelle della richiesta dell'ordine, per il suo
    // paziente: una conferma fatta qui a mano per un altro paziente si stampa
    // qui, come sempre (con la stampa automatica, anche lei dal service worker).
    if (LAVORO && String(flag.episodeId || here) === String(LAVORO.ep)) {
      tabStore.set("print.v1", null);
      if (panel) panel._lavoroChiuso = true;   // da qui la scheda non racconta più niente: l'ordine è delle etichette
      consegnaFogli(panel, LAVORO.id, jobs, fine);
      panel?.segnala({ tag: "Confermata", testo: "Etichette pronte: si stampano dove sei", tono: "ok" });
      return true;
    }
    if (wizardOpen) return false;   // keep the flag: these jobs must not vanish behind another wizard
    tabStore.set("print.v1", null);
    avviaStampa(jobs, { panel, tag: "Confermata", fine, title: ids.length > 1 ? `${ids.length} richieste appena confermate.` : "Richiesta appena confermata.",
      ep: flag.episodeId || here, paziente: panel?.nomePaziente(), url });
    return true;
  }

  // I fogli di un ordine fatto in sottofondo, appena la conferma è provata: i
  // link letti da questa pagina vanno al service worker, che da lì tiene il
  // conto foglio per foglio. Con la stampa automatica li stampa lui, senza
  // dialogo e senza nessuno davanti — il medico può essere altrove, anche
  // lontano (l'ordine arriva dal telefono) —, chiedendo i PDF a questa scheda
  // (psassistPdf); se no li consegna alla scheda dove sta il medico. Una volta
  // sola: il segno della stampa è già consumato.
  async function consegnaFogli(panel, id, jobs, fine) {
    const m = { t: "ordineStampa", id, fine, riassunto: confermati(fine), quesito: quesitoDetto(fine.quesito), registro: registroLavoro(panel),
      jobs: jobs.map(({ name, printer, url }) => ({ name, printer, url })) };
    let r = await ask(m);
    if (r.perso) r = await ask(m);   // il service worker che si sveglia può perdere la prima (la seconda è la stessa)
    if (r && r.ok) return panel?.slegaLavoro();
    // il service worker non li vuole (ordine sparito): si stampano da qui, come sempre
    panel?.log(`${now()}  consegna delle etichette non riuscita: le stampo da questa scheda`);
    if (!wizardOpen) avviaStampa(jobs, { panel, tag: "Confermata", fine, title: "Richiesta appena confermata.", ep: LAVORO && LAVORO.ep, url: LAVORO && LAVORO.url });
  }

  // Le ultime righe del Registro della scheda di un ordine: viaggiano con la
  // sua ultima parola, perché la scheda si chiude e il perché di com'è
  // andata deve restare al medico (lo aggiunge al suo Registro: registriOrdini).
  function registroLavoro(panel) {
    const l = panel ? panel.logLines : (tabStore.get("log." + (LAVORO && LAVORO.ep || "x"), null) || {}).lines;
    // (questa scheda, se resta aperta, non se lo riaggiunge)
    if (LAVORO) tabStore.set(REGISTRI, [...(tabStore.get(REGISTRI, []) || []), String(LAVORO.id)].slice(-30));
    return (Array.isArray(l) ? l : []).slice(-40).map((s) => String(s).slice(0, 240));
  }
  const REGISTRI = "registriOrdini.v1";   // gli ordini il cui Registro questa scheda ha già aggiunto al suo
  // la richiesta dell'ordine, e se la sua Conferma è già partita da questa scheda
  const ridLavoro = () => String((LAVORO && LAVORO.rid) || (tabStore.get("receipt.v1", null) || {}).richiestaId || "");
  function confermaPartita() {
    const rid = ridLavoro(), pr = tabStore.get("print.v1", null);
    return !!rid && !!pr && (pr.ids || []).map(String).includes(rid);
  }
  // La scheda di un ordine che si ritrova senza niente da fare — ricaricata
  // (dal gestionale, o da un clic del medico), o finita su una pagina che non
  // è il carrello — quando l'ordine non ha ancora detto com'è andata: niente
  // da riprendere, nessuna conferma armata. Non resta «in corso» per sempre
  // (la coda aspetterebbe con lei): se la Conferma era partita da qui se ne
  // cerca la prova — solo letture —, se no si dice di controllare il
  // carrello. E l'ordine finisce.
  async function lavoroSenzaSeguito(panel) {
    if (!LAVORO || (panel && panel._lavoroChiuso)) return;
    const L = LAVORO, ep = String(L.ep || ""), rid = ridLavoro();
    const listUrl = [(daConfermare().find((x) => x.rid === rid) || {}).listUrl, L.listUrl].find(leggibilePagina) || "";
    const fine = (vista, striscia = null) => {
      const consegna = listUrl && striscia ? { url: listUrl, avviso: { striscia: { paziente: L.paziente || "", ...striscia } }, receipt: tabStore.get("receipt.v1", null) } : null;
      if (panel) return panel.consegnaLavoro(vista, consegna);
      // (una pagina senza pannello: l'ultima parola la dice da qui)
      const m = { t: "ordineAggiorna", id: L.id, stato: "avviso", vista, ...(consegna ? { consegna } : {}), registro: registroLavoro(null) };
      LAVORO = null;
      return ask(m).then((r) => (r.perso ? ask(m) : r));
    };
    if (confermaPartita()) {
      const prova = await provaConferma(rid, ep, { patientUrl: (L.piano && L.piano.patientUrl) || "", panel });
      if (LAVORO !== L || (panel && panel._lavoroChiuso)) return;
      if (prova && maybeAutoPrint(panel, prova.doc, prova.url)) return;
      if (prova) return fine({ tag: "Confermata", testo: "etichette dalla sua pagina, Stampa", tono: "ok" });
      return fine({ tag: "Non confermata", testo: "controlla il carrello e premi tu Conferma", tono: "warn" },
        { tag: "Non confermata", testo: "Controlla il carrello e premi tu Conferma", tono: "warn" });
    }
    panel?.log(`${now()}  la scheda dell'ordine è ripartita a giro finito: niente da riprendere, la conferma non è partita`);
    return fine({ tag: "Da controllare", testo: listUrl ? "apri il carrello e controlla" : "controlla le sue richieste", tono: "warn" },
      { tag: "Da controllare", testo: "Controlla il carrello e premi tu Conferma", tono: "warn" });
  }

  // Le etichette di un ordine fatto in sottofondo arrivano qui, dalla scheda
  // dell'ordine attraverso il service worker: i link sono quelli che quella
  // scheda ha letto dalla pagina del gestionale (mai costruiti), e la stampa è
  // quella di sempre. Una volta sola: lo stesso ordine non si stampa due volte,
  // nemmeno da due schede (il segno sta nella memoria condivisa). Da sola,
  // non sopra chi scrive e non sulla pagina di un altro paziente: lì si dice
  // di no, la striscia dice di chi sono, e un tocco («Stampa», `forza`) le stampa.
  function stampaOrdine(panel, m) {
    if (document.visibilityState === "hidden") return { ok: false, why: "nascosta" };
    const fatti = store.get("ordini.stampati", []);
    const giaFatti = Array.isArray(fatti) ? fatti : [];
    if (giaFatti.includes(m.id)) return { ok: true, gia: true };
    if (wizardOpen) return { ok: false, why: "occupata" };
    if (!m.forza) {
      if (staScrivendo(true)) return { ok: false, why: "scrive" };
      const qui = panel ? panel.epDiQuesta() : findEpisodeId(document, location.href);
      if (qui && qui !== String(m.ep || "")) return { ok: false, why: "altro paziente" };
    }
    const st = m.stampa || {};
    // (un consenso è un file dell'estensione: solo quelli)
    const nostro = (j) => !!j.diretto && String(j.url).startsWith(chrome.runtime.getURL("consensi/"));
    const jobs = (Array.isArray(st.jobs) ? st.jobs : []).filter((j) => {
      try { return j && typeof j.name === "string" && (nostro(j) || new URL(j.url, location.href).origin === location.origin); } catch { return false; }
    }).map((j) => ({ name: j.name, printer: j.printer || "stampante normale", url: nostro(j) ? j.url : new URL(j.url, location.href).href,
      ...(nostro(j) ? { diretto: true } : {}),
      ...(j.motivo ? { motivo: String(j.motivo).slice(0, 160) } : {}) }));   // (la stampa automatica non ci è riuscita: si dice perché)
    if (!jobs.length) return { ok: false, why: "niente da stampare" };
    store.set("ordini.stampati", [...giaFatti, String(m.id)].slice(-30));
    const nome = String(m.paziente || "").slice(0, 60);
    // Si può essere sulla pagina di un altro paziente: la striscia della
    // stampa porta il nome di chi sono le etichette, e la scheda lo scrive.
    const conNome = panel ? new Proxy(panel, {
      get(t, k) {
        if (k === "segnala") return (s, o) => t.segnala(s ? { paziente: nome, ...s } : s, o);
        const v = t[k];
        return typeof v === "function" ? v.bind(t) : v;
      },
      set(t, k, v) { t[k] = v; return true; },
    }) : null;
    panel?.log(`${now()}  etichette dell'ordine per ${nome || "un paziente"}: le stampo qui`);
    // (con la stampa automatica, «Ristampa» non apre niente qui: li rifà il service worker)
    const tag = st.tag || "Confermata";
    avviaStampa(jobs, { panel: conNome, tag, fine: st.fine || null, ep: m.ep, paziente: nome,
      title: `${nome ? nome + " · " : ""}${tag === "Confermata" ? "richiesta appena confermata." : st.riassunto || ""}` });
    return { ok: true };
  }
  // Un foglio che il service worker sta stampando: il PDF, preso da qui come
  // sempre (solo da questa origine). Ogni scheda del gestionale risponde, da
  // subito — prima ancora di sapere chi è: la scheda aperta apposta per dare i
  // PDF di una stampa (ordineFogli) riceve la prima domanda appena l'ha detto.
  function ascoltaPdf() {
    try {
      chrome.runtime.onMessage.addListener((m, _s, reply) => {
        if (!m || m.t !== "psassistPdf") return;
        (async () => {
          const u = new URL(String(m.url || ""), location.href);
          if (u.origin !== location.origin) throw new Error("fuori dal gestionale");
          const { blob } = await fetchPdf(u.href, {});
          return { ok: true, pdf: bufB64(await blob.arrayBuffer()) };
        })().catch((e) => ({ ok: false, why: String(e?.head || e?.message || e).slice(0, 120) })).then(reply);
        return true;
      });
    } catch { /* niente estensione */ }
  }
  // Una scheda del gestionale ascolta gli ordini in sottofondo: le etichette
  // da stampare, e — se è la scheda di un ordine — ⏹ e «ci sei?». Lo stato
  // degli ordini arriva da storage.session (onChanged) e, ogni pochi secondi
  // finché un ordine gira o aspetta la stampa, da una domanda al service
  // worker: è anche lì che si accorge di una scheda chiusa o ferma.
  function ascoltaOrdini(panel) {
    try {
      chrome.runtime.onMessage.addListener((m, _s, reply) => {
        if (!m || typeof m !== "object") return;
        if (m.t === "psassistStampa") { reply(stampaOrdine(panel, m)); return; }
        if (!panel || !LAVORO || m.id !== LAVORO.id) return;
        if (m.t === "psassistVivo") { reply({ ok: true }); return; }
        if (m.t === "psassistFerma") reply({ ok: panel.fermaLavoro() });
      });
      if (panel) {
        chrome.storage.onChanged.addListener((ch, area) => {
          if (area === "session" && ch.ordini) panel.ordiniAggiorna(ch.ordini.newValue || []);
        });
      }
    } catch { /* niente estensione */ }
    if (!panel) return;
    setInterval(() => {
      if (!LAVORO && !panel.ordini.some((x) => ORDINE_APERTO.has(x.stato))) return;
      ask({ t: "ordineControlla" }).then((r) => { if (r && r.ok && Array.isArray(r.ordini)) panel.ordiniAggiorna(r.ordini); });
    }, 4000);
  }

  // =================================================================== PONTE
  // Il pannello sull'iPhone (ps-app/ponte/README.md). La presa cifrata sta
  // nel service worker (ponte-sw.js); qui, in una scheda del gestionale, si
  // eseguono i comandi del telefono col codice di sempre — elenco, esiti,
  // ordine, nota, promemoria — e ogni scheda dice, nell'intestazione, che una
  // sessione è aperta. Niente qui manda dati fuori dall'ospedale: le risposte
  // vanno al service worker, che le cifra per il telefono.
  let PANNELLO = null;       // il pannello di questa pagina (per il Registro)
  let PONTE_STATO = null;    // lo stato del ponte (storage.session), per l'intestazione
  let PONTE_VALORI = null;   // questa scheda l'ha aperta il ponte per «Aggiorna i valori» di { ep }
  const ICO_TEL = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" aria-hidden="true"><rect x="4.4" y="1.4" width="7.2" height="13.2" rx="1.7"/><path d="M7 12.1h2"/></svg>';
  const PONTE_CSS = `
    .pontespia { display: inline-flex; align-items: center; gap: 7px; margin-top: 6px; padding: 4px 4px 4px 11px; border-radius: 999px;
                 background: #16232E; color: #fff; font-size: 12px; font-weight: 700; white-space: nowrap; box-shadow: 0 4px 14px rgba(9,42,74,.28); }
    .wrap:not(.win) > .pontespia { display: flex; width: max-content; margin-left: auto; }
    .hd .pontespia { margin: 0; box-shadow: none; }
    .pontespia .pdot { width: 8px; height: 8px; border-radius: 50%; background: #7FD1A8; animation: psaPulse 1.6s ease-in-out infinite; }
    .pontespia button { border: 0; border-radius: 999px; background: #fff; color: #16232E; padding: 4px 10px; font: inherit; font-size: 11.5px; font-weight: 700; cursor: pointer; }
    .pontespia button:hover { background: #E3E9F0; }
    .menu button .mico { display: inline-flex; vertical-align: -2px; margin-right: 6px; }
  `;
  // «iPhone collegato · Scollega»: finché una sessione è aperta, in ogni
  // scheda, a pannello aperto o ridotto. Chi passa davanti al PC lo vede.
  const ponteSpia = () => (PONTE_STATO && PONTE_STATO.sessione ? `<div class="pontespia" role="status" title="Il medico sta usando il pannello dall'iPhone: ogni comando finisce nel Registro">
      <span class="pdot"></span>${ICO_TEL}<span>iPhone collegato</span><button type="button" id="ponteoff" title="Chiude la sessione dell'iPhone">Scollega</button></div>` : "");

  const pontePaziente = (ep) => tuttiPazienti().find((p) => p.ep === ep) || null;
  // l'indirizzo della sua pagina, come il gestionale l'ha dato: solo da leggere, e di quell'episodio
  const ponteUrlPaziente = (p) => (p && leggibilePagina(p.url) && param(p.url, "EPISODIO_ID") === p.ep
    && /\/menuPsoEpisodio\.do$/i.test(new URL(p.url).pathname) ? p.url : "");
  // L'elenco, come la vista Pazienti: chi è in lista e chi è nella stanza (col
  // suo posto), il triage, la nota e i promemoria — cioè «Da fare»: la nota è
  // la prima voce aperta senza ora, i promemoria quelle con l'ora (il telefono
  // non ha la lista intera) —; gli episodi precedenti in fondo.
  function pontePazienti() {
    const m = PANNELLO.pazModello();
    return [...m.info.values()].map((i) => ({
      // (due con lo stesso nome: il nome porta il segno che li distingue, «· …9001», anche nella conferma)
      ep: i.p.ep, nome: i.lungo + i.coda, breve: i.breve + i.coda, omonimo: !!i.omonimo, triage: i.p.triage || "",
      posto: PANNELLO.nomePosto(m, i), nota: dfNota(i.p.ep, m.df)?.testo || "", prec: !!i.prec, spento: !!i.spento, visto: i.p.ts || 0,
      eta: Number.isInteger(i.p.eta) ? i.p.eta : String(i.p.pk || "").startsWith("cf:") ? etaDaCf(i.p.pk.slice(3)) : null,
      prom: promDi(i.p.ep, m.prom).map((x) => ({ id: x.id, t: x.t, testo: x.testo })),
      ordina: !!ponteUrlPaziente(i.p) && !i.prec,
    }));
  }
  // Quello che serve al telefono per ordinare: i quesiti (prima i tre
  // pacchetti, con quanti esami portano su questo computer), i profili e gli
  // esami della griglia, per laboratorio. Gli stessi filtri del pannello: un
  // esame che questo catalogo non ha non compare.
  function ponteCatalogo() {
    const cat = fullCatalog();
    const c = (r, k) => !!cat[r]?.items?.[k];
    const nomi = {}, rx = [];
    const chiave = (r, k) => { const x = `${r}:${k}`; nomi[x] = displayLabel(r, k); if (RADIO_SET.includes(r)) rx.push(x); return x; };
    const gruppi = [];
    const gruppo = (r) => {
      const nome = RES_SHORT[r] || r;
      let g = gruppi.find((x) => x.nome === nome);
      if (!g) gruppi.push(g = { nome, rx: RADIO_SET.includes(r), profili: [], esami: [] });
      return g;
    };
    for (const p of PRESETS) if (p.items.every(([r, k]) => c(r, k))) gruppo(p.items[0][0]).profili.push({ nome: p.name, esami: p.items.map(([r, k]) => chiave(r, k)) });
    for (const [r, k] of SINGLES) if (c(r, k)) gruppo(r).esami.push(chiave(r, k));
    const pacchetti = PACCHETTI.map((p) => ({ q: p.q, esami: p.items.filter(([r, k]) => c(r, k)).map(([r, k]) => chiave(r, k)) }));
    const quesiti = [...PACCHETTI.map((p) => p.q), ...store.get("quesiti", QUESITI_DEFAULT)
      .filter((q) => !PACCHETTI.some((p) => p.q.toLowerCase() === String(q).toLowerCase()))].slice(0, 6);
    return { quesiti, pacchetti, gruppi, nomi, rx: [...new Set(rx)] };
  }
  // La tabella dei Valori, in dati: colonne (il prelievo più recente a
  // sinistra, l'ora se è di oggi, se no la data) e righe per sezione, coi
  // nomi e le unità del pannello. Un valore: [testo, fuori range ±1, parziale, %].
  function ponteTabella(st) {
    const col = st.date.map((d, i) => ({ ...d, i })).reverse();
    const righe = righeTabella(st.righe);
    const ambS = sigleAmbigue(righe);
    const inatteso = (r) => !siglaCurata(r.nome) || ambS.has(chiaveAmbigua(r));
    const d0 = new Date();
    const oggi = `${String(d0.getDate()).padStart(2, "0")}/${String(d0.getMonth() + 1).padStart(2, "0")}/${d0.getFullYear()}`;
    return {
      colonne: col.map((c) => ({ cima: c.ignota ? "?" : c.data === oggi ? c.ora || "oggi" : c.data.slice(0, 5), sotto: c.ignota ? "ora ignota" : c.data === oggi ? "" : c.ora || "",
        parziale: righe.some((r) => r.valori[c.i] && r.valori[c.i].v && r.valori[c.i].parziale) })),
      gruppi: raggruppaStorico(righe).map((g) => ({ nome: g.nome, righe: g.righe.map((r) => ({
        nome: inatteso(r) ? String(r.nome).replace(/\s+/g, " ").trim() : sigla(r.nome),
        um: unitaChiara((r.valori.find((v) => v && v.um) || {}).um || "", r.nome),
        valori: col.map((c) => { const v = r.valori[c.i]; return v && v.v ? [v.v, v.stato || 0, v.parziale ? 1 : 0, v.pct || ""] : null; }),
      })) })),
    };
  }
  // Gli esiti di un paziente: la tabella che il PC ha di lui (la sua scheda
  // clinica, scelta con la regola d'identità del pannello) e i referti della
  // sua pagina — letta una volta, solo lettura, e solo se è del suo episodio —
  // col testo di quelli già letti.
  async function ponteEsiti(p) {
    const url = ponteUrlPaziente(p);
    let referti = [], nota = "";
    if (url) {
      try {
        const { doc, url: fin } = await fetchDoc(url, {});
        if (classify(doc) === "login") return { ok: false, errore: "Gestionale da riaprire: sul PC la sessione è scaduta", sessione: true };
        if (findEpisodeId(doc, fin) !== p.ep) return { ok: false, errore: "La pagina del paziente sul PC è di un altro episodio: non mostro niente" };
        referti = esitiModel(doc, fin).filter((e) => e.kind === "referto");
      } catch (e) { nota = `Referti non letti: ${e?.head || e?.message || e}`; }
    } else nota = "Per i referti, apri una volta il paziente sul PC";
    let st = null;
    const testi = new Map();
    if (hasExt()) {
      const r = await ask({ t: "getStorico" });
      const indice = (r && r.ok && r.indice) || [];
      const mio = String(p.pk || "").startsWith("cf:") ? p.pk.slice(3) : "";
      const scelta = scegliScheda(indice, mio, p.name, p.ep);
      const leggi = async (chiave) => { const x = await ask({ t: "getStorico", chiave }); return x && x.ok ? x.dati : null; };
      if (scelta) st = await leggi(scelta.chiave);
      // I testi dei referti si cercano per numero di referto, quello della
      // pagina di QUESTO paziente: un referto letto prima che il codice
      // fiscale fosse noto sta nella scheda col suo nome.
      const perNome = "nome:" + normNome(p.name);
      const altra = perNome !== "nome:" && (!scelta || scelta.chiave !== perNome) && indice.some((v) => v.chiave === perNome) ? await leggi(perNome) : null;
      for (const s of [altra, st]) for (const x of (s && s.referti) || []) if (x && x.id && x.testo) testi.set(x.id, x.testo);
    }
    const dati = st && st.righe && st.righe.length ? normalizzaStorico(st) : null;
    const tabella = dati && dati.righe.length ? ponteTabella(dati) : null;
    let resta = 400000;   // il telefono riceve un messaggio solo, mai oltre 1 MB
    const lista = referti.filter((e) => refertoTipo(e) !== "lab" || !tabella).map((e) => {
      const t = testi.get(e.id) || "";
      const sta = !!t && t.length <= resta;
      if (sta) resta -= t.length;
      return { id: e.id, quando: e.when, sistema: e.sistema, titolo: shortLabel(e.label), tipo: refertoTipo(e), testo: sta ? t : "", lungo: !!t && !sta };
    });
    // quando il PC li ha letti: sul telefono si vede quanto sono vecchi
    return { ok: true, dati: { ep: p.ep, paziente: p.name, tabella, letto: tabella ? Number(st.letto) || 0 : 0, referti: lista, nota }, registro: `esiti di ${p.name}` };
  }
  // L'ordine: lo stesso giro di «Conferma e stampa», dato alla scheda di
  // sottofondo dalla pagina del paziente — tutti i controlli di sempre. Il
  // laboratorio si conferma da solo; la radiologia resta sul carrello, come
  // dal pannello (la sua conferma è sempre del medico). Il numero dell'ordine
  // lo dà il service worker: chiesto due volte, l'ordine è uno.
  async function ponteOrdina(p, a) {
    const url = ponteUrlPaziente(p);
    if (!url) return { ok: false, errore: `Apri una volta ${p.name || "il paziente"} sul PC: per ordinare serve la sua pagina` };
    const quesito = String(a.quesito || "").replace(/\s+/g, " ").trim();
    if (!quesito) return { ok: false, errore: "Scrivi il quesito diagnostico" };
    const cat = fullCatalog();
    const items = [];
    for (const k of new Set(a.esami || [])) {
      const [res, code] = k.split(":");
      if (!cat[res]?.items?.[code]) return { ok: false, errore: `Un esame non è nel catalogo di questo PC: niente inviato` };
      items.push({ res, code, label: examLabel(res, code), display: displayLabel(res, code), chiave: k });
    }
    if (!items.length) return { ok: false, errore: "Scegli almeno un esame" };
    const gambe = [["lab", items.filter((i) => !RADIO_SET.includes(i.res))], ["radio", items.filter((i) => RADIO_SET.includes(i.res))]].filter(([, l]) => l.length);
    const ordini = [];
    for (const [kind, l] of gambe) {
      const id = `${a.id}${kind === "radio" ? "r" : "l"}`, autoConfirm = kind === "lab";
      const job = { id, ep: p.ep, paziente: p.name, n: l.length, autoConfirm, url, rid: null, nomi: l.map((i) => i.display),
        piano: { startPage: "patient", items: l, quesito, quesitoMio: !!a.mio, autoConfirm, episodeId: p.ep, patientName: p.name, patientUrl: url, kind } };
      let r = { ok: false };
      for (let k = 0; k < 3 && !r.ok && !r.no; k++) r = await ask({ t: "ordineNuovo", job });
      if (!r.ok) {
        const perche = r.no ? r.why || "rifiutato" : "il service worker non risponde: guarda il carrello prima di rifarlo";
        if (!ordini.length) return { ok: false, errore: `Ordine non partito: ${perche}` };
        return { ok: true, dati: { ordini, avviso: `La radiologia non è partita: ${perche}` }, registro: `ordine per ${p.name}: la radiologia non è partita` };
      }
      ordini.push({ id, ep: p.ep, paziente: p.name, n: l.length, rx: kind === "radio" });
    }
    rememberQuesito(quesito);
    const n = items.length;
    return { ok: true, dati: { ordini }, registro: `ordine di ${n} ${n === 1 ? "esame" : "esami"} per ${p.name} (${items.map((i) => i.display).join(", ")})` };
  }
  // Un comando del telefono, eseguito qui. `no`: questa scheda non può (il
  // service worker prova la prossima).
  async function ponteEsegui(m) {
    if (classify(document) === "login") return { no: "login" };
    if (LAVORO || PONTE_VALORI) return { no: "lavoro" };
    if (!PANNELLO) return { no: "pannello" };
    const a = m.args || {}, cmd = m.cmd;
    const fatto = (r) => {
      if (r && r.registro) PANNELLO.log(`${now()}  iPhone · ${r.registro}`);
      if (r && r.ok && ["nota", "promemoria", "fatto"].includes(cmd) && !PANNELLO.root.activeElement) PANNELLO.render();
      return r;
    };
    if (cmd === "pazienti") return fatto({ ok: true, dati: pontePazienti(), registro: "elenco dei pazienti" });
    if (cmd === "richieste") return fatto({ ok: true, dati: ponteCatalogo(), registro: "catalogo degli esami" });
    const p = a.ep ? pontePaziente(a.ep) : null;
    if (!p) return { ok: false, errore: "Questo paziente non è più nell'elenco del PC" };
    // dimesso sul PC (archiviato): dal telefono non si tocca più
    if (p.arch) return { ok: false, errore: "Dimesso sul PC: niente inviato", dimesso: true };
    // un episodio precedente si legge, ma non si ordina e non si promemora
    if ((cmd === "ordina" || cmd === "promemoria") && PANNELLO.pazModello().info.get(p.ep)?.prec) {
      return { ok: false, errore: `Episodio precedente: ${cmd === "ordina" ? "per ordinare" : "per un promemoria"} apri quello di oggi` };
    }
    const riga = () => pontePazienti().find((x) => x.ep === p.ep) || null;
    if (cmd === "esiti") return fatto(await ponteEsiti(p));
    if (cmd === "aggiornaValori") {
      const url = ponteUrlPaziente(p);
      if (!url) return { ok: false, errore: `Apri una volta ${p.name || "il paziente"} sul PC: serve la sua pagina` };
      return fatto({ ok: true, dati: { url, paziente: p.name }, registro: `aggiorna i valori di ${p.name}` });
    }
    // La nota del telefono è la prima voce aperta senza ora di «Da fare»:
    // scritta, cambia quella (o, se non c'è, ne fa una in cima: il post-it);
    // vuota, la toglie. Mai un'ora letta dentro: una nota resta una nota.
    if (cmd === "nota") {
      const testo = String(a.testo || "").replace(/\s*\n+\s*/g, " · ").replace(/\s+/g, " ").trim().slice(0, 500);
      const n = dfNota(p.ep);
      const ok = n ? (testo ? dfCambia(p.ep, n.id, testo) : dfTogli(p.ep, n.id)) : !testo || !!dfAggiungi(p.ep, testo, { t: null, inCima: true, max: 500 });
      if (!ok) return { ok: false, errore: n || dfAperte(p.ep).length < PROM_MAX ? "Nota non salvata: la memoria del browser del PC è piena o bloccata" : `Già ${PROM_MAX} cose da fare per questo paziente` };
      return fatto({ ok: true, dati: riga(), registro: `nota di ${p.name}` });
    }
    if (cmd === "promemoria") {
      const x = leggiPromemoria(a.testo, Date.now());
      if (!x) return { ok: false, errore: "Scrivi anche l'ora: «11:30 tropo», «tra 2h ECG»" };
      if (dfAperte(p.ep).length >= PROM_MAX) return { ok: false, errore: `Già ${PROM_MAX} cose da fare per questo paziente` };
      if (!promAggiungi(p.ep, x)) return { ok: false, errore: "Promemoria non salvato: la memoria del browser del PC è piena o bloccata" };
      return fatto({ ok: true, dati: riga(), registro: `promemoria per ${p.name}: ${promRiga(x, Date.now())}` });
    }
    if (cmd === "fatto") {
      const via = promTogli(p.ep, String(a.pid || ""));
      if (!via) return { ok: false, errore: "Promemoria non trovato: forse è già fatto", dati: riga() };
      return fatto({ ok: true, dati: riga(), registro: `promemoria fatto per ${p.name}: ${via.testo}` });
    }
    if (cmd === "ordina") return fatto(await ponteOrdina(p, a));
    return { ok: false, errore: "Comando sconosciuto" };
  }
  // In ogni scheda del gestionale: i comandi, e lo stato per l'intestazione.
  // Finché un iPhone è associato le schede tengono sveglio il service worker
  // (se Chrome l'ha fermato, la presa si riapre).
  function ponteAscolta() {
    if (!hasExt() || ponteAscolta.fatto) return;
    ponteAscolta.fatto = true;
    try {
      chrome.runtime.onMessage.addListener((m, _s, reply) => {
        if (!m || m.t !== "ponteEsegui") return;
        ponteEsegui(m).then(reply, (e) => reply({ ok: false, errore: `Errore sul PC: ${e?.head || e?.message || e}` }));
        return true;
      });
      const segui = (s) => {
        const prima = !!(PONTE_STATO && PONTE_STATO.sessione);
        PONTE_STATO = s || null;
        if (prima !== !!(PONTE_STATO && PONTE_STATO.sessione) && PANNELLO && !PANNELLO.root.activeElement) PANNELLO.render();
      };
      chrome.storage.session.get("ponte").then((o) => segui(o.ponte)).catch(() => {});
      chrome.storage.onChanged.addListener((ch, area) => { if (area === "session" && ch.ponte) segui(ch.ponte.newValue); });
      setInterval(() => { if (PONTE_STATO && PONTE_STATO.accoppiato) ask({ t: "ponteSveglia" }); }, 30e3);
    } catch { /* niente estensione */ }
  }
  // La scheda aperta dal ponte per «Aggiorna i valori»: il «⭳ Carica i valori»
  // di sempre, e poi lo dice al service worker (che la chiude).
  async function ponteValoriQui(panel) {
    const v = PONTE_VALORI;
    let esito;
    if (!panel || panel.pageType !== "patient" || panel.episodeId !== v.ep || !panel.nomePaziente()) {
      esito = { ok: false, testo: "la scheda ha aperto un'altra pagina: niente letto" };
    } else {
      try {
        panel.log(`${now()}  ── iPhone: «Aggiorna i valori» per ${panel.nomePaziente()} ──`);
        await panel.caricaValori();
        esito = { ok: true, testo: "letti" };
      } catch (e) { esito = { ok: false, testo: `non letti: ${e?.head || e?.message || e}` }; }
    }
    ask({ t: "ponteValoriFatto", ...esito });
  }

  // ==================================================================== BOOT
  // The extension runs on two applications: SA4PSO, and the clinical portal
  // where the multi-day table lives. Everything below the storico reader is
  // written for SA4PSO's markup and must never be applied to the other one —
  // its login page carries a password field, and mistaking it for SA4PSO's
  // would wipe the shift's saved documents.
  const SA4PSO = location.hostname === "smarthealth.multimedica.it";
  function voceTabella(doc) {
    const el = [...doc.querySelectorAll('button, a, [role="tab"], [role="button"], li, span')]
      .find((x) => x.childElementCount <= 2 && /^tabella$/i.test((x.textContent || "").trim()));
    return el ? el.closest('button, a, [role="tab"], [role="button"], [onclick]') || el : null;
  }

  function boot() {
    if (document.getElementById("psassist-host")) return;
    // The portal's multi-day table: here the panel does not order anything and
    // does not ask the server anything. It reads the table already on screen
    // and hands it to the patient's page. Nothing else.
    if (haStorico(document)) { bootStorico(); return; }
    if (!SA4PSO) {
      // Una scheda che il pannello ha aperto per un REFERTO: qui non c'è
      // nessuna tabella da aspettare, si aspetta il PDF (vedi sotto).
      let perReferto = false;
      const chi = hasExt() ? ask({ t: "chiAprivo" }).catch(() => null) : Promise.resolve(null);
      chi.then((r) => { if (r && r.ok && r.sotto && r.cosa === "referto") { perReferto = true; leggiRefertoPortale(r); } });
      // The portal is a single-page application: it paints the table AFTER
      // this script has run, and reaching it is an in-app route change that
      // never re-injects us. Probing once would mean never reading anything.
      let atteso = null;
      const occhio = new MutationObserver(() => {
        clearTimeout(atteso);
        atteso = setTimeout(() => {
          if (document.getElementById("psassist-host")) return;
          if (haStorico(document)) { occhio.disconnect(); clearTimeout(muto); bootStorico(); }
        }, 120);
      });
      occhio.observe(document.documentElement, { childList: true, subtree: true });
      // Se dopo un po' la tabella non c'è, non si resta muti: «non si vede
      // niente» è indistinguibile da «l'estensione non gira su questa pagina»,
      // e senza saperlo non si sa nemmeno cosa raccontarmi. La striscia dice
      // che il programma c'è e cosa gli manca. Sparisce da sola.
      const muto = setTimeout(async () => {
        if (document.getElementById("psassist-host") || haStorico(document)) return;
        // La scheda che il pannello ha aperto in sottofondo («⭳ Carica i
        // valori»): nessuno la guarda, quindi niente striscia. Se il portale
        // chiede di entrare lo si dice al pannello; se la tabella sta dietro la
        // voce «Tabella», la si apre — un clic nell'interfaccia del portale,
        // come farebbe il medico, e UNA volta sola.
        let mia = false;
        const r0 = await chi;
        if (perReferto || (r0 && r0.ok && r0.sotto && r0.cosa === "referto")) return;
        mia = !!(r0 && r0.ok && r0.sotto);
        if (mia) {
          let cliccato = false;
          for (let giro = 0; giro < 8 && !document.getElementById("psassist-host") && !haStorico(document); giro++) {
            if (document.querySelector('input[type="password"]')) { ask({ t: "sottoLogin" }).catch(() => {}); return; }
            const voce = !cliccato && voceTabella(document);
            if (voce) { voce.click(); cliccato = true; }
            await sleep(1500);
          }
          return;
        }
        const h = document.createElement("div");
        h.id = "psassist-attesa";
        const r = h.attachShadow({ mode: "open" });
        r.innerHTML = `<style>:host{all:initial}
          .b{position:fixed;left:12px;bottom:12px;z-index:2147483647;display:flex;align-items:center;gap:10px;
             max-width:min(520px,92vw);font:12.5px/1.4 -apple-system,"Segoe UI",Roboto,Arial,sans-serif;
             background:#6B7A88;color:#fff;border-radius:10px;padding:8px 10px 8px 12px;box-shadow:0 6px 22px rgba(11,44,80,.28)}
          button{border:1px solid rgba(255,255,255,.5);background:transparent;color:#fff;border-radius:7px;
                 padding:4px 9px;font:inherit;font-weight:600;cursor:pointer}
          button:hover{background:rgba(255,255,255,.14)}</style>
          <div class="b" role="status"><span><b>PS Assist</b> è attivo, ma qui non c'è nessuna tabella:
          apri <b>Tabella</b> nello storico dati clinici.</span><button id="via">✕</button></div>`;
        r.getElementById("via").addEventListener("click", () => h.remove());
        document.documentElement.appendChild(h);
        setTimeout(() => h.remove(), 15000);
      }, 1500);
      return;
    }
    // Con l'estensione, per prima cosa: questa scheda è quella di un ordine
    // in sottofondo? Lo sa il service worker, dal numero della scheda. (Una
    // risposta che non arriva vale «no»: la scheda parte come sempre.)
    if (hasExt()) {
      let fatto = false;
      const via = (r) => { if (fatto) return; fatto = true; bootGestionale(r && r.ok ? r : null); };
      ascoltaPdf();
      ask({ t: "ordineChi" }).then(via);
      setTimeout(() => via(null), 3000);
      return;
    }
    bootGestionale(null);
  }

  function bootGestionale(chi) {
    if (document.getElementById("psassist-host")) return;
    // la scheda aperta dal service worker solo per dare i PDF di una stampa: niente pannello
    if (chi && chi.fogli) return;
    LAVORO = chi && chi.lavoro ? chi.lavoro : null;
    PONTE_VALORI = chi && chi.ponteValori ? chi.ponteValori : null;
    ponteAscolta();
    scadenzaQuesiti();
    const pageType = classify(document);
    if (pageType === "login") {
      // La sessione è caduta. forgetAll() porta via anche l'appunto del giro:
      // se c'era qualcosa da mandare va detto QUI, prima di cancellare, perché
      // dopo il nuovo accesso non ne resterebbe traccia. Senza nomi: questa
      // pagina la può avere davanti chiunque.
      const c = tabStore.get(CORSA, null);
      // (anche un giro di un'altra scheda, o di un browser chiuso a metà: il
      // segno condiviso lo sa, e dopo il nuovo accesso non ci sarebbe più)
      const a = store.get(APERTA, null);
      const fresca = !!a && Date.now() - (a.ts || 0) < APERTA_TTL;
      const mai = c ? (c.restanti || []).length : fresca ? a.quanti || 0 : 0;
      const forse = c ? (c.involo ? 1 : 0) : fresca ? a.forse || 0 : 0;
      // Gli ordini in sottofondo restano — le etichette da stampare, gli
      // avvisi —: dopo il nuovo accesso la striscia li dice ancora. Qui solo
      // quanti sono, senza nomi. La scheda di un ordine lo dice alle altre.
      const aperti = LAVORO ? 0 : (chi?.ordini || []).length;
      if (LAVORO) ask({ t: "ordineAggiorna", id: LAVORO.id, stato: "errore", vista: { tag: "Sessione scaduta", testo: "Rifai l'accesso, poi controlla il carrello", tono: "err", sessione: true } });
      if (PONTE_VALORI) ask({ t: "ponteValoriFatto", ok: false, testo: "il gestionale chiede di rifare l'accesso" });
      // e la sessione del ponte verso l'iPhone si chiude (l'associazione resta: rientrati, il telefono riapre)
      if (hasExt()) ask({ t: "ponteLogin" });
      forgetAll();
      if (mai || forse || aperti) {
        const d = document.createElement("div");
        d.id = "psassist-avviso-login";
        d.style.cssText = "position:fixed;left:12px;bottom:12px;z-index:2147483647;max-width:min(520px,92vw);background:#B3261E;color:#fff;border-radius:10px;padding:10px 12px;font:13px/1.45 -apple-system,'Segoe UI',Roboto,Arial,sans-serif;box-shadow:0 6px 20px rgba(9,42,74,.35)";
        d.textContent = "PS Assist: " + [
          mai || forse ? `la sessione è scaduta mentre mandava gli esami — ${contoRimasto(mai, forse)}. Rientra e controlla il carrello dell'ultima richiesta.` : "",
          aperti ? `${mai || forse ? "E c'è" : "La sessione è scaduta con"} ${aperti === 1 ? "1 ordine di esami ancora aperto" : `${aperti} ordini di esami ancora aperti`} (etichette da stampare, o un avviso): rientra, e la striscia ${aperti === 1 ? "lo mostra" : "li mostra"}.` : "",
        ].filter(Boolean).join(" ");
        document.documentElement.appendChild(d);
      }
      return;
    }
    if (pageType === "other") {
      // e.g. the post-confirm label page: no panel, but a pending print
      // handoff starts here when the page lists the richiesta's print links.
      if (chi) ascoltaOrdini(null);   // e le etichette di un ordine in sottofondo, se il medico è qui
      if (PONTE_VALORI) ponteValoriQui(null);
      nonConfermateQui();   // le richieste che questa pagina mostra confermate non vanno più sorvegliate
      if (!maybeAutoPrint(null) && LAVORO && LAVORO.stato !== "avvio") lavoroSenzaSeguito(null);
      return;
    }
    const panel = new Panel(pageType);
    PANNELLO = panel;
    // «Reset dati pazienti» da un'altra scheda: anche questa dimentica (non a metà di un giro)
    window.addEventListener("storage", (ev) => {
      if (ev.key !== NS + "reset.v1" || !ev.newValue || panel.giroInCorso()) return;
      azzeraScheda();
      panel.dimenticaTutto();
      panel.render();
    });
    if (chi) { panel.ordiniOk = true; ascoltaOrdini(panel); }
    if (hasExt()) { panel.seguiStampa(); panel.seguiRec(); }
    if (pageType === "patient") {
      panel.entry = patientModel(document, location.href);
      panel.esiti = esitiModel(document, location.href);
      // le richieste che la pagina elenca, con il loro stato: per la riga dei
      // Pazienti, le Dimissioni e le Richieste (solo la pagina del paziente,
      // non la lista del PS, che porta l'episodio del primo in elenco)
      if (panel.episodeId && (panel.entry.labUrl || panel.entry.radioUrl)) leggiStatoPagina(panel.episodeId, document);
      // Se una riga di prelievo non si lascia leggere, il Registro lo dice
      // subito e con le sue parole: senza questo, un prelievo che non diventa
      // una colonna è indistinguibile da un prelievo che non esiste. Quando
      // sono tutte a posto non si scrive niente: la pagina si ricarica a ogni
      // click, e un Registro pieno di righe uguali non lo legge nessuno.
      const dp = diagPrelievi(document, location.href);
      const male = dp.filter((r) => !r.ok);
      if (male.length) {
        panel.log(`${now()}  ${male.length} righe di prelievo su ${dp.length} non si lasciano leggere:\n${
          dp.map((r) => `    ${r.ok ? "ok" : "✗ "} ${r.testo}`).join("\n")}`);
      }
    }
    panel.restoreUi(); // same tab + same episode → quesito/selezione/vista tornano come prima
    // Quello che è stato deciso in sottofondo si dice sulla pagina dove il
    // medico atterra — che può essere il carrello, non solo quella del paziente.
    // Con la striscia si atterra come pill (un giro in sottofondo non apre mai
    // la finestra da solo); un errore porta con sé il resoconto, che si apre
    // con un tocco.
    const av = tabStore.get(AVVISO, null);
    if (av) {
      tabStore.set(AVVISO, null);
      if (Date.now() - (av.ts || 0) < CONFIRM_FLAG_TTL) {
        if (av.testo) panel.message = av.testo;
        if (av.giro) {
          panel.runState = av.giro.stato || "fail";
          panel.runPatient = av.giro.paziente || "";
          panel.runData = { steps: Array.isArray(av.giro.steps) ? av.giro.steps : [], added: [],
            lastListUrl: av.giro.listUrl || null, finishedListUrl: null };
          if (av.riprova && Array.isArray(av.riprova.mancanti)) panel.riprova = av.riprova;
          panel.tieneDopoErrore = Array.isArray(av.giro.tiene) ? av.giro.tiene.map(String) : null;
        }
        if (av.striscia) { panel.collapsed = true; panel.striscia = av.striscia; }
        else panel.collapsed = false;
      }
    }
    panel.render();
    // La scheda di un ordine fermato col ⏹ mentre cambiava pagina: non
    // riprende, non conferma — lo dice alle altre e si slega.
    if (LAVORO && LAVORO.ferma) panel.fermaLavoro();
    // Un giro rimasto a metà viene prima di tutto: ha esami ancora da mandare,
    // e riprende da qualunque pagina del gestionale — anche da quella di un
    // altro paziente, perché le richieste portano il loro episodio con sé.
    const ripresa = riprendiCorsa(panel);
    let segue = false;   // (la conferma cliccata, o un carrello da rileggere: la pagina dopo dirà)
    // (un ordine in sottofondo di quel paziente lo racconta già la sua striscia)
    if (!ripresa && !LAVORO) avvisaGiroAbbandonato(panel, chi?.ordini || []);
    osservaScrittura();
    // (le richieste da confermare le ricordano le schede del medico, non quella di un ordine)
    if (!ripresa && !LAVORO) panel.sorvegliaConferme(true);
    if (chi) panel.ordiniAggiorna(chi.ordini || []);
    // la scheda di sottofondo appena aperta: l'ordine parte da qui
    if (LAVORO && LAVORO.stato === "avvio" && !ripresa) panel.avviaLavoro();
    if (pageType === "patient") {
      // this patient is now one the panel knows (name + episode + page only)
      // only a page that can actually order is a patient: the ER worklist
      // classifies the same way but its episode belongs to someone in the list
      // (la scheda di un ordine non è il medico che apre il paziente: niente «visto adesso»)
      if (panel.entry && (panel.entry.labUrl || panel.entry.radioUrl) && !LAVORO && !PONTE_VALORI) {
        const an = anagraficaPagina(document);
        rememberPatient(panel.episodeId, nomeInPagina(), location.href, triageDi(document), an.eta, an.sesso);
        iconaCf(document);
        // Il portale clinico si apre da QUESTO link, sulla pagina di QUESTO
        // paziente: quel clic è l'identità, ed è esatta. Si annota qui, prima
        // che la scheda si apra, così di là la tabella sa di chi è senza
        // confrontare nomi e senza chiedere niente al server.
        document.addEventListener("click", (ev) => {
          const a = ev.target?.closest?.('a[href*="MODALITA=CLINICA"]');
          if (!a || !hasExt()) return;
          ask({ t: "apreStorico", ep: panel.episodeId || "", nome: panel.nomePaziente() || "" }).catch(() => {});
        }, true);
      }
      if (hasExt()) ask({ t: "portale" }).then((r) => {
        if (r && r.ok && r.origine) { panel.portale = r.origine; panel.render(); }
      }).catch(() => {});
      panel.applyAfterNav();
      const pending = nextQueued(findEpisodeId(document, location.href));
      panel.pending = pending; // a richiesta of this run still needs confirming
      // Il bottone che porta a termine la richiesta rimasta a metà (la
      // radiologia dopo il laboratorio) sta nelle Richieste: finché qualcosa
      // è in sospeso si atterra lì, non sugli Esiti.
      if (pending && panel.view === "esiti") panel.view = "richieste";
      panel.render();
      panel.refreshRefCache();
      panel.caricaStorico();
      // (la scheda dei valori del ponte legge e basta: niente conferme né stampe da qui)
      if (PONTE_VALORI) { ponteValoriQui(panel); return; }
      if (ripresa) return;   // il giro ripreso arriva da sé a conferma e stampa
      if (pending) {
        // auto-continue once per richiesta; afterwards it is a button, so an
        // abandoned confirmation can never turn into a navigation loop
        if (pending.q.autoConfirm && !pending.next.nav) {
          goToQueued(pending, (u) => panel.vaiSeLibero(u, { ms: 0, striscia: { tag: "Richiesta da confermare", testo: "Conferma dal gestionale", tono: "warn" } }));
          return;
        }
      } else {
        // nothing left to confirm → print everything at once
        maybeAutoPrint(panel);
      }
    } else {
      panel.render();
      if (PONTE_VALORI) ponteValoriQui(panel);   // non è la pagina del paziente: lo dice e basta
    }
    if (pageType === "exam") {
      const model = examModel(document, location.href);
      learnFrom(model);
      panel.render(); // pick up anything just learned
      armPrintOnConfirm(model, findEpisodeId(document, location.href)); // native Conferma → print handoff
      if (!ripresa) {   // prima si finisce di mandare gli esami
        let cliccato = maybeAutoConfirm(panel);
        const qui = model.richiestaId && model.listUrl(model.res);
        // Al carrello manca una riga che deve avere: si ricarica l'elenco
        // pulito (una lettura), e i controlli ripartono da capo; la striscia
        // che aspetta la conferma viaggia con la pagina.
        if (cliccato && cliccato.rileggi) {
          const s = panel.striscia;
          if (leggibilePagina(qui)) panel.vaiSeLibero(qui, { ms: cliccato.rileggi, striscia: s, prima: () => { if (s) tabStore.set(AVVISO, { ts: Date.now(), striscia: s }); } });
          else { tabStore.set("confirm.v1", null); cliccato = false; }
        }
        segue = !!cliccato;
        // si aspettava la conferma e un controllo ha detto di no: tocca al medico
        if (!cliccato && panel.striscia && panel.striscia.attesaConferma) {
          const sospesa = { tag: "Conferma sospesa", testo: "Controlla il carrello e premi tu Conferma", tono: "warn", paziente: panel.striscia.paziente || "" };
          // nella scheda di un ordine: lo si passa alle schede del medico
          if (LAVORO) {
            panel.consegnaLavoro({ tag: "Conferma sospesa", testo: "controlla il carrello e premi tu Conferma", tono: "warn" },
              leggibilePagina(qui) ? { url: qui, avviso: { striscia: sospesa, ...(typeof panel.message === "string" && panel.message ? { testo: panel.message } : {}) },
                receipt: tabStore.get("receipt.v1", null) } : null);
          } else panel.segnala(sospesa);
        }
      }
    }
    if (pageType === "crea") {
      // Mirror a quesito the server (triage) already filled in, so the panel
      // never suggests overwriting it.
      const pageQ = document.forms.namedItem("RICHIESTACrea")?.elements?.namedItem("QUESITO_DIAGNOSTICO");
      if (pageQ && pageQ.value.trim()) { panel._q = pageQ.value; panel.quesitoMio = false; panel.render(); }
    }
    // La scheda di un ordine che qui non ha più niente da fare: l'ordine non
    // resta «in corso» per sempre (vedi lavoroSenzaSeguito).
    if (LAVORO && LAVORO.stato !== "avvio" && !ripresa && !segue) lavoroSenzaSeguito(panel);
  }

  // ---------------------------------------------------- portale clinico
  // A strip at the bottom of the portal page: what was read, for whom, and a
  // way to read it again after moving the columns. No panel, no ordering.
  // Una scheda del portale aperta dal pannello per leggere un REFERTO (ECG,
  // radiologia). Il PDF lo ha in mano la pagina — l'ha scaricato lei, per
  // mostrarlo — e portale-pdf.js, che sta nel suo mondo, ne passa una copia:
  // qui la si porta al service worker, che la tiene e chiude la scheda. Se il
  // portale chiede di entrare lo si dice; se il PDF non arriva, si manda com'è
  // fatta la pagina (mai il contenuto), per capire perché.
  // Il portale può mostrare più di un PDF — quello rimasto aperto da prima,
  // poi il nostro —: non si tiene il primo che passa. Si raccolgono, si
  // aspetta un attimo che non ne arrivino altri, e si tiene quello che è di
  // QUESTO paziente (e dell'esame chiesto): vedi scegliPdfReferto. Se sono
  // tutti di un altro paziente non se ne tiene nessuno, e lo si dice.
  function leggiRefertoPortale(chi) {
    let fatto = false, deciso = false;
    let sguardo = null;   // i conti di portale-pdf.js: se risponde, e cosa ha visto
    const candidati = [];
    let attesa = null;
    const decidi = async () => {
      if (deciso) return;
      deciso = true;
      const letti = [];
      for (const c of candidati) letti.push({ righe: (await testoPdf(c.buf).catch(() => null))?.righe || [] });
      const k = scegliPdfReferto(letti, chi || {});
      if (k.i < 0) {
        ask({ t: "refertoSottoDiag", esito: "altro", diag: `${candidati.length} PDF nel portale, ${k.altri} di un altro paziente` }).catch(() => {});
        return;
      }
      const c = candidati[k.i];
      ask({ t: "refertoSotto", data: bufB64(c.buf), size: c.buf.byteLength,
        via: `${c.via}${candidati.length > 1 ? ` ${k.i + 1}/${candidati.length}` : ""}` }).catch(() => {});
    };
    const consegna = (buf, via) => {
      if (deciso || !buf || !(buf.byteLength > 8)) return;
      // lo stesso PDF visto due volte (dal frame e dalla rete) è uno solo
      const coda = new Uint8Array(buf, Math.max(0, buf.byteLength - 48), Math.min(48, buf.byteLength));
      const firma = `${buf.byteLength}:${String.fromCharCode(...coda)}`;
      if (candidati.some((c) => c.firma === firma)) return;
      candidati.push({ buf, via, firma });
      fatto = true;
      clearTimeout(attesa);
      attesa = setTimeout(decidi, 2500);
    };
    window.addEventListener("message", (ev) => {
      const d = ev.data;
      if (ev.origin !== location.origin || !d || typeof d !== "object") return;
      if (d.psassistPdfPronto === 1) {
        const v = sguardo || { blob: 0, rete: 0, pdf: 0 };
        sguardo = { blob: Math.max(v.blob, d.blob || 0), rete: Math.max(v.rete, d.rete || 0), pdf: Math.max(v.pdf, d.pdf || 0) };
      }
      if (d.psassistPdf === 1) consegna(d.buf, d.via || "");
    });
    // a tutti i frame di questa origine: «sei una scheda del pannello» e
    // «ripeti quelli già visti» (lo script del portale parte prima di noi)
    const chiedi = () => {
      const tutti = [window];
      for (let i = 0; i < window.frames.length; i++) tutti.push(window.frames[i]);
      for (const w of tutti) { try { w.postMessage({ psassistSotto: 1, psassistPdfChiedi: 1 }, location.origin); } catch { /* altra origine */ } }
    };
    // …e la pagina stessa: un PDF dentro un frame, un embed o un object come blob:
    const nellaPagina = async () => {
      for (const el of document.querySelectorAll("iframe[src], embed[src], object[data]")) {
        const src = el.getAttribute("src") || el.getAttribute("data") || "";
        if (!/^blob:/i.test(src)) continue;
        try {
          const b = await (await fetch(src)).arrayBuffer();
          if (b.byteLength > 8 && String.fromCharCode(...new Uint8Array(b, 0, 5)) === "%PDF-") consegna(b, "pagina");
        } catch { /* revocato, o d'altra origine */ }
      }
    };
    (async () => {
      for (let giro = 0; giro < 25 && !deciso; giro++) {
        if (document.querySelector('input[type="password"]')) { ask({ t: "sottoLogin" }).catch(() => {}); return; }
        chiedi();
        await nellaPagina();
        await sleep(1000);
      }
      if (!fatto) ask({ t: "refertoSottoDiag", diag: diagPortale(sguardo) }).catch(() => {});
    })();
  }
  // Com'è fatta la pagina del portale, senza niente del paziente: il percorso
  // (numeri tolti), i frame e cosa mostrano, e cosa ha visto portale-pdf.js.
  function diagPortale(sguardo) {
    const senzaId = (x) => String(x || "").replace(/[?#].*$/, "").replace(/\d{2,}/g, "#").slice(0, 80);
    const hash = String(location.hash || "").replace(/[?].*$/, "").replace(/\d+/g, "#").slice(0, 60);
    const frame = [...document.querySelectorAll("iframe, embed, object")].slice(0, 6).map((el) => {
      const src = el.getAttribute("src") || el.getAttribute("data") || "";
      const tipo = el.getAttribute("type") ? `[${el.getAttribute("type")}]` : "";
      return `${el.tagName.toLowerCase()}${tipo} ${/^blob:/i.test(src) ? "blob:" : src ? senzaId(src) : "(vuoto)"}`;
    });
    return [
      `portale ${senzaId(location.pathname)}${hash ? " " + hash : ""}`,
      sguardo ? `sguardo sì (blob ${sguardo.blob} · rete ${sguardo.rete} · pdf ${sguardo.pdf})` : "sguardo NO (portale-pdf.js non risponde)",
      `frame: ${frame.length ? frame.join(", ") : "nessuno"}`,
      `canvas ${document.querySelectorAll("canvas").length}`,
      `textLayer ${document.querySelectorAll(".textLayer").length}`,
      `script ${document.scripts.length}`,
    ].join(" · ");
  }

  function bootStorico() {
    document.getElementById("psassist-attesa")?.remove();
    let unito = null;
    let chiAprivo;   // undefined = non ancora chiesto, null = non lo sappiamo
    const host = document.createElement("div");
    host.id = "psassist-host";
    const root = host.attachShadow({ mode: "open" });
    document.documentElement.appendChild(host);

    const disegna = (stato) => {
      root.innerHTML = `
        <style>
          :host { all: initial; }
          .bar { position: fixed; left: 12px; bottom: 12px; z-index: 2147483647;
                 display: flex; align-items: center; gap: 10px; max-width: min(560px, 92vw);
                 font: 12.5px/1.4 -apple-system, "Segoe UI", Roboto, Arial, sans-serif;
                 background: #0B5CAD; color: #fff; border-radius: 10px; padding: 8px 10px 8px 12px;
                 box-shadow: 0 6px 22px rgba(11,44,80,.28); }
          .bar.ko { background: #6B7A88; }
          b { font-weight: 700; }
          .who { opacity: .85; }
          button { border: 1px solid rgba(255,255,255,.5); background: transparent; color: #fff;
                   border-radius: 7px; padding: 4px 9px; font: inherit; font-weight: 600; cursor: pointer; }
          button:hover { background: rgba(255,255,255,.14); }
          button:focus-visible { outline: 2px solid #fff; outline-offset: 1px; }
        </style>
        <div class="bar ${stato.ok ? "" : "ko"}" role="status">
          <span>${stato.html || esc(stato.testo || "")}</span>
          <button id="rileggi" title="Dopo aver spostato le colonne o cambiato il periodo">↻ Rileggi</button>
        </div>`;
      root.getElementById("rileggi").addEventListener("click", leggi);
    };

    const leggi = async () => {
      const letto = leggiStorico(document);
      if (!letto) { disegna({ ok: false, testo: "Nessuna tabella da leggere in questa pagina." }); return; }
      // Da quale paziente il medico è arrivato qui: l'ha aperto lui, dalla sua
      // pagina. È l'identità più solida che ci sia, e non costa una richiesta.
      // Si richiede a OGNI lettura: la scheda del portale resta aperta, e nel
      // frattempo il medico può aver cliccato «Storico» da un altro paziente.
      if (hasExt()) {
        chiAprivo = null;
        try { const r = await ask({ t: "chiAprivo" }); if (r && r.ok) chiAprivo = r; } catch { /* si va avanti */ }
      }
      // …ma vale solo se di là c'è LO STESSO nome: il portale cambia paziente
      // senza ricaricare la pagina, e la tabella di un altro non deve portarsi
      // dietro l'episodio da cui si era partiti.
      const dalClic = !!(chiAprivo && chiAprivo.ep && combaciaNome(chiAprivo.nome, letto.paziente));
      if (dalClic) { letto.ep = chiAprivo.ep; letto.nomeSa4 = chiAprivo.nome || ""; }
      unito = unisciStorico(unito, letto);
      const valori = unito.righe.reduce((n, r) => n + r.valori.filter((v) => v.v).length, 0);
      const chi = [unito.paziente.cognome, unito.paziente.nome].filter(Boolean).join(" ");
      const quanti = `<b>${esc(String(unito.righe.length))} esami · ${esc(String(unito.date.length))} prelievi</b> letti (${esc(String(valori))} valori)`;
      // l'unico testo con del markup dentro: passa da `html`, e ogni pezzo che
      // viene dalla pagina del portale è scappato qui, uno per uno
      const nonSuo = chiAprivo && chiAprivo.ep && !dalClic
        ? ` · non è ${esc(chiAprivo.nome || "il paziente")}, da cui l'hai aperta: si attribuirà col codice fiscale (⭳ Carica i valori)` : "";
      const detto = (nuovo, n) => `${quanti} <span class="who">— ${esc(chi)}${nuovo ? ", nuovo" : ""}${n > 1 ? ` · ${esc(String(n))} pazienti in memoria` : ""}${nonSuo}</span>. Torna sul paziente: sono in Esiti.`;
      if (!hasExt()) {
        disegna({ ok: false, testo: `Letti ${unito.righe.length} esami, ma serve l'estensione per portarli sul paziente.` });
        return;
      }
      // una scheda per paziente: se non c'era, la crea
      mettiInScheda(chiaveArchivio(unito), unito).then((r) => {
        disegna(r && r.ok ? { ok: true, html: detto(r.nuovo, r.pazienti || 1) }
          : { ok: false, testo: "Letto, ma l'estensione non li ha ricevuti: apri il paziente e riprova." });
      });
    };

    // the table redraws when the period changes or the columns are scrolled
    let attesa = null;
    const osserva = document.querySelector(".clinical-data-table__freeze-panel");
    if (osserva) {
      new MutationObserver(() => { clearTimeout(attesa); attesa = setTimeout(leggi, 400); })
        .observe(osserva, { childList: true, subtree: true });
    }
    // Il portale disegna solo le colonne IN VISTA: il medico scorre la tabella e
    // i prelievi compaiono. Nella scheda che il pannello ha aperto in sottofondo
    // non scorre nessuno — e si leggevano solo i primi quattro. Lì la tabella la
    // si scorre qui, a passi, da un capo all'altro: lo stesso gesto del medico,
    // nessuna richiesta nostra. Ogni passo che disegna colonne nuove le aggiunge
    // a quelle già lette (unisciStorico somma, non sostituisce).
    const scorriTutto = async () => {
      const sc = document.querySelector(".clinical-data-table__freeze-container-right");
      if (!sc || sc.scrollWidth <= sc.clientWidth + 4) return;
      const vai = async (x) => {
        sc.scrollLeft = x;
        sc.dispatchEvent(new Event("scroll"));   // in una scheda nascosta il browser non lo manda da sé
        await sleep(700);
        await leggi();
      };
      const passo = Math.max(60, Math.floor(sc.clientWidth * 0.7));
      for (let x = 0; x < sc.scrollWidth; x += passo) await vai(x);
      await vai(sc.scrollWidth);
    };
    leggi().then(() => { if (chiAprivo && chiAprivo.sotto) scorriTutto().catch(() => {}); });
  }

  boot();
})();
