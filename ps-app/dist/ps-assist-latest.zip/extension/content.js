/*
 * PS Assist — Pronto Soccorso order helper for SA4PSO (Dedalus)
 * ============================================================
 *
 * Rebuilt from scratch (2026 re-audit of the saved SA4PSO pages).
 *
 * WHAT IT DOES
 * ------------
 * From the patient page (or the "Nuova Richiesta" / exam pages) it creates a
 * lab or radiology richiesta, fills the quesito diagnostico, adds the chosen
 * prestazioni and verifies each one landed in the cart — all driven with
 * same-origin fetch() calls that replay exactly the requests the browser
 * would send by clicking. The doctor then reviews the cart on the real page,
 * or — opt-in («+ Conferma») — the real cart page is loaded in a hidden,
 * script-less frame and its own "Conferma" button is clicked natively (the
 * confirm posts to MVPG=RcsStampaEtichetteLIS). "Confermata" is said only on
 * proof: a page of the same episode listing that richiesta's print links.
 *
 * WHY FETCH INSTEAD OF THE OLD "one exam per page reload" WALKER
 * --------------------------------------------------------------
 * The 0.x helper kept a queue in localStorage and re-entered itself after
 * every full-page reload. That design needed TTLs, in-flight markers and a
 * re-check dance to avoid double orders. Driving the server with fetch()
 * from a single page collapses all of that into one linear async function:
 * no cross-reload state, no reload of Insert URLs, and every step's response
 * is parsed and checked before the next request is sent.
 *
 * AUDITED FACTS THIS FILE RELIES ON (from the saved source pages)
 * ---------------------------------------------------------------
 * - Pages are windows-1252; POST bodies must be urlencoded in that charset.
 * - Patient page  : MVPG=PsoEpisodioClinicoAmbulatorio, has entry links
 *                   <a title="Richieste Laboratorio">, "Richieste Radiologia".
 * - Crea page     : form[name=RICHIESTACrea], method=post; fields include
 *                   QUESITO_DIAGNOSTICO (textarea), URGENZA/MODALITA/MEDICO
 *                   (server-prefilled; left untouched), hidden RICHIESTA_ID
 *                   (allocated when the page renders), submit Update="Crea".
 * - Exam page     : form[name=Prestazioni] (POST, submit Update="Conferma"),
 *                   filter select[name=RISORSA_ID] + input[name=s_PRESTAZIONE]
 *                   + submit DoSearch="Cerca". Each orderable exam is an
 *                   <a class="AFCDataLink"> whose href carries PRESTAZIONE=<code>
 *                   and either Insert=Inserisci (add) or Delete=Elimina (in
 *                   cart). A cart-wide "svuota" link also carries
 *                   Delete=Elimina but NO PRESTAZIONE param — so "in cart"
 *                   checks must require BOTH markers.
 * - The rendered list is a plain GET: swapping RISORSA_ID in the list URL
 *   switches resource; s_PRESTAZIONE filters. No pagination (146 rows max).
 * - Saved pages carry two `selected` options in some selects (server quirk);
 *   browsers keep the LAST one — serialization must do the same.
 *
 * SAFETY RULES (all enforced in code)
 * -----------------------------------
 * 1. An Insert URL is requested AT MOST ONCE. Verification re-reads the
 *    plain list URL (no Insert params); if the exam still isn't in the cart
 *    after the re-check budget, the run HARD-STOPS and says what to check.
 * 2. Every fetched page must belong to the same EPISODIO_ID the run started
 *    with; any mismatch aborts before anything else is sent.
 * 3. The final Conferma is opt-in and immediate (the doctor's click on
 *    «+ Conferma» is the decision): a native click on the EHR's own button,
 *    only when the cart equals the receipt of this run. Confirmed = proven
 *    by the EHR's page, never assumed.
 * 4. The quesito diagnostico is only written when the server field is empty.
 * 5. Stop/Esc aborts in-flight work immediately (AbortController).
 * 6. No request ever leaves the hospital origin.
 */

(function () {
  "use strict";

  // ================================================================ CONFIG
  const APP = "PS Assist";
  const VERSION = "3.48.0";
  const NS = "psassist:"; // storage namespace

  const TIMEOUT_MS = 20000;      // per-request timeout
  const PACE_MS = 250;           // gentle pause between consecutive requests
  const VERIFY_RECHECKS = 3;     // list re-reads before declaring an add lost
  const VERIFY_WAIT_MS = 1200;   // pause before each verify re-read
  const CONFIRM_FLAG_TTL = 120e3;// ms an auto-confirm handoff stays valid
  // un messaggio che deve sopravvivere al cambio di pagina: quello che si è
  // deciso in sottofondo va detto sulla pagina dove il medico arriva
  const AVVISO = "avviso.v1";
  const PRINT_FLAG_TTL = 180e3;  // ms a post-confirm print handoff stays valid
  const QUEUE_TTL = 30 * 60e3;   // ms a still-unconfirmed richiesta keeps reminding
  // Il giro in corso, annotato passo per passo. Il gestionale ricarica la
  // pagina a ogni click e il motore muore con lei: così invece riprende da
  // dov'era, e quello che era già partito non riparte MAI una seconda volta.
  const CORSA = "corsa.v1";
  const CORSA_TTL = 10 * 60e3;   // più vecchio di così non si riprende da solo
  const CORSA_MAX = 12;          // riprese massime: mai un ciclo senza fine
  // Due schede sulla stessa richiesta non devono mandare gli stessi esami.
  // L'appunto sta nella scheda (sessionStorage) e una scheda DUPLICATA se lo
  // porta dietro: il presidio invece sta in memoria condivisa, dove le schede
  // si vedono fra loro, e dice chi ci sta lavorando adesso.
  const PRESIDIO = "corsa.presidio.v1";
  const PRESIDIO_MS = 25e3;      // un segno più vecchio è di una scheda morta
  // Un giro lasciato a metà (scheda chiusa, sessione scaduta, browser caduto)
  // non deve sparire in silenzio: questo lo dice alla prima pagina utile.
  const APERTA = "corsa.aperta.v1";
  const APERTA_TTL = 30 * 60e3;

  // Resources ("Risorsa" dropdown values) — verified in the saved pages.
  const RES = {
    POC:     "00660001P", // LABORATORIO ANALISI POC - SSG
    URGENZE: "00720001P", // LABORATORIO ANALISI URGENZE - SSG
    CENTRAL: "00130001P", // LABORATORIO ANALISI - SSG
    RX:      "00120001P", // RADIOLOGIA - RX - SSG
    ECO:     "00400001P", // RADIOLOGIA - ECOGRAFIA - SSG
    RMN:     "00360001P", // RADIOLOGIA - RISONANZA MAGNETICA NUCLEARE - SSG
    TAC:     "00380001P", // RADIOLOGIA - TAC - SSG
  };
  const RES_SHORT = {
    // Urgenze e laboratorio centrale, per chi ordina, sono lo stesso posto:
    // un nome solo, e nella griglia un gruppo solo
    [RES.POC]: "POC", [RES.URGENZE]: "Lab centrale", [RES.CENTRAL]: "Lab centrale",
    [RES.RX]: "RX", [RES.ECO]: "Eco", [RES.RMN]: "RMN", [RES.TAC]: "TAC",
  };

  // Quick presets shown as chips. Codes verified against the saved pages
  // (see ps-app/README.md). A preset is shown only when every code exists in
  // the catalog available on this machine (embedded + learned).
  const PRESETS = [
    { name: "Base PS",  items: [[RES.POC, "320"], [RES.POC, "325"], [RES.POC, "176"]] },          // emocromo, EGA venosa NEW, creatinina
    { name: "Epatico",  items: [[RES.URGENZE, "16"], [RES.URGENZE, "228"], [RES.URGENZE, "53"], [RES.URGENZE, "167"], [RES.URGENZE, "34"]] }, // bili reflex, GPT, GOT, GGT, lipasi
    { name: "Coag POC", items: [[RES.POC, "220"], [RES.POC, "134"], [RES.POC, "135"]] },          // PT, PTT, fibrinogeno POC
    { name: "Coag",     items: [[RES.URGENZE, "181"], [RES.URGENZE, "54"], [RES.URGENZE, "258"]] }, // PT, PTT, fibrinogeno urgenze
  ];
  const SINGLES = [ // one-tap single exams (compact grid, grouped by lab)
    [RES.POC, "320"], [RES.POC, "325"], [RES.POC, "326"], [RES.POC, "176"],
    [RES.POC, "101"], [RES.POC, "324"], [RES.POC, "30"],
    // la coagulazione POC, uno per uno: i pacchetti la mettono, e da qui si vede e si toglie
    [RES.POC, "220"], [RES.POC, "134"],
    [RES.URGENZE, "293"], [RES.URGENZE, "159"], [RES.URGENZE, "297"],
    [RES.URGENZE, "317"],
    // gli epatici: il profilo rapido li ordina insieme, ma quasi sempre se ne
    // vuole uno solo — la lipasi c'era già, gli altri quattro no
    [RES.URGENZE, "228"], [RES.URGENZE, "53"], [RES.URGENZE, "167"],
    [RES.URGENZE, "16"], [RES.URGENZE, "34"],
    [RES.CENTRAL, "212"],
    [RES.RX, "35"], [RES.RX, "36"], [RES.RX, "28"],
  ];
  // Short ward names for the UI only. The catalog label stays the source of
  // truth for the anti-wrong-exam check, so renaming here is always safe.
  const DISPLAY = {
    [`${RES.POC}:320`]: "EMOCROMO POC",
    // Il laboratorio ha rifatto gli emogas: sono i codici «- NEW». Chi ordina
    // deve vedere che è quella nuova, o non saprebbe distinguerla dalla
    // vecchia che resta in elenco.
    [`${RES.POC}:325`]: "EGA VENOSA NEW",
    [`${RES.POC}:326`]: "EGA ARTERIOSA NEW",
    [`${RES.POC}:176`]: "CREATININA POC",
    [`${RES.POC}:101`]: "D-DIMERO POC",
    [`${RES.POC}:324`]: "TROPONINA US",
    [`${RES.POC}:30`]:  "GLUCOSIO POC",
    [`${RES.POC}:220`]: "PT POC",
    [`${RES.POC}:134`]: "PTT POC",
    [`${RES.POC}:135`]: "FIBRINOGENO POC",
    [`${RES.CENTRAL}:212`]: "SARSCOV",
    [`${RES.URGENZE}:293`]: "PCR",
    [`${RES.URGENZE}:34`]:  "LIPASI",
    [`${RES.URGENZE}:228`]: "GPT",
    [`${RES.URGENZE}:53`]:  "GOT",
    [`${RES.URGENZE}:167`]: "GAMMA GT",
    [`${RES.URGENZE}:16`]:  "BILIRUBINA",
    [`${RES.URGENZE}:159`]: "PROCALCITONINA",
    [`${RES.URGENZE}:297`]: "NT PRO-BNP",
    [`${RES.URGENZE}:317`]: "ESAME URINE",
    [`${RES.RX}:35`]: "RX TORACE",
    [`${RES.RX}:36`]: "RX TORACE 1 PROIEZ.",
    [`${RES.RX}:28`]: "RX ADDOME",
  };
  // If EGA arteriosa is selected, the venosa is dropped automatically.
  const EXCLUDE = [
    { keep: [RES.POC, "326"], drop: [RES.POC, "325"], note: "EGA arteriosa sostituisce la venosa" },
    { keep: [RES.POC, "166"], drop: [RES.POC, "3"], note: "EGA arteriosa sostituisce la venosa" },
  ];

  // Common quesiti offered as one-tap chips (editable; last used are kept).
  const QUESITI_DEFAULT = [
    "Dolore toracico", "Dolore addominale", "Dispnea", "Febbre",
    "Trauma", "Sincope", "Vertigini", "Cefalea",
  ];
  // Quesito = pacchetto di esami: toccare il chip scrive il quesito E spunta
  // gli esami che per quel quesito servono quasi sempre. Stanno sempre in
  // testa ai chip, anche se l'elenco dei quesiti salvato non li ha. Un esame
  // che in questa macchina non esiste nel catalogo si salta e si dice.
  // «PT PTT Fantoli» = il laboratorio non-POC, cioè URGENZE (181 PT, 54 PTT).
  const PACCHETTI = [
    // base, coagulazione POC, troponina US
    { q: "Dolore toracico", items: [[RES.POC, "320"], [RES.POC, "325"], [RES.POC, "176"], [RES.POC, "220"], [RES.POC, "134"], [RES.POC, "324"]] },
    // base ma con l'EGA ARTERIOSA (326, non la venosa 325), coag POC, D-dimero, troponina, proBNP
    { q: "Dispnea", items: [[RES.POC, "320"], [RES.POC, "326"], [RES.POC, "176"], [RES.POC, "220"], [RES.POC, "134"], [RES.POC, "101"], [RES.POC, "324"], [RES.URGENZE, "297"]] },
    // base, epatico e pancreatico (bili reflex, GPT, GOT, GGT, lipasi), PT PTT Fantoli
    { q: "Dolore addominale", items: [[RES.POC, "320"], [RES.POC, "325"], [RES.POC, "176"], [RES.URGENZE, "16"], [RES.URGENZE, "228"], [RES.URGENZE, "53"], [RES.URGENZE, "167"], [RES.URGENZE, "34"], [RES.URGENZE, "181"], [RES.URGENZE, "54"]] },
  ];

  // Embedded catalog: every exam extracted from the saved lab pages
  // (code → label per resource). Radiology lists aren't in the saved pages;
  // they are LEARNED automatically the first time the list is seen and kept
  // in localStorage, after which radiology works one-click too.
  const EMBEDDED_CATALOG = {"00660001P":{"label":"LABORATORIO ANALISI POC - SSG (P)","items":{"3":"EMOGASANALISI VENOSA POC (POC2117)","30":"GLUCOSIO (POC1250)","31":"ACIDO LATTICO POC (POC1094)","63":"NA+ POC (POC1434)","64":"K+ POC (POC1435)","101":"D-DIMERO POC (POC1405)","102":"BICARBONATI EMATICI POC (POC1499)","134":"PTT POC (POC1402)","135":"FIBRINOGENO POC (POC1404)","138":"ACT POC (POCACT)","166":"EGA EMOGASANALISI ARTERIOSA (POC1006)","176":"CREATININEMIA (POC1206)","220":"PT (POC1401)","221":"CL- POC (POC1436)","223":"ACT LR POC (POCACTLR)","224":"CALCIO IONIZZATO (POC1982)","225":"TEST GRAVIDANZA URINE (POC1612)","266":"PCR POC (POC1102)","303":"BILIRUBINA (NEONATALE) (POC1341NEO)","305":"PANNELLO 1 – ANEMIA, EMORRAGIA, ISCHEMIA ARTO","306":"PANNELLO 3 - CARDIOPALMO","307":"PANNELLO 4 - TRAUMA","308":"PANNELLO 5 – DISPNEA, STROKE","309":"PANNELLO 6 – PDC, TORACALGIA","310":"PANNELLO 2 - BASE","318":"PANNELLO 9 - ESAMI POC","320":"EMOCROMOCITOMETRICO URGENTE (POCT1502)","323":"EMOGASANALISI CAPILLARE POC (POC2117)","324":"TROPONINA ULTRASENSIBILE (POC3001)","325":"EMOGASANALISI VENOSA POC - NEW (POC21171)","326":"EGA EMOGASANALISI ARTERIOSA POC - NEW (POC10061)","327":"BICARBONATI EMATICI POC - NEW (POC14991)","328":"GLUCOSIO POC - NEW (POC12501)","329":"ACIDO LATTICO POC - NEW (POC10941)","330":"SODIO NEL SIERO POC - NEW (POC14341)","331":"POTASSIO NEL SIERO - NEW (POC14351)","332":"CLORO NEL SIERO POC - NEW (POC14361)","333":"EMOGAS CAPILLARE POC (POC21172)"}},"00720001P":{"label":"LABORATORIO ANALISI URGENZE - SSG (P)","items":{"1":"EMOCROMO (1501)","15":"PEPTIDE NATRIURETICO TIPO B BNP (450057)","16":"BILIRUBINA TOTALE REFLEX (450008)","23":"PSEUDOCOLINESTERASI (450007)","34":"LIPASI (1572)","35":"ANTIGENE URINARIO STRPTOCOCCUS PNEUMONIAE (2136)","53":"GOT (1582)","54":"PTT (1402)","59":"LIQUOR ESAME CHIMICO FISICO (2338)","62":"URINOCOLTURA DA MITTO INTERMEDIO (2015)","73":"EMOCOLTURA (2000)","92":"AZOTEMIA (1200)","93":"CPK (1560)","105":"POTASSIO NEL SIERO (1435)","141":"D-DIMERO (1405)","147":"LEGIONELLE: RICERCA ANTIGENE NELLE URINE (450124)","159":"PROCALCITONINA (1690)","167":"GAMMA GT (1596)","168":"GLUCOSIO (1250)","171":"TROPONINA I (450106)","175":"TIREOTROPINA RIFLESSA(TSH-R)TSH. INCL. EVENTUALE DOSAGGIO DI FT4 E FT3 (450064)","181":"PT (1401)","183":"AMMONIEMIA (1343)","211":"URINOCOLTURA DA SACCHETTO (2036)","215":"CLORO NEL SIERO (1436)","216":"CREATININEMIA (1206)","217":"SODIO NEL SIERO (1434)","228":"GPT (1583)","230":"BETA HCG PLASMATICO (1766)","258":"FIBRINOGENO (450102)","270":"CALCIO TOTALE (1437)","272":"ANTITROMBINA III (1530)","293":"PROTEINA C REATTIVA (1102)","297":"NT PRO-BNP (2040)","316":"RICERCA DIRETTA ANTIGENI MALARIA (21295)","317":"ESAME URINE URGENTI (21296)"}},"00130001P":{"label":"LABORATORIO ANALISI - SSG (P)","items":{"1":"EMOCROMO (1501)","2":"URICEMIA (1300)","6":"COPROCOLTURA (1205)","7":"PF4 (1209)","9":"COLTURALE SU RACCOLTA SIERO EMATICA (1275)","10":"COLTURALE SU LIQUIDO DA CISTI (1282)","15":"PEPTIDE NATRIURETICO TIPO B BNP (450057)","16":"BILIRUBINA TOTALE REFLEX (450008)","17":"QUANTIFERON SINGOLO MITOGENO (1358)","18":"PREALBUMINA (1397)","22":"DOSAGGIO AMIKACINA PICCO (450030)","23":"PSEUDOCOLINESTERASI (450007)","24":"FERRITINA (450042)","25":"DOSAGGIO GENTAMICINA VALLE (450032)","26":"HERPES VIRUS 2: RICERCA ANTICORPI IGM (450153)","27":"VIRUS PAROTITE ANTICORPI IGG E IGM PER SOSPETTA INFEZIONE ACUTA (450160)","28":"ACIDI BILIARI (1999)","29":"AB BORRELIA B. IGG (450109)","34":"LIPASI (1572)","35":"ANTIGENE URINARIO STRPTOCOCCUS PNEUMONIAE (2136)","37":"COLTURALE BRONCOLAVAGGIO BAL (1262)","39":"FT3 (1837)","41":"CRYPTOCOCCO ANTIGENE SU LIQUOR (450115)","42":"PLASMODI DELLA MALARIA: RIC. MICR. STRISCIO SOTTILE E GOCCIA SPESSA (450127)","47":"COLTURALE MICOLOGICO CUTE E ANNESSI UNGHIA (1619)","48":"COLTURALE MICOLOGICO CUTE E ANNESSI CUTE (1657)","49":"COLTURALE MICOLOGICO CUTE E ANNESSI CAPELLI (1658)","50":"FARMACI ANTIBIOTICI: VANCOMICINA (450034)","53":"GOT (1582)","54":"PTT (1402)","55":"VIRUS EPATITE B (HBSAG) ANT. AUSTRA (1119)","58":"LIQUIDO ASCITICO ESAME CHIMICO E FISICO (2335)","59":"LIQUOR ESAME CHIMICO FISICO (2338)","62":"URINOCOLTURA DA MITTO INTERMEDIO (2015)","69":"COLTURALE VALVOLA CARDIACA (2496)","70":"URICURIA (1301)","71":"LDH (LATTATODEIDROGENASI) (1569)","72":"ALCOOL ETILICO (ETANOLO) (2003)","73":"EMOCOLTURA (2000)","76":"COLTURALE SU TAMPONE CUTANEO (1274)","79":"COLTURALE BRONCOASPIRATO (1009)","84":"CONTEGGIO RETICOLOCITI (1511)","86":"IMMUNOGLOBULINE G (1539)","87":"PCR AD ALTA SENSIBILITA' (CRPH) (1556)","92":"AZOTEMIA (1200)","93":"CPK (1560)","94":"VIRUS IMMUNODEF. ACQUISITA [HIV 1-2] TEST COMB. ANTICORPI/ANTIGENE P24 (450158)","95":"VIRUS EPATITE B (HBSAG) ANTICORPI (1121)","98":"VIRUS MORBILLO IGG E IGM PER SOSPETTA INFEZIONE ACUTA (450159)","99":"DOSAGGIO GENTAMICINA PICCO (450033)","105":"POTASSIO NEL SIERO (1435)","106":"CLOSTRIDIOIDES DIFFICILE:RIC. DIRETTA DELLA TOSSINA NELLE FECI (450120)","109":"ESAME COLTURALE SU TAMPONE FARINGEO (12171)","110":"COLTURALE SU TAMPONE PIAGA DECUBITO (1270)","114":"COLTURALE BIOPSIA (1516)","116":"PARASSITI NEL SANGUE (450128)","117":"COLTURALE FERITA CHIRURGICA (1564)","120":"COLTURALE MAMMELLA SINISTRA (1603)","122":"URINOCOLTURA DA CATETERE A PERMANENZA (2035)","126":"FOSFATASI ALCALINA (1590)","127":"VIRUS EPATITE B (HBEAG) ANTIGENE (1116)","130":"COLTURALE FERITE SUPERFICIALI NON CHIRURGICHE (2494)","131":"COLTURALE FILI PACE-MAKER (2495)","133":"ALBUMINURIA (MICROALBUMINURIA) (1953)","141":"D-DIMERO (1405)","142":"VIRUS EPATITE DELTA [HDV]: RICERCA ANTICORPI (450149)","143":"ELETTROFORESI PROTEICA (2109)","147":"LEGIONELLE: RICERCA ANTIGENE NELLE URINE (450124)","149":"TEST DI COOMBS INDIRETTO (1171)","152":"FT4 (1839)","154":"EMOGLOBINE. DETERMINAZIONE FRAZIONI (HBA2, HBF, HB ANOMALE) (450104)","156":"COLTURALE PLACENTA (1575)","158":"COLTURALE MICOLOGICO CUTE E ANNESSI PELI (1654)","159":"PROCALCITONINA (1690)","160":"URINOCOLTURA DA CATETERISMO SINGOLO (2037)","161":"DOSAGGIO AMIKACINA VALLE (450031)","163":"AB BORRELIA B. IGM (450110)","164":"LIQUIDO SINOVIALE ESAME CHIMICO E FISICO (2337)","167":"GAMMA GT (1596)","168":"GLUCOSIO (1250)","169":"VIRUS EPATITE B [HBV] - REFLEX (450148)","170":"VIRUS EPATITE C (HCV) (1099)","171":"TROPONINA I (450106)","174":"HERPES VIRUS 2: RICERCA ANTICORPI IGG (450152)","175":"TIREOTROPINA RIFLESSA(TSH-R)TSH. INCL. EVENTUALE DOSAGGIO DI FT4 E FT3 (450064)","180":"ALBUMINA (2391)","181":"PT (1401)","183":"AMMONIEMIA (1343)","185":"FERRO (450043)","186":"APTOGLOBINA (1098)","187":"TITOLO ANTI-O-STREPTOLISINICO (1100)","195":"LIQUIDO PERICARDICO ESAME CHIIMICO FISICO E MICROSCOPICO (1884)","196":"TRANSFERRINA IND. SATURAZIONE (1351)","197":"COLTURALE PER YERSINIA NELLE FECI (1412)","198":"COLTURALE PER STREPTOCOCCUS AGALACTIAE (1414)","205":"IMMUNOGLOBULINE A (1538)","209":"COLTURALE MAMMELLA DESTRA (1589)","211":"URINOCOLTURA DA SACCHETTO (2036)","212":"TAMPONE ANTIGENICO SARS COV-2 (21225)","213":"BICARBONATI EMATICI (1499)","215":"CLORO NEL SIERO (1436)","216":"CREATININEMIA (1206)","217":"SODIO NEL SIERO (1434)","227":"PROTEINA S LIBERA (90724)","228":"GPT (1583)","229":"PROTEINE TOTALI (1346)","230":"BETA HCG PLASMATICO (1766)","231":"FOSFORO (SIERO) (1438)","232":"TRANSFERRINA TOTALE (1352)","233":"INSULINA (1139)","237":"TSH (1841)","239":"LIQUIDO PERITONEALE ESAME CHIMICO FISICO E MICROSCOPICO (1885)","240":"ALFA 1 GLICOPROTEINA (1348)","241":"QUANTIFERON ANTIGENI TB SPECIFICI (1357)","243":"LITIEMIA (1433)","250":"LIQUIDO DA VERSAMENTO ESAME CHIMICO FISICO (2217)","254":"LIQUIDO PLEURICO ESAME CHIMICO E FISICO (2336)","255":"TEMPO DI TROMBINA (2347)","256":"AMILASI PANCREATICA (1553)","257":"FARMACI: DIGOSSINA (450016)","258":"FIBRINOGENO (450102)","259":"VIRUS EPATITE A [HAV] ANTICORPI IGG E IGM PER SOSPETTA INFEZIONE ACUTA (450147)","260":"FARMACI ANTIEPILETTICI: CARBAMAZEPINA (450018)","261":"PROTEINA C ATTIVATA-RESISTENZA (2301)","263":"HERPES VIRUS 1: RICERCA ANTICORPI IGM (450151)","264":"HERPES VIRUS 1: RICERCA ANTICORPI IGG (450150)","265":"VIRUS VARICELLA ZOSTER ANTICORPI IGG E IGM PER SOSPETTA INF. ACUTA (450162)","267":"MAGNESIO NEL SIERO (1432)","268":"ALFA AMILASI NEL SIERO (1551)","270":"CALCIO TOTALE (1437)","271":"IG M (1540)","272":"ANTITROMBINA III (1530)","273":"VITAMINA B12 (1880)","274":"HBS AB DOSAGGIO QUANTITATIVO (1110)","275":"VELOCITA'ERITROSEDIMENTAZIONE (1095)","279":"COLTURALE MATERIALE VARIO (1212)","281":"COLTURALE SU MATERIALE DA TRACHEOSTOMA (1269)","282":"COLTURALE SU MATERIALE DA FISTOLA (1271)","293":"PROTEINA C REATTIVA (1102)","294":"MIOGLOBINA (1004)","295":"VIRUS EPATITE B (HBEAG) ANTICORPI (1120)","297":"NT PRO-BNP (2040)","299":"TREPONEMA PALLIDUM RICERCA ANTICORPI SCREENING (450137)","311":"PANNELLO 7 - ESAMI EMATICI DI CONTROLLO FANTOLI","312":"PANNELLO 8 - INFORTUNIO BIOLOGICO","316":"RICERCA DIRETTA ANTIGENI MALARIA (21295)"}},"00120001P":{"label":"RADIOLOGIA - RX - SSG (P)","items":{"21":"RX OSSA NASALI (A6952)","22":"ORTOPANORAMICA ARCATE DENTARIE (ORTOPANTOMOGRAFIA) (A699)","23":"SCHELETRO TORACICO COSTALE BIL (A6960)","24":"GINOCCHIO SX (A6936A)","25":"GINOCCHIO DX (A6936B)","26":"RX DIG.PARZ.STOMACO/DUODEN (6930)","27":"SENI PARANASALI (A6962)","28":"RX ADDOME SENZA CONTRASTO (A692)","29":"BACINO (A6917)","30":"RX COLONNA CERVICALE (6920)","31":"CRANIO (A6924)","32":"RX RACHIDE TORACO-DORSALE (A6929)","33":"RX RACHIDE LOMBO-SACRALE (A6941)","35":"RX TORACE (6979)","36":"RX TORACE 1 PROIEZIONE (6980)","37":"RX DELL'ANCA SX (A696A)","38":"RX DELL'ANCA DX (A696B)","39":"MANO SX (A6944A)","40":"GAMBA DX (A6936E)","41":"GAMBA SX (A6936F)","42":"FEMORE DX (A6936C)","43":"FEMORE SX (A6936D)","44":"GOMITO SX (A6937A)","45":"POLSO SX (A6955A)","46":"AVAMBRACCIO SX (A6915A)","47":"AVAMBRACCIO DX (A6915B)","48":"GOMITO DX (A6937B)","49":"MANO DX (A6944B)","50":"PIEDE DX (A6953B)","51":"POLSO DX (A6955B)","52":"PIEDE SX (A6953A)","53":"RX ORBITE (A6906)","54":"STERNO (A6985C)","118":"SPALLA DX (A6964C)","119":"SPALLA SX (A6964D)","120":"RADIOGRAFIA IN REPARTO (6903)","122":"TIBIO-TARSICA DX (A6953C)","123":"TIBIO-TARSICA SX (A6953D)","134":"RX CLAVICOLA DX (A6985D)","135":"RX CLAVICOLA SX (A6985E)"}},"00650002P":{"label":"LABORATORIO ANALISI POC - OSG (P)","items":{"3":"EMOGASANALISI VENOSA POC (POC2117)","30":"GLUCOSIO (POC1250)","31":"ACIDO LATTICO POC (POC1094)","63":"NA+ POC (POC1434)","64":"K+ POC (POC1435)","101":"D-DIMERO POC (POC1405)","102":"BICARBONATI EMATICI POC (POC1499)","134":"PTT POC (POC1402)","135":"FIBRINOGENO POC (POC1404)","138":"ACT POC (POCACT)","166":"EGA EMOGASANALISI ARTERIOSA (POC1006)","176":"CREATININEMIA (POC1206)","220":"PT (POC1401)","221":"CL- POC (POC1436)","223":"ACT LR POC (POCACTLR)","224":"CALCIO IONIZZATO (POC1982)","225":"TEST GRAVIDANZA URINE (POC1612)","266":"PCR POC (POC1102)","303":"BILIRUBINA (NEONATALE) (POC1341NEO)","305":"PANNELLO 1 – ANEMIA, EMORRAGIA, ISCHEMIA ARTO","306":"PANNELLO 3 - CARDIOPALMO","307":"PANNELLO 4 - TRAUMA","308":"PANNELLO 5 – DISPNEA, STROKE","309":"PANNELLO 6 – PDC, TORACALGIA","310":"PANNELLO 2 - BASE","318":"PANNELLO 9 - ESAMI POC","320":"EMOCROMOCITOMETRICO URGENTE (POCT1502)","323":"EMOGASANALISI CAPILLARE POC (POC2117)","324":"TROPONINA ULTRASENSIBILE (POC3001)","325":"EMOGASANALISI VENOSA&nbsp;POC - NEW (POC21171)","326":"EGA EMOGASANALISI ARTERIOSA POC - NEW (POC10061)","327":"BICARBONATI EMATICI POC - NEW (POC14991)","328":"GLUCOSIO POC - NEW (POC12501)","329":"ACIDO LATTICO POC - NEW (POC10941)","330":"SODIO NEL SIERO POC - NEW (POC14341)","331":"POTASSIO NEL SIERO - NEW (POC14351)","332":"CLORO NEL SIERO POC - NEW (POC14361)","333":"EMOGAS CAPILLARE POC (POC21172)"}},"00290002P":{"label":"LABORATORIO ANALISI - OSG (P)","items":{"1":"EMOCROMO (1501)","2":"URICEMIA (1300)","6":"COPROCOLTURA (1205)","7":"PF4 (1209)","9":"COLTURALE SU RACCOLTA SIERO EMATICA (1275)","10":"COLTURALE SU LIQUIDO DA CISTI (1282)","15":"PEPTIDE NATRIURETICO TIPO B BNP (450057)","16":"BILIRUBINA TOTALE REFLEX (450008)","17":"QUANTIFERON SINGOLO MITOGENO (1358)","18":"PREALBUMINA (1397)","22":"DOSAGGIO AMIKACINA PICCO (450030)","23":"PSEUDOCOLINESTERASI (450007)","24":"FERRITINA (450042)","25":"DOSAGGIO GENTAMICINA VALLE (450032)","26":"HERPES VIRUS 2: RICERCA ANTICORPI IGM (450153)","27":"VIRUS PAROTITE ANTICORPI IGG E IGM PER SOSPETTA INFEZIONE ACUTA (450160)","28":"ACIDI BILIARI (1999)","29":"AB BORRELIA B. IGG (450109)","34":"LIPASI (1572)","35":"ANTIGENE URINARIO STRPTOCOCCUS PNEUMONIAE (2136)","37":"COLTURALE BRONCOLAVAGGIO BAL (1262)","39":"FT3 (1837)","41":"CRYPTOCOCCO ANTIGENE SU LIQUOR (450115)","42":"PLASMODI DELLA MALARIA: RIC. MICR. STRISCIO SOTTILE E GOCCIA SPESSA (450127)","47":"COLTURALE MICOLOGICO CUTE E ANNESSI UNGHIA (1619)","48":"COLTURALE MICOLOGICO CUTE E ANNESSI CUTE (1657)","49":"COLTURALE MICOLOGICO CUTE E ANNESSI CAPELLI (1658)","50":"FARMACI ANTIBIOTICI: VANCOMICINA (450034)","53":"GOT (1582)","54":"PTT (1402)","55":"VIRUS EPATITE B (HBSAG) ANT. AUSTRA (1119)","58":"LIQUIDO ASCITICO ESAME CHIMICO E FISICO (2335)","59":"LIQUOR ESAME CHIMICO FISICO (2338)","62":"URINOCOLTURA DA MITTO INTERMEDIO (2015)","69":"COLTURALE VALVOLA CARDIACA (2496)","70":"URICURIA (1301)","71":"LDH (LATTATODEIDROGENASI) (1569)","72":"ALCOOL ETILICO (ETANOLO) (2003)","73":"EMOCOLTURA (2000)","76":"COLTURALE SU TAMPONE CUTANEO (1274)","79":"COLTURALE BRONCOASPIRATO (1009)","84":"CONTEGGIO RETICOLOCITI (1511)","86":"IMMUNOGLOBULINE G (1539)","87":"PCR AD ALTA SENSIBILITA' (CRPH) (1556)","92":"AZOTEMIA (1200)","93":"CPK (1560)","94":"VIRUS IMMUNODEF. ACQUISITA [HIV 1-2] TEST COMB. ANTICORPI/ANTIGENE P24 (450158)","95":"VIRUS EPATITE B (HBSAG) ANTICORPI (1121)","98":"VIRUS MORBILLO IGG E IGM PER SOSPETTA INFEZIONE ACUTA (450159)","99":"DOSAGGIO GENTAMICINA PICCO (450033)","105":"POTASSIO NEL SIERO (1435)","106":"CLOSTRIDIOIDES DIFFICILE:RIC. DIRETTA DELLA TOSSINA NELLE FECI (450120)","109":"ESAME COLTURALE SU TAMPONE FARINGEO (12171)","110":"COLTURALE SU TAMPONE PIAGA DECUBITO (1270)","114":"COLTURALE BIOPSIA (1516)","116":"PARASSITI NEL SANGUE (450128)","117":"COLTURALE FERITA CHIRURGICA (1564)","120":"COLTURALE MAMMELLA SINISTRA (1603)","122":"URINOCOLTURA DA CATETERE A PERMANENZA (2035)","126":"FOSFATASI ALCALINA (1590)","127":"VIRUS EPATITE B (HBEAG) ANTIGENE (1116)","130":"COLTURALE FERITE SUPERFICIALI NON CHIRURGICHE (2494)","131":"COLTURALE FILI PACE-MAKER (2495)","133":"ALBUMINURIA (MICROALBUMINURIA) (1953)","141":"D-DIMERO (1405)","142":"VIRUS EPATITE DELTA [HDV]: RICERCA ANTICORPI (450149)","143":"ELETTROFORESI PROTEICA (2109)","147":"LEGIONELLE: RICERCA ANTIGENE NELLE URINE (450124)","149":"TEST DI COOMBS INDIRETTO (1171)","152":"FT4 (1839)","154":"EMOGLOBINE. DETERMINAZIONE FRAZIONI (HBA2, HBF, HB ANOMALE) (450104)","156":"COLTURALE PLACENTA (1575)","158":"COLTURALE MICOLOGICO CUTE E ANNESSI PELI (1654)","159":"PROCALCITONINA (1690)","160":"URINOCOLTURA DA CATETERISMO SINGOLO (2037)","161":"DOSAGGIO AMIKACINA VALLE (450031)","163":"AB BORRELIA B. IGM (450110)","164":"LIQUIDO SINOVIALE ESAME CHIMICO E FISICO (2337)","167":"GAMMA GT (1596)","168":"GLUCOSIO (1250)","169":"VIRUS EPATITE B [HBV] - REFLEX (450148)","170":"VIRUS EPATITE C (HCV) (1099)","171":"TROPONINA I (450106)","174":"HERPES VIRUS 2: RICERCA ANTICORPI IGG (450152)","175":"TIREOTROPINA RIFLESSA(TSH-R)TSH. INCL. EVENTUALE DOSAGGIO DI FT4 E FT3 (450064)","180":"ALBUMINA (2391)","181":"PT (1401)","183":"AMMONIEMIA (1343)","185":"FERRO (450043)","186":"APTOGLOBINA (1098)","187":"TITOLO ANTI-O-STREPTOLISINICO (1100)","195":"LIQUIDO PERICARDICO ESAME CHIIMICO FISICO E MICROSCOPICO (1884)","196":"TRANSFERRINA IND. SATURAZIONE (1351)","197":"COLTURALE PER YERSINIA NELLE FECI (1412)","198":"COLTURALE PER STREPTOCOCCUS AGALACTIAE (1414)","205":"IMMUNOGLOBULINE A (1538)","209":"COLTURALE MAMMELLA DESTRA (1589)","211":"URINOCOLTURA DA SACCHETTO (2036)","212":"TAMPONE ANTIGENICO SARS COV-2 (21225)","213":"BICARBONATI EMATICI (1499)","215":"CLORO NEL SIERO (1436)","216":"CREATININEMIA (1206)","217":"SODIO NEL SIERO (1434)","227":"PROTEINA S LIBERA (90724)","228":"GPT (1583)","229":"PROTEINE TOTALI (1346)","230":"BETA HCG PLASMATICO (1766)","231":"FOSFORO (SIERO) (1438)","232":"TRANSFERRINA TOTALE (1352)","233":"INSULINA (1139)","237":"TSH (1841)","239":"LIQUIDO PERITONEALE ESAME CHIMICO FISICO E MICROSCOPICO (1885)","240":"ALFA 1 GLICOPROTEINA (1348)","241":"QUANTIFERON ANTIGENI TB SPECIFICI (1357)","243":"LITIEMIA (1433)","250":"LIQUIDO DA VERSAMENTO ESAME CHIMICO FISICO (2217)","254":"LIQUIDO PLEURICO ESAME CHIMICO E FISICO (2336)","255":"TEMPO DI TROMBINA (2347)","256":"AMILASI PANCREATICA (1553)","257":"FARMACI: DIGOSSINA (450016)","258":"FIBRINOGENO (450102)","259":"VIRUS EPATITE A [HAV] ANTICORPI IGG E IGM PER SOSPETTA INFEZIONE ACUTA (450147)","260":"FARMACI ANTIEPILETTICI: CARBAMAZEPINA (450018)","261":"PROTEINA C ATTIVATA-RESISTENZA (2301)","263":"HERPES VIRUS 1: RICERCA ANTICORPI IGM (450151)","264":"HERPES VIRUS 1: RICERCA ANTICORPI IGG (450150)","265":"VIRUS VARICELLA ZOSTER ANTICORPI IGG E IGM PER SOSPETTA INF. ACUTA (450162)","267":"MAGNESIO NEL SIERO (1432)","268":"ALFA AMILASI NEL SIERO (1551)","270":"CALCIO TOTALE (1437)","271":"IG M (1540)","272":"ANTITROMBINA III (1530)","273":"VITAMINA B12 (1880)","274":"HBS AB DOSAGGIO QUANTITATIVO (1110)","275":"VELOCITA'ERITROSEDIMENTAZIONE (1095)","279":"COLTURALE MATERIALE VARIO (1212)","281":"COLTURALE SU MATERIALE DA TRACHEOSTOMA (1269)","282":"COLTURALE SU MATERIALE DA FISTOLA (1271)","293":"PROTEINA C REATTIVA (1102)","294":"MIOGLOBINA (1004)","295":"VIRUS EPATITE B (HBEAG) ANTICORPI (1120)","297":"NT PRO-BNP (2040)","299":"TREPONEMA PALLIDUM RICERCA ANTICORPI SCREENING (450137)","311":"PANNELLO 7 – ESAMI EMATICI DI CONTROLLO FANTOLI","312":"PANNELLO 8 - INFORTUNIO BIOLOGICO","316":"RICERCA DIRETTA ANTIGENI MALARIA (21295)"}}};
  // Discharge instructions, reviewed before shipping and freely editable by
  // the doctor: what is kept here is a TEMPLATE, never a patient's text.
  const DIMISSIONI = {"gastrite":{"nome":"Gastrite acuta","rivisto":true,"testo":"GASTRITE ACUTA — INDICAZIONI ALLA DIMISSIONE\n\nFARMACI\n- Pantoprazolo 40 mg, 1 compressa al mattino a digiuno (30 minuti prima di colazione), per 4 settimane.\n- Antiacido/alginato al bisogno dopo i pasti e alla sera.\n- Sospendere i FANS. Per il dolore utilizzare paracetamolo 1 g fino a 3 volte al giorno.\n\nCOSA FARE A CASA\n- Sospendere alcol e fumo.\n- Pasti piccoli e frequenti; evitare cibi piccanti, grassi, caffè, cioccolato, bevande gassate.\n- Non coricarsi nelle 3 ore dopo il pasto.\n- Prediligere carboidrati come fette biscottate, pasta, patate, riso, e carni bianche come pollo e tacchino.\n\nFOLLOW-UP\n- Rivalutazione dal Medico Curante entro 7–10 giorni.\n- Valutare EGDS in caso di persistenza dei sintomi oltre 4 settimane di terapia, o in presenza di segni d'allarme.\n\nRITORNARE IN PRONTO SOCCORSO O CHIAMARE IL 112 SE\n- Vomito con sangue o a «fondo di caffè».\n- Feci nere, catramose o con sangue.\n- Dolore addominale intenso o improvviso.\n- Vomito persistente con impossibilità a bere.\n- Febbre.\n- Svenimento, vertigini, sudorazione fredda o palpitazioni.\n- Dolore che si irradia al dorso o al torace.\n\nQueste indicazioni si riferiscono alla valutazione di oggi e non sostituiscono il medico curante. Se compaiono sintomi nuovi o il disturbo peggiora torni in Pronto Soccorso anche prima dei tempi indicati; chiami il 112 se il sintomo è grave o improvviso e non si metta alla guida. Porti con sé questo foglio, la documentazione consegnata e l'elenco dei farmaci che assume, allergie comprese. Attenzione ai preparati per l'influenza: contengono già paracetamolo."},"gastroenterite":{"nome":"Gastroenterite / diarrea acuta","rivisto":true,"testo":"GASTROENTERITE ACUTA — INDICAZIONI ALLA DIMISSIONE\n\nBERE\n- Almeno 2 litri al giorno a piccoli sorsi, più un bicchiere in più dopo ogni scarica.\n- Evitare bevande molto zuccherate, alcolici, caffè.\n\nMANGIARE\n- Appena tollerato, in bianco, con pasti piccoli e frequenti.\n- Nei primi giorni evitare latte e latticini, fritti e cibi grassi, frutta e verdura (in particolare cruda).\n- Prediligere carboidrati semplici come fette biscottate, pasta, patate, riso, e carni bianche come pollo e tacchino.\n- Utili i fermenti lattici.\n\nIGIENE\n- Lavarsi le mani con acqua e sapone dopo ogni evacuazione.\n- Non preparare cibo per altri fino a 48 ore dopo l'ultima scarica.\n\nFARMACI\n- Sospendere metformina, farmaci per la pressione, diuretici o gliflozine.\n- Se dolore o febbre: paracetamolo 1 g ogni 8 ore (massimo 3 g al giorno).\n- NON prendere antinfiammatori (ibuprofene, ketoprofene, diclofenac, aspirina) finché vomito e diarrea non sono passati.\n- Se la diarrea è un problema pratico: loperamide 2 mg (Imodium, Dissenten) 2 compresse subito, poi 1 compressa dopo ogni scarica liquida; massimo 8 compresse al giorno, per non più di due giorni consecutivi. NON assumerla se ha febbre o sangue nelle feci.\n\nTORNI IN PRONTO SOCCORSO SE\n- Sangue nelle feci o feci nere.\n- Vomito continuo che impedisce di bere.\n- Febbre oltre 39 °C che non risponde al paracetamolo o che dura più di 3 giorni.\n- Dolore addominale forte e localizzato, in peggioramento.\n\nCONTROLLO\n- Medico curante se non migliora in 3–4 giorni.\n\nQueste indicazioni si riferiscono alla valutazione di oggi e non sostituiscono il medico curante. Se compaiono sintomi nuovi o il disturbo peggiora torni in Pronto Soccorso anche prima dei tempi indicati; chiami il 112 se il sintomo è grave o improvviso e non si metta alla guida. Porti con sé questo foglio, la documentazione consegnata e l'elenco dei farmaci che assume, allergie comprese. Attenzione ai preparati per l'influenza: contengono già paracetamolo."},"colica-renale":{"nome":"Colica renale","rivisto":true,"testo":"COLICA RENALE — INDICAZIONI ALLA DIMISSIONE\n\nFARMACI\n- Metoclopramide 10 mg, 1 compressa fino a 3 volte al giorno.\n- Tamsulosina 0,4 mg dopo cena: si alzi lentamente e non la associ a farmaci per l'erezione.\n- Cefixoral 400 mg, 1 compressa al giorno per 5 giorni.\n\nSE DOLORE\n- Ketoprofene sale di lisina 80 mg (1 bustina) fino a 3 volte al giorno, a stomaco pieno (in alternativa ibuprofene 600 mg fino a 3 volte al giorno).\n- Se il dolore non è controllato, insieme al ketoprofene: Tachidol 500/30 mg, 1 bustina al bisogno, massimo 3 volte al giorno.\n- In alternativa, sospendere quanto sopra e assumere Lenizak 75/25, 1 bustina fino a 3 volte al giorno.\n\nCOSA FARE A CASA\n- Bere normalmente, 1,5–2 litri al giorno: non deve forzarsi a bere di più, ma nemmeno bere di meno.\n- Filtrare l'urina (con un filtro da caffè americano) se possibile e conservare il calcolo espulso per l'analisi.\n- Il calcolo può essere espulso in giorni o settimane: un nuovo episodio di dolore è possibile.\n\nTORNI SUBITO IN PRONTO SOCCORSO SE\n- Febbre o brividi: possono indicare un rene ostruito e infetto. Chiami il 112.\n- Dolore che non passa con la terapia.\n- Vomito che impedisce di assumere i farmaci.\n- Urina assente o molto ridotta.\n\nCONTROLLI\n- Ecografia addome completo entro 5 giorni.\n- Visita urologica in 7–14 giorni, con esami e documentazione del Pronto Soccorso.\n- Se il calcolo non viene espulso entro 4 settimane serve comunque una rivalutazione.\n\nQueste indicazioni si riferiscono alla valutazione di oggi e non sostituiscono il medico curante. Se compaiono sintomi nuovi o il disturbo peggiora torni in Pronto Soccorso anche prima dei tempi indicati; chiami il 112 se il sintomo è grave o improvviso e non si metta alla guida. Porti con sé questo foglio, la documentazione consegnata e l'elenco dei farmaci che assume, allergie comprese. Attenzione ai preparati per l'influenza: contengono già paracetamolo."},"cistite":{"nome":"Cistite non complicata","rivisto":true,"testo":"CISTITE NON COMPLICATA — INDICAZIONI ALLA DIMISSIONE\n(indicazioni per la donna non in gravidanza; nell'uomo la cistite va sempre rivalutata dal medico)\n\nANTIBIOTICO\n- Se nitriti presenti: fosfomicina 3 g, una sola bustina sciolta in un bicchiere d'acqua, la sera prima di coricarsi dopo aver urinato, lontano dai pasti. Una dose sola è tutta la cura.\n- Cefixoral 400 mg, 1 compressa al giorno per 5 giorni.\n\nSINTOMI\n- Paracetamolo 1 g ogni 8 ore (massimo 3 g al giorno) oppure ibuprofene 400 mg fino a 3 volte al giorno per bruciore e dolore.\n- Bere 1,5–2 litri al giorno e urinare spesso, senza trattenere.\n\nSE È O POTREBBE ESSERE IN GRAVIDANZA\n- Lo dica subito: non prenda ibuprofene, servono un esame delle urine con antibiogramma e un controllo dopo la terapia. Usi solo paracetamolo e non assuma antibiotici di sua iniziativa.\n\nPER EVITARE CHE TORNI\n- Urinare dopo i rapporti sessuali.\n- Evitare lavande vaginali e detergenti aggressivi.\n\nTORNI IN PRONTO SOCCORSO SE\n- Febbre oltre 38 °C, brividi, dolore al fianco o alla schiena: possibile infezione del rene.\n- Vomito che impedisce di assumere l'antibiotico.\n\nCONTROLLO\nDal medico di base se:\n- I sintomi non migliorano dopo 48–72 ore di terapia.\n- Sangue nelle urine che persiste a terapia finita.\n- Se i sintomi scompaiono non serve un esame delle urine di controllo.\n- Se i sintomi non passano o tornano entro 2 settimane, serve un esame delle urine con antibiogramma prima di riprendere l'antibiotico.\n- Se gli episodi si ripetono (3 o più in un anno).\n\nQueste indicazioni si riferiscono alla valutazione di oggi e non sostituiscono il medico curante. Se compaiono sintomi nuovi o il disturbo peggiora torni in Pronto Soccorso anche prima dei tempi indicati; chiami il 112 se il sintomo è grave o improvviso e non si metta alla guida. Porti con sé questo foglio, la documentazione consegnata e l'elenco dei farmaci che assume, allergie comprese. Attenzione ai preparati per l'influenza: contengono già paracetamolo."},"trauma-cranico-minore":{"nome":"Trauma cranico minore","rivisto":true,"testo":"TRAUMA CRANICO MINORE — INDICAZIONI ALLA DIMISSIONE\n\nSE ASSUME ANTICOAGULANTI O CARDIOASPIRINA\n- Non resti solo nelle prossime 24 ore e torni in Pronto Soccorso per qualsiasi sintomo nuovo, anche solo mal di testa.\n- Non sospenda di sua iniziativa l'anticoagulante o la cardioaspirina.\n- Il sanguinamento può comparire anche dopo 3–7 giorni.\n\nLE PROSSIME 24–48 ORE\n- Non resti solo: una persona adulta deve poterla assistere.\n- Può dormire normalmente. Chi assiste deve solo verificare che respiri regolarmente e che si svegli facilmente chiamandolo; se non si sveglia facilmente, chiami subito il 112.\n- Riposo nelle prime 24–48 ore, poi ripresa graduale.\n- Niente alcol, niente sonniferi o sedativi.\n- Non guidare, non usare macchinari, non fare sport finché i sintomi non sono scomparsi. Ritorno allo sport per gradi.\n\nFARMACI\n- Per il mal di testa usi solo paracetamolo 1 g ogni 8 ore (massimo 3 g al giorno).\n- Non prenda antinfiammatori (ibuprofene, ketoprofene, aspirina come antidolorifico) per una settimana.\n\nCHIAMI IL 112 SE COMPARE ANCHE UNO SOLO DI QUESTI (non si metta alla guida)\n- Mal di testa che peggiora e non passa con il paracetamolo.\n- Vomito ripetuto.\n- Sonnolenza insolita o difficoltà a svegliarsi.\n- Confusione, difficoltà a parlare, vista doppia, pupille di dimensione diversa, debolezza o formicolio a un braccio o a una gamba, perdita di equilibrio.\n- Convulsioni.\n- Sangue o liquido chiaro dal naso o dalle orecchie.\n\nNELLE SETTIMANE SUCCESSIVE\n- Sopra i 65 anni o in terapia anticoagulante i sintomi possono comparire anche dopo 2–6 settimane: mal di testa persistente, sonnolenza, cambiamento di carattere o difficoltà a camminare vanno rivalutati dal medico.\n\nCONTROLLO\n- Medico curante se mal di testa, stanchezza, difficoltà di concentrazione o irritabilità durano oltre una settimana.\n\nQueste indicazioni si riferiscono alla valutazione di oggi e non sostituiscono il medico curante. Se compaiono sintomi nuovi o il disturbo peggiora torni in Pronto Soccorso anche prima dei tempi indicati; chiami il 112 se il sintomo è grave o improvviso e non si metta alla guida. Porti con sé questo foglio, la documentazione consegnata e l'elenco dei farmaci che assume, allergie comprese. Attenzione ai preparati per l'influenza: contengono già paracetamolo."},"artrosi":{"nome":"Artrosi (fase dolorosa)","testo":"ARTROSI IN FASE DOLOROSA — INDICAZIONI ALLA DIMISSIONE\n\nLA CURA PRINCIPALE È IL MOVIMENTO\n- Camminare in piano ogni giorno, secondo tolleranza: il riposo assoluto peggiora l'artrosi.\n- Esercizi quotidiani di rinforzo della coscia (li insegna il fisioterapista o il medico curante).\n- Evitare solo ciò che provoca dolore forte.\n- Perdere peso quando indicato: ogni chilo in meno scarica il ginocchio in modo significativo.\n- Bastone dal lato opposto all'articolazione dolente, se serve.\n- Ghiaccio 15–20 minuti 2–3 volte al giorno in fase acuta; calore se prevale la rigidità.\n\nFARMACI\n- Gel antinfiammatorio localmente 2–3 volte al giorno: è la prima scelta, più sicuro degli antinfiammatori per bocca. Non esporre al sole la zona trattata durante la cura e nelle 2 settimane successive.\n- Paracetamolo 1 g ogni 8 ore (massimo 3 g al giorno; massimo 2 g sopra i 75 anni, sotto i 50 kg, con problemi di fegato o se beve alcolici).\n- Se non basta: ibuprofene 400–600 mg fino a 3 volte al giorno a stomaco pieno, per pochi giorni, con un farmaco che protegge lo stomaco.\n\nQUANDO NON PRENDERE ANTINFIAMMATORI PER BOCCA\n- Se prende anticoagulanti (warfarin, apixaban, rivaroxaban, edoxaban, dabigatran) o due antiaggreganti: in questi casi NON vanno presi in nessun caso, nemmeno con il gastroprotettore. Usi paracetamolo e gel locale.\n- Problemi di reni, scompenso cardiaco, pressione alta non controllata, ulcera.\n\nTORNI IN PRONTO SOCCORSO SE\n- Articolazione calda, molto gonfia e arrossata, con febbre: possibile infezione.\n- Articolazione che si gonfia improvvisamente senza trauma.\n- Impossibilità totale di caricare il peso, o deformità dopo una caduta.\n- Feci nere o vomito con sangue: sospenda l'antinfiammatorio e venga subito.\n\nCONTROLLO\n- Medico curante entro 1–2 settimane per la terapia di fondo e la fisioterapia.\n- Valutazione ortopedica se il dolore limita la vita quotidiana nonostante la terapia.\n\nQueste indicazioni si riferiscono alla valutazione di oggi e non sostituiscono il medico curante. Se compaiono sintomi nuovi o il disturbo peggiora torni in Pronto Soccorso anche prima dei tempi indicati; chiami il 112 se il sintomo è grave o improvviso e non si metta alla guida. Porti con sé questo foglio, la documentazione consegnata e l'elenco dei farmaci che assume, allergie comprese. Attenzione ai preparati per l'influenza: contengono già paracetamolo."},"lombalgia":{"nome":"Lombalgia acuta","testo":"MAL DI SCHIENA ACUTO — INDICAZIONI ALLA DIMISSIONE\n\nCOSA SAPERE\n- Nella grande maggioranza dei casi non c'è una lesione grave e il dolore migliora in 2–6 settimane.\n- Le radiografie non servono nel mal di schiena semplice: non cambiano la cura.\n\nCOSA FARE\n- Restare attivi: continuare le normali attività riducendo ciò che fa male. Il riposo a letto oltre 1–2 giorni PEGGIORA il dolore.\n- Camminare ogni giorno e alzarsi spesso se si sta seduti a lungo.\n- Calore locale 20 minuti più volte al giorno.\n\nFARMACI\n- Ibuprofene 400–600 mg fino a 3 volte al giorno a stomaco pieno per 5–7 giorni, oppure ketoprofene sale di lisina 80 mg 2 volte al giorno.\n- Paracetamolo 1 g ogni 8 ore, associabile (massimo 3 g al giorno; 2 g sopra i 75 anni, sotto i 50 kg, con problemi di fegato o se beve alcolici).\n- Farmaco che protegge lo stomaco se prende antinfiammatori per più giorni, ha più di 65 anni, ha avuto ulcera o gastrite, o prende cortisone o cardioaspirina.\n- Se le è stato prescritto un farmaco che rilassa i muscoli (tiocolchicoside 4 mg 2 volte al giorno): non più di 7 giorni, mai in gravidanza, allattamento o in età fertile senza contraccezione sicura. Dà sonnolenza: non guidi, non usi macchinari, non beva alcolici.\n\nTORNI IN PRONTO SOCCORSO SE\n- Difficoltà a urinare, o perdita di urina o feci.\n- Perdita di sensibilità nella zona genitale o all'interno delle cosce.\n- Debolezza di una gamba che peggiora.\n- Febbre insieme al mal di schiena.\n- Dolore che non si calma nemmeno da sdraiati o che sveglia di notte.\n\nCONTATTI PRESTO IL MEDICO SE\n- Ha avuto un tumore, prende cortisone, ha osteoporosi, ha perso peso senza motivo, oppure ha più di 65 anni e il dolore è comparso dopo una caduta.\n\nCONTROLLO\n- Medico curante se il dolore non migliora in 7–10 giorni o si accompagna a dolore lungo la gamba.\n\nQueste indicazioni si riferiscono alla valutazione di oggi e non sostituiscono il medico curante. Se compaiono sintomi nuovi o il disturbo peggiora torni in Pronto Soccorso anche prima dei tempi indicati; chiami il 112 se il sintomo è grave o improvviso e non si metta alla guida. Porti con sé questo foglio, la documentazione consegnata e l'elenco dei farmaci che assume, allergie comprese. Attenzione ai preparati per l'influenza: contengono già paracetamolo."},"distorsione-caviglia":{"nome":"Distorsione di caviglia","testo":"DISTORSIONE DI CAVIGLIA — INDICAZIONI ALLA DIMISSIONE\n\nPRIME 48–72 ORE\n- Ghiaccio 15–20 minuti ogni 2–3 ore, mai a contatto diretto con la pelle.\n- Bendaggio elastico durante il giorno, da togliere la notte.\n- Gamba sollevata sopra il livello del cuore da seduti o sdraiati.\n- Appoggiare il piede quanto il dolore permette, aiutandosi con le stampelle all'inizio.\n\nFARMACI\n- Paracetamolo 1 g ogni 8 ore (massimo 3 g al giorno; 2 g sopra i 75 anni, sotto i 50 kg, con problemi di fegato o se beve alcolici).\n- Ibuprofene 400–600 mg fino a 3 volte al giorno a stomaco pieno per 3–5 giorni; gel antinfiammatorio localmente 2–3 volte al giorno.\n- Non prenda antinfiammatori in gravidanza, con anticoagulanti, ulcera o problemi di reni.\n\nDOPO I PRIMI GIORNI\n- Riprendere gradualmente il movimento: la caviglia rigida guarisce peggio.\n- Esercizi: muovere il piede su e giù, disegnare l'alfabeto con l'alluce, più volte al giorno; poi equilibrio su un piede solo.\n- Tornare allo sport quando si cammina e si corre senza dolore né gonfiore, di solito in 2–6 settimane; cavigliera negli sport per i 6 mesi successivi riduce le recidive.\n\nTORNI IN PRONTO SOCCORSO SE\n- Polpaccio dolente, gonfio e caldo, oppure affanno improvviso o dolore al torace.\n- Dolore sopra la caviglia lungo la gamba, vicino al ginocchio sul lato esterno, o sul bordo esterno del piede: possono essere fratture non visibili all'inizio.\n- Impossibilità di appoggiare il piede dopo 3–4 giorni.\n- Deformità evidente, formicolii persistenti, piede freddo o pallido.\n- Dolore o gonfiore che peggiorano dopo il terzo giorno.\n\nCONTROLLO\n- Medico curante o visita ortopedica se dopo 7–10 giorni persistono dolore o instabilità.\n- Se le è stato messo un tutore o un gesso, chieda al medico curante se le serve una puntura anticoagulante.\n\nQueste indicazioni si riferiscono alla valutazione di oggi e non sostituiscono il medico curante. Se compaiono sintomi nuovi o il disturbo peggiora torni in Pronto Soccorso anche prima dei tempi indicati; chiami il 112 se il sintomo è grave o improvviso e non si metta alla guida. Porti con sé questo foglio, la documentazione consegnata e l'elenco dei farmaci che assume, allergie comprese. Attenzione ai preparati per l'influenza: contengono già paracetamolo."},"faringotonsillite":{"nome":"Faringite / mal di gola","testo":"MAL DI GOLA — INDICAZIONI ALLA DIMISSIONE\n\nCOSA SAPERE\n- La maggior parte dei mal di gola è virale e guarisce da sola in 5–7 giorni: l'antibiotico non serve e non accorcia i tempi.\n- L'antibiotico serve solo nelle forme da streptococco, quando lo indica il medico: in quel caso va completato tutto il ciclo.\n\nFARMACI\n- Paracetamolo 1 g ogni 8 ore (massimo 3 g al giorno; 2 g sopra i 75 anni, sotto i 50 kg, con problemi di fegato o se beve alcolici), oppure ibuprofene 400–600 mg fino a 3 volte al giorno a stomaco pieno.\n- Non prenda insieme bustine o compresse per l'influenza e il raffreddore: contengono già paracetamolo.\n- Bevande fresche o tiepide, ghiaccioli, miele (non sotto l'anno di età).\n\nCOSA FARE\n- Riposo relativo, bere spesso, non fumare.\n- Rientro al lavoro o a scuola dopo almeno 24 ore di antibiotico E almeno 24 ore senza febbre.\n\nTORNI IN PRONTO SOCCORSO SE\n- Difficoltà a respirare, voce ovattata come se avesse qualcosa in bocca, saliva che cola perché non riesce a deglutire.\n- Impossibilità a deglutire anche i liquidi.\n- Difficoltà ad aprire la bocca, gonfiore del collo, dolore forte da un lato solo.\n- Macchie rosse o violacee che NON scompaiono premendoci sopra un bicchiere trasparente.\n- Febbre che dura oltre 5 giorni o che ricompare dopo il miglioramento.\n- Gonfiore del viso, orticaria o affanno dopo l'antibiotico: lo sospenda e chiami il 112.\n\nATTENZIONE PARTICOLARE\n- Se assume metimazolo (per la tiroide), clozapina, immunosoppressori o chemioterapia, un mal di gola con febbre richiede un emocromo urgente: lo dica subito al medico.\n\nCONTROLLO\n- Medico curante se non migliora in 5 giorni.\n\nQueste indicazioni si riferiscono alla valutazione di oggi e non sostituiscono il medico curante. Se compaiono sintomi nuovi o il disturbo peggiora torni in Pronto Soccorso anche prima dei tempi indicati; chiami il 112 se il sintomo è grave o improvviso e non si metta alla guida. Porti con sé questo foglio, la documentazione consegnata e l'elenco dei farmaci che assume, allergie comprese."}};
  // Esame obiettivo: modelli PER IL MEDICO, da incollare nella cartella.
  // Non escono mai dal computer e non contengono dati di nessun paziente.
  const EO = {"base":{"nome":"EO generale","meta":"completo, tutto negativo","testo":"Vigile, orientato, eupnoico, normocolorito, ben perfuso, apiretico. Non segni di distress. Torace: MV normotrasmesso bilateralmente, non rumori patologici aggiunti. Cuore: toni ritmici, validi, non soffi. Polsi periferici presenti e simmetrici. Addome: piano, trattabile, non dolente né dolorabile, peristalsi presente, Blumberg e Murphy negativi, Giordano negativo bilateralmente. Non masse, non organomegalie. Arti inferiori: non edemi, non segni di TVP, polpacci indolori. Neuro: non deficit focali, forza e sensibilità conservate ai 4 arti, non segni meningei. Cute: integra, non lesioni, non esantemi."},"casi":[{"k":"toracico","nome":"Dolore toracico","testo":"Dolore non riproducibile alla palpazione della parete / riproducibile. Toni validi, non sfregamenti. Polsi radiali e femorali simmetrici, PA comparativa agli arti superiori [dx/sx]. Non turgore giugulare. Non edemi. Polpacci indolori simmetrici."},{"k":"dispnea","nome":"Dispnea","testo":"Utilizzo dei muscoli accessori sì/no, parla per frasi intere. MV ridotto alle basi con crepitii bibasali fino a [livello] / sibili diffusi espiratori. Non ottusità plessica. Turgore giugulare. Edemi declivi improntabili fino a [livello]. Polpacci simmetrici."},{"k":"addominale","nome":"Dolore addominale","testo":"Blumberg, Rovsing, Murphy, Giordano, psoas. Non difesa, non peritonismo. Non masse pulsanti (AAA). Orifizi erniari liberi. Peristalsi presente/torpida."},{"k":"cefalea","nome":"Cefalea","testo":"Non segni meningei (Kernig, Brudzinski negativi). Pupille isocoriche isocicliche normoreagenti. Nervi cranici indenni. Non deficit focali, non atassia, Romberg negativo. arterie temporali non dolenti (>50 anni)."},{"k":"trauma","nome":"Trauma / caduta","testo":"Non ferite lacerocontuse. Rachide cervicale non dolente alla palpazione della linea mediana, ROM conservato (criteri NEXUS soddisfatti). Bacino stabile. Non dolorabilità sternale né costale. Arti: assi conservati, non deformità, articolarità e polsi distali conservati, sensibilità integra. Sempre: polso distale + sensibilità + motilità distalmente alla lesione."},{"k":"sincope","nome":"Sincope","testo":"PA in clino e ortostatismo [valori], toni validi non soffi, polsi simmetrici, non deficit neurologici, esplorazione rettale negativa per melena se indicata."},{"k":"lombalgia","nome":"Lombalgia","testo":"Lasègue negativo bilateralmente, forza 5/5 ai distretti L2-S1, ROT rotulei e achillei normoevocabili simmetrici, sensibilità conservata, non anestesia a sella, tono sfinteriale conservato, non globo vescicale (cauda equina)"},{"k":"vertigine","nome":"Vertigine","testo":"Nistagmo [assente/orizzontale con fase rapida verso...], HINTS: head impulse [ ], nistagmo direzione fissa/mutevole, skew deviation assente. Marcia e Romberg [ ]. Non dismetria, non deficit focali."},{"k":"pediatrico","nome":"Pediatrico","testo":"Bambino vivace, reattivo, consolabile, colorito valido, refill capillare <2s, non segni di disidratazione (mucose umide, lacrimazione presente, diuresi riferita normale). Non esantemi, non petecchie. Fontanella normotesa. Non segni meningei."}],"frasi":[{"k":"rettale","nome":"Rettale non eseguita","testo":"Esplorazione rettale non eseguita per rifiuto del paziente"},{"k":"collaborazione","nome":"Neuro poco collaborante","testo":"esame neurologico limitato dalla scarsa collaborazione"},{"k":"nexus","nome":"NEXUS: niente collare","testo":"criteri NEXUS applicabili, non necessaria immobilizzazione"},{"k":"allarme","nome":"Segni d'allarme spiegati","testo":"Paziente informato dei segni d'allarme (elencati), che dichiara di aver compreso, con indicazione a tornare in PS."}]};

  // ================================================================ UTILS
  const sleep = (ms, signal) => new Promise((res, rej) => {
    const t = setTimeout(res, ms);
    if (signal) signal.addEventListener("abort", () => { clearTimeout(t); rej(new DOMException("Aborted", "AbortError")); }, { once: true });
  });
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const now = () => new Date().toLocaleTimeString("it-IT");

  // Copiare negli appunti. navigator.clipboard non esiste sulle origini non
  // sicure (il portale clinico è http://): lì si passa dal vecchio
  // execCommand, che invece funziona. Un pulsante «copia» non deve dipendere
  // da quale delle due pagine si ha davanti.
  // il lampo sul pulsante dopo una copia: era ricopiato in sette punti
  function segnaCopia(b, ok, riposo = "⧉ Copia", ms = 2000) {
    if (!b) return ok;
    b.textContent = ok ? "✓ copiato" : "non riuscito";
    setTimeout(() => { if (b.isConnected) b.textContent = riposo; }, ms);
    return ok;
  }
  async function copiaTesto(text) {
    const t = String(text ?? "");
    try { await navigator.clipboard.writeText(t); return true; } catch { /* ripiego qui sotto */ }
    let ok = false;
    try {
      const ta = document.createElement("textarea");
      ta.value = t;
      ta.style.cssText = "position:fixed;left:-9999px;top:0";
      document.body.appendChild(ta);
      ta.select();
      ok = document.execCommand("copy");
      ta.remove();
    } catch { ok = false; }
    return ok;
  }

  // Controlled hard-stop carrying a headline + body the UI can render loudly.
  class StopError extends Error {
    constructor(head, body = "") { super(body ? `${head} — ${body}` : head); this.head = head; this.body = body; }
  }

  // --- banco di prova (offline) --------------------------------------------
  // A page that is NOT the hospital may provide these hooks to run the panel
  // against a simulator (tools/demo.mjs). The host check comes first, so on
  // the real system the hooks do not exist and nothing served by SA4PSO can
  // take over navigation, tabs or printing.
  const DEMO = (location.hostname !== "smarthealth.multimedica.it" && window.__PSA_DEMO__) || null;
  // Una pagina a cui ci ha portato il PANNELLO si apre con la finestra
  // aperta; una a cui è arrivato il medico dal gestionale, con la pill.
  const nav = (url) => {
    try { sessionStorage.setItem("psassist:navPannello.v1", JSON.stringify(Date.now())); } catch { /* niente */ }
    if (DEMO && DEMO.nav) return DEMO.nav(url);
    location.href = url;
  };
  const openTab = (url, name) => (DEMO && DEMO.open ? DEMO.open(url, name) : window.open(url, name));

  // Il medico sta scrivendo nel gestionale? Una navigazione decisa dal
  // programma (errore → carrello, revisione, conferma sospesa) non deve mai
  // portarsi via quello che ha sotto le dita: un campo col cursore dentro, un
  // campo cambiato e non salvato, un tasto premuto da poco. Allora non si va:
  // lo dice la pill, e un tocco porta dove si sarebbe andati.
  const TASTO_MS = 15e3;
  const scrittura = { tasto: 0, cambiato: false, toccato: false, nostri: new WeakSet(), attivo: false };
  const dalGestionale = (e) => e.isTrusted && !(e.composedPath ? e.composedPath() : []).some((x) => x && x.id === "psassist-host");
  const NON_SCRITTURA = /^(button|submit|reset|image|hidden|checkbox|radio|file|range|color)$/i;
  const eCampo = (el) => !!el && el.id !== "psassist-host" && (el.isContentEditable || el.tagName === "TEXTAREA" || el.tagName === "SELECT"
    || (el.tagName === "INPUT" && !NON_SCRITTURA.test(el.type || "")));
  function osservaScrittura() {
    if (scrittura.attivo) return;
    scrittura.attivo = true;
    document.addEventListener("keydown", (e) => { if (dalGestionale(e)) { scrittura.tasto = Date.now(); scrittura.toccato = true; } }, true);
    // il cursore in un campo conta se ce l'ha messo lui (un campo col fuoco
    // automatico, appena caricata la pagina, non è qualcuno che scrive)
    document.addEventListener("pointerdown", (e) => { if (dalGestionale(e)) scrittura.toccato = true; }, true);
    const cambia = (e) => { if (dalGestionale(e) && eCampo(e.target)) scrittura.cambiato = true; };
    document.addEventListener("input", cambia, true);
    document.addEventListener("change", cambia, true);
  }
  // perché adesso non si cambia pagina ("" = si può)
  function staScrivendo() {
    if (scrittura.toccato && eCampo(document.activeElement)) return "cursore in un campo";
    if (scrittura.cambiato) return "un campo modificato";
    // il testo scritto prima che il programma arrivasse (il bookmarklet si clicca dopo)
    for (const t of document.querySelectorAll("textarea")) {
      if (!scrittura.nostri.has(t) && t.value !== t.defaultValue) return "un campo modificato";
    }
    if (Date.now() - scrittura.tasto < TASTO_MS) return "un tasto premuto da poco";
    return "";
  }

  function param(url, name) {
    try { return new URL(url, location.href).searchParams.get(name); } catch { return null; }
  }

  // --- windows-1252 form body encoder --------------------------------------
  // application/x-www-form-urlencoded in the page charset, like a real form
  // submit: space → "+", bytes outside the safe set → %XX of the win1252
  // byte, characters not representable in win1252 → HTML numeric reference.
  const W1252_EXTRA = { // unicode → win1252 byte for the 0x80–0x9F specials
    0x20AC: 0x80, 0x201A: 0x82, 0x0192: 0x83, 0x201E: 0x84, 0x2026: 0x85,
    0x2020: 0x86, 0x2021: 0x87, 0x02C6: 0x88, 0x2030: 0x89, 0x0160: 0x8A,
    0x2039: 0x8B, 0x0152: 0x8C, 0x017D: 0x8E, 0x2018: 0x91, 0x2019: 0x92,
    0x201C: 0x93, 0x201D: 0x94, 0x2022: 0x95, 0x2013: 0x96, 0x2014: 0x97,
    0x02DC: 0x98, 0x2122: 0x99, 0x0161: 0x9A, 0x203A: 0x9B, 0x0153: 0x9C,
    0x017E: 0x9E, 0x0178: 0x9F,
  };
  function encodeW1252Component(str) {
    let out = "";
    for (const ch of String(str)) {
      const cp = ch.codePointAt(0);
      let byte = null;
      if (cp <= 0x7F) byte = cp;
      else if (cp >= 0xA0 && cp <= 0xFF) byte = cp;
      else if (W1252_EXTRA[cp] !== undefined) byte = W1252_EXTRA[cp];
      if (byte === null) { out += encodeW1252Component(`&#${cp};`); continue; }
      if (byte === 0x20) out += "+";
      else if ((byte >= 0x30 && byte <= 0x39) || (byte >= 0x41 && byte <= 0x5A) || (byte >= 0x61 && byte <= 0x7A) || byte === 0x2A || byte === 0x2D || byte === 0x2E || byte === 0x5F) {
        out += String.fromCharCode(byte);
      } else out += "%" + byte.toString(16).toUpperCase().padStart(2, "0");
    }
    return out;
  }
  const encodeFormBody = (pairs) => pairs.map(([k, v]) => encodeW1252Component(k) + "=" + encodeW1252Component(v)).join("&");

  // --- fetch + parse --------------------------------------------------------
  // Returns {doc, url} where url is the FINAL response URL — every href or
  // action extracted from doc must be resolved against it (DOMParser docs
  // inherit the creating page's URL, which is NOT the fetched page's URL).
  async function fetchDoc(url, { method = "GET", body = null, signal } = {}) {
    // Enforce, not just promise, that nothing ever leaves the hospital origin.
    const target = new URL(url, location.href);
    if (target.origin !== location.origin) {
      throw new StopError("Richiesta fuori dall'ospedale bloccata", `destinazione inattesa: ${target.origin}`);
    }
    // Own timeout composition (AbortSignal.any needs Chrome 116+; hospital
    // Chromes can be older and a hung request must never hang the run).
    const ctl = new AbortController();
    const tid = setTimeout(() => ctl.abort(new DOMException("Timeout", "TimeoutError")), TIMEOUT_MS);
    const onAbort = () => ctl.abort(new DOMException("Aborted", "AbortError"));
    if (signal) {
      if (signal.aborted) { clearTimeout(tid); throw new DOMException("Aborted", "AbortError"); }
      signal.addEventListener("abort", onAbort, { once: true });
    }
    let res, buf;
    try {
      res = await fetch(target.href, {
        method, body, signal: ctl.signal,
        credentials: "same-origin",
        cache: "no-store",
        redirect: "follow",
        headers: method === "POST" ? { "Content-Type": "application/x-www-form-urlencoded" } : undefined,
      });
      // La scadenza e lo STOP devono coprire ANCHE il corpo: il vecchio
      // finally li spegneva appena arrivavano le intestazioni, e un corpo che
      // non arriva mai lasciava la corsa appesa senza modo di fermarla.
      if (new URL(res.url || target.href).origin !== location.origin) {
        throw new StopError("Risposta fuori dall'ospedale bloccata", `destinazione inattesa: ${res.url}`);
      }
      if (!res.ok) throw new StopError(`Il server ha risposto HTTP ${res.status}`, res.statusText || "");
      buf = await res.arrayBuffer();
    } finally {
      clearTimeout(tid);
      if (signal) signal.removeEventListener("abort", onAbort);
    }
    const ct = res.headers.get("content-type") || "";
    const m = /charset=([\w-]+)/i.exec(ct);
    let charset = (m ? m[1] : "windows-1252").toLowerCase();
    let text;
    try { text = new TextDecoder(charset).decode(buf); }
    catch { text = new TextDecoder("windows-1252").decode(buf); }
    const doc = new DOMParser().parseFromString(text, "text/html");
    return { doc, url: res.url || String(url) };
  }

  const absUrl = (el, attr, baseUrl) => {
    const raw = el.getAttribute(attr);
    return raw ? new URL(raw, baseUrl).href : baseUrl;
  };

  // --- form serialization (browser semantics) -------------------------------
  // Successful controls in tree order; only the activated submit button is
  // included. Select values honour "last selected wins" explicitly, because
  // the server emits duplicate `selected` attributes on some pages.
  // Both live documents and DOMParser documents resolve duplicate `selected`
  // attributes with "last one wins" during parsing, so the value/selectedOptions
  // IDL properties are already correct — use them, never the attributes.
  function selectValue(sel) {
    if (sel.multiple) return [...sel.selectedOptions].map((o) => o.value);
    return sel.value;
  }
  function serializeForm(form, submitEl) {
    const pairs = [];
    for (const el of form.elements) {
      if (!el.name || el.disabled) continue;
      const type = (el.type || "").toLowerCase();
      if (type === "submit" || type === "button" || type === "image" || type === "reset") {
        if (el === submitEl) pairs.push([el.name, el.value ?? ""]);
        continue;
      }
      if ((type === "checkbox" || type === "radio") && !el.checked) continue;
      if (el.tagName === "SELECT") {
        const v = selectValue(el);
        if (Array.isArray(v)) v.forEach((x) => pairs.push([el.name, x]));
        else pairs.push([el.name, v]);
        continue;
      }
      if (type === "file") continue;
      pairs.push([el.name, el.value ?? ""]);
    }
    return pairs;
  }

  // ============================================================ PAGE MODELS
  function classify(doc) {
    if (doc.querySelector('form[name="RICHIESTACrea"]')) return "crea";
    if (doc.querySelector('form[name="Prestazioni"]')) return "exam";
    if (doc.querySelector('form[name="AmbulatorioPSO"]') ||
        doc.querySelector('a[title="Richieste Laboratorio"], a[title="Richieste Radiologia"]')) return "patient";
    if (doc.querySelector('input[type="password"]')) return "login";
    return "other";
  }

  // Episode id as stated by the SERVER inside the page (links/forms).
  function findEpisodeIdInDoc(doc) {
    const el = doc.querySelector('a[href*="EPISODIO_ID="], form[action*="EPISODIO_ID="]');
    if (el) {
      const raw = el.getAttribute("href") || el.getAttribute("action") || "";
      const m = /[?&]EPISODIO_ID=([^&]+)/.exec(raw);
      if (m) return decodeURIComponent(m[1]);
    }
    return null;
  }
  function findEpisodeId(doc, baseUrl) {
    return param(baseUrl, "EPISODIO_ID") || findEpisodeIdInDoc(doc);
  }

  // Lab names as they are read at a glance. The LIS writes them out in full
  // ("MCH Cont. Media Hgb"), which is unreadable in a two-line preview: what a
  // doctor scans is the short form and the number.
  const SIGLE = [
    [/^leucociti|^globuli bianchi|^wbc/i, "GB"],
    // l'emoglobina glicata è un'altra grandezza in un'altra unità: non deve
    // mai finire nella riga dell'Hb accanto a un'emoglobina in g/dL
    [/emoglobina\s*glicat|^hba1c|\bhb\s?a1c\b/i, "HbA1c"],
    [/^emoglobina(?!\s*glicat)|^hgb\b|^hb\b|^c?thb\b/i, "Hb"],
    [/^ematocrito|^hct/i, "Ht"], [/^piastrine|^plt/i, "PLT"], [/^eritrociti|globuli rossi|^rbc/i, "GR"],
    [/^mcv|vol\.? glob/i, "MCV"], [/^mchc/i, "MCHC"], [/^mch\b|cont\.? media/i, "MCH"], [/^rdw/i, "RDW"],
    [/^(granulociti\s+)?eosinofil/i, "Eos"], [/^(granulociti\s+)?basofil/i, "Bas"], [/^granulociti|neutrofil/i, "Neu"], [/^linfocit/i, "Lin"], [/^monocit/i, "Mon"],
    [/^eosinofil/i, "Eos"], [/^basofil/i, "Bas"], [/altre popolazioni/i, "Altre"],
    [/^creatinin/i, "Cr"], [/^azotemia|^urea/i, "Az"], [/^sodio|^na\b/i, "Na"], [/^potassio|^k\b/i, "K"],
    [/^cloro|^cl\b/i, "Cl"], [/calcio ioniz/i, "Ca++"], [/^calcio/i, "Ca"], [/^magnesio/i, "Mg"],
    [/^glucosio|glicemia/i, "Glu"], [/proteina c reattiva|^pcr\b/i, "PCR"], [/procalcitonin/i, "PCT"],
    [/troponina/i, "Trop"], [/d.?dimero/i, "DD"], [/^inr/i, "INR"], [/^pt\b|protrombin/i, "PT"],
    // il rapporto del PTT è un'altra grandezza dei secondi: con la stessa
    // sigla le due righe finivano scritte per esteso, e sembravano un doppione
    [/^a?ptt\s*ratio/i, "PTTr"],
    [/^ptt|tromboplastin/i, "PTT"], [/fibrinogeno/i, "Fib"],
    // "indiretta" contiene "diretta": vanno distinte, o la bilirubina diretta
    // e l'indiretta diventano due righe con la stessa etichetta
    [/bilirubina\s+indiretta|bil\.?\s*indiretta/i, "BilI"],
    [/bilirubina\s+diretta|bil\.?\s*diretta/i, "BilD"],
    [/bilirubina/i, "Bil"], [/^got\b|^ast\b/i, "AST"], [/^gpt\b|^alt\b/i, "ALT"],
    [/gamma\s?gt|^ggt/i, "γGT"], [/fosfatasi alc/i, "ALP"], [/^ldh/i, "LDH"],
    // «cK+» è il potassio dell'emogas: senza questa riga la regola del CPK
    // (^ck) lo prendeva, e il potassio compariva come CPK fra gli enzimi
    [/^c?k\s*\+/i, "K"],
    // gli altri nomi dell'emogas, scritti come li scrive l'emogasanalizzatore
    [/^c?na\s*\+/i, "Na"], [/^c?cl\s*-/i, "Cl"], [/^c?ca\s*(?:2\s*\+|\+\+)/i, "Ca++"],
    [/^c?glu\b/i, "Glu"], [/^cLac\b/, "Lac"],   // «LAC» (lupus anticoagulant) non è lattato
    [/\bck\s?-?\s?mb\b/i, "CKMB"], [/^cpk|creatinchinasi|^ck\b(?!\s?-?\s?mb)/i, "CPK"],
    [/^lipasi/i, "Lip"], [/^amilasi/i, "Amy"],
    [/albuminuria|microalbuminur/i, "Albu"], [/^albumin/i, "Alb"],
    [/nt.?pro.?bnp/i, "NTproBNP"], [/^bnp/i, "BNP"], [/^ves\b/i, "VES"],
    [/^ph\b/i, "pH"], [/pco2|pco₂/i, "pCO2"], [/po2\b|po₂/i, "pO2"], [/hco3|bicarbon/i, "HCO3"],
    [/base excess|^be\b|^eb\b|^[as]be\b|^cbase/i, "BE"],
    [/lattico\s+deidrogen|lattato\s+deidrogen/i, "LDH"],   // prima di "lattat"
    [/lattat/i, "Lac"], [/saturaz|^so2/i, "SatO2"],
    [/carbossiemo|^cohb/i, "COHb"], [/metaemo|^methb/i, "MetHb"], [/^tsh/i, "TSH"],
    [/emogas/i, "EGA"], [/^ammonio|ammoniem/i, "NH3"], [/^mioglobin/i, "Mb"],
    // urine dipstick and blood-gas derivatives: names the portal's multi-day
    // table shows and the Risultati window does not
    [/corpi chetonici|^chetoni/i, "Chet"], [/esterasi leucocit/i, "EstLeu"],
    [/peso specifico/i, "PesoSp"], [/urobilinogen/i, "Urob"], [/^nitriti/i, "Nitr"],
    [/anion gap/i, "AG"], [/^ca\+\+/i, "Ca++"],
    [/^fcohb/i, "FCOHb"], [/^fo2hb|^fo₂hb/i, "FO2Hb"], [/^hhb/i, "HHb"],
    [/^shunt/i, "Shunt"], [/^ctco2|^ctco₂/i, "ctCO2"], [/^cto2|^cto₂/i, "ctO2"],
  ];
  // The portal writes the specimen in front of the analyte: S-ALT, P-Sodio,
  // U-Emoglobina, Lcr-Glucosio. Serum, plasma and blood are what a sigla
  // already means, so they drop; every other specimen STAYS in the label,
  // because urine haemoglobin is not haemoglobin and must never read as Hb.
  const CAMPIONE = /^\s*(S|P|B|Sg|Ser|Pl)\s*-\s*/i;
  const CAMPIONE_ALTRO = /^\s*(U|Lcr|Liq|F|Fec|Exp|Esc)\s*-\s*/i;
  // Le sezioni dello storico. La chiave è la SIGLA (l'uscita di sigla()), non
  // il nome del laboratorio: così bastano poche righe invece di un elenco di
  // sinonimi, e l'ordine dentro ogni sezione è l'ordine in cui si leggono.
  // Chi non è in elenco finisce in «Altri»: non si perde niente, mai.
  const SEZIONI = [
    ["Emocromo", ["GB", "Neu", "Lin", "Mon", "Eos", "Bas", "Altre", "Hb", "Ht", "GR", "MCV", "MCH", "MCHC", "RDW", "PLT"]],
    ["Coagulazione", ["PT", "INR", "PTT", "PTTr", "Fib", "DD"]],
    ["Biochim", ["PCR", "PCT", "VES", "Trop", "NTproBNP", "BNP", "CPK", "CKMB", "Mb", "LDH"]],
    ["Organi", ["Cr", "Az", "AST", "ALT", "γGT", "ALP", "Bil", "BilD", "BilI", "Amy", "Lip", "Alb", "NH3"]],
    ["Elettroliti e metabolismo", ["Na", "K", "Cl", "Ca", "Ca++", "Mg", "Glu", "HbA1c", "TSH"]],
    ["Emogas", ["pH", "pCO2", "pO2", "HCO3", "BE", "Lac", "SatO2", "AG", "ctCO2", "ctO2", "COHb", "MetHb", "FCOHb", "FO2Hb", "HHb", "Shunt", "EGA"]],
    ["Urine e altri liquidi", ["Albu", "PesoSp", "Nitr", "Chet", "EstLeu", "Urob"]],
  ];
  const ALTRI = "Altri";
  // sigla → [sezione, posizione dentro la sezione], costruita una volta sola
  const DOVE = (() => {
    const m = new Map();
    SEZIONI.forEach(([sez, sigle]) => sigle.forEach((s, i) => m.set(s, [sez, i])));
    return m;
  })();
  // Un'abbreviazione che porta il campione (U·Hb, Lcr·Glu) non è quell'analita
  // nel sangue: l'emoglobina delle urine non va nell'emocromo. Il campione
  // decide la sezione prima di tutto il resto.
  function sezioneDi(sg) {
    const s = String(sg || "");
    if (s.includes("·")) return ["Urine e altri liquidi", 900];
    return DOVE.get(s) || [ALTRI, 900];
  }
  // L'emogas è un'altra macchina e un altro campione: Hb, Ht, K, Na, Cl, Ca++
  // e glucosio dell'emogas NON sono quelli dell'emocromo o della chimica.
  // Chi li legge li vuole divisi: stanno nella sezione Emogas, su righe loro,
  // e non si fondono mai con gli stessi analiti fatti in laboratorio. Lo dice
  // l'ESAME che li ha prodotti (EGA venosa, emogasanalisi…), non il nome.
  const eEga = (esame) => /EMOGAS|\bEGA\b/i.test(String(esame || ""));
  const ORDINE_EGA = ["pH", "pCO2", "pO2", "HCO3", "BE", "Lac", "SatO2", "Hb", "Ht", "Na", "K", "Cl", "Ca++", "Glu",
    "AG", "ctCO2", "ctO2", "COHb", "MetHb", "FCOHb", "FO2Hb", "HHb", "Shunt", "EGA"];
  function sezioneRiga(r, sg = sigla(r.nome)) {
    const [sez, ord] = eEga(r.esame) && !String(sg).includes("·") ? ["Emogas", 0] : sezioneDi(sg);
    if (sez !== "Emogas") return [sez, ord];
    const i = ORDINE_EGA.indexOf(sg);
    return ["Emogas", i < 0 ? 900 : i];
  }
  const ordineSezioni = [...SEZIONI.map(([n]) => n), "Urine e altri liquidi", ALTRI]
    .filter((n, i, a) => a.indexOf(n) === i);

  function scomponi(nome) {
    const n = String(nome || "").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim();
    if (CAMPIONE.test(n)) return { pre: "", resto: n.replace(CAMPIONE, "") };
    const m = CAMPIONE_ALTRO.exec(n);
    if (m) return { pre: m[1].toUpperCase() + "·", resto: n.slice(m[0].length) };
    return { pre: "", resto: n };
  }
  function sigla(nome) {
    const n = String(nome || "").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim();
    const { pre, resto } = scomponi(n);
    for (const [re, s] of SIGLE) if (re.test(resto)) return pre + s;
    // Dropping the prefix only pays off when what is left is a name we KNOW.
    // Otherwise that letter was never a specimen: "S-100" is a protein, not
    // serum 100, and "B-12" is a vitamin. Keep the name whole.
    const w = n.split(/[\s(,]+/).filter(Boolean)[0] || n;   // first word, never a paragraph
    return w.length > 9 ? w.slice(0, 8) + "." : w;
  }
  // An abbreviation this program has NOT been taught is a guess, and a guess
  // that looks like a known sigla is how a doctor reads the wrong analyte.
  // Everywhere a guess is shown it is marked, and counted.
  const siglaCurata = (nome) => SIGLE.some(([re]) => re.test(scomponi(nome).resto));
  // Peggio di un nome che non conosciamo: due nomi DIVERSI che nello stesso
  // prelievo escono con la stessa abbreviazione («PTT secondi» e «PTT Ratio»,
  // «Granulociti» e «Granulociti %»). Anche quelli vanno scritti per esteso.
  // (L'Hb dell'emogas e quella dell'emocromo stanno in due sezioni diverse:
  // la stessa sigla non le confonde. Si confondono due righe della STESSA
  // sezione con la stessa sigla — la chiave è quella.)
  const chiaveAmbigua = (r) => sezioneRiga(r)[0] + "|" + sigla(r.nome);
  function sigleAmbigue(rows) {
    const per = new Map();
    for (const r of rows || []) {
      const nome = String(r.nome || "").trim();
      if (!nome) continue;
      const k = chiaveAmbigua(r);
      const set = per.get(k) || new Set();
      set.add(nome + (eEga(r.esame) ? "|ega" : ""));
      per.set(k, set);
    }
    const out = new Set();
    for (const [k, nomi] of per) if (nomi.size > 1) out.add(k);
    return out;
  }
  // Le righe divise in sezioni, in ordine FISSO. L'ordine non deve dipendere da
  // come il laboratorio ha stampato la tabella: se dipendesse, lo stesso esame
  // cambierebbe posto da un prelievo all'altro e lo si cercherebbe ogni volta.
  // La formula leucocitaria arriva in coppia — «Granulociti» (x10³/µL) e
  // «Granulociti %» — e in tabella erano due righe con lo stesso nome, che il
  // medico leggeva come doppioni (e che, per non confonderle, finivano pure
  // scritte per esteso). Diventano UNA riga: il valore assoluto, e fra
  // parentesi la percentuale. Il fuori range è quello dell'assoluto; una
  // percentuale senza assoluto resta da sola («Altre 5.9%»).
  const FORMULA = new Set(["Neu", "Lin", "Mon", "Eos", "Bas", "Altre"]);
  const ePct = (r) => /%/.test(String(r.nome || "")) || (r.valori || []).some((v) => v && String(v.um || "").trim() === "%");
  function fondiFormula(righe) {
    const coppie = new Map();   // sigla → { abs, pct }
    const out = [];
    for (const r of righe || []) {
      const sg = sigla(r.nome);
      if (!FORMULA.has(sg)) { out.push(r); continue; }
      const stelo = valKey(String(r.nome).replace(/[%#]/g, " "));   // «Granulociti %» → «granulociti»
      const c = coppie.get(stelo) || {};
      const lato = ePct(r) ? "pct" : "abs";
      // una terza riga con la stessa sigla non si indovina: resta com'è
      if (c[lato]) { out.push(r); continue; }
      c[lato] = r;
      if (!coppie.has(stelo)) { coppie.set(stelo, c); out.push({ segnaposto: stelo }); }
    }
    return out.map((r) => {
      if (!r.segnaposto) return r;
      const { abs, pct } = coppie.get(r.segnaposto);
      if (!abs || !pct) return abs || pct;
      const n = Math.max(abs.valori.length, pct.valori.length);
      const valori = Array.from({ length: n }, (_, i) => {
        const a = abs.valori[i], q = pct.valori[i];
        if (a && a.v) return { ...a, pct: q && q.v ? String(q.v) : "" };
        // solo la percentuale in quel prelievo: il numero porta il suo «%», e
        // l'unità resta quella dell'assoluto per tutta la riga
        if (q && q.v) return { ...q, v: String(q.v) + "%", um: "" };
        return a || q;
      });
      return { ...abs, valori };
    });
  }

  // Lo stesso esame in due prestazioni della stessa richiesta («EMOCROMO» e
  // «EMOCROMO CON FORMULA») dà le stesse righe due volte, a volte col nome
  // scritto in due modi («MCH Cont. Medio Hgb», «… Media Hgb»): in tabella
  // erano doppioni. Due righe della stessa sezione con la stessa sigla
  // diventano una sola se dicono LA STESSA COSA: tutte e due assolute o
  // tutte e due percentuali, almeno un prelievo in comune e lo stesso valore
  // in ognuno. Un solo valore diverso, e restano due (scritte per esteso).
  function fondiDoppioni(righe) {
    const numero = (x) => (/^-?\d+(?:[.,]\d+)?$/.test(x) ? Number(x.replace(",", ".")) : NaN);
    const uguali = (a, b) => a === b || numero(a) === numero(b);   // «131.0» e «131»: lo stesso numero
    const stessa = (a, b) => {
      let comuni = 0;
      for (let i = 0; i < Math.max(a.valori.length, b.valori.length); i++) {
        const x = String(a.valori[i]?.v || "").trim(), y = String(b.valori[i]?.v || "").trim();
        if (!x || !y) continue;
        if (!uguali(x, y)) return false;
        comuni++;
      }
      return comuni > 0;
    };
    const out = [];
    for (const r of righe || []) {
      const k = chiaveAmbigua(r) + (ePct(r) ? "|%" : "") + (eEga(r.esame) ? "|ega" : "");
      const gemella = out.find((x) => x.k === k && stessa(x.r, r));
      if (!gemella) { out.push({ k, r }); continue; }
      gemella.r = { ...gemella.r, valori: gemella.r.valori.map((v, i) => (v && v.v ? v : r.valori[i] || v)) };
    }
    return out.map((x) => x.r);
  }
  // le righe come si mostrano: prima via i doppioni, poi la formula in coppia
  const righeTabella = (righe) => fondiFormula(fondiDoppioni(righe));

  function raggruppaStorico(righe) {
    const per = new Map();
    for (const r of righe || []) {
      const sg = sigla(r.nome);
      const [sez, ord] = sezioneRiga(r, sg);
      if (!per.has(sez)) per.set(sez, []);
      per.get(sez).push({ ...r, sg, ord });
    }
    const out = [];
    for (const sez of ordineSezioni) {
      const l = per.get(sez);
      if (!l) continue;
      l.sort((a, b) => (a.ord - b.ord) || String(a.sg).localeCompare(String(b.sg), "it"));
      out.push({ nome: sez, righe: l });
      per.delete(sez);
    }
    for (const [sez, l] of per) out.push({ nome: sez, righe: l });   // mai, ma non si perde
    return out;
  }

  // Chi ha fatto quale valore. Quasi sempre una macchina sola, e allora non si
  // segna niente. Quando sono due o più — l'emocromo del POC e quello del
  // laboratorio — la più frequente resta muta e le altre prendono un segno,
  // spiegato sotto la tabella e sul valore stesso.
  const SEGNI = ["*", "†", "‡", "§"];
  // `simboli` è condiviso da tutta la tabella (esame → segno): così «*» vuol
  // dire lo stesso esame in ogni riga, e la legenda lo spiega una volta sola.
  function provenienze(r, simboli = new Map()) {
    const conta = new Map();
    (r.valori || []).forEach((v, i) => {
      if (!v || !v.v) return;
      const e = String(v.esame || r.esame || "").trim();
      if (!e) return;
      const c = conta.get(e) || { n: 0, ultimo: -1 };
      c.n++; c.ultimo = i;                       // date: dal più vecchio al più recente
      conta.set(e, c);
    });
    const nulla = { solita: "", segno: () => "", legenda: [] };
    if (conta.size < 2) return nulla;
    const ord = [...conta.entries()].sort((a, b) => (b[1].n - a[1].n) || (b[1].ultimo - a[1].ultimo));
    const solita = ord[0][0];
    const marchi = new Map();
    ord.slice(1).forEach(([e]) => {
      if (!simboli.has(e)) simboli.set(e, SEGNI[simboli.size] || "•");
      marchi.set(e, simboli.get(e));
    });
    return {
      solita,
      segno: (v) => marchi.get(String((v && v.esame) || r.esame || "").trim()) || "",
      legenda: [...marchi.entries()].map(([esame, segno]) => ({ segno, esame, solita })),
    };
  }

  const nomiInattesi = (rows) => {
    const out = [];
    for (const r of rows || []) {
      const n = String(r.nome || "").trim();
      if (n && !siglaCurata(n) && !out.includes(n)) out.push(n);
    }
    return out;
  };

  // ---- comparing draws -----------------------------------------------------
  // The identity of an analyte across draws: the same name however the
  // laboratory spelled it. Rows of two draws meet on this key.
  // Il campione neutro (S-, P-, B-…) non fa l'identità, come per sigla(): «S-Sodio» del portale
  // e «Sodio» della finestra Risultati sono lo stesso analita — solo se il resto è un nome noto
  // («S-100» resta intero), e U-/Lcr- restano. pCO₂ = pCO2, «Linfociti%» = «Linfociti %».
  const valKey = (nome) => { const n = String(nome || "").replace(/&nbsp;/g, " ").normalize("NFKC"), { pre, resto } = scomponi(n); return (siglaCurata(n) ? pre + resto : n).replace(/[^a-zà-ù0-9%+]+/gi, " ").replace(/\s*%\s*/g, " % ").trim().toLowerCase(); };

  // First ~160 chars of visible page text, for the log when a page is unexpected.
  function snippet(doc) {
    return (doc.body?.textContent || "").replace(/\s+/g, " ").trim().slice(0, 160);
  }

  // Fail-closed episode pinning: crea/exam pages ALWAYS carry EPISODIO_ID in
  // the audited system, so a page without one is itself an anomaly.
  // IMPORTANT: trust the DOCUMENT first — the response URL only echoes the id
  // WE requested, so it is not independent evidence of what the server served.
  function assertSameEpisode(doc, episodeId, what) {
    const found = findEpisodeIdInDoc(doc);
    if (!found) {
      throw restaQui(new StopError(`Episodio non identificabile nella pagina "${what}"`, "Interrotto per sicurezza."));
    }
    if (episodeId && found !== episodeId) {
      throw restaQui(new StopError(`La pagina "${what}" appartiene a un altro episodio (${found} ≠ ${episodeId})`, "Interrotto per sicurezza."));
    }
  }
  // Un errore dopo il quale la scheda NON va portata sul carrello: un episodio
  // che non torna (quel carrello potrebbe essere di un altro paziente), la
  // sessione scaduta, un'altra scheda al lavoro sulla stessa richiesta.
  const restaQui = (err) => { err.restaQui = true; return err; };

  // Patient page: entry links to open a new richiesta.
  function patientModel(doc, baseUrl) {
    const link = (title) => {
      const a = doc.querySelector(`a[title="${title}"]`);
      return a ? absUrl(a, "href", baseUrl) : null;
    };
    return {
      labUrl: link("Richieste Laboratorio"),
      radioUrl: link("Richieste Radiologia"),
    };
  }

  // ------------------------------------------------------------- PRINT MODEL
  // The patient page (and possibly the post-confirm page) lists, per
  // richiesta, the print links audited from the real pages:
  //   "Stampa Etichette"  → RcsStampaEtichetteLISHMIMU.do?RICHIESTA_ID=…  (barcode icon → label PDF)
  //   "Stampa Richiesta"  → /jasperserverSAN/jasperservlet?REPORT=RcsRichiesta&RICHIESTA_ID=…&BRANCA=…
  //   "Stampa Prenotazione Esterna" → jasperservlet, radiology bookings
  // BRANCA varies per richiesta, so these URLs are always READ from the DOM,
  // never constructed.
  // A richiesta whose exams span more than one laboratory is split by the
  // LIS into MULTIPLE rows — same RICHIESTA_ID, different RICHIESTA_PROG —
  // each with its own label PDF and its own exam-list PDF. ALL of them must
  // be printed, so rows are grouped per (RICHIESTA_ID, RICHIESTA_PROG) and
  // never collapsed.
  function printModel(doc, baseUrl) {
    const map = {}; // richiestaId -> { prog -> row, _meta }
    const sel = 'a[title="Stampa Etichette"], a[title="Stampa Richiesta"], a[title="Stampa Prenotazione Esterna"]';
    for (const a of doc.querySelectorAll(sel)) {
      const href = absUrl(a, "href", baseUrl);
      const rid = param(href, "RICHIESTA_ID");
      if (!rid) continue;
      const prog = param(href, "RICHIESTA_PROG") || "1";
      const rows = (map[rid] = map[rid] || { _meta: { ts: 0, when: "", exams: [] } });
      const row = (rows[prog] = rows[prog] || { prog });
      const t = a.getAttribute("title");
      if (t === "Stampa Etichette") row.etichette = href;
      else if (t === "Stampa Richiesta") row.lista = href;
      else row.prenotazione = href;
      // the row this print icon lives in also carries when + what was ordered
      const tr = a.closest("tr");
      if (tr) {
        const dt = istanteRiga(tr);
        if (dt && (!rows._meta.ts || dt.ts < rows._meta.ts)) { rows._meta.ts = dt.ts; rows._meta.when = dt.when; }
        const desc = tr.querySelector('input[name="DESCRIZIONE_TITLE"]')?.value || "";
        const nice = shortLabel(desc.replace(/^\d+-\d+\s*/, "")).trim();
        if (nice && !rows._meta.exams.includes(nice)) rows._meta.exams.push(nice);
      }
    }
    // every OTHER row of the same richiesta adds its exam to the list
    for (const tr of doc.querySelectorAll("tr")) {
      const link = tr.querySelector('a[href*="RICHIESTA_ID="], a[onclick*="RICHIESTA_ID="]');
      if (!link) continue;
      const raw = link.getAttribute("href") || link.getAttribute("onclick") || "";
      const rid = (/RICHIESTA_ID=([^&'"]+)/.exec(raw) || [])[1];
      if (!rid || !map[rid]) continue;
      const desc = tr.querySelector('input[name="DESCRIZIONE_TITLE"]')?.value || "";
      const nice = shortLabel(desc.replace(/^\d+-\d+\s*/, "")).trim();
      if (nice && !map[rid]._meta.exams.includes(nice)) map[rid]._meta.exams.push(nice);
    }
    return map;
  }

  function printRowsFor(map, rid) {
    return Object.entries(map[rid] || {}).filter(([k]) => k !== "_meta").map(([, v]) => v)
      .sort((a, b) => Number(a.prog) - Number(b.prog));
  }
  const printMeta = (map, rid) => (map[rid] && map[rid]._meta) || { ts: 0, when: "", exams: [] };
  // Jobs grouped by printer to minimise switching: every label PDF first
  // (etichettatrice), then every exam-list sheet, then radiology bookings.
  function printJobsFor(map, rid) {
    const rows = printRowsFor(map, rid);
    const multi = rows.length > 1;
    const tag = (r) => (multi ? ` — riga ${r.prog}` : "");
    const jobs = [];
    for (const r of rows) if (r.etichette) jobs.push({ name: `Etichette provette${tag(r)}`, printer: "etichettatrice", url: r.etichette });
    for (const r of rows) if (r.lista) jobs.push({ name: `Lista esami${tag(r)}`, printer: "stampante normale", url: r.lista });
    for (const r of rows) if (r.prenotazione) jobs.push({ name: `Prenotazione esterna${tag(r)}`, printer: "stampante normale", url: r.prenotazione });
    const seen = new Set();
    return jobs.filter((j) => !seen.has(j.url) && seen.add(j.url));
  }
  // Compact description of what a richiesta will print, e.g. "2× etichette + 2× liste".
  function printLabelFor(map, rid) {
    const rows = printRowsFor(map, rid);
    const count = (k) => rows.filter((r) => r[k]).length;
    const parts = [];
    const put = (n, sing, plur) => { if (n === 1) parts.push(sing); else if (n > 1) parts.push(`${n}× ${plur}`); };
    put(count("etichette"), "etichette", "etichette");
    put(count("lista"), "lista esami", "liste esami");
    put(count("prenotazione"), "prenotazione", "prenotazioni");
    return parts.join(" + ");
  }

  // ------------------------------------------------------------ REFERTI MODEL
  // Result rows on the patient page: the sheet icon before the exam name is
  // <a title="REFERTO" onclick="window.open('…Sa4ViewerExtRedirect.do?…
  // REFERTO_SISTEMA=HL7LIS|HL7RIS|HL7AMB&REFERTO_ID=<uuid>')">. The same cell
  // carries hidden inputs DATA_ORD ("YYYY-MM-DD HH:MM:SS.f") and
  // DESCRIZIONE_TITLE. Archive links (MODALITA=ELENCODOC/…) have no
  // REFERTO_ID and are ignored. The same exam can have MORE than one referto
  // (e.g. a TC with two documents): dedupe by REFERTO_ID only.
  function refertiModel(doc, baseUrl) {
    const out = [];
    const seen = new Set();
    for (const a of doc.querySelectorAll('a[title="REFERTO"]')) {
      const m = /window\.open\(\s*['"]([^'"]+)['"]/.exec(a.getAttribute("onclick") || "");
      if (!m) continue;
      let url;
      try { url = new URL(m[1], baseUrl).href; } catch { continue; }
      const id = param(url, "REFERTO_ID");
      if (!id || seen.has(id)) continue;
      seen.add(id);
      const td = a.closest("td");
      const label = (td?.querySelector('input[name="DESCRIZIONE_TITLE"]')?.value ||
                     td?.getAttribute("title") || td?.textContent || "referto")
                    .replace(/\s+/g, " ").trim()
                    .replace(/^\d+-\d+\s+/, "");   // «0-324 TROPONINA» → «TROPONINA»: le prime cifre sono del LIS
      const dt = istanteDa(td?.querySelector('input[name="DATA_ORD"]')?.value) || istanteRiga(a.closest("tr"));
      out.push({
        id, url, label,
        sistema: (param(url, "REFERTO_SISTEMA") || "").replace(/^HL7/, ""),
        ts: dt ? dt.ts : 0,
        when: dt ? dt.when : "—",
      });
    }
    out.sort((a, b) => b.ts - a.ts || a.label.localeCompare(b.label));
    return out;
  }

  // Viewers often navigate (by script) to a DIRECT pdf endpoint, e.g. the
  // field-observed label URL:
  //   /UploadDownload/uploaddownloadservlet.rra2?…&mimetype=application/pdf
  // Those URLs are built inside the page, so we harvest them as text and try
  // them in order — never constructing one ourselves.
  // Volutamente PIÙ STRETTA di quella in extension/bg.js: là si cacciano i
  // referti, dove «report» è un indizio buono; qui si passa in rassegna una
  // pagina intera e si tengono i primi quattro candidati — una parola larga
  // se li mangia prima che tocchi a quello giusto. Le due cacciano documenti
  // diversi su host diversi: farle identiche era un'idea mia, non un requisito.
  const PDF_SMELL = /uploaddownloadservlet|mimetype=application\/pdf|get_pdf|jasperservlet|refertostream|\.pdf(?:[?&"']|$)/i;
  // Quando un visualizzatore non si lascia leggere, l'unica cosa che può
  // dire com'è fatto è la sua pagina. La si copia SENZA numeri
  // (identificativi, date, token) e senza i valori dei campi: resta la
  // struttura, che è quello che serve per adattare il lettore.
  function mascheraDiagnosi(html) {
    return String(html || "")
      .replace(/(value\s*=\s*")[^"]*(")/gi, "$1…$2")
      .replace(/(value\s*=\s*')[^']*(')/gi, "$1…$2")
      .replace(/\d{3,}/g, "###")
      .slice(0, 16000);
  }
  function diagnosiTesto(d) {
    if (!d) return "";
    let dove = String(d.url || "");
    try { const u = new URL(d.url, location.href); dove = u.pathname + "?" + [...u.searchParams.keys()].join("&"); } catch { /* com'è */ }
    return [`PS Assist ${VERSION} · ${d.quando || ""} · ${d.cosa || ""}`, dove, d.diag || "", "---", mascheraDiagnosi(d.html)].join("\n");
  }
  function bufB64(buf) {
    const by = new Uint8Array(buf);
    let s = "";
    for (let i = 0; i < by.length; i += 0x8000) s += String.fromCharCode.apply(null, by.subarray(i, i + 0x8000));
    return btoa(s);
  }

  function pdfCandidates(text) {
    const out = [], seen = new Set();
    const push = (raw) => {
      const u = String(raw || "").trim().replace(/&amp;/gi, "&");
      if (!u || u.length < 8 || seen.has(u)) return;
      if (/^(javascript:|#|data:|blob:|mailto:)/i.test(u)) return;
      // must look like a whole URL, not a fragment of one being concatenated
      if (!/^(https?:)?\/|^[\w.-]+\.(?:do|rra2|pdf|jsp)\b/i.test(u)) return;
      if (/[([+=&%]$|%27$/.test(u)) return;
      if (!PDF_SMELL.test(u)) return;
      seen.add(u); out.push(u);
    };
    for (const re of [/"([^"<>\n\r]{8,1200})"/g, /'([^'<>\n\r]{8,1200})'/g]) {
      for (const m of text.matchAll(re)) push(m[1]);
    }
    return out.slice(0, 4);
  }

  const isPdfBlob = (b) => b instanceof Blob && b.size > 4 &&
    (b.type.includes("pdf") || b.type === "" || b.type.includes("octet") || b.type.includes("download"));

  // Raised when an endpoint is a client-side VIEWER we can't safely turn into
  // a Blob (see note below). Carries the URL so the caller opens it natively.
  class ViewerError extends StopError {
    constructor(url) { super("È un visualizzatore, non un PDF diretto"); this.viewerUrl = url; }
  }

  // WHY WE DON'T HARVEST THE VIEWER'S BLOB
  // --------------------------------------
  // SA4PSO's label/referto endpoints are HTML pages whose own script builds
  // the PDF and navigates the tab to a blob: URL. Capturing that Blob from a
  // hidden iframe is not safely possible against an unknown viewer:
  //   - a SANDBOXED iframe that navigates to blob: becomes an OPAQUE origin →
  //     we can't read its location or fetch its Blob (verified);
  //   - a NON-sandboxed iframe can read it, but a framebusting viewer would
  //     navigate the doctor's whole tab away (verified — unacceptable).
  // So we only handle PDFs we can get SAFELY: a direct application/pdf
  // response, or a viewer that builds the Blob INLINE in its first document
  // (caught by a short sandboxed replay, which never navigates). Anything else
  // is opened natively in a new tab — exactly the manual fallback the doctor
  // asked for. This never hangs and never hijacks the page.
  let harvestSeq = 0;
  function harvestInlinePdf(url, { html, baseUrl, signal, timeoutMs = 6000 } = {}) {
    return new Promise((resolve, reject) => {
      const cb = `__psaH${++harvestSeq}`;
      const iframe = document.createElement("iframe");
      iframe.setAttribute("sandbox", "allow-scripts allow-same-origin"); // no top-nav: framebusters are inert
      iframe.style.cssText = "position:fixed;width:2px;height:2px;left:-9999px;top:-9999px;visibility:hidden";
      let done = false;
      const finish = (fn, v) => {
        if (done) return;
        done = true;
        clearTimeout(tt); clearInterval(iv);
        window.removeEventListener("message", onMsg);
        signal?.removeEventListener("abort", onAbort);
        iframe.remove();
        fn(v);
      };
      if (signal?.aborted) return finish(reject, new DOMException("Aborted", "AbortError"));
      const onAbort = () => finish(reject, new DOMException("Aborted", "AbortError"));
      signal?.addEventListener("abort", onAbort, { once: true });
      const tt = setTimeout(() => finish(reject, new ViewerError(url)), timeoutMs);
      const onMsg = (e) => {
        const d = e.data;
        if (!d || d.__psassist !== cb) return;
        if (isPdfBlob(d.blob)) return finish(resolve, { blob: d.blob, url });
        if (typeof d.nav === "string" && d.nav) {
          let u;
          try { u = new URL(d.nav, baseUrl || url); } catch { return; }
          if (u.origin !== location.origin || u.href === (baseUrl || url)) return; // never leave the hospital
          fetch(u.href, { credentials: "same-origin", cache: "no-store" })
            .then((r) => (r.ok ? r.blob() : null))
            .then((blob) => { if (isPdfBlob(blob)) finish(resolve, { blob, url }); })
            .catch(() => {});
        }
      };
      window.addEventListener("message", onMsg);
      document.documentElement.appendChild(iframe);
      // Hook createObjectURL BEFORE the replayed markup runs; postMessage
      // crosses the MV3 isolated world and Blobs survive the structured clone.
      // Prelude + a bounded rewrite of the viewer's own script, so that inside
      // the replay a navigation INTENT (location.replace/assign/href) is handed
      // to us as a URL instead of being attempted, and any Blob it builds is
      // handed over the moment it is created. Both cover viewers that assemble
      // their pdf URL piece by piece.
      const CB = JSON.stringify(cb);
      // Il visualizzatore replicato deve sapere DOV'È. Il suo script gira in
      // una cornice che non ha il suo indirizzo, quindi un visualizzatore che
      // costruisce l'indirizzo del PDF dalla propria query string leggeva la
      // nostra: non trovava niente, e si finiva sul ripiego manuale. Qui non
      // si inventa nessun indirizzo — si toglie una bugia che avevamo messo
      // noi: l'indirizzo che gli si dà è il suo, quello che il medico ha
      // aperto. L'indirizzo del PDF continua a calcolarselo lui.
      const suo = (() => { try { return new URL(baseUrl || url, location.href); } catch { return null; } })();
      const LOC = JSON.stringify(suo ? {
        href: suo.href, search: suo.search, pathname: suo.pathname, origin: suo.origin,
        protocol: suo.protocol, host: suo.host, hostname: suo.hostname, port: suo.port, hash: suo.hash,
        toString: undefined,
      } : {});
      const prelude = `<script>(function(){
        window.__psaLoc = ${LOC};
        window.__psaLoc.toString = function(){ return this.href || ""; };
        function nav(u){ try { parent.postMessage({ __psassist: ${CB}, nav: String(u) }, "*"); } catch (e) {} }
        window.__psaNav = nav;
        try { Object.defineProperty(window, "__psaNavHref", { set: nav, get: function(){ return ""; } }); } catch (e) {}
        function hb(b){ try { if (b instanceof Blob) parent.postMessage({ __psassist: ${CB}, blob: b }, "*"); } catch (e) {} }
        var wo = window.open;
        window.open = function(u){ if (u) nav(u); return { closed: false, close: function(){}, focus: function(){}, document: {} }; };
        var m = window.URL.createObjectURL.bind(window.URL);
        window.URL.createObjectURL = function(b){ hb(b); return m(b); };
        if (window.webkitURL && window.webkitURL.createObjectURL) {
          var wm = window.webkitURL.createObjectURL.bind(window.webkitURL);
          window.webkitURL.createObjectURL = function(b){ hb(b); return wm(b); };
        }
      })();<\/script>`;
      // `location` va riconosciuto SOLO quando è quello globale: preceduto da
      // niente, o da window/self/top/parent/document. Con un prefisso
      // facoltativo «a.location.search» diventava «a.__psaLoc.search», cioè un
      // errore dentro lo script del visualizzatore — che moriva lì.
      const LOCRE = "(?:\\b(?:window|self|top|parent|document)\\s*\\.\\s*|(?<![.\\w$]))location";
      const PROPS = "href|search|pathname|hostname|host|origin|protocol|port|hash";
      const patched = String(html || "")
        .replace(new RegExp(`${LOCRE}\\s*\\.\\s*(?:replace|assign)\\s*\\(`, "g"), "__psaNav(")
        // una SCRITTURA su una qualunque parte dell'indirizzo è una navigazione:
        // prima solo «.href =» era riconosciuta, e «.search = …» finiva fra le
        // letture, cioè spariva senza che nessuno se ne accorgesse
        .replace(new RegExp(`${LOCRE}\\s*\\.\\s*(?:${PROPS})\\s*(?:\\+)?=(?!=)`, "g"), "__psaNavHref =")
        .replace(new RegExp(`\\b(?:window|self|top)\\s*\\.\\s*location\\s*=(?!=)`, "g"), "__psaNavHref =")
        // quello che resta sono LETTURE: codice che vuole sapere dove si trova
        .replace(new RegExp(`${LOCRE}\\s*\\.\\s*(${PROPS})\\b`, "g"), "__psaLoc.$1");
      const idoc = iframe.contentDocument;
      idoc.open();
      idoc.write(prelude + `<base href="${esc(baseUrl || url)}">` + patched);
      idoc.close();
      const grab = (u, opts) => fetch(u, opts).then((r) => (r.ok ? r.blob() : null))
        .then((blob) => { if (isPdfBlob(blob)) finish(resolve, { blob, url }); }).catch(() => {});
      const iv = setInterval(() => {
        try {
          const w = iframe.contentWindow;
          // (a) the viewer navigated the frame to its real pdf endpoint —
          //     same-origin, so readable (a blob: target would be opaque and
          //     is caught by the createObjectURL hook above instead)
          const href = w && w.location ? w.location.href : "";
          if (href && href.startsWith(location.origin)) {
            return grab(href, { credentials: "same-origin", cache: "no-store" });
          }
          // (b) or embedded the pdf inside its own document
          const el = w?.document?.querySelector('embed[src^="blob:"],iframe[src^="blob:"],object[data^="blob:"]');
          const b = el && (el.getAttribute("src") || el.getAttribute("data"));
          if (b) return grab(b);
        } catch { /* transiently inaccessible (cross-doc or opaque) */ }
      }, 150);
    });
  }

  // Get a PDF SAFELY, or throw ViewerError(url) so the caller opens it in a
  // tab. Same origin/timeout guards as fetchDoc.
  // Un prelievo letto dalla finestra Risultati del gestionale, messo nella
  // stessa forma della tabella del portale: una colonna (la sua data e ora) e
  // una riga per analita. Così la scheda del paziente è una sola, alimentata
  // da tutt'e due le finestre — comprese quelle ancora PARZIALI, che restano
  // marcate come tali.
  // La finestra Risultati porta TUTTA la richiesta («PT, PTT POC, EMOCROMO
  // URGENTE»): un valore va attribuito al SUO esame dentro il pacchetto, o
  // due richieste che differiscono per un esame in più segnerebbero come
  // «fatta con un'altra macchina» ogni riga. Si sceglie l'esame che parla
  // della stessa sezione dell'analita; se non è uno solo, resta il pacchetto.
  const ESAME_DI = {
    "Emocromo": /EMOCROM|EMOCITOM/i,
    "Coagulazione": /\bPT\b|\bPTT\b|\bINR\b|FIBRIN|D.?DIM|COAGUL|ANTITROMB/i,
    "Biochim": /\bPCR\b|PROTEINA C|PROCALC|\bPCT\b|\bVES\b|TROPON|BNP|\bCPK\b|CK.?MB|MIOGLOB|\bLDH\b/i,
    "Organi": /CREATININ|AZOT|\bUREA\b|\bAST\b|\bALT\b|TRANSAMIN|\bGGT\b|GAMMA.?GT|γ.?GT|FOSFATASI|BILIRUB|AMILAS|LIPAS|ALBUMIN|AMMON/i,
    "Elettroliti e metabolismo": /SODIO|POTASSIO|CLORO|CALCIO|MAGNESIO|ELETTROL|GLUC|GLICEM|GLICAT|HBA1C|\bTSH\b/i,
    "Emogas": /EMOGAS|\bEGA\b/i,
    "Urine e altri liquidi": /URIN|LIQU|STICK/i,
  };
  // PT e PTT viaggiano quasi sempre insieme: la sezione non basta a dire
  // quale dei due è il SUO, la sigla sì.
  const ESAME_DI_SIGLA = {
    PT: /\bPT\b|PROTROMB/i, INR: /\bPT\b|PROTROMB|\bINR\b/i, PTT: /\bPTT\b|TROMBOPLASTINA/i, Fib: /FIBRIN/i, DD: /D.?DIM/i,
  };
  function esameDiRiga(exams, label, nome) {
    // un tampone o una PCR virale non fanno valori di chimica: fuori dai candidati
    const tutti = (Array.isArray(exams) ? exams : []).map((x) => String(x || "").replace(/\s+/g, " ").trim())
      .filter((x) => x && !/TAMPONE|MOLECOL|SARS|COV|VIRUS|ANTIGEN/i.test(x));
    const pacchetto = String(label || "").replace(/\s+/g, " ").trim();
    if ((Array.isArray(exams) ? exams.length : 0) < 2) return pacchetto;
    // cK+, cNa+, ctHb, cGlu, cLac, Hctc… sono i nomi dell'emogasanalizzatore:
    // in un pacchetto con l'emocromo e l'EGA, quei valori sono dell'EGA
    if (/^c(?:K|Na|Ca|Cl|Glu|Lac|tHb|HCO3|tCO2|tO2|Base|Crea|Urea)(?![a-z])|^Hctc\b|^[as]BE\b/.test(String(nome || "").trim())) {
      const ega = tutti.filter((x) => eEga(x));
      if (ega.length === 1) return ega[0];
    }
    const sg = sigla(nome);
    for (const re of [ESAME_DI_SIGLA[sg], ESAME_DI[sezioneDi(sg)[0]]]) {
      const miei = re ? tutti.filter((x) => re.test(x)) : [];
      if (miei.length === 1) return miei[0];
    }
    return pacchetto;
  }

  function prelievoComeTabella(meta, rows, cf, scartate = []) {
    // La colonna vuole giorno E ora completi: «10/07 22:23» come lo scrive
    // la lista Esiti non dice l'anno, e sia il confronto con «oggi» sia
    // l'ordine fra le colonne si fanno sulla data intera. L'istante della
    // richiesta (DATA_ORD, tenuto come ore UTC) ce l'ha tutta.
    const pad = (n) => String(n).padStart(2, "0");
    const m = DATA_ORA.exec(String(meta?.when || ""));
    const t = !m && meta?.ts ? new Date(meta.ts) : null;
    const data = m ? m[1] : t ? `${pad(t.getUTCDate())}/${pad(t.getUTCMonth() + 1)}/${t.getUTCFullYear()}` : String(meta?.when || "").trim();
    const ora = m ? (m[2] || "") : t ? `${pad(t.getUTCHours())}:${pad(t.getUTCMinutes())}` : "";
    const label = [data, ora].filter(Boolean).join(" ");
    if (!rows || !rows.length) return null;
    // Senza data il prelievo NON sparisce: diventa una colonna «?». Un valore
    // che il medico vede, con l'ora dichiarata ignota, vale infinitamente più
    // di un valore buttato via in silenzio. L'accesso fa da identità, così due
    // prelievi senza ora restano due colonne e non si fondono.
    const ignota = !label;
    const id = String(meta?.id || "");
    // il titolo della richiesta viaggia con la colonna: in tabella lo dice il
    // tooltip dell'intestazione, e non serve più una riga per prelievo
    const date = [{
      data, ora, ignota, id,
      label: label || "?",
      chiave: ignota ? "?#" + (id || Math.random().toString(36).slice(2)) : label + "#1",
      titolo: String(meta?.label || "").replace(/\s+/g, " ").trim(),
    }];
    const righe = rows.filter((r) => r.nome && String(r.valore).trim()).map((r, i) => ({
      nome: String(r.nome).replace(/\s+/g, " ").trim(),
      esame: esameDiRiga(meta?.exams, meta?.label, r.nome),
      codice: "", mnem: "", pos: i,
      valori: [{
        v: String(r.valore).trim(), stato: outOfRange(r.valore, r.range),
        um: String(r.um || "").trim(), range: String(r.range || "").trim(),
        parziale: /parz/i.test(r.stato || ""),
      }],
    }));
    if (!righe.length) return null;
    return { paziente: { idMPI: "", cognome: "", nome: (document.title || "").trim() },
             // le righe che il lettore ha rifiutato viaggiano con la tabella:
             // in Esiti si devono vedere, non solo nella finestra di origine
             cf: cf || "", periodo: "", date, righe,
             scartate: (scartate || []).filter((x) => x && x.nome).slice(0, 40), letto: Date.now() };
  }

  // ------------------------------------------------------- STORICO (portale clinico)
  // "Storico dati clinici" draws the multi-day table as TWO tables side by
  // side: a frozen left one with the exam names, a scrollable right one with
  // one column per draw, row-aligned by position. Nothing is asked of the
  // server here — this reads the table the doctor already has on screen.
  const STORICO_SX = ".clinical-data-table__freeze-container-left table";
  const STORICO_DX = ".clinical-data-table__freeze-container-right table";
  const DATA_ORA = /\b(\d{2}\/\d{2}\/\d{4})(?:\s+(\d{2}:\d{2}))?/;

  function haStorico(doc) { return !!(doc.querySelector(STORICO_SX) && doc.querySelector(STORICO_DX)); }

  // Both tooltips open with an identifier and " - ": the exam one with the
  // catalogue code ("1583 - ALT TRANSAMINASI", "ABC1234 - …"), the specific
  // one with the LIS mnemonic ("ALT - S-ALT (…)", "LINF% - …", "HbA1c - …").
  function primoToken(t) {
    const m = /^\s*([A-Za-z0-9][A-Za-z0-9%._/-]{0,23})\s+-\s+/.exec(String(t || ""));
    return m ? m[1] : "";
  }
  function pezziTooltip(t) {
    const tok = primoToken(t);
    // a code has a number in it: a bare word is a name, and naming it "code"
    // would be a made-up identifier
    const codice = /\d/.test(tok) ? tok : "";
    const resto = tok ? String(t).slice(String(t).indexOf(tok) + tok.length).replace(/^\s*-\s*/, "") : String(t || "");
    return { codice, nome: resto.trim() };
  }
  const mnemonicoStorico = (t) => primoToken(t);

  function leggiStorico(doc) {
    const sx = doc.querySelector(STORICO_SX), dx = doc.querySelector(STORICO_DX);
    if (!sx || !dx) return null;
    // The two tables are one table cut in half: if they ever stop lining up,
    // a value would land on the wrong exam. Then we read nothing at all.
    if (sx.rows.length !== dx.rows.length) return null;

    // Two draws can carry the SAME date and time — a POC and the central lab
    // drawn together is an ordinary morning here — so a column's identity is
    // not its label: each gets an occurrence key, or merging two reads would
    // pour one draw's values into the other's empty cells.
    const date = [], visti = new Map();
    for (const th of dx.rows[0] ? dx.rows[0].cells : []) {
      const m = DATA_ORA.exec((th.textContent || "").replace(/\s+/g, " "));
      if (!m) { date.push(null); continue; }
      const label = m[1] + (m[2] ? " " + m[2] : "");
      const n = (visti.get(label) || 0) + 1;
      visti.set(label, n);
      date.push({ data: m[1], ora: m[2] || "", label, chiave: label + "#" + n });
    }
    if (!date.some(Boolean)) return null;

    const righe = [], scartate = [];
    const nCol = dx.rows[0] ? dx.rows[0].cells.length : 0;
    for (let i = 1; i < sx.rows.length; i++) {
      const tdE = sx.rows[i].querySelector("td.exam");
      if (!tdE) continue;                                   // header and filler rows
      // The LEFT column is the ordered exam ("ESAME URINE COMPLETO"), the one
      // next to it is the analyte ("U-Albumina", "S-ALT"): a panel repeats the
      // same exam on every one of its rows, so the analyte is the name — and
      // its specimen prefix (U-, S-) stays, because U-Emoglobina is not Hb.
      const esame = (tdE.textContent || "").replace(/\s+/g, " ").trim();
      const tdS = sx.rows[i].querySelector("td.exam-specific");
      const spec = tdS ? tdS.querySelector("[uib-tooltip]") : null;
      const nome = (tdS?.textContent || "").replace(/\s+/g, " ").trim() || esame;
      if (!nome) continue;
      const { codice } = pezziTooltip(tdE.querySelector("[uib-tooltip]")?.getAttribute("uib-tooltip"));
      const mnem = mnemonicoStorico(spec?.getAttribute("uib-tooltip"));
      const valori = [];
      const celle = dx.rows[i] ? dx.rows[i].cells : [];
      // one cell per column, or the values would slide under the wrong draw:
      // a row that does not line up is left out AND declared, never guessed
      if (celle.length !== nCol) { scartate.push({ nome, valore: "riga fuori colonna" }); continue; }
      for (let c = 0; c < date.length; c++) {
        if (!date[c]) continue;
        const d = celle[c] ? celle[c].querySelector(".exam-value") : null;
        const v = d ? (d.textContent || "").replace(/\s+/g, " ").trim() : "";
        // the page already knows what is out of range: SUP above, INF below
        const stato = !v || !d.classList.contains("out-of-range") ? 0
          : d.classList.contains("SUP") ? 1 : d.classList.contains("INF") ? -1 : 0;
        valori.push({ v, stato });
      }
      if (valori.some((x) => x.v)) righe.push({ nome, esame, codice, mnem, pos: i, valori });
    }
    if (!righe.length) return null;

    // who this table belongs to — a value under the wrong name is the worst
    // thing this program could do, so the identity travels WITH the values
    const testa = [...doc.querySelectorAll(".panel-heading, app-root-selected-anagrafe")]
      .map((e) => (e.textContent || "").replace(/\s+/g, " ")).find((t) => /idMPI/i.test(t)) || "";
    // "Nome" must not match inside "Cognome": the label starts a word
    // The heading is one line of "Etichetta: valore" pairs. Cutting it on the
    // labels we know is the only way to keep a two-word name whole: a generic
    // "up to the next word with a colon" stops at the first space, turning
    // "MARIA ANNA" into "MARIA" — the name of a different patient.
    const campi = new Map();
    for (const pezzo of testa.split(/\s+(?=(?:idMPI|Cognome|Nome|Sesso|Data di nascita|Data nascita)\s*:)/i)) {
      const m = /^\s*([A-Za-z ]+?)\s*:\s*(.*)$/.exec(pezzo);
      if (m) campi.set(m[1].toLowerCase(), m[2].trim());
    }
    const campo = (k) => campi.get(k.toLowerCase()) || "";
    const periodo = [...doc.querySelectorAll(".panel-heading")]
      .map((e) => (e.textContent || "").replace(/\s+/g, " ").trim())
      .find((t) => /^Tabella esami periodo/i.test(t)) || "";

    return normalizzaStorico({
      paziente: { idMPI: campo("idMPI"), cognome: campo("Cognome"), nome: campo("Nome") },
      cf: cfImpronta(doc),
      periodo, date: date.filter(Boolean), righe, scartate, letto: Date.now(),
    });
  }

  // Two reads of the same table can show different draws: the portal only
  // renders the columns in view. Merging by (esame, data) means scrolling the
  // period ADDS draws instead of replacing them.
  // Scrivere nella scheda clinica del paziente SENZA cancellare quello che
  // c'è: si legge, si fonde, si riscrive dicendo da quale revisione si è
  // partiti. Se un'altra scrittura è passata nel mezzo, si rilegge e si
  // rifonde. Prima si scriveva e basta: la tabella del portale arrivata dopo i
  // Risultati si portava via i prelievi letti e i referti salvati.
  async function mettiInScheda(chiave, nuovo, fondi = unisciStorico) {
    for (let i = 0; i < 4; i++) {
      const gia = await ask({ t: "getStorico", chiave });
      const vecchio = gia && gia.ok ? gia.dati : null;
      const r = await ask({ t: "putStorico", chiave, dati: fondi(vecchio, nuovo), base: (vecchio && vecchio.rev) || 0 });
      if (!r || !r.conflitto) return r || { ok: false };
    }
    return { ok: false };
  }

  function unisciStorico(vecchio, nuovo) {
    if (!vecchio || !nuovo) return nuovo || vecchio || null;
    // Un altro paziente: si ricomincia. Il nome NON basta a dire «è lo
    // stesso»: sul portale si passa da un omonimo all'altro senza ricaricare
    // la pagina, e due persone con lo stesso nome finirebbero in un unico
    // grafico. Quindi devono combaciare il codice fiscale E il nome, e
    // un'identità che non si è potuta leggere conta come un altro paziente.
    if (!stessoPaziente(vecchio.paziente, nuovo.paziente)) return nuovo;
    // Due codici fiscali che non si sono potuti leggere NON sono lo stesso
    // codice fiscale: "" === "" è vero per JavaScript, non per due persone.
    // Senza questa riga due omonimi senza codice finivano in un grafico solo.
    if (!vecchio.cf || !nuovo.cf || vecchio.cf !== nuovo.cf) return nuovo;
    return fondiStorico(vecchio, nuovo);
  }
  // La fusione vera e propria, SENZA il cancello d'identità: la usa chi sa già
  // che le due tabelle sono dello stesso paziente — i prelievi letti in questa
  // scheda del browser sono tutti della pagina aperta.
  function fondiStorico(vecchio, nuovo) {
    if (!vecchio || !nuovo) return nuovo || vecchio || null;
    const date = [...vecchio.date];
    // Due prelievi allo stesso minuto (POC e laboratorio centrale: una
    // mattina qualunque) NON sono lo stesso prelievo: se l'accesso è un
    // altro, la colonna è un'altra e prende il primo numero libero. Senza
    // accesso (la tabella del portale) vale la chiave com'è.
    const rinomina = new Map();
    for (const d of nuovo.date) {
      const k = chiaveCol(d);
      const gia = date.find((x) => chiaveCol(x) === k);
      if (!gia) { date.push(d); continue; }
      if (!d.id || !gia.id || d.id === gia.id) continue;
      const stesso = date.find((x) => x.id && x.id === d.id);
      if (stesso) { rinomina.set(k, chiaveCol(stesso)); continue; }
      let n = 2;
      while (date.some((x) => chiaveCol(x) === d.label + "#" + n)) n++;
      const nuova = { ...d, chiave: d.label + "#" + n };
      date.push(nuova); rinomina.set(k, nuova.chiave);
    }
    date.sort((a, b) => ordData(a.label) - ordData(b.label));   // stable: same minute keeps its order
    const perEsame = new Map();
    const versa = (dati, mappa) => {
      const colDi = (d) => (mappa && mappa.get(chiaveCol(d))) || chiaveCol(d);
      const qui = new Map();   // chiave → { nome, celle }, dentro QUESTA tabella
      for (const r of dati.righe) {
        // HB is both blood haemoglobin and the urine dipstick: the analyte
        // alone is not an identity, the ordered exam is part of it
        // La chiave di una riga è l'ANALITA, la stessa identità che il
        // programma usa già per dire «è lo stesso esame» fra due prelievi.
        // Così l'emoglobina letta dalla finestra Risultati del gestionale e
        // quella della tabella del portale finiscono nella stessa riga,
        // invece di diventarne due. Quando l'analita non c'è (il nome ricade
        // sulla prestazione) solo la posizione distingue le righe.
        const anonima = !r.mnem && r.nome === r.esame;
        const base = valKey(r.nome) + (anonima ? "|#" + (r.pos ?? 0) : "");
        // L'emogas fa riga a sé (vedi eEga). Si decide valore per valore: una
        // tabella salvata prima di questa regola può avere nella stessa riga
        // valori dell'emocromo e dell'emogas — qui si separano.
        const gruppi = new Map();   // chiave → indici dei valori
        r.valori.forEach((v, i) => {
          if (!(v && v.v && dati.date[i])) return;
          const kv = base + (eEga(v.esame || r.esame) ? "|ega" : "");
          if (!gruppi.has(kv)) gruppi.set(kv, []);
          gruppi.get(kv).push(i);
        });
        if (!gruppi.size) gruppi.set(base + (eEga(r.esame) ? "|ega" : ""), []);
        for (const [k0, idx] of gruppi) {
          let k = k0;
          // due righe della stessa tabella con la stessa chiave (S-Sodio e
          // P-Sodio, o lo stesso nome due volte nello stesso prelievo) si
          // fondono solo se non si contraddicono: un valore non ne copre mai
          // un altro
          const gia = qui.get(k);
          if (gia && idx.some((i) => gia.celle.has(colDi(dati.date[i])) && gia.celle.get(colDi(dati.date[i])) !== r.valori[i].v)) {
            k += gia.nome !== r.nome ? "|" + r.nome : "|#" + (r.pos ?? 0);
          }
          const mio = qui.get(k) || { nome: r.nome, celle: new Map() };
          idx.forEach((i) => mio.celle.set(colDi(dati.date[i]), r.valori[i].v));
          qui.set(k, mio);
          const primo = idx.length ? r.valori[idx[0]] : null;
          const cur = perEsame.get(k) || { nome: r.nome, esame: (primo && primo.esame) || r.esame, codice: r.codice, mnem: r.mnem, pos: r.pos, per: new Map() };
          // La provenienza viaggia CON il valore. Due prelievi possono aver
          // fatto lo stesso esame con macchine diverse (POC e laboratorio):
          // stessa riga, ma si deve poter dire quale cella viene da dove.
          // Una cella che sa già con cosa è stata fatta lo tiene: rifondere una
          // tabella già fusa non deve riscrivere ogni cella con l'esame della
          // riga, o la provenienza (POC vs laboratorio) sparisce alla seconda
          // passata.
          idx.forEach((i) => { const v = r.valori[i]; cur.per.set(colDi(dati.date[i]), v.esame ? v : r.esame ? { ...v, esame: r.esame } : v); });
          perEsame.set(k, cur);
        }
      }
    };
    versa(vecchio); versa(nuovo, rinomina);
    const righe = [...perEsame.values()].map((e) => ({
      nome: e.nome, esame: e.esame, codice: e.codice, mnem: e.mnem, pos: e.pos,
      valori: date.map((d) => e.per.get(chiaveCol(d)) || { v: "", stato: 0 }),
    }));
    // i referti già letti per questo paziente non si perdono in una fusione
    const referti = [...(nuovo.referti || []), ...(vecchio.referti || [])]
      .filter((r, i, a) => r && r.id && a.findIndex((x) => x.id === r.id) === i).slice(0, 40);
    // Chi arriva dopo con meno non cancella quello che c'era: un prelievo dei
    // Risultati non ha il periodo del portale, e ha il nome solo come titolo
    // di pagina. L'identità strutturata (cognome/nome del portale) resta —
    // mai mescolata campo per campo, o «ROSSI» + «ROSSI MARIO» diventerebbe
    // un terzo nome che non combacia più con nessuno.
    const strutturata = (p) => !!(p && (p.cognome || p.idMPI));
    const paziente = strutturata(vecchio.paziente) && !strutturata(nuovo.paziente) ? vecchio.paziente : nuovo.paziente;
    return { paziente, cf: nuovo.cf || vecchio.cf || "",
             ep: nuovo.ep || vecchio.ep || "", nomeSa4: nuovo.nomeSa4 || vecchio.nomeSa4 || "",
      periodo: nuovo.periodo || vecchio.periodo || "", date, righe, referti,
             // le stesse righe rifiutate arrivano da tutt'e due i lati quando
             // una tabella viene rifusa: una volta sola
             scartate: [...(vecchio.scartate || []), ...(nuovo.scartate || [])]
               .filter((x, i, a) => x && a.findIndex((y) => y && y.nome === x.nome && y.valore === x.valore) === i).slice(0, 40),
             letto: Date.now() };
  }
  // Una tabella passa per la fusione anche da sola, appena letta e prima di
  // mostrarla: così le colonne vanno sempre in ordine di tempo (il portale le
  // può dare dalla più recente, e «ultimo» finiva sul prelievo più vecchio),
  // lo stesso analita ripetuto da due prestazioni è una riga sola, e una
  // scheda salvata prima che l'emogas avesse righe sue si divide.
  function normalizzaStorico(st) {
    return st ? fondiStorico(st, { ...st, righe: [], date: [], referti: [], scartate: [] }) : null;
  }
  const chiaveCol = (d) => (d && (d.chiave || d.label)) || "";
  const ordData = (label) => {
    const m = /(\d{2})\/(\d{2})\/(\d{4})(?:\s+(\d{2}):(\d{2}))?/.exec(label || "");
    return m ? Date.UTC(+m[3], +m[2] - 1, +m[1], +(m[4] || 0), +(m[5] || 0)) : 0;
  };
  // names as the two systems write them: "ROSSI MARIO" in SA4PSO's title,
  // Cognome + Nome on the portal. Only those two ORDERS are accepted: sorting
  // the words would make "MARINO BRUNO" and "BRUNO MARINO" the same person,
  // and that check is the only thing standing between one patient's lab table
  // and another patient's screen.
  const normNome = (t) => String(t || "").toUpperCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^A-Z0-9 ]+/g, " ").trim().replace(/\s+/g, " ");
  const chiavePaziente = (p) => normNome([p?.cognome, p?.nome].filter(Boolean).join(" "));
  // La scheda di un paziente nell'archivio: il codice fiscale quando c'è (è
  // l'unica identità che non si può confondere), altrimenti il nome.
  const chiaveArchivio = (d) => (d?.cf ? "cf:" + d.cf : "nome:" + chiavePaziente(d?.paziente));
  // Il gestionale scrive il nome come una stringa sola («ROSSI MARIO» o
  // «MARIO ROSSI», a seconda del presidio), il portale lo dà separato: si
  // accettano i due ordini, mai le parole mescolate.
  function stessoPaziente(a, b) {
    const ka = chiavePaziente(a), kb = chiavePaziente(b);
    if (!ka || !kb) return false;
    if (ka === kb) return true;
    return (!a?.cognome && combaciaNome(a?.nome, b)) || (!b?.cognome && combaciaNome(b?.nome, a));
  }
  // SA4PSO scrive il nome come una stringa sola, il portale lo dà già
  // separato: da lì l'ordine delle due parole non si può dedurre. Ma
  // entrambi i sistemi scrivono anche il CODICE FISCALE — il portale nel
  // titolo, il gestionale accanto al nome nella finestra Risultati, che il
  // pannello legge già per i valori. Quello è un identificativo unico: dove
  // c'è, decide lui. Ne teniamo solo l'IMPRONTA, mai il codice in chiaro.
  const CF_RE = /\b[A-Z]{6}\d{2}[A-Z]\d{2}[A-Z]\d{3}[A-Z]\b/g;
  function cfPagina(doc) {
    const testo = ((doc.title || "") + " " + (doc.body?.textContent || "")).toUpperCase();
    const trovati = [...new Set(testo.match(CF_RE) || [])];
    return trovati.length === 1 ? trovati[0] : "";   // più di uno: non sappiamo quale
  }
  const cfImpronta = (doc) => { const c = cfPagina(doc); return c ? impronta(c) : ""; };

  // Il codice fiscale è più forte del nome, ma le due prove non devono
  // potersi CONTRADDIRE: un codice che combacia accanto a un nome che non
  // ha niente in comune è un segnale che qualcosa non torna, non un via
  // libera. Basta una parola in comune (il titolo può portare altro).
  function nomiCompatibili(titolo, p) {
    const a = normNome(titolo).split(" ").filter((x) => x.length >= 3);
    const b = normNome([p?.cognome, p?.nome].filter(Boolean).join(" ")).split(" ").filter((x) => x.length >= 3);
    if (!a.length || !b.length) return true;          // uno dei due non è leggibile
    return a.some((x) => b.includes(x));
  }
  // Fra le schede in archivio, quella di questo paziente. DUE PASSATE, non
  // una decisione per candidato: se esiste una scheda col codice fiscale di
  // questo paziente è QUELLA, sempre. Si ripiega sul nome solo se nessuna
  // scheda porta un codice fiscale — altrimenti un omonimo senza codice,
  // incontrato per primo, vincerebbe su una scheda verificata col codice.
  function scegliScheda(indice, mio, titolo, ep) {
    const v = indice || [];
    // Prima di tutto: la scheda letta ARRIVANDO DA QUESTO PAZIENTE. È stato il
    // medico ad aprire il portale da questa pagina, e nessun confronto di nomi
    // può essere più sicuro di così.
    // …ma il clic non può CONTRADDIRE le altre prove: sul portale si passa
    // da un omonimo all'altro senza ricaricare, e la scheda arrivata da quel
    // clic può essere di un altro ROSSI MARIO. Con un codice fiscale diverso
    // o un nome che non c'entra, il clic non conta.
    if (ep) {
      const suo = v.find((x) => x.ep && String(x.ep) === String(ep)
        && (!mio || !x.cf || x.cf === mio) && nomiCompatibili(titolo, x.paziente));
      if (suo) return suo;
    }
    // Se di questo paziente conosciamo il codice fiscale, decide SOLO quello:
    // niente ripieghi sul nome, perché una scheda senza codice col suo stesso
    // nome può essere di un omonimo.
    if (mio) return v.find((x) => x.cf === mio && nomiCompatibili(titolo, x.paziente)) || null;
    // Se non lo conosciamo ancora, si può andare solo per nome — ma allora si
    // guarda solo fra le schede che un codice non ce l'hanno: una scheda che
    // porta un codice non si può attribuire a un paziente di cui non ne
    // sappiamo nessuno.
    return v.find((x) => !x.cf && combaciaNome(titolo, x.paziente)) || null;
  }
  function combaciaNome(titolo, p) {
    const t = normNome(titolo);
    const c = normNome(p?.cognome), n = normNome(p?.nome);
    if (!t || (!c && !n)) return false;
    const dritto = [c, n].filter(Boolean).join(" ");
    const rovescio = [n, c].filter(Boolean).join(" ");
    return t === dritto || t === rovescio;
  }

  // ------------------------------------------------------- RISULTATI MODEL
  // While a lab request is still being reported, the patient page shows a
  // coloured icon that pops up RcsAccessiRisultatiElenco.do — plain HTML on
  // THIS origin, so the values can be read and shown inside the panel.
  // QUANDO è stato fatto un prelievo. SA4PSO lo scrive in un campo nascosto
  // della riga (DATA_ORD) come «yyyy-mm-dd HH:MM», ma un presidio può averlo
  // in un'altra forma, e senza un istante un prelievo non può diventare una
  // colonna. Si accettano le forme che NON sono ambigue; il giorno prima del
  // mese perché questo programma gira in un ospedale italiano, dove così è
  // scritto anche a video. Tutto il resto si rifiuta invece di indovinare.
  function istanteDa(grezzo) {
    const s = String(grezzo || "").trim();
    const fatto = (a, me, g, h, mi) => ({ ts: Date.UTC(a, me - 1, g, h, mi), when: `${String(g).padStart(2, "0")}/${String(me).padStart(2, "0")} ${String(h).padStart(2, "0")}:${String(mi).padStart(2, "0")}` });
    let m = /^(\d{4})-(\d{1,2})-(\d{1,2})[ T](\d{1,2})[:.](\d{2})/.exec(s);
    if (m) return fatto(+m[1], +m[2], +m[3], +m[4], +m[5]);
    m = /^(\d{1,2})[/-](\d{1,2})[/-](\d{2}|\d{4})[ ,T]+(\d{1,2})[:.](\d{2})/.exec(s);
    if (m) return fatto(m[3].length === 2 ? 2000 + +m[3] : +m[3], +m[2], +m[1], +m[4], +m[5]);
    m = /^(\d{4})(\d{2})(\d{2})[ T]?(\d{2})(\d{2})/.exec(s);
    if (m) return fatto(+m[1], +m[2], +m[3], +m[4], +m[5]);
    return null;
  }
  // La data della riga, presa dalla riga: prima il campo nascosto, e se non
  // c'è (o è scritto in un modo mai visto) la cella che il medico ha davanti.
  // Non si costruisce niente: si legge quello che la pagina mostra già.
  function istanteRiga(tr) {
    const campo = tr?.querySelector('input[name="DATA_ORD"]');
    const dal = istanteDa(campo ? campo.value : "");
    if (dal) return { ...dal, via: "campo" };
    for (const td of tr?.querySelectorAll(":scope > td") || []) {
      const t = istanteDa(td.textContent.replace(/\s+/g, " ").trim());
      if (t) return { ...t, via: "cella" };
    }
    return null;
  }

  function risultatiModel(doc, baseUrl) {
    const out = [], seen = new Set();
    for (const a of doc.querySelectorAll('a[title="Visualizza Risultati"]')) {
      const m = /window\.open\(\s*['"]([^'"]+)['"]/.exec(a.getAttribute("onclick") || "");
      if (!m) continue;
      let url;
      try { url = new URL(m[1], baseUrl).href; } catch { continue; }
      const id = param(url, "RCS_ACCESSO_ID");
      if (!id || seen.has(id)) continue;
      seen.add(id);
      const td = a.closest("td"), tr = a.closest("tr");
      const exams = (td?.getAttribute("title") || "").split(";")
        .map((x) => shortLabel(x.replace(/^\s*\d+-\d+\s*/, "")).trim()).filter(Boolean);
      const dt = istanteRiga(tr);
      out.push({ id, url, exams, ts: dt ? dt.ts : 0, when: dt ? dt.when : "", dataVia: dt ? dt.via : "" });
    }
    out.sort((a, b) => b.ts - a.ts);
    return out;
  }

  // Perché un prelievo non è diventato una colonna: l'unica risposta sta
  // nelle righe della pagina, non nel pannello. Una riga per collegamento
  // «Visualizza Risultati», con quello che c'era scritto davvero.
  function diagPrelievi(doc, baseUrl) {
    const righe = [], visti = new Set();
    for (const a of doc.querySelectorAll('a[title="Visualizza Risultati"]')) {
      const m = /window\.open\(\s*['"]([^'"]+)['"]/.exec(a.getAttribute("onclick") || "");
      const tr = a.closest("tr");
      const campo = tr?.querySelector('input[name="DATA_ORD"]');
      let id = "";
      if (m) { try { id = param(new URL(m[1], baseUrl).href, "RCS_ACCESSO_ID") || ""; } catch { /* indirizzo rotto */ } }
      const doppio = !!id && visti.has(id);
      if (id) visti.add(id);
      const dt = istanteRiga(tr);
      righe.push({
        ok: !!dt && !doppio && !!id && !!m,
        testo: `${id || "senza identificativo"}${doppio ? " (già visto: la riga si ripete)" : ""} · campo ${
          !campo ? "ASSENTE" : campo.value ? `«${String(campo.value).slice(0, 30)}»` : "vuoto"} · ${
          dt ? `letta dalla ${dt.via}: ${dt.when}` : "NESSUNA data leggibile in questa riga"}${m ? "" : " · senza collegamento"}`,
      });
    }
    return righe;
  }

  // a value outside its own reference range is worth the eye
  // Is this value outside its reference range? Returns -1 / 0 / +1.
  //
  // Laboratories write ranges in more ways than one ("4 - 10", "< 0.5",
  // "fino a 5", "> 60", "-2 - +2", "4 - 10 x10^3"), and values come with
  // modifiers ("<0.01") or as words ("NEGATIVO"). The rule here is
  // deliberately one-sided: when a format is not understood — or the range
  // depends on something we cannot know, like sex — it returns 0 and the
  // value is shown plain. Never a red mark we cannot justify.
  function outOfRange(value, range) {
    const num = (s) => {
      const m = /-?\d+(?:[.,]\d+)?/.exec(String(s));
      return m ? parseFloat(m[0].replace(",", ".")) : NaN;
    };
    const raw = String(range || "").replace(/\s+/g, " ").trim();
    const vs = String(value).replace(/\s+/g, " ").trim();
    if (!raw || !vs) return 0;
    // "M: 13-17 F: 12-16", or two ranges in one cell: which one applies is not
    // ours to guess
    if (/\b[MF]\s*[:=]/.test(raw)) return 0;
    if ((raw.match(/\s[-–]\s/g) || []).length > 1) return 0;

    const v = num(vs);
    if (!isFinite(v)) return 0;                       // NEGATIVO, Assente, tracce…
    const vLt = /^[<≤]/.test(vs), vGt = /^[>≥]/.test(vs);

    let lo = NaN, hi = NaN;
    const due = /^(-?[\d.,]+)\s*[-–]\s*([+-]?[\d.,]+)/.exec(raw);
    if (due) { lo = num(due[1]); hi = num(due[2]); }
    else if (/^[<≤]|^inf\.?\s*a\b|^fino a\b|^minore\b/i.test(raw)) hi = num(raw);
    else if (/^[>≥]|^sup\.?\s*a\b|^maggiore\b|^oltre\b/i.test(raw)) lo = num(raw);
    else return 0;
    if (!isFinite(lo) && !isFinite(hi)) return 0;
    if (isFinite(lo) && isFinite(hi) && lo > hi) return 0;   // unreadable, not a range

    if (isFinite(lo) && (v < lo || (vLt && v <= lo))) return -1;
    if (isFinite(hi) && (v > hi || (vGt && v >= hi))) return 1;
    return 0;
  }

  // Returns the value rows AND the candidate rows it refused: a row this
  // parser does not understand must become a warning, never a hole.
  function parseRisultati(doc) {
    const rows = [], scartate = [];
    for (const tr of doc.querySelectorAll("tr")) {
      // DIRECT children only: the patient header of the same table nests its own
      // tables, and cells picked up from those made a row look like a result
      const tds = [...tr.querySelectorAll(":scope > td.AFCDataTD")];
      if (tds.length < 5) continue;
      const [nome, valore, um, range, stato, data] = tds.map((t) => t.textContent.replace(/\s+/g, " ").trim());
      if (!nome || !valore) continue;
      // the same table carries the patient header (Assistito, Pronto Soccorso,
      // Quesito…): those rows have no date, no range and no state, and would
      // otherwise show up among the values as a nonsense line
      if (/^(assistito|pronto soccorso|quesito|reparto|medico|paziente|data)\b/i.test(nome)) continue;
      // A result row proves itself: a reporting date, a numeric range, or a
      // laboratory state. The header block of the same table (name, età, CF,
      // quesito) has none of the three, whichever way it is nested.
      const dataOk = /\d{1,2}\/\d{1,2}\/\d{2,4}/.test(data || "");
      const rangeOk = /\d/.test(range || "") && /[-–<>≤≥]|fino a|inf\.|sup\./i.test(range || "");
      const statoOk = /^(parziale|definitiv|refertat|eseguit|in corso|validat|preliminar|provvisori)/i.test(stato || "");
      if (!dataOk && !rangeOk && !statoOk) { scartate.push({ nome, valore }); continue; }
      rows.push({ nome, valore, um, range, stato });
    }
    return { rows, scartate };
  }

  // One chronological list of everything the lab/radiology returned for this
  // patient: values we can read (risultati) and reported documents (referti).
  // what a values row needs to exist on its own, without the page
  const risMeta = (e) => ({ id: e.id || "", url: e.url, label: e.label || "", exams: e.exams || [], when: e.when || "", ts: e.ts || 0 });

  // What a referto row is, from its own label: decides how it opens today and
  // which ones become inline text when their sources are wired (lab table, RX
  // and ECG referti). Anything else stays a document you open.
  function refertoTipo(e) {
    const l = String(e.label || "").toUpperCase();
    const sis = String(e.sistema || "").toUpperCase();
    if (/ELETTROCARDIOGRAMM|\bECG\b/.test(l)) return "ecg";
    // the whole of radiology reads as text, not just plain films: the system
    // that issued the document says it better than the exam's name does
    if (sis.includes("RIS") || /\bRX\b|RADIOGRAF|\bTC\b|\bTAC\b|ECOGRAF|RISONANZA|\bRMN\b/.test(l)) return "rx";
    if (sis.includes("LIS")) return "lab";
    return "altro";
  }

  // Quali sistemi di referti stanno nel portale (lo si scopre al primo tocco:
  // il link del gestionale rimanda là). Vale un turno, poi si riverifica.
  const nelPortale = (e) => {
    if (!hasExt() || !e || !e.sistema) return false;
    const t = (store.get("refPortale", {}) || {})[String(e.sistema).toUpperCase()];
    return !!t && Date.now() - t < 12 * 3600e3;
  };
  const segnaPortale = (e) => {
    if (!e || !e.sistema) return;
    store.set("refPortale", { ...(store.get("refPortale", {}) || {}), [String(e.sistema).toUpperCase()]: Date.now() });
  };

  function esitiModel(doc, baseUrl) {
    const out = [
      ...risultatiModel(doc, baseUrl).map((r) => ({ ...r, kind: "valori", label: r.exams.join(", ") })),
      ...refertiModel(doc, baseUrl).map((r) => ({ ...r, kind: "referto" })),
    ];
    // Once an exam is reported the LIS takes its Risultati window away, and the
    // values we had already read would vanish with it. They are ours: the draws
    // read earlier in this tab stay in the list, marked as read before, each
    // with its own time. They are never attached to a referto — nothing links
    // the two — they simply keep their place.
    const ep = findEpisodeId(doc, baseUrl) || "x";
    const vivi = new Set(out.filter((r) => r.kind === "valori").map((r) => r.id));
    for (const k of tabStore.keys(`ris.${ep}.`)) {
      const id = k.slice(`ris.${ep}.`.length);
      if (!id || vivi.has(id)) continue;
      const v = tabStore.get(k, null);
      if (!v || !v.rows || !v.rows.length || !v.meta) continue;
      out.push({ ...v.meta, id, kind: "valori", storico: true });
    }
    out.sort((a, b) => b.ts - a.ts);
    return out;
  }

  // Un tetto duro ai tentativi, UNO SOLO per tutta la caccia: un documento che
  // non si lascia catturare in pochi colpi si apre in una scheda e si stampa da
  // lì. Il contatore va passato ai livelli sotto — quando stava dentro la
  // funzione ogni ricorsione ripartiva da zero e il tetto vero era 6+6×6 = 43.
  const MAX_TENTATIVI = 6;
  async function fetchPdf(url, { signal, hop = 0, budget } = {}) {
    budget = budget || { n: 0 };
    const target = new URL(url, location.href);
    if (target.origin !== location.origin) {
      throw new StopError("Richiesta fuori dall'ospedale bloccata", `destinazione inattesa: ${target.origin}`);
    }
    const ctl = new AbortController();
    const tid = setTimeout(() => ctl.abort(new DOMException("Timeout", "TimeoutError")), TIMEOUT_MS);
    const onAbort = () => ctl.abort(new DOMException("Aborted", "AbortError"));
    if (signal) {
      // agganciarsi a un segnale GIÀ abortito non fa scattare niente: chiudere
      // la finestra di stampa deve fermare anche il tentativo che deve ancora
      // partire, non solo quello in volo
      if (signal.aborted) { clearTimeout(tid); throw new DOMException("Aborted", "AbortError"); }
      signal.addEventListener("abort", onAbort, { once: true });
    }
    let res;
    try {
      try {
        res = await fetch(target.href, { signal: ctl.signal, credentials: "same-origin", cache: "no-store", redirect: "follow" });
      } catch (e) {
        // Solo l'errore di rete (TypeError) si traduce: timeout e stop
        // restano quello che sono. Quasi sempre è un rinvio verso un ALTRO
        // server (il RIS, gli ECG, il portale in http): la pagina del
        // gestionale non può leggerlo, il medico che clicca sì — per questo
        // il referto si apre ma non si lascia salvare.
        if (!(e instanceof TypeError)) throw e;
        throw new StopError("Non raggiungibile da qui", "rete, o rinvio a un altro server");
      }
      if (new URL(res.url || target.href).origin !== location.origin) {
        // si dice DOVE (solo il server: nell'indirizzo ci sono gli id del paziente)
        throw new StopError("Il documento sta su un altro server", `rimanda a ${new URL(res.url).origin}`);
      }
      if (!res.ok) throw new StopError(`Il server ha risposto HTTP ${res.status}`, res.statusText || "");
    } finally {
      clearTimeout(tid);
      if (signal) signal.removeEventListener("abort", onAbort);
    }
    const ctype = (res.headers.get("content-type") || "").toLowerCase();
    const buf = await res.arrayBuffer();
    // Il tipo dichiarato è un'etichetta; i primi cinque byte sono il
    // documento. Un servlet che manda un PDF chiamandolo «text/html» o
    // «application/force-download» manda comunque un PDF, e buttarlo via per
    // il nome sarebbe l'unico errore vero: si guarda dentro.
    const magico = buf.byteLength > 4
      && String.fromCharCode(...new Uint8Array(buf, 0, 5)) === "%PDF-";
    if (magico || ctype.includes("pdf") || ctype.includes("octet-stream")) {
      return { blob: new Blob([buf], { type: "application/pdf" }), url: res.url || target.href,
               via: hop === 0 ? "diretto" : magico && !ctype.includes("pdf") ? `dichiarato ${ctype.split(";")[0] || "senza tipo"}` : "" };
    }
    if (ctype.includes("html") && hop < 2) {
      const text = new TextDecoder("windows-1252").decode(buf);
      const doc = new DOMParser().parseFromString(text, "text/html");
      if (classify(doc) === "login") throw new StopError("Sessione scaduta", "Fai l'accesso a SA4PSO e riprova la stampa.");
      const base = res.url || target.href;
      const tried = [];
      const fuoriQui = new Set();   // dove rimanda, quando rimanda a un altro server
      const attempt = async (raw, via) => {
        if (!raw || /^(javascript:|#|about:)/i.test(raw)) return null;
        if (++budget.n > MAX_TENTATIVI) return null;
        let u; try { u = new URL(String(raw).replace(/&amp;/gi, "&").trim(), base); } catch { return null; }
        if (u.origin !== location.origin && /^https?:$/.test(u.protocol)) fuoriQui.add(u.origin);
        if (u.origin !== location.origin || u.href === base) return null;
        if (tried.includes(u.href)) return null;
        tried.push(u.href);
        try {
          const r = await fetchPdf(u.href, { signal, hop: hop + 1, budget });
          return r ? { ...r, via: r.via || via } : r;
        } catch (e) { if (e?.name === "AbortError") throw e; return null; }
      };

      // 1. explicit references in the markup (old apps still use <frameset>)
      const domCands = [];
      for (const el of doc.querySelectorAll('frame[src], iframe[src], embed[src], object[data], a[href], form[action]')) {
        const v = el.getAttribute("src") || el.getAttribute("data") || el.getAttribute("href") || el.getAttribute("action");
        const loose = el.tagName === "FRAME" || el.tagName === "IFRAME" || el.tagName === "EMBED" || el.tagName === "OBJECT";
        if (v && (loose || /jasperservlet|uploaddownload|\.pdf|report|stampa/i.test(v))) domCands.push(v);
      }
      // Il rinvio del visualizzatore delle etichette porta l'indirizzo del PDF
      // con dentro degli APICI:
      //   URL=…uploaddownloadservlet.rra2?…blobfield=…get_pdf('PSOWEB_HL7_123')…
      // Tagliarlo al primo apice dava un indirizzo monco — ed era l'unico
      // tentativo che il programma faceva, quindi le etichette non uscivano.
      // Dopo «URL=» finisce l'attributo: si prende tutto quello che resta.
      const meta = doc.querySelector('meta[http-equiv="refresh" i]')?.getAttribute("content") || "";
      const rinvio = /url\s*=\s*(.+)$/is.exec(meta);
      // Un rinvio verso un ALTRO server è il portale (ECG, radiologia): là il
      // referto si apre con un accesso a token, e la pagina lo scarica e lo
      // mostra da sé. Da qui non si legge e non ci si prova nemmeno (niente
      // replay, niente attese): chi chiama lo apre nel portale, in una scheda.
      if (rinvio) {
        let dest = null;
        try { dest = new URL(rinvio[1].trim().replace(/^(["'])([\s\S]*)\1$/, "$2").trim().replace(/&amp;/gi, "&"), base); } catch { /* niente */ }
        if (dest && dest.origin !== location.origin && /^https?:$/.test(dest.protocol)) {
          const x = new StopError("Il referto si apre nel portale", `rimanda a ${dest.origin}`);
          x.portale = dest.origin;
          throw x;
        }
      }
      domCands.push(rinvio ? rinvio[1].trim().replace(/^(["'])([\s\S]*)\1$/, "$2").trim() : undefined);
      for (const m of text.matchAll(/window\.open\(\s*["']([^"']+)["']/gi)) domCands.push(m[1]);
      for (const c of domCands) { const r = await attempt(c, "link nella pagina"); if (r) return r; }

      // 2. a whole direct-pdf URL sitting in the viewer's own script
      for (const c of pdfCandidates(text)) { const r = await attempt(c, "URL nello script"); if (r) return r; }

      // Qui prima c'era una terza strada: prendere l'id del documento dalla
      // pagina e COSTRUIRE l'indirizzo del PDF. È stata tolta. Un indirizzo
      // costruito a mano su un id letto male non dà un errore: dà il
      // documento di qualcun altro. La regola del programma è che gli
      // indirizzi si prendono dalla pagina, e questa era l'unica eccezione.

      // 3. replay the viewer (sandboxed) and take the URL/Blob it produces
      // In the banco di prova the replay is skipped on purpose: it would run a
      // viewer's own script inside a frame, and the banco's promise is that
      // nothing on the page can reach the network. The tab fallback covers it.
      if (DEMO) throw new ViewerError(target.href);
      try { return { ...(await harvestInlinePdf(target.href, { html: text, baseUrl: base, signal })), via: "replay del visualizzatore" }; }
      catch (e) {
        if (e?.name === "AbortError") throw e;
        const err = new ViewerError(target.href);
        // NB: questa diagnosi è l'unica cosa che dice, da uno schermo al
        // lavoro, com'è fatto il visualizzatore vero. Era morta: citava una
        // variabile che non esiste più, quindi al posto del ViewerError con la
        // diagnosi partiva un ReferenceError, e non si vedeva niente.
        const idQui = /\b[A-Z][A-Z0-9]*_[A-Z0-9]+_\d{6,}\b/.test(text);
        err.diag = `html ${Math.round(text.length / 1024)}KB · ${(text.match(/<script/gi) || []).length} script · ${(text.match(/<frame\b/gi) || []).length} frame · tentati ${tried.length} URL · id ${idQui ? "sì" : "no"} · upload ${/uploaddownloadservlet/i.test(text) ? "sì" : "no"}${fuoriQui.size ? ` · rimanda a ${[...fuoriQui].join(", ")}` : ""}`;
        err.html = text;   // la pagina stessa, per «⧉ Diagnosi» (mascherata prima di copiarla)
        throw err;
      }
    }
    throw new ViewerError(target.href);
  }

  // Exam page: everything the engine needs from a rendered list.
  function examModel(doc, baseUrl) {
    const form = doc.querySelector('form[name="Prestazioni"]');
    let links = form ? [...form.querySelectorAll("a.AFCDataLink")] : [];
    if (!links.length) links = [...doc.querySelectorAll("a.AFCDataLink")];
    const exams = [];
    for (const a of links) {
      const href = absUrl(a, "href", baseUrl);
      const code = param(href, "PRESTAZIONE");
      if (!code) continue; // e.g. the cart-wide "svuota" link
      exams.push({
        code,
        label: a.textContent.replace(/\s+/g, " ").replace(/^\d+-\d+\s*/, "").trim(),
        isAdd: /[?&]Insert=Inserisci/.test(href),
        isDel: /[?&]Delete=Elimina/.test(href),
        href,
      });
    }
    const sel = doc.querySelector('select[name="RISORSA_ID"]');
    const res = sel ? selectValue(sel) : null;
    const resOptions = sel ? [...sel.options].filter((o) => o.value).map((o) => ({ value: o.value, label: o.textContent.replace(/\s+/g, " ").trim() })) : [];

    // Plain list URL template, derived from a data link's own params (they
    // carry the complete state). Fallback: the Prestazioni form action.
    const DROP = ["Insert", "Delete", "MVPG", "ccsForm", "PRESTAZIONE", "BRANCA", "toPG"];
    let template = null;
    const src = exams.find((e) => e.href);
    if (src) template = new URL(src.href);
    else if (form) { template = new URL(absUrl(form, "action", baseUrl)); }
    if (template) {
      DROP.forEach((k) => template.searchParams.delete(k));
      template.searchParams.set("MVPG", "RcsRichiestaPrestazioniRicercaErogatore");
      template.searchParams.set("toPage", "RcsRichiestaPrestazioniRicercaErogatore");
      template.searchParams.set("s_PRESTAZIONE", "");
    }
    const listUrl = (targetRes) => {
      if (!template) return null;
      const u = new URL(template);
      if (targetRes) u.searchParams.set("RISORSA_ID", targetRes);
      return u.href;
    };
    const richiestaId = template ? template.searchParams.get("RICHIESTA_ID") : null;

    return {
      form, exams, res, resOptions, listUrl, richiestaId,
      inCart: (code) => exams.some((e) => e.code === code && e.isDel),
      addLink: (code) => exams.find((e) => e.code === code && e.isAdd),
      confirmButton: form ? form.querySelector('input[type="submit"][name="Update"]') || form.querySelector('input[type="submit"][name="Update1"]') : null,
    };
  }

  const agoLabel = (ts) => {
    const min = Math.max(0, Math.round((Date.now() - (ts || 0)) / 60000));
    if (min < 1) return "adesso";
    if (min < 60) return `${min} min fa`;
    const d = new Date(ts || 0);
    const today = new Date().toDateString() === d.toDateString();
    return `${today ? "alle" : "ieri"} ${hhmm(ts)}`;
  };
  const hhmm = (ts) => { const d = new Date(ts || 0); return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`; };
  const shortLabel = (l) => String(l).replace(/\s*\([\w./-]*\)\s*$/, "");

  // =============================================================== CATALOG
  // Merged view of the embedded (audited) catalog and everything learned
  // from live pages. Learning happens on every parsed list, so radiology
  // becomes one-click after it has been seen once.
  // Un solo magazzino, due depositi. `set` torna false quando la scrittura NON
  // è avvenuta (memoria piena o bloccata): chi promette al medico «salvato»
  // deve poterlo verificare — e ora vale anche per le consegne fra pagina e
  // pagina, che prima fallivano in silenzio.
  const magazzino = (dep) => ({
    get(key, fallback) {
      try { const v = JSON.parse(dep.getItem(NS + key)); return v ?? fallback; }
      catch { return fallback; }
    },
    set(key, value) { try { dep.setItem(NS + key, JSON.stringify(value)); return true; } catch { return false; } },
    del(key) { try { dep.removeItem(NS + key); return true; } catch { return false; } },
    keys(prefix) {
      try { return Object.keys(dep).filter((k) => k.startsWith(NS + prefix)).map((k) => k.slice(NS.length)); }
      catch { return []; }
    },
  });
  const store = magazzino(localStorage);
  // il presidio del giro: chi lo tiene, su quale richiesta, e da quando
  const presidioLibero = (rid, token) => {
    const p = store.get(PRESIDIO, null);
    if (!p || !p.rid || !rid || p.rid !== String(rid)) return true;
    if (p.token === token) return true;
    return Date.now() - (p.ts || 0) > PRESIDIO_MS;
  };
  const segnaPresidio = (rid, token) => { if (rid) store.set(PRESIDIO, { rid: String(rid), token, ts: Date.now() }); };
  const liberaPresidio = (token) => { const p = store.get(PRESIDIO, null); if (p && p.token === token) store.set(PRESIDIO, null); };
  // Tab-scoped storage for the run→landing handoffs (receipt + auto-confirm
  // flag): sessionStorage survives the same-tab navigation but is invisible
  // to other tabs, so two patients in two tabs can never clobber or clear
  // each other's pending confirm.
  const tabStore = magazzino(sessionStorage);

  // ------------------------------------------------------- KNOWN PATIENTS
  // I pazienti su cui si è lavorato, per ritrovarli dalla schermata iniziale:
  // nome, episodio, indirizzo della pagina e il colore di triage che la sua
  // intestazione mostra. Un turno è di dodici ore e i
  // pazienti sono più di dodici, quindi l'elenco tiene un giorno e non ha un
  // limite che dia fastidio. Qui non entra MAI altro contenuto clinico (né esami,
  // né valori, né quesito): quello sta nella scheda, che è un'altra cosa.
  // Chi viene dimesso si ARCHIVIA: esce dall'elenco principale e resta negli
  // archiviati, da dove si può riportare indietro o cancellare del tutto.
  const PATIENTS_TTL = 24 * 3600e3;
  const PATIENTS_MAX = 60;

  function tuttiPazienti() {
    const list = store.get("patients.v1", []);
    const fresh = Array.isArray(list) ? list.filter((p) => p && p.ep && Date.now() - (p.ts || 0) < PATIENTS_TTL) : [];
    return fresh.sort((a, b) => (b.ts || 0) - (a.ts || 0)).slice(0, PATIENTS_MAX);
  }
  const knownPatients = () => tuttiPazienti().filter((p) => !p.arch);
  const pazientiArchiviati = () => tuttiPazienti().filter((p) => p.arch);
  // Il codice colore del triage, come lo mostra l'intestazione della scheda:
  // un elemento col titolo esatto. Le righe del diario (.myRiepilogo) portano
  // il colore di quando sono state scritte, e non contano.
  const TRIAGE_COLORI = ["ROSSO", "ARANCIONE", "AZZURRO", "VERDE", "BIANCO"];
  function triageDi(doc) {
    for (const el of doc.querySelectorAll("[title]")) {
      const t = (el.getAttribute("title") || "").trim();
      if (TRIAGE_COLORI.includes(t) && !el.closest(".myRiepilogo")) return t;
    }
    return "";
  }
  function rememberPatient(ep, name, url, triage) {
    if (!ep) return;
    const prima = tuttiPazienti().find((p) => p.ep === ep);
    const list = tuttiPazienti().filter((p) => p.ep !== ep);
    // il triage è quello letto all'ultima apertura; se la pagina non lo dice,
    // resta quello di prima
    const tr = TRIAGE_COLORI.includes(triage) ? { triage, triageTs: Date.now() }
      : prima?.triage ? { triage: prima.triage, triageTs: prima.triageTs || 0 } : {};
    // riaprire un paziente archiviato lo riporta fra i vivi: se sei sulla sua
    // pagina, è di lui che ti stai occupando
    list.unshift({ ep, name: (name || "").trim().slice(0, 60), url: url || "", ts: Date.now(),
                   pk: prima?.pk || "", ...tr });
    store.set("patients.v1", list.slice(0, PATIENTS_MAX));
  }
  // la chiave della scheda clinica, annotata quando la conosciamo, così
  // archiviare o eliminare un paziente sa cosa toccare
  function segnaChiave(ep, pk) {
    if (!ep || !pk) return;
    const list = tuttiPazienti();
    const p = list.find((x) => x.ep === ep);
    if (!p || p.pk === pk) return;
    p.pk = pk;
    store.set("patients.v1", list);
  }
  function archiviaPaziente(ep, si = true) {
    const list = tuttiPazienti();
    const p = list.find((x) => x.ep === ep);
    if (!p) return false;
    p.arch = !!si;
    p.archTs = si ? Date.now() : 0;
    return store.set("patients.v1", list);
  }
  // Eliminare un paziente vuol dire eliminare TUTTO quello che il programma
  // sa di lui: la riga nell'elenco, la sua scheda clinica, i referti tenuti,
  // la nota, e i dati per episodio in questa scheda del browser.
  function eliminaPaziente(ep, pk, nome) {
    const list = tuttiPazienti().filter((x) => x.ep !== ep);
    store.set("patients.v1", list);
    // la nota può stare sotto la chiave del codice fiscale O sotto il nome,
    // a seconda di quando è stata scritta: si tolgono tutt'e due
    const n = store.get(noteKey, {});
    const perNome = nome ? "nome:" + normNome(nome) : "";
    let tolte = 0;
    for (const k of [pk, perNome].filter(Boolean)) if (n[k]) { delete n[k]; tolte++; }
    if (tolte) store.set(noteKey, n);
    const s = store.get(segniKey, {});   // e i segni sui valori, stesse chiavi
    let toltiSegni = 0;
    for (const k of [pk, perNome].filter(Boolean)) if (s[k]) { delete s[k]; toltiSegni++; }
    if (toltiSegni) store.set(segniKey, s);
    try {
      for (const k of Object.keys(sessionStorage)) {
        const kk = k.startsWith(NS) ? k.slice(NS.length) : "";
        if (kk && new RegExp(`(^|\\.)(ris|visto|reftxt|log|refopen|ui)\\.${ep}\\b`).test(kk)) sessionStorage.removeItem(k);
      }
    } catch { /* memoria bloccata: niente da togliere */ }
    const corsa = tabStore.get(CORSA, null);
    if (corsa && corsa.ep === ep) tabStore.set(CORSA, null);
    const aperta = store.get(APERTA, null);
    if (aperta && aperta.ep === ep) store.set(APERTA, null);
    const posti = store.get("stanza.posti.v1", null);   // e il suo posto nella stanza
    if (posti && posti[ep]) { delete posti[ep]; store.set("stanza.posti.v1", posti); }
    const prom = store.get(PROM, null);   // e i suoi promemoria
    if (prom && prom[ep]) { delete prom[ep]; store.set(PROM, prom); }
    if (hasExt()) ask({ t: "delStorico", chiave: pk, ep, nome: nome || "" }).catch(() => {});
    return true;
  }
  function forgetPatients() { store.set("patients.v1", []); }
  // end of shift / another user: drop names and every per-episode leftover
  function forgetAll() {
    forgetPatients();
    forgetQuesiti();
    try {
      for (const k of Object.keys(sessionStorage)) {
        if (k.startsWith(NS) && /(^|\.)(ris|visto|reftxt|log|refopen|receipt|confirm|queue|print|ui|afterNav|dimdraft|storico|corsa)\b/.test(k.slice(NS.length))) sessionStorage.removeItem(k);
      }
    } catch { /* blocked storage: nothing to clear */ }
    store.set(APERTA, null);    // porta un nome: se ne va col turno
    store.set(PRESIDIO, null);
    // I posti nella stanza NO: sono solo numeri di episodio, e chi viene
    // riaperto dopo una sessione scaduta deve ritrovare il suo letto.
    try { if (typeof chrome !== "undefined" && chrome.runtime?.id) chrome.runtime.sendMessage({ t: "clearRef" }, () => void chrome.runtime.lastError); } catch { /* not the extension build */ }
  }

  // The doctor's edits live in localStorage under their own key. They are
  // templates, not patient data, so forgetAll leaves them alone — and nothing
  // patient-specific ever gets written here.
  // ------------------------------------------------------------- CONSENSI
  // I moduli di consenso stanno DENTRO l'estensione (cartella consensi/):
  // niente rete, niente server, funzionano anche se il gestionale è giù.
  // Un tocco apre il PDF e la finestra di stampa, come per la lista esami.
  // `pagine` è quanta carta esce: nove pagine non si scoprono dalla stampante.
  // `gruppo` separa i consensi da firmare dalle deleghe per il ritiro.
  const CONSENSI = [
    { k: "emocolture", nome: "Emocolture", file: "emocolture.pdf", pagine: 1,
      esteso: "Esame colturale su campioni biologici diversi" },
    { k: "hiv-dipendente", nome: "HIV Dipendente", file: "hiv-dipendente.pdf", pagine: 1,
      esteso: "Consenso del dipendente all'esecuzione del test HIV (MDL 170)" },
    { k: "lesioni-animali", nome: "Lesioni Animali", file: "lesioni-animali.pdf", pagine: 1,
      esteso: "Rapporto di lesione provocata da animali" },
    { k: "antitetano", nome: "Antitetano", file: "antitetano.pdf", pagine: 1,
      esteso: "Immuno-profilassi antitetanica" },
    { k: "tac-cmdc", nome: "TAC cmdc", file: "tac-cmdc.pdf", pagine: 1,
      esteso: "Consenso alla TAC con mezzo di contrasto" },
    { k: "emotrasfusione", nome: "Emotrasfusione", file: "emotrasfusione.pdf", pagine: 9,
      esteso: "Pacchetto trasfusionale: consenso informato, richiesta emocomponenti, dichiarazione del medico in urgenza" },
    { k: "ritiro-esami", nome: "Ritiro esami", file: "ritiro-esami.pdf", pagine: 1, gruppo: "ritiro",
      esteso: "Delega per il ritiro del referto degli esami ematochimici di Pronto Soccorso" },
    { k: "ritiro-referto-rx", nome: "Ritiro referto RX", file: "ritiro-referto-rx.pdf", pagine: 1, gruppo: "ritiro",
      esteso: "Delega per il ritiro del referto radiologico" },
    { k: "ritiro-cartella-cd", nome: "Ritiro cartella e CD", file: "ritiro-cartella-cd.pdf", pagine: 5, gruppo: "ritiro",
      esteso: "Richiesta e delega per copia della documentazione sanitaria: verbale di PS, referti, CD radiologico" },
  ];
  // nel banco di prova non c'è un'estensione: la pagina finta serve un PDF
  const urlConsenso = (c) => (DEMO ? "/consensi/" + c.file
    : (hasExt() ? chrome.runtime.getURL("consensi/" + c.file) : ""));

  // ------------------------------------------------------------------ NOTA
  // Una nota per paziente, sotto il suo nome. Si scrive e basta: non c'è un
  // tasto Salva, si salva mentre scrivi. Sta nel browser di questo computer,
  // legata al paziente (codice fiscale quando c'è, altrimenti il nome), e
  // scade dopo 24 ore come i dati clinici letti.
  const noteKey = "note.v1";
  const NOTA_TTL = 24 * 3600e3;
  function noteTutte() {
    const n = store.get(noteKey, {});
    const ora = Date.now();
    let pulito = false;
    for (const k of Object.keys(n)) if (ora - (n[k]?.ts || 0) > NOTA_TTL) { delete n[k]; pulito = true; }
    if (pulito) store.set(noteKey, n);
    return n;
  }
  const leggiNota = (chiave) => (chiave ? (noteTutte()[chiave]?.t || "") : "");
  // la nota di un paziente dell'elenco, su una riga: la chiave è quella
  // annotata sulla sua pagina (codice fiscale), o il nome
  // La nota di un paziente dell'elenco o della stanza. Col codice fiscale
  // (pk «cf:…») si legge SOLO quella: il nome è di chiunque si chiami così.
  // Senza codice fiscale, il nome — ma mai se fra i pazienti attivi c'è un
  // omonimo: la nota sul paziente sbagliato è peggio di nessuna nota.
  const notaDi = (p, attivi = knownPatients()) => {
    const pulisci = (t) => String(t || "").replace(/\s*\n+\s*/g, " · ").trim();
    if (p.pk && String(p.pk).startsWith("cf:")) return pulisci(leggiNota(p.pk));
    const n = normNome(p.name);
    if (!n || attivi.some((x) => x.ep !== p.ep && normNome(x.name) === n)) return "";
    return pulisci(leggiNota(p.pk || "nome:" + n));
  };
  function scriviNota(chiave, testo) {
    if (!chiave) return false;
    const n = noteTutte();
    if (String(testo).trim()) n[chiave] = { t: String(testo).slice(0, 4000), ts: Date.now() };
    else delete n[chiave];
    return store.set(noteKey, n);
  }

  // ----------------------------------------------------------------- SEGNI
  // Un valore toccato si evidenzia: giallo, al secondo tocco arancio, al
  // terzo torna com'era. Il medico «segna» quello che vuole tenere d'occhio.
  // Per paziente come la nota, con la stessa chiave e la stessa scadenza;
  // la cella è «colonna|analita», la stessa identità della tabella.
  const segniKey = "segni.v1";
  function segniTutti() {
    const s = store.get(segniKey, {});
    const ora = Date.now();
    let pulito = false;
    for (const k of Object.keys(s)) if (ora - (s[k]?.ts || 0) > NOTA_TTL) { delete s[k]; pulito = true; }
    if (pulito) store.set(segniKey, s);
    return s;
  }
  const leggiSegni = (chiave) => (chiave ? (segniTutti()[chiave]?.celle || {}) : {});
  function scriviSegno(chiave, cella, stato) {
    if (!chiave || !cella) return false;
    const s = segniTutti();
    const celle = { ...(s[chiave]?.celle || {}) };
    if (stato) celle[cella] = stato; else delete celle[cella];
    if (Object.keys(celle).length) s[chiave] = { celle, ts: Date.now() }; else delete s[chiave];
    return store.set(segniKey, s);
  }
  // come la nota: i segni fatti prima di conoscere il codice fiscale lo seguono
  function migraSegni(da, a) {
    const s = segniTutti();
    if (!s[da]) return;
    // due buste (una per il nome, una per il codice) si sommano, non si scelgono
    s[a] = { celle: { ...s[da].celle, ...(s[a]?.celle || {}) }, ts: Date.now() };
    delete s[da];
    store.set(segniKey, s);
  }

  // ------------------------------------------------------------ PROMEMORIA
  // «11:30 tropo», «tra 2h ECG»: un'ora per fare una cosa, per paziente. Si
  // tiene l'ISTANTE, come il cronometro: ricaricare la pagina non sposta
  // niente. Per episodio, mai un nome; al massimo 10 a paziente; scadono 12
  // ore dopo l'ora fissata. Stanno in questo browser e non vanno da nessuna parte.
  const PROM = "promemoria.v1";
  const PROM_MAX = 10;
  const PROM_TTL = 12 * 3600e3;
  // Il primo orario scritto nel testo; il resto è la cosa da fare. Un'ora:
  // «11:30», «11.30», «11h30», «11h», «alle 14». Fra quanto: «tra 2h», «+2h»,
  // «2h», «2h30», «90m», «30 min», «30'», «tra 45 minuti», «2 ore». Con una
  // cifra «2h» è fra quanto, con due «11h» è un'ora. Un'ora passata da non più
  // di 2 ore è di oggi (già scaduta); più indietro è di domani: il turno di notte.
  function leggiPromemoria(testo, ora) {
    const s = String(testo || "").replace(/\s+/g, " ").trim();
    const T = "(?<![\\p{L}\\p{N}_])", F = "(?![\\p{L}\\p{N}_])";
    const FRA = "(?:(?:tra|fra|entro|in|dopo)\\s+|\\+\\s?)", ALLE = "(?:(?:alle|verso\\s+le|per\\s+le|entro\\s+le)(?:\\s+ore)?\\s+|ore\\s+)";
    const eFra = (p) => new RegExp(`^${FRA}$`, "i").test(p || "");   // «entro le 14» è un'ora, «entro 2h» fra quanto
    const alle = (h, m) => {
      if (h > 23 || m > 59) return null;
      const d = new Date(ora);
      d.setHours(h, m, 0, 0);
      if (d.getTime() < ora - 2 * 3600e3) d.setDate(d.getDate() + 1);
      else if (d.getTime() >= ora + 22 * 3600e3) d.setDate(d.getDate() - 1);
      return d.getTime();
    };
    const fra = (min) => (min >= 1 && min <= 1440 ? Math.floor((ora + min * 60e3) / 60e3) * 60e3 : null);
    const forme = [
      // 11:30, 11.30 (e «tra 1:30»: fra un'ora e mezza). Col punto è anche un
      // numero («K 3.50», «pH 7.30»): cede a ogni altro orario scritto nel testo
      [`${T}(${FRA}|${ALLE})?(\\d{1,2})([:.])(\\d{2})${F}`, (m) => (+m[4] > 59 ? null : eFra(m[1]) ? fra(+m[2] * 60 + +m[4]) : alle(+m[2], +m[4]))],
      // 11h, 11h30 · 2h, 2h30, tra 2h
      [`${T}(${FRA}|${ALLE})?(\\d{1,2}) ?h(?:(\\d{2})(?: ?min| ?m)?)?${F}`, (m) => {
        const h = +m[2], mm = +(m[3] || 0);
        if (mm > 59) return null;
        return (m[1] ? eFra(m[1]) : m[2].length === 1) ? fra(h * 60 + mm) : alle(h, mm);
      }],
      // 2 ore, tra 1 ora
      [`${T}${FRA}?(\\d{1,2}) ?or[ae]${F}`, (m) => fra(+m[1] * 60)],
      // 90m, 30 min, 30', tra 45 minuti
      [`${T}${FRA}?(\\d{1,4}) ?(?:minut[io]|min|m|['’′])(?![\\p{L}\\p{N}_'’′])`, (m) => fra(+m[1])],
      // alle 14, ore 14
      [`${T}${ALLE}(\\d{1,2})(?![\\p{L}\\p{N}_:'’′]|\\.\\d)`, (m) => alle(+m[1], 0)],
    ];
    let primo = null;
    for (const [re, quando] of forme) {
      for (const m of s.matchAll(new RegExp(re, "giu"))) {
        const t = quando(m);
        if (t == null) continue;
        const c = { i: m.index, n: m[0].length, t, debole: m[3] === "." ? 1 : 0 };
        if (!primo || c.debole < primo.debole
          || (c.debole === primo.debole && (c.i < primo.i || (c.i === primo.i && c.n > primo.n)))) primo = c;
        break;   // di ogni forma conta la prima che vale
      }
    }
    if (!primo) return null;
    // il resto è la cosa da fare: senza la punteggiatura rimasta dove stava l'orario
    const prima = s.slice(0, primo.i).replace(/[\s·:,;\-–—]+$/, ""), dopo = s.slice(primo.i + primo.n).replace(/^[\s·:,;.\-–—]+/, "");
    const resto = `${prima} ${dopo}`.replace(/^[\s·:,;.\-–—]+|[\s·:,;\-–—]+$/g, "").slice(0, 40).trim();
    return { t: primo.t, testo: resto || "promemoria" };
  }
  // Quanto manca, nel modo più corto: «1h40», «40m», «ora», «−5m».
  function promTempo(t, ora) {
    const hm = (min) => (min >= 60 ? `${Math.floor(min / 60)}h${min % 60 ? String(min % 60).padStart(2, "0") : ""}` : `${min}m`);
    if (t > ora) return hm(Math.ceil((t - ora) / 60e3));
    const tardi = Math.floor((ora - t) / 60e3);
    return tardi < 1 ? "ora" : "−" + hm(tardi);
  }
  // oltre la mezz'ora tranquilla; ambra sotto i 30 minuti; rossa sotto i 10, e quando è l'ora
  const promBanda = (t, ora) => { const m = Math.ceil((t - ora) / 60e3); return m > 30 ? "" : m > 10 ? "amb" : "ros"; };
  // l'ora fissata, col giorno quando non è oggi: «11:30», «domani 07:30»
  function promOra(t, ora) {
    const giorno = (x) => { const d = new Date(x); d.setHours(0, 0, 0, 0); return d.getTime(); };
    const g = Math.round((giorno(t) - giorno(ora)) / 864e5);
    return `${g === 1 ? "domani " : g === -1 ? "ieri " : ""}${hhmm(t)}`;
  }
  // per esteso, per il passaggio del mouse: «11:30 · tropo · tra 15 min»
  function promRiga(p, ora) {
    const parole = (min) => (min >= 60 ? `${Math.floor(min / 60)} h${min % 60 ? ` ${min % 60} min` : ""}` : `${min} min`);
    const tardi = Math.floor((ora - p.t) / 60e3);
    const quando = p.t > ora ? "tra " + parole(Math.ceil((p.t - ora) / 60e3)) : tardi < 1 ? "adesso" : "in ritardo di " + parole(tardi);
    return `${promOra(p.t, ora)}${p.testo ? " · " + p.testo : ""} · ${quando}`;
  }
  function promTutti() {
    const raw = store.get(PROM, {});
    const tutti = {}, ora = Date.now();
    let cambiato = false;
    for (const [ep, l] of Object.entries(raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {})) {
      const vivi = /^[\w.-]{1,40}$/.test(ep) && Array.isArray(l)
        ? l.filter((p) => p && typeof p.id === "string" && Number.isFinite(p.t) && typeof p.testo === "string" && ora - p.t <= PROM_TTL).slice(0, PROM_MAX)
        : [];
      if (vivi.length !== (Array.isArray(l) ? l.length : -1)) cambiato = true;
      if (vivi.length) tutti[ep] = vivi;
    }
    if (cambiato) store.set(PROM, tutti);
    return tutti;
  }
  // quelli di un paziente, il più vicino per primo
  const promDi = (ep, tutti = promTutti()) => (ep && tutti[ep] ? [...tutti[ep]].sort((a, b) => a.t - b.t) : []);
  function promScrivi(ep, l) {
    const tutti = promTutti();
    if (l.length) tutti[ep] = l; else delete tutti[ep];
    return store.set(PROM, tutti);
  }
  function promAggiungi(ep, p) {
    const l = promDi(ep);
    if (!ep || l.length >= PROM_MAX) return false;
    l.push({ id: "p" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), t: p.t, testo: String(p.testo || "").slice(0, 40), ts: Date.now() });
    return promScrivi(ep, l);
  }
  function promTogli(ep, id) {
    const l = promDi(ep), p = l.find((x) => x.id === id);
    return p && promScrivi(ep, l.filter((x) => x !== p)) ? p : null;
  }
  // «+15 min»: da quando era fissato, o da adesso se è già passato
  function promRinvia(ep, id, ms = 15 * 60e3) {
    const l = promDi(ep), p = l.find((x) => x.id === id);
    if (!p) return false;
    p.t = Math.floor((Math.max(p.t, Date.now()) + ms) / 60e3) * 60e3;
    return promScrivi(ep, l);
  }
  const promRimetti = (ep, p) => promScrivi(ep, [...promDi(ep).filter((x) => x.id !== p.id), p]);

  // ----------------------------------------------------------------- TEMPI
  // Un cronometro per capire dove va il tempo di un turno. Si tiene solo
  // l'ISTANTE DI INIZIO, mai i secondi passati: così ricaricare la pagina o
  // riavviare il browser non perde niente e il conto resta giusto. Il
  // cronometro in corso è semplicemente la voce che non ha ancora una fine.
  const tempiKey = "tempi.v1";
  const TEMPI_TTL = 7 * 24 * 3600e3;
  const TITOLI = ["Visita ed esami", "Scrittura cartella", "Gestione (consulenti)", "Dimissione"];
  function tempi() {
    const l = store.get(tempiKey, []);
    const ora = Date.now();
    const vivi = (Array.isArray(l) ? l : []).filter((t) => t && t.inizio && ora - t.inizio < TEMPI_TTL);
    if (vivi.length !== (Array.isArray(l) ? l.length : 0)) store.set(tempiKey, vivi);
    return vivi;
  }
  const tempoInCorso = () => tempi().find((t) => !t.fine) || null;
  function avviaTempo(titolo, paz, ep) {
    const l = tempi();
    const ora = Date.now();
    for (const t of l) if (!t.fine) t.fine = ora;   // uno solo alla volta: il precedente si chiude
    l.push({ id: "t" + ora.toString(36), titolo: String(titolo || "").slice(0, 60) || "Attivita",
             paz: String(paz || "").slice(0, 60), ep: String(ep || ""), inizio: ora });
    return store.set(tempiKey, l);
  }
  function fermaTempo() {
    const l = tempi();
    const t = l.find((x) => !x.fine);
    if (!t) return false;
    t.fine = Date.now();
    return store.set(tempiKey, l);
  }
  const scordaTempo = (id) => store.set(tempiKey, tempi().filter((t) => t.id !== id));
  const durata = (t) => Math.max(0, ((t.fine || Date.now()) - t.inizio));
  const mmss = (ms) => {
    const s = Math.floor(ms / 1000);
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60);
    return h ? `${h}h ${String(m).padStart(2, "0")}m` : `${m}m ${String(s % 60).padStart(2, "0")}s`;
  };
  const oraDi = (ms) => new Date(ms).toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" });
  const giornoDi = (ms) => new Date(ms).toLocaleDateString("it-IT", { day: "2-digit", month: "2-digit", year: "numeric" });

  const dimKey = "dimissioni.v1";
  // A short fingerprint of the text a doctor's version was forked from. It is
  // what lets a later release SAY that the original changed (a dose, a
  // contraindication): without it, a corrected sheet would be silently
  // invisible to everyone who had ever edited that sheet.
  function impronta(testo) {
    let h = 0x811c9dc5;
    const t = String(testo || "").replace(/\s+/g, " ").trim();
    for (let i = 0; i < t.length; i++) { h ^= t.charCodeAt(i); h = Math.imul(h, 0x01000193); }
    return (h >>> 0).toString(36);
  }
  const dimValido = (v) => !!(v && typeof v.testo === "string" && v.testo.trim());
  function dimissioni() {
    const mie = store.get(dimKey, {});
    const out = {};
    for (const [k, v] of Object.entries(DIMISSIONI)) {
      const m = dimValido(mie[k]) ? mie[k] : null;
      out[k] = {
        nome: v.nome, testo: m ? m.testo : v.testo, originale: v.testo, modificato: !!m,
        rivisto: !!v.rivisto,
        // the shipped text moved AFTER this doctor forked it
        aggiornato: !!(m && m.base && m.base !== impronta(v.testo)),
      };
    }
    for (const [k, v] of Object.entries(mie)) {
      if (!out[k] && dimValido(v)) out[k] = { nome: (v.nome || k), testo: v.testo, originale: "", modificato: true, mio: true };
    }
    return out;
  }
  function salvaDimissione(k, nome, testo) {
    const mie = store.get(dimKey, {});
    const base = DIMISSIONI[k];
    if (base && testo.trim() === base.testo.trim()) delete mie[k];   // back to the original: stop overriding
    else mie[k] = { nome, testo, base: base ? impronta(base.testo) : "" };
    return store.set(dimKey, mie);
  }
  function ripristinaDimissione(k) {
    const mie = store.get(dimKey, {});
    delete mie[k];
    return store.set(dimKey, mie);
  }

  // EO — un elenco piatto chiave→voce, così una riga o una tendina copiano
  // allo stesso modo. I testi sono quelli scritti dal medico, verbatim.
  function eoVoci() {
    const out = {};
    if (EO.base && EO.base.testo) out.base = { nome: EO.base.nome || "EO generale", meta: EO.base.meta || "", testo: EO.base.testo, gruppo: "base" };
    for (const v of EO.casi || []) if (v && v.k && v.testo) out["caso:" + v.k] = { nome: v.nome || v.k, testo: v.testo, gruppo: "casi" };
    for (const v of EO.frasi || []) if (v && v.k && v.testo) out["frase:" + v.k] = { nome: v.nome || v.k, testo: v.testo, gruppo: "frasi" };
    return out;
  }

  function learnedCatalog() { return store.get("catalog.v1", {}); }
  // Il catalogo si impara dalle pagine vere, MA un nome già noto non viene
  // mai sovrascritto. Il motivo è il controllo anti-esame-sbagliato: quello
  // confronta il nome della riga viva col nome con cui l'esame è stato
  // scelto. Se la stessa pagina potesse riscrivere il catalogo un istante
  // prima del click, il confronto sarebbe fra un valore e se stesso — e non
  // potrebbe più fallire. Un codice che oggi porta un altro nome è proprio
  // l'anomalia che deve fermare tutto: la ferma quel controllo, non si assorbe.
  function learnFrom(model) {
    if (!model.res || !model.exams.length) return;
    const cat = learnedCatalog();
    const entry = cat[model.res] || { label: "", items: {} };
    const opt = model.resOptions.find((o) => o.value === model.res);
    if (opt) entry.label = opt.label;
    const incisi = (EMBEDDED_CATALOG[model.res] || {}).items || {};
    for (const e of model.exams) if (!incisi[e.code] && !entry.items[e.code]) entry.items[e.code] = e.label;
    // gli appunti delle versioni prima (lo schema dell'«aggiungi», BRANCA, i
    // nomi cambiati) servivano solo a mandare un esame col codice salvato:
    // quella strada non c'è più, e nemmeno loro
    delete entry.ins; delete entry.par; delete entry.rinominati;
    entry.ts = Date.now();
    cat[model.res] = entry;
    store.set("catalog.v1", cat);
  }
  // La ricerca del gestionale, quella della casella «Prestazione» sopra la
  // griglia: l'elenco stesso, con s_PRESTAZIONE scritto (ogni link della
  // pagina lo porta già: è lo stato della ricerca). Si cerca per mnemonico LIS
  // se il nome ne ha uno — «(POC1401)» — altrimenti per nome.
  const termineRicerca = (label) => mnemonico(label) || shortLabel(String(label || "")).replace(/\s+/g, " ").trim();
  function urlRicerca(listUrl, termine) {
    if (!listUrl || !termine || !/[?&]s_PRESTAZIONE=/.test(listUrl)) return null;
    return listUrl.replace(/([?&]s_PRESTAZIONE=)[^&#]*/, (m, k) => k + encodeW1252Component(termine));
  }
  // A resource id is site-local: "LABORATORIO ANALISI POC" is 00660001P in one
  // presidio and something else in another, and the same is true of radiology.
  // What travels is the NAME, so that is what we match on — the site suffix
  // ("- SSG (P)") is dropped first. Nothing is ordered on the strength of this
  // alone: the exam's own live name is still checked before every send.
  const chiaveRisorsa = (label) => String(label || "")
    .toUpperCase().replace(/\s+/g, " ")
    .replace(/\s*-\s*[A-Z]{2,5}\s*(\([A-Z]\))?\s*$/, "")
    .replace(/\s*\([A-Z]\)\s*$/, "")
    .trim();
  // the mnemonic the LIS puts in brackets — "EMOCROMOCITOMETRICO URGENTE
  // (POCT1502)" — identifies an exam far better than its numeric code
  const mnemonico = (label) => { const m = /\(([A-Z0-9._-]{3,})\)\s*$/i.exec(String(label || "").trim()); return m ? m[1].toUpperCase() : ""; };
  const normEsame = (s) => String(s || "").replace(/\s+/g, " ").trim().toUpperCase();

  // Dove va un esame in QUESTA sede. Le risorse cambiano numero da una sede
  // all'altra (e si riconoscono per nome), ma una sede può anche non avere
  // proprio quella risorsa: a OSG il laboratorio «Urgenze» non esiste, e i
  // suoi esami stanno nel laboratorio unico. Allora vale la risorsa offerta
  // qui che ha lo STESSO esame — stesso nome o stesso mnemonico LIS — e mai un
  // POC per un esame che POC non è (è un altro strumento, un'altra provetta),
  // né il contrario. Nessun esame viene inviato sulla fiducia di questa
  // scelta: il nome vero si ricontrolla sull'elenco vivo prima di ogni invio.
  const ePoc = (label) => /\bPOC\b/i.test(String(label || ""));
  function risorsaQui(it, opzioni, cat) {
    const offerte = new Set(opzioni.map((o) => o.value));
    if (!it.res || offerte.has(it.res)) return it.res ? { res: it.res } : null;
    const nomeRis = (cat[it.res] && cat[it.res].label) || "";
    const atteso = chiaveRisorsa(nomeRis);
    const stessoNome = atteso ? opzioni.find((o) => chiaveRisorsa(o.label) === atteso) : null;
    if (stessoNome) return { res: stessoNome.value, perNome: true, opt: stessoNome };
    const mioPoc = ePoc(nomeRis) || ePoc(it.label);
    const mioNome = normEsame(it.label), mioMn = mnemonico(it.label);
    if (!mioNome || /^ESAME \d+$/.test(mioNome)) return null;
    for (const o of opzioni) {
      if (ePoc(o.label) !== mioPoc) continue;
      const voci = Object.entries((cat[o.value] && cat[o.value].items) || {});
      const hit = voci.find(([, l]) => normEsame(l) === mioNome) || (mioMn ? voci.find(([, l]) => mnemonico(l) === mioMn) : null);
      if (hit) return { res: o.value, code: hit[0], label: hit[1], opt: o };
    }
    return null;
  }
  // Come si chiamano in reparto → come comincia il nome nel catalogo del LIS.
  const ALIAS_RICERCA = {
    PCR: ["PROTEINA C REATTIVA"], PCT: ["PROCALCITONINA"],
    EGA: ["EMOGAS", "EGA "], GGT: ["GAMMA GT"], AST: ["GOT"], ALT: ["GPT"],
    BNP: ["NT PRO-BNP", "NT-PRO", "BNP"], TROPO: ["TROPONINA"], TROP: ["TROPONINA"],
    EMOCROMO: ["EMOCROMOCITOMETRICO"], URINE: ["ESAME URINE"],
  };
  // a parità di nome: urgenze, poi il laboratorio, poi il POC, poi il resto
  function ordineRisorsa(res, cat) {
    const l = chiaveRisorsa((cat[res] && cat[res].label) || "");
    if (/URGENZ/.test(l)) return 0;
    if (/\bPOC\b/.test(l)) return 2;
    if (/^LABORATORIO/.test(l)) return 1;
    return 3;
  }
  // un nome corto per una risorsa che RES_SHORT non conosce (quelle di
  // un'altra sede): «LABORATORIO ANALISI POC - OSG (P)» → «POC»
  function risorsaCorta(res, cat = fullCatalog()) {
    if (RES_SHORT[res]) return RES_SHORT[res];
    const l = chiaveRisorsa((cat[res] && cat[res].label) || "");
    if (!l) return res;
    if (/\bPOC\b/.test(l)) return "POC";
    if (/URGENZ/.test(l)) return "Lab centrale";
    if (/^RADIOLOGIA/.test(l)) return l.replace(/^RADIOLOGIA\s*-?\s*/, "").replace(/RISONANZA MAGNETICA NUCLEARE/, "RMN").trim() || "Radiologia";
    if (/^LABORATORIO/.test(l)) return "Lab centrale";
    return l.slice(0, 18);
  }

  function fullCatalog() {
    const out = {};
    for (const [res, v] of Object.entries(EMBEDDED_CATALOG)) out[res] = { label: v.label, items: { ...v.items } };
    for (const [res, v] of Object.entries(learnedCatalog())) {
      out[res] = out[res] || { label: v.label || res, items: {} };
      if (v.label) out[res].label = v.label;
      Object.assign(out[res].items, v.items);
    }
    return out;
  }
  const examLabel = (res, code) => (fullCatalog()[res]?.items || {})[code] || `esame ${code}`;
  // Il laboratorio affianca al vecchio esame la sua versione «- NEW» e lascia
  // in elenco tutti e due (l'emogas venoso e l'arterioso sono così). Chi
  // ordina vuole il nuovo. Il confronto è sul NOME, non sul numero, che cambia
  // da un ospedale all'altro.
  // NB: si toglie SOLO il mnemonico in fondo — «(POC2117)» — non tutte le
  // parentesi: «EPATITE B (HBSAG) ANTICORPI» e «EPATITE B (HBEAG) ANTICORPI»
  // sono due esami diversi e diventerebbero lo stesso nome.
  const baseEsame = (label) => String(label || "").replace(/&nbsp;/gi, " ").toUpperCase()
    .replace(/\s*\([A-Z]*\d+\)\s*$/, " ").replace(/\s+-\s*NEW\b/g, " ").replace(/\bPOC\b/g, " ")
    .replace(/[^A-Z0-9()]+/g, " ").trim();
  const eNuovo = (label) => /\s-\s*NEW\b/i.test(String(label || "").replace(/&nbsp;/gi, " "));
  // Due nomi che parlano dello stesso esame: identici, stesso mnemonico, o
  // l'uno dentro l'altro parola per parola — «BILIRUBINA TOTALE REFLEX» mette
  // in carrello «BILIRUBINA TOTALE». Serve SOLO a riconoscere la riga che il
  // nostro inserimento ha appena prodotto: nessun esame viene mai scelto o
  // inviato in base a questo.
  const stessoEsame = (a, b) => {
    const x = baseEsame(a), y = baseEsame(b);
    if (!x || !y) return false;
    if (x === y) return true;
    const ma = mnemonico(a), mb = mnemonico(b);
    if (ma && ma === mb) return true;
    const [lungo, corto] = x.length >= y.length ? [x, y] : [y, x];
    return corto.length >= 6 && ` ${lungo} `.includes(` ${corto} `);
  };
  // UI-facing short name (falls back to the catalog label, trimmed of its code)
  const displayLabel = (res, code) => DISPLAY[`${res}:${code}`] || shortLabel(examLabel(res, code));

  // ================================================================ ENGINE
  // A run is a linear list of steps executed by runPlan(). Each step updates
  // its own status so the UI can render live progress.
  //
  // plan = {
  //   startPage: 'patient' | 'crea' | 'exam' | 'ripresa',
  //   entryUrl:  (patient only) crea-page URL to open,
  //   creaForm:  (crea only) the LIVE form element to serialize,
  //   examDoc/examUrl: (exam only) the live page — used ONLY to find the
  //              list URL, which is then re-read from the server,
  //   quesito:   text used only if the server field is empty,
  //   items:     [{res, code, label}],
  //   autoConfirm: boolean,
  //   episodeId: pinned patient episode,
  //   listUrl:   (ripresa only) the exam list to re-read — nothing is created,
  //   items:     (ripresa) what is still to send; the one that was IN FLIGHT
  //              when the page changed comes first, marked soloVerifica: it is
  //              looked up in the cart and NEVER sent again.
  // }

  function orderItems(items, currentRes) {
    const rank = (r) => (r === currentRes ? "0" : "1" + r);
    return [...items].sort((a, b) => rank(a.res).localeCompare(rank(b.res)) || a.code.localeCompare(b.code));
  }

  function applyExclusions(items, log) {
    let out = [...items];
    for (const rule of EXCLUDE) {
      const has = out.some((i) => i.res === rule.keep[0] && i.code === rule.keep[1]);
      if (!has) continue;
      const before = out.length;
      out = out.filter((i) => !(i.res === rule.drop[0] && i.code === rule.drop[1]));
      if (out.length !== before) log(`↺ ${rule.note}`);
    }
    const seen = new Set();
    return out.filter((i) => { const k = i.res + ":" + i.code; if (seen.has(k)) return false; seen.add(k); return true; });
  }

  async function runPlan(plan, ui) {
    const ctrl = new AbortController();
    const signal = ctrl.signal;
    // Un giro solo si riprende dopo un cambio pagina; una catena
    // lab+radiologia no: le sue due gambe vivono nella memoria del pannello,
    // e a metà non si riprendono. Lì si avvisa prima di uscire, come sempre.
    plan.riprendibile = !plan.hold;
    const token = Math.random().toString(36).slice(2);   // questo motore, per il presidio
    // La pagina che se ne va porta via il motore: il presidio si molla subito,
    // o la pagina dopo crederebbe che ci sia ancora qualcuno a lavorare.
    const mollaPresidio = () => liberaPresidio(token);
    window.addEventListener("pagehide", mollaPresidio);
    const state = {
      steps: [], added: [], stop: () => ctrl.abort(),
      finishedListUrl: null, lastListUrl: null, richiestaId: null,
    };
    ui.beginRun(state, plan);
    const log = (msg) => ui.log(`${now()}  ${msg}`);
    // Any fetched page that is a login page means the session died mid-flow.
    const guardSession = (doc, whatMayHaveHappened) => {
      if (classify(doc) === "login") {
        const e = restaQui(new StopError("Sessione scaduta durante l'operazione",
          `${whatMayHaveHappened ? whatMayHaveHappened + ". " : ""}Rifai l'accesso e controlla il carrello.`));
        e.sessione = true;
        throw e;
      }
    };
    const step = (label) => {
      const s = { label, status: "pending", note: "" };
      state.steps.push(s);
      return s;
    };
    const running = (s, note) => { s.status = "running"; if (note) s.note = note; ui.renderRun(state); };
    const done = (s, note) => { s.status = "ok"; if (note) s.note = note; ui.renderRun(state); };
    const pace = () => sleep(PACE_MS, signal);

    plan.items = applyExclusions(plan.items, log);

    // Pre-build the visible step list.
    const legTag = plan.legLabel ? ` (${plan.legLabel})` : "";
    const riprende = plan.startPage === "ripresa";
    const sOpen = plan.startPage === "patient" ? step("Apro la nuova richiesta" + legTag) : null;
    const sRipresa = riprende ? step("Riprendo la richiesta da dov'ero") : null;
    const sCrea = plan.startPage !== "exam" && !riprende ? step("Compilo quesito e creo la richiesta" + legTag) : null;
    const itemSteps = new Map();
    // i passi-esame si contano a parte: la striscia dice «esame 2 di 6», non i passi
    for (const it of plan.items) { const s = step(it.display || it.label); s.esame = true; itemSteps.set(it, s); }
    const sEnd = step(riprende && !plan.autoConfirm ? "Chiudo: il carrello è pronto"
      : plan.autoConfirm ? "Passo alla pagina esami per la conferma" : "Passo alla pagina esami per la revisione");
    ui.renderRun(state);

    try {
      // ---- 1. reach the exam page --------------------------------------
      let doc, url;
      if (plan.startPage === "patient") {
        running(sOpen);
        ({ doc, url } = await fetchDoc(plan.entryUrl, { signal }));
        guardSession(doc, "Nessuna richiesta creata");
        assertSameEpisode(doc, plan.episodeId, "nuova richiesta");
        if (classify(doc) !== "crea") throw new StopError("Pagina Nuova Richiesta inattesa", "Il server non ha aperto la pagina prevista. Nessuna richiesta creata.");
        done(sOpen);
      }

      if (riprende) {
        // Non si crea niente e non si manda niente: si rilegge l'elenco della
        // richiesta che era già aperta, e da lì si continua.
        running(sRipresa);
        ({ doc, url } = await fetchDoc(plan.listUrl, { signal }));
        guardSession(doc, "Nessun esame inviato");
        assertSameEpisode(doc, plan.episodeId, "elenco esami");
        if (classify(doc) !== "exam") {
          log(`elenco esami inatteso alla ripresa: "${snippet(doc)}"`);
          throw new StopError("Non ritrovo l'elenco esami della richiesta", "Il giro si ferma qui: apri il carrello e controlla.");
        }
        done(sRipresa);
      } else if (plan.startPage !== "exam") {
        running(sCrea);
        if (plan.startPage === "patient") await pace();
        let form, base;
        if (plan.startPage === "crea") { form = plan.creaForm; base = plan.creaUrl; }
        else { form = doc.querySelector('form[name="RICHIESTACrea"]'); base = url; }
        if (!form) throw new StopError("form RICHIESTACrea non trovato");

        const quesitoEl = form.elements.namedItem("QUESITO_DIAGNOSTICO");
        if (quesitoEl) {
          const existing = (quesitoEl.value || "").trim();
          if (!existing) {
            const q = (plan.quesito || "").trim();
            if (!q) throw new StopError("Quesito diagnostico mancante", "Scrivilo nel pannello e riprova. Nessuna richiesta creata.");
            quesitoEl.value = q;
            scrittura.nostri.add(quesitoEl);   // scritto da noi: non è il medico che sta scrivendo
          } else {
            state.quesitoKept = existing;
            log(`quesito del triage mantenuto: "${existing.slice(0, 60)}"`);
          }
        }
        const submit = form.querySelector('input[type="submit"][name="Update"]');
        if (!submit) throw new StopError('bottone "Crea" non trovato');
        const body = encodeFormBody(serializeForm(form, submit));
        const action = absUrl(form, "action", base);
        ({ doc, url } = await fetchDoc(action, { method: "POST", body, signal }));
        guardSession(doc, "La richiesta potrebbe non essere stata creata");
        assertSameEpisode(doc, plan.episodeId, "esami della richiesta");
        if (classify(doc) !== "exam") {
          log(`pagina inattesa dopo Crea: "${snippet(doc)}"`);
          throw new StopError("Il server non ha aperto la pagina esami dopo la creazione", "Controlla a mano (vedi Registro).");
        }
        done(sCrea);
        await pace();
      } else {
        // La pagina esami che il medico ha davanti NON è una fonte attendibile:
        // gli inserimenti viaggiano in background, quindi dopo una corsa
        // interrotta il carrello sullo schermo è quello di prima. Fidarsene
        // vorrebbe dire leggere «non c'è» un esame che c'è già — e ordinarlo
        // una seconda volta. Del DOM vivo si prende solo l'INDIRIZZO
        // dell'elenco, e lo si rilegge dal server come fa tutto il resto del
        // motore: una richiesta in più, e in cambio i due controlli che questa
        // strada saltava — sessione scaduta ed episodio.
        const vivo = examModel(plan.examDoc, plan.examUrl);
        ({ doc, url } = await fetchDoc(vivo.listUrl(vivo.res) || plan.examUrl, { signal }));
        guardSession(doc, "Nessun esame inviato");
        assertSameEpisode(doc, plan.episodeId, "esami della richiesta");
        if (classify(doc) !== "exam") {
          log(`pagina esami inattesa alla partenza: "${snippet(doc)}"`);
          throw new StopError("Questa non è più la pagina degli esami", "Ricaricala e riprova. Nessun esame inviato.");
        }
      }

      // ---- 2. add each exam, verifying every add ------------------------
      let model = examModel(doc, url);
      learnFrom(model);
      // «↻ Riprova» lavora sul carrello della richiesta di prima e su nessun
      // altro: un elenco di un'altra richiesta non si tocca.
      if (plan.richiestaId && String(model.richiestaId) !== String(plan.richiestaId)) {
        throw new StopError("Non è il carrello della richiesta di prima", "Nessun esame inviato.");
      }
      state.richiestaId = model.richiestaId;
      const noteList = () => { const u = model.listUrl(model.res); if (u) state.lastListUrl = u; };
      noteList();
      if (!state.lastListUrl) throw new StopError("Impossibile ricostruire l'indirizzo dell'elenco esami", "Nessun esame inviato.");
      const offered = new Set(model.resOptions.map((o) => o.value));
      if (offered.size) {
        const cat = fullCatalog();
        for (const i of plan.items) {
          if (!i.res || offered.has(i.res)) continue;
          const dove = risorsaQui(i, model.resOptions, cat);
          if (!dove) continue;
          if (dove.perNome) log(`risorsa di questo presidio: «${dove.opt.label}» ${dove.res} (nel catalogo ${i.res})`);
          else log(`«${i.display || i.label}»: qui la risorsa ${risorsaCorta(i.res, cat)} non c'è — lo stesso esame sta in «${dove.opt.label}»`);
          i.resCat = i.res;        // il catalogo che conosce questo esame resta quello di partenza
          i.res = dove.res;        // the exam's own name is verified before any send
          if (dove.code && dove.code !== i.code) i.code = dove.code;
        }
        const wrongRes = plan.items.filter((i) => i.res && !offered.has(i.res));
        if (wrongRes.length) {
          const qui = model.resOptions.map((o) => `«${o.label}» ${o.value}`).join(", ") || "nessuna";
          const cercate = [...new Set(wrongRes.map((i) => `«${(cat[i.res] && cat[i.res].label) || RES_SHORT[i.res] || i.res}» ${i.res}`))].join(", ");
          log(`risorse offerte qui: ${qui} — cercavo: ${cercate}`);
          throw new StopError("Esami non ordinabili in questa richiesta",
            `${wrongRes.map((i) => `«${i.display || i.label}»`).join(", ")}. Questa richiesta offre ${qui}. Nessun esame inviato.`);
        }
      }

      // Quello che in questo giro era già passato — sistemato prima
      // dell'interruzione, o in volo nell'istante in cui la pagina è cambiata —
      // viene per primo e si CERCA soltanto in carrello: non si rimanda mai.
      const items = [
        ...plan.items.filter((i) => i.soloVerifica),
        ...orderItems(plan.items.filter((i) => !i.soloVerifica), model.res),
      ];
      state.ordine = items;   // l'ordine vero: dice qual è il primo esame rimasto fuori
      // Il giro annotato dove sopravvive al cambio pagina: cosa è già entrato,
      // cosa era in volo, cosa resta. Si riscrive a ogni passo — è la memoria
      // da cui il pannello riparte, e l'unica che non muore con la pagina.
      // …con la risorsa di catalogo di partenza: serve al ritorno alla versione
      // vecchia in una sede che la «- NEW» non ce l'ha
      const nudo = (i) => ({ res: i.res, code: i.code, label: i.label, display: i.display || i.label,
        ...(i.resCat ? { resCat: i.resCat } : {}) });
      const salvaCorsa = (inVolo, resto) => {
        if (!plan.riprendibile) return;
        // Un esame che è già passato di qui non torna mai fra quelli «da
        // mandare»: resta fra i fatti, e alla ripresa si cerca in carrello.
        const rimasti = resto || [];
        segnaPresidio(state.richiestaId, token);
        const restano = rimasti.filter((x) => !x.soloVerifica).length + (inVolo ? 1 : 0);
        // Il segno condiviso: se questa scheda muore, la prima pagina utile —
        // anche in un'altra scheda — dirà che un giro è rimasto a metà.
        store.set(APERTA, restano
          ? { ts: Date.now(), ep: plan.episodeId, paziente: plan.patientName || "", rid: state.richiestaId || null, quanti: restano }
          : null);
        const scritto = tabStore.set(CORSA, {
          ts: Date.now(), ep: plan.episodeId, paziente: plan.patientName || "",
          autoConfirm: !!plan.autoConfirm, quesito: plan.quesito || "",
          rid: state.richiestaId || null, listUrl: state.lastListUrl || null,
          riprese: plan.riprese || 0,
          // «in volo» resta in volo finché non lo si ritrova: se scivolasse fra
          // i fatti, alla ripresa dopo passerebbe per uno che qualcuno ha tolto
          // dal carrello — e un esame mai partito sparirebbe in silenzio.
          fatti: [...state.added, ...rimasti.filter((x) => x.giaFatto)].map(nudo),
          involo: inVolo ? nudo(inVolo) : (rimasti.find((x) => x.soloVerifica && !x.giaFatto) ? nudo(rimasti.find((x) => x.soloVerifica && !x.giaFatto)) : null),
          restanti: rimasti.filter((x) => !x.soloVerifica).map(nudo),
        });
        // Memoria piena o bloccata: l'appunto non c'è. Non si promette una
        // ripresa che non ci sarà — si dice, una volta sola, e da qui in poi
        // il giro è quello di prima: se cambi pagina, va perso.
        if (!scritto && plan.riprendibile) {
          plan.riprendibile = false;
          log("⚠ non riesco ad annotare il giro: se cambi pagina adesso, quello che resta non riparte da solo");
        }
      };
      for (let i = 0; i < items.length; i++) {
        const it = items[i];
        const st = itemSteps.get(it);
        const nm = it.display || it.label; // short name for messages
        salvaCorsa(null, items.slice(i));   // da qui in poi, questo è ancora da mandare
        running(st);
        await pace(); // pace AFTER marking, so exactly one step is always live

        // Switch list when the exam lives on another resource.
        if (it.res && model.res !== it.res) {
          running(st, `passo a ${risorsaCorta(it.res)}`);
          ({ doc, url } = await fetchDoc(model.listUrl(it.res) || state.lastListUrl, { signal }));
          guardSession(doc);
          assertSameEpisode(doc, plan.episodeId, "elenco esami");
          model = examModel(doc, url);
          learnFrom(model);
          if (model.res !== it.res) throw new StopError(`Cambio risorsa fallito (${risorsaCorta(it.res)})`, "Nessun ordine inviato per questo esame.");
          noteList();
        }

        if (model.inCart(it.code)) {
          done(st, "già nel carrello");
          log(`già presente ✓ ${nm}`);
          state.added.push(it);
          // anche qui il carrello vero di questa risorsa va registrato: la
          // conferma automatica confronta la ricevuta col carrello, e una
          // risorsa mai «toccata» in questo giro le risulterebbe non vista
          state.carrelli = state.carrelli || {};
          state.carrelli[model.res] = model.exams.filter((e) => e.isDel).map((e) => String(e.code));
          salvaCorsa(null, items.slice(i + 1));
          continue;
        }
        if (it.soloVerifica) {
          // Questo era IN VOLO quando la pagina è cambiata: il server può
          // averlo preso lo stesso. Si guarda — con le stesse riletture di
          // sempre — e non si rimanda mai: un esame ordinato due volte è una
          // provetta in più al laboratorio.
          running(st, "controllo se è entrato…");
          let riga = null;
          for (let attempt = 1; !riga && attempt <= VERIFY_RECHECKS; attempt++) {
            running(st, `controllo il carrello ${attempt}/${VERIFY_RECHECKS}…`);
            await sleep(VERIFY_WAIT_MS, signal);
            ({ doc, url } = await fetchDoc(model.listUrl(it.res || model.res) || state.lastListUrl, { signal }));
            guardSession(doc, `«${nm}» potrebbe essere stato aggiunto o no`);
            assertSameEpisode(doc, plan.episodeId, "verifica carrello");
            if (classify(doc) !== "exam") { log(`pagina inattesa in verifica: "${snippet(doc)}"`); continue; }
            model = examModel(doc, url);
            noteList();
            // Qui la fotografia «prima» non c'è più: senza, «POTASSIO» si
            // riconoscerebbe in «POTASSIO URINARIO». Vale il proprio codice,
            // il nome IDENTICO, o lo stesso mnemonico LIS — niente di più
            // largo, o si dichiara entrato un esame che non c'è.
            riga = model.inCart(it.code) ? { code: it.code, label: it.label }
              : model.exams.find((e) => e.isDel && (
                baseEsame(e.label) === baseEsame(it.label) ||
                (mnemonico(it.label) && mnemonico(e.label) === mnemonico(it.label)))) || null;
          }
          if (!riga) {
            if (it.giaFatto) {
              // era entrato prima dell'interruzione e adesso non c'è più: lo
              // ha tolto qualcuno a mano. Non si rimette: si dice e si va.
              st.status = "skipped"; st.note = "non è più in carrello";
              it.tolto = true;   // tolto a mano: non è uno «da aggiungere»
              log(`⚠ «${nm}» era in carrello e adesso non c'è più: non lo rimetto`);
              ui.renderRun(state);
              salvaCorsa(null, items.slice(i + 1));
              continue;
            }
            throw new StopError(`«${nm}»: invio interrotto dal cambio pagina`,
              "Non risulta nel carrello e NON è stato rimandato. Apri il carrello e controlla.");
          }
          if (riga.code !== it.code) {
            log(`«${nm}» era entrato come «${riga.label}» (${riga.code})`);
            it.code = riga.code; it.label = riga.label;
          }
          done(st, "nel carrello ✓");
          log(`ritrovato ✓ ${nm}`);
          state.added.push(it);
          // il carrello vero di questa risorsa, come per un inserimento: senza,
          // una ripresa fatta di sole verifiche lascerebbe la ricevuta vuota e
          // la conferma automatica si sospenderebbe da sola
          state.carrelli = state.carrelli || {};
          state.carrelli[model.res] = model.exams.filter((e) => e.isDel).map((e) => String(e.code));
          salvaCorsa(null, items.slice(i + 1));
          continue;
        }
        // La versione «- NEW» dello stesso esame, se la pagina ne offre una:
        // si guarda l'elenco VIVO, non il catalogo, così vale in ogni sede e
        // anche per gli esami nuovi che il catalogo non ha mai visto.
        // …e al contrario: se qui la «- NEW» non c'è ancora, si torna a quella
        // di sempre invece di fallire per un codice che questa sede non ha.
        if (!/^esame \d+$/i.test(it.label)) {
          const mia = baseEsame(it.label);
          const trova = (nuova) => mia && model.exams.find((e) => e.isAdd && eNuovo(e.label) === nuova && baseEsame(e.label) === mia);
          let scelto = trova(true) || (eNuovo(it.label) ? trova(false) : null);
          // Qui la «- NEW» non c'è e nemmeno la sua gemella in elenco: si
          // torna alla vecchia del NOSTRO catalogo. Serve davvero, perché la
          // versione nuova ha anche un mnemonico nuovo (POC21171 contro
          // POC2117): senza questo passo, in una sede che ha solo la vecchia
          // e la chiama in un altro modo non la ritroverebbe più nessuno.
          if (!scelto && eNuovo(it.label)) {
            const items = (fullCatalog()[it.resCat || it.res]?.items) || {};
            const twin = Object.entries(items).find(([c, l]) => c !== it.code && !eNuovo(l) && baseEsame(l) === mia);
            if (twin) scelto = { code: twin[0], label: twin[1] };
          }
          if (scelto && scelto.code !== it.code) {
            log(eNuovo(scelto.label)
              ? `questa sede ha la versione nuova: «${scelto.label}» al posto di «${it.label}»`
              : `qui la versione «- NEW» non c'è: uso «${scelto.label}»`);
            it.code = scelto.code; it.label = scelto.label;
          }
        }
        // la riga dell'esame su un elenco: col suo codice o — il numero cambia
        // da un presidio all'altro, l'esame no — col nome esatto o col
        // mnemonico che il LIS stampa fra parentesi. Mai per somiglianza.
        const rigaDi = (m) => {
          const l = m.addLink(it.code);
          if (l || /^esame \d+$/i.test(it.label)) return l || null;
          const mio = mnemonico(it.label);
          const perNome = m.exams.find((e) => e.isAdd && normEsame(e.label) === normEsame(it.label));
          const alt = perNome || (mio ? m.exams.find((e) => e.isAdd && mnemonico(e.label) === mio) : null);
          if (!alt) return null;
          log(`codice di questo presidio: ${alt.code} per «${alt.label}» (nel catalogo ${it.code})`);
          it.code = alt.code;
          return alt;
        };
        let link = rigaDi(model);
        // Né il codice né il nome sull'elenco: a volte arriva monco (la riga
        // c'è, ma non si vede). Lo si rilegge UNA volta con la ricerca del
        // gestionale — una semplice lettura — e la riga che compare passa per
        // la strada di sempre: il nome vivo controllato, un invio solo. Se non
        // c'è nemmeno lì, non si manda niente: lo si aggiunge a mano.
        let cercato = false, giaCercando = false, riletto = false;
        if (!link && !/^esame \d+$/i.test(it.label) && !model.inCart(it.code)) {
          const termine = termineRicerca(it.label);
          const su = urlRicerca(model.listUrl(it.res || model.res), termine);
          if (su) {
            running(st, `cerco «${termine}»…`);
            log(`«${nm}» non è sull'elenco: lo cerco con la ricerca del gestionale («${termine}»)`);
            const r = await fetchDoc(su, { signal });
            guardSession(r.doc, "Nessun esame inviato");
            assertSameEpisode(r.doc, plan.episodeId, "ricerca esame");
            const trovata = classify(r.doc) === "exam" ? examModel(r.doc, r.url) : null;
            if (!trovata) log(`pagina inattesa nella ricerca: "${snippet(r.doc)}"`);
            else if (trovata.res !== model.res || trovata.richiestaId !== model.richiestaId) log("la ricerca ha risposto con un altro elenco: non la uso");
            else {
              riletto = true;
              link = rigaDi(trovata);
              giaCercando = trovata.inCart(it.code);
              if (link) { cercato = true; log(`riletto con la ricerca del gestionale: «${link.label}»`); }
            }
            await pace();
          }
        }
        if (!link) {
          const gia = model.inCart(it.code) || giaCercando;
          throw new StopError(`«${nm}» non è nell'elenco di ${risorsaCorta(it.res)}`,
            gia ? "Risulta già nel carrello: controlla a mano."
              : riletto ? "Non c'è nemmeno con la ricerca del gestionale: non inviato. Aggiungilo a mano." : "Non inviato. Completa a mano.");
        }
        // Anti wrong-exam guardrail: the LIVE row label must match what the
        // doctor picked. If the hospital ever renumbers a code, every other
        // check would stay green — this one goes red BEFORE anything is sent.
        // (skipped for items carrying only the "esame N" fallback label)
        // Dashes differ between sites ("PANNELLO 1 – ANEMIA" vs "- ANEMIA") and
        // so does the odd word ("EMOGASANALISI MISTA" vs "CAPILLARE", same
        // POC2117). Typography is never a rename, and neither is a different
        // wording carrying the SAME LIS mnemonic — anything else still stops.
        const norm = (s) => s.replace(/[–—‐‑‒−]/g, "-").replace(/\s+/g, " ").trim().toUpperCase();
        if (!/^esame \d+$/i.test(it.label) && norm(link.label) !== norm(it.label)) {
          const mioMn = mnemonico(it.label), suoMn = mnemonico(link.label);
          if (!mioMn || mioMn !== suoMn) {
            throw new StopError(`Il codice ${it.code} oggi si chiama «${link.label}»`, `Selezionato come «${nm}» — non inviato.`);
          }
          log(`stesso esame, nome diverso in questa sede: «${link.label}» (${suoMn})`);
        }

        // ---- the one and only send of this exam -----------------------
        running(st, "invio…");
        log(`aggiungo → ${nm}`);
        // Il carrello com'è un attimo prima: se l'esame entra sotto un altro
        // codice — le prestazioni «REFLEX» lo fanno — è questa differenza a
        // dire quale riga ha prodotto il nostro clic.
        // Un'altra scheda sta mandando gli esami di QUESTA richiesta (succede
        // duplicando la scheda: si porta dietro l'appunto del giro). Due
        // motori sullo stesso carrello vuol dire due volte lo stesso esame.
        if (!presidioLibero(state.richiestaId, token)) {
          throw restaQui(new StopError("Un'altra scheda sta mandando gli esami di questa richiesta",
            "Da qui non mando niente. Finisci di là, o ricarica questa pagina."));
        }
        const prima = new Set(model.exams.filter((e) => e.isDel).map((e) => e.code));
        salvaCorsa(it, items.slice(i + 1));   // da qui è IN VOLO: non si rimanda
        it.inviato = true;   // da qui, se non si vede in carrello, è «da controllare» — mai «manca»
        ({ doc, url } = await fetchDoc(link.href, { signal }));
        guardSession(doc, `«${nm}» potrebbe essere stato aggiunto o no`);
        assertSameEpisode(doc, plan.episodeId, "conferma inserimento");
        // Una pagina inattesa QUI non dice che l'esame non sia entrato:
        // l'inserimento è già partito. Invece di fermarsi al buio si rilegge
        // l'elenco pulito — mai un secondo invio — e si guarda il carrello.
        if (classify(doc) !== "exam") {
          log(`pagina inattesa dopo l'inserimento: "${snippet(doc)}" — rileggo il carrello`);
        } else {
          model = examModel(doc, url);
          learnFrom(model);
          noteList();
        }

        // ---- verify (re-reading the clean list only — never re-insert) --
        // In carrello l'esame può comparire col proprio codice oppure, se è a
        // riflesso, con quello dell'esame che ne deriva: una riga nuova vale
        // solo se porta il NOME di quello che il medico ha scelto.
        const entrato = () => {
          if (model.inCart(it.code)) return { code: it.code, label: it.label };
          const nuove = model.exams.filter((e) => e.isDel && !prima.has(e.code));
          if (nuove.length) log(`nuove righe in carrello: ${nuove.map((e) => `«${e.label}» ${e.code}`).join(", ")}`);
          return nuove.find((e) => stessoEsame(e.label, it.label)) || null;
        };
        // Mandato da una ricerca, la risposta è l'elenco FILTRATO: il carrello
        // che la conferma automatica confronta deve essere quello intero, e
        // lo dà solo una rilettura dell'elenco pulito.
        let verified = classify(doc) === "exam" && !cercato && entrato();
        for (let attempt = 1; !verified && attempt <= VERIFY_RECHECKS; attempt++) {
          running(st, `verifica ${attempt}/${VERIFY_RECHECKS}…`);
          await sleep(VERIFY_WAIT_MS, signal);
          ({ doc, url } = await fetchDoc(model.listUrl(it.res || model.res) || state.lastListUrl, { signal }));
          guardSession(doc, `«${nm}» potrebbe essere stato aggiunto o no`);
          assertSameEpisode(doc, plan.episodeId, "verifica carrello");
          if (classify(doc) !== "exam") {
            log(`pagina inattesa in verifica: "${snippet(doc)}"`);
            continue; // count the attempt; the next re-read may recover
          }
          model = examModel(doc, url);
          verified = entrato();
          noteList();
        }
        if (!verified) {
          // Una riga che porta lo stesso esame sotto un altro nome c'era già
          // PRIMA del nostro clic: non vale come conferma — potrebbe essere
          // un altro esame con un nome che somiglia — ma dirlo evita al medico
          // di cercare al buio.
          const simile = model.exams.find((e) => e.isDel && stessoEsame(e.label, it.label));
          throw new StopError(`«${nm}» non risulta nel carrello`,
            simile ? `In carrello c'è «${simile.label}»: forse c'era già. Non reinviato — controlla.`
              : `Verificato ${VERIFY_RECHECKS} volte, non reinviato. Apri il carrello.`);
        }
        // È entrato con un altro numero: da qui in poi l'esame è QUELLA riga —
        // la ricevuta, il carrello registrato e la conferma automatica devono
        // parlare del carrello vero, non di quello che avevamo chiesto.
        if (verified.code !== it.code) {
          log(`«${nm}» è entrato come «${verified.label}» (${verified.code})`);
          it.code = verified.code;
          it.label = verified.label;
        }
        done(st, "nel carrello ✓");
        log(`aggiunto ✓ ${nm}`);
        state.added.push(it);
        salvaCorsa(null, items.slice(i + 1));
        // Il carrello di QUESTA risorsa come lo vediamo adesso. La Conferma
        // nativa invia la richiesta INTERA, comprese le righe che stanno sul
        // carrello di un'altra risorsa e che questa pagina non mostra: senza
        // registrarle qui, l'auto-conferma non potrebbe nemmeno vederle.
        state.carrelli = state.carrelli || {};
        state.carrelli[model.res] = model.exams.filter((e) => e.isDel).map((e) => String(e.code));
      }

      // ---- 3. hand the visible tab over for review / native confirm -----
      running(sEnd);
      const last = state.added[state.added.length - 1] || null;
      const landUrl = model.listUrl(last ? last.res : model.res);
      state.finishedListUrl = landUrl;
      // Receipt for the landing page: the panel there shows the full,
      // verified accounting (including exams on other resources).
      if (!plan.hold) tabStore.set("receipt.v1", {
        richiestaId: model.richiestaId, episodeId: plan.episodeId, ts: Date.now(),
        quesitoKept: state.quesitoKept || null,
        carrelli: state.carrelli || {},
        items: state.added.map((i) => ({ res: i.res, code: i.code, label: i.label, display: i.display || i.label })),
      });
      // Radiology is deliberately excluded from auto-confirm (README, collaudo
      // step 8-9): a booking must always be a human click.
      const isRadio = state.added.some((i) => RADIO_SET.includes(i.res));
      if (plan.autoConfirm && state.added.length && !plan.hold && !isRadio) {
        tabStore.set("confirm.v1", {
          richiestaId: model.richiestaId, episodeId: plan.episodeId,
          lastCode: last.code, lastLabel: last.label, count: state.added.length, ts: Date.now(),
        });
      }
      done(sEnd);
      // Da qui in poi il giro non ha più esami da mandare: quello che resta
      // (conferma e stampa) ha già i suoi passaggi di consegna fra le pagine.
      tabStore.set(CORSA, null);
      store.set(APERTA, null);
      liberaPresidio(token);
      window.removeEventListener("pagehide", mollaPresidio);
      log(plan.autoConfirm ? "tutti verificati — passo alla pagina esami per la conferma" : "tutti verificati — rivedi il carrello e premi Conferma");
      ui.finished(state, plan);
      return state;
    } catch (err) {
      // Una decisione — STOP del medico, o un controllo che ha detto no — mette
      // fine al giro: da lì in poi decide lui, con quello che il pannello gli
      // ha appena detto. Un errore non deciso (la rete, o la pagina che muore
      // mentre navighi) invece NON cancella il giro: è proprio quello da cui
      // si riprende.
      if (signal.aborted || err?.name === "AbortError" || err instanceof StopError) {
        tabStore.set(CORSA, null);
        store.set(APERTA, null);   // fermato o fallito: il medico lo sta leggendo adesso
        liberaPresidio(token);
        window.removeEventListener("pagehide", mollaPresidio);
      }
      // Make the failure legible in the step plan: the live step goes red,
      // everything not yet run is explicitly "skipped".
      for (const s of state.steps) {
        if (s.status === "running") { s.status = "fail"; s.note = "fermato qui"; }
        else if (s.status === "pending") { s.status = "skipped"; s.note = "non eseguito"; }
      }
      // Che cosa è in carrello e che cosa resta da aggiungere a mano: è quello
      // che il medico deve sapere per finire dal gestionale. (Un esame tolto a
      // mano durante il giro non è «da aggiungere».)
      const nomeDi = (x) => x.display || shortLabel(x.label);
      const fuori = (state.ordine || plan.items).filter((x) => !state.added.includes(x) && !x.tolto);
      // Mandato (o in volo, o già entrato prima di un cambio pagina) ma non
      // visto in carrello adesso: è da CONTROLLARE, non da rifare — chi lo
      // aggiungesse a mano lo ordinerebbe due volte. «Mancano» sono solo
      // quelli mai partiti.
      // (quelli da controllare di un errore prima, lasciati fuori da «Riprova»,
      // restano in elenco: non sono spariti, sono ancora da guardare)
      const controllare = [...fuori.filter((x) => x.inviato || x.soloVerifica), ...(plan.daControllare || [])];
      const mancanoIt = fuori.filter((x) => !controllare.includes(x));
      state.mancanti = mancanoIt;          // per «↻ Riprova i mancanti»: questi soli si mandano
      state.daControllare = controllare;   // …e questi mai
      // il carrello su cui atterrare: quello del laboratorio del primo esame da fare a mano
      const primo = mancanoIt[0] || controllare[0] || null;
      state.resMancante = primo ? primo.res : null;
      const liste = {
        nel: state.added.map(nomeDi),
        mancano: mancanoIt.map(nomeDi),
        controllare: controllare.map(nomeDi),
      };
      if (signal.aborted || err?.name === "AbortError") {
        log("■ interrotto dall'utente");
        ui.stopped(state, { head: "Interrotto", body: "L'ultimo esame inviato potrebbe essere in carrello: controlla.", ...liste }, plan);
      } else if (err instanceof StopError) {
        log(`⚠ ${err.message}`);
        // quanti esami restavano fuori: senza questo, il messaggio parla solo
        // di quello che è andato storto e il resto si vede solo espandendo
        const restavano = plan.items.filter((x) => !state.added.includes(x)).length - 1;
        ui.failed(state, { head: err.head, body: `${err.body || ""}${
          restavano > 0 ? ` Restavano ${restavano === 1 ? "1 altro esame" : restavano + " altri esami"} da mandare.` : ""}`,
          ...liste, restaQui: !!err.restaQui, sessione: !!err.sessione }, plan);
      } else {
        // La pagina che muore mentre navighi arriva qui come una fetch fallita:
        // il giro annotato è ancora lì, e riprende da solo alla pagina dopo.
        const riprende2 = !!tabStore.get(CORSA, null);
        log(`⚠ ${riprende2 ? "giro interrotto" : "errore imprevisto"}: ${err?.message || err}`);
        ui.failed(state, riprende2
          ? { head: "Giro interrotto", body: "Riprende da solo appena si carica una pagina del gestionale: niente viene rimandato due volte.", ...liste }
          : { head: "Errore imprevisto", body: `${err?.message || err} — apri il carrello e controlla.`, ...liste }, plan);
      }
      return state;
    }
  }

  // Che cosa rifà «↻ Riprova i mancanti» dopo un errore: gli esami mai
  // partiti, sulla STESSA richiesta e nello stesso modo (revisione, o conferma
  // automatica e stampa). Quelli già in carrello vanno con loro solo per
  // essere ritrovati — mai rimandati — così ricevuta e conferma parlano della
  // richiesta intera; quelli «da controllare» (mandati e non visti) restano
  // fuori. Se la richiesta non era ancora nata, è un giro nuovo dalla pagina
  // del paziente. Mai per una catena lab+radiologia: a metà non si riprende.
  function ricettaRiprova(state, plan) {
    if (!plan || plan.hold || !plan.episodeId) return null;
    const nudo = (i) => ({ res: i.res, code: i.code, label: i.label, display: i.display || i.label,
      ...(i.resCat ? { resCat: i.resCat } : {}) });
    const mancanti = (state.mancanti || []).map(nudo);
    if (!mancanti.length) return null;
    const suo = plan.examUrl || plan.listUrl;
    const rid = state.richiestaId || (suo ? param(suo, "RICHIESTA_ID") : null);
    if (!rid && plan.startPage !== "patient" && plan.startPage !== "crea") return null;
    return {
      ep: String(plan.episodeId), rid: rid ? String(rid) : null, autoConfirm: !!plan.autoConfirm,
      paziente: plan.patientName || "", patientUrl: plan.patientUrl || "",
      verdi: (state.added || []).map(nudo), mancanti, controllare: (state.daControllare || []).map(nudo),
    };
  }

  // La pianta della Stanza: una griglia di celle tutte uguali, 40 × 24. Un
  // letto prende 5 × 4 celle, un'area almeno 5 × 3. Si salvano solo celle
  // intere: a qualunque misura la stanza si ridisegna uguale, in scala.
  const PIANTA = { cols: 40, rows: 24, lw: 5, lh: 4, aw: 5, ah: 3 };
  // due rettangoli di celle si sovrappongono (con g > 0: stanno a meno di g celle)
  const troppoVicini = (a, b, g = 0) => a.c < b.c + b.w + g && b.c < a.c + a.w + g && a.r < b.r + b.h + g && b.r < a.r + a.h + g;

  // ============================================================== UI (panel)
  // Shadow-DOM panel, top right. Collapsible pill with live state; per-page
  // content; running/error states designed to be legible from a metre away;
  // countdown handoff for the native confirm. Design system: one brand blue,
  // green = verified in cart, amber = armed/attention, red = abort/error.

  const COLORS = `
    :host { all: initial; }
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; }
    .wrap { position: fixed; top: 10px; right: 10px; z-index: 2147483647; color: #16232E; }
    .pill { display: flex; align-items: center; gap: 8px; background: #0B5CAD; color: #fff; border: 0; border-radius: 999px;
            padding: 9px 15px 9px 11px; font-size: 13px; font-weight: 600; cursor: pointer; box-shadow: 0 4px 14px rgba(9,42,74,.22);
            touch-action: none; }
    .pill:active { cursor: grabbing; }
    .pill:hover { background: #094a8c; }
    .pill .badge { background: #fff; color: #0B5CAD; border-radius: 999px; padding: 1px 8px; font-size: 11px; font-weight: 800; }
    .pill .dot { width: 8px; height: 8px; border-radius: 50%; background: #7FD1A8; animation: psaPulse 1.2s ease-in-out infinite; }
    /* La striscia del giro in corso: due righe in un angolo, e sotto ci lavori
       come se il pannello non ci fosse. */
    .strip { display: flex; align-items: center; gap: 6px; }
    .pill.run { border-radius: 12px; padding: 7px 13px 7px 11px; max-width: min(380px, 82vw); text-align: left; }
    .pill.run.alt, .pill.run.warn { background: #8A5A00; }
    .pill.run.alt:hover, .pill.run.warn:hover { background: #764d00; }
    /* errore: si completa a mano, nel gestionale */
    .pill.run.err { background: #B3261E; }
    .pill.run.err:hover { background: #8f1e18; }
    .pill .col { display: flex; flex-direction: column; align-items: flex-start; min-width: 0; line-height: 1.3; }
    .pill .l1 { display: flex; align-items: center; gap: 6px; max-width: 100%; min-width: 0; }
    .pill .l1 .who { max-width: 150px; }
    .pill .tag { font-weight: 700; white-space: nowrap; }
    .pill .l2 { font-size: 11.5px; font-weight: 500; opacity: .93; max-width: 100%;
                white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .pill .tick { font-size: 13px; font-weight: 800; }
    .stopmini { border: 0; border-radius: 999px; width: 30px; height: 30px; cursor: pointer; font-size: 12px;
                background: #B3261E; color: #fff; box-shadow: 0 6px 20px rgba(9,42,74,.35); }
    .stopmini:hover { background: #8f1e18; }
    /* un'azione tranquilla accanto al resoconto («Ristampa») */
    .strazione { border: 1px solid #C4D0DC; background: #fff; color: #0B5CAD; border-radius: 999px; padding: 6px 11px;
                 font: inherit; font-size: 12px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 14px rgba(9,42,74,.18); }
    .strazione:hover { background: #F4F8FB; }
    /* La finestra: al centro, l'85% dello schermo. Intestazione, schede e
       selezione restano ferme; scorre solo il corpo. Il contenuto sta su una
       colonna comoda da leggere; valori e stanza usano tutta la larghezza. */
    .wrap.win { display: flex; }
    .card { position: relative; display: flex; flex-direction: column; width: 100%; height: 100%;
            overflow: hidden; background: #fff; border: 1px solid #D9E2EC; border-radius: 14px;
            box-shadow: 0 28px 70px rgba(9,42,74,.24), 0 2px 8px rgba(9,42,74,.08); font-size: 13px; line-height: 1.45; }
    .cap { flex: 0 0 auto; width: 100%; box-sizing: border-box; }
    .bd { flex: 1 1 auto; min-height: 0; overflow: auto; overscroll-behavior: contain; }
    .bdi { padding: 14px 24px; box-sizing: border-box; }
    /* il testo da leggere di seguito resta su una riga comoda */
    .eotxt, .reftxt, .dedit, .qrow, .btnrow, .banner { max-width: 820px; }
    .rz { position: absolute; z-index: 6; touch-action: none; }
    .rz-n, .rz-s { left: 14px; right: 14px; height: 6px; cursor: ns-resize; }
    .rz-e, .rz-w { top: 14px; bottom: 14px; width: 6px; cursor: ew-resize; }
    .rz-n { top: 0; } .rz-s { bottom: 0; } .rz-e { right: 0; } .rz-w { left: 0; }
    .rz-ne, .rz-nw, .rz-se, .rz-sw { width: 14px; height: 14px; }
    .rz-ne { top: 0; right: 0; cursor: nesw-resize; } .rz-sw { bottom: 0; left: 0; cursor: nesw-resize; }
    .rz-nw { top: 0; left: 0; cursor: nwse-resize; } .rz-se { bottom: 0; right: 0; cursor: nwse-resize; }
    .hd { flex: 0 0 auto; display: flex; align-items: center; gap: 10px; min-height: 52px; padding: 0 12px 0 20px; background: #fff; color: #16232E;
          border-bottom: 1px solid #E6EBF0; border-radius: 13px 13px 0 0; position: relative; z-index: 3; cursor: grab; user-select: none; touch-action: none; }
    .hd:active { cursor: grabbing; }
    .hd .logo { display: inline-flex; }
    .hd b { font-size: 16px; font-weight: 600; letter-spacing: .1px; }
    .hd .who { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; max-width: 50%; }
    .card:focus { outline: none; }
    .hd .hsp { flex: 1 1 auto; }
    .pill .who { max-width: 200px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .hd .sub { font-size: 12px; color: #5B6B7A; white-space: nowrap; font-variant-numeric: tabular-nums; }
    .iconbtn { display: inline-grid; place-items: center; width: 36px; height: 36px; background: transparent; border: 0; color: #5B6B7A;
               cursor: pointer; border-radius: 8px; padding: 0; }
    .iconbtn:hover { background: #F1F4F7; color: #16232E; }
    .iconbtn:focus-visible { outline: 2px solid #0B5CAD; outline-offset: -2px; }
    .menuw { position: relative; }
    .menu { position: absolute; right: 0; top: 40px; z-index: 20; min-width: 200px; background: #fff; border: 1px solid #E3E8EF;
            border-radius: 10px; box-shadow: 0 12px 32px rgba(9,42,74,.16); padding: 6px; cursor: default; }
    .menu button { display: block; width: 100%; text-align: left; border: 0; background: none; padding: 8px 10px; border-radius: 6px;
                   font-size: 13px; color: #16232E; cursor: pointer; }
    .menu button:hover, .menu button:focus-visible { background: #F1F4F7; outline: none; }
    .menu hr { border: 0; border-top: 1px solid #EEF2F6; margin: 5px 4px; }
    .menu .mver { padding: 6px 10px 4px; font-size: 12px; color: #5B6B7A; }
    .pbar { flex: 0 0 auto; height: 3px; background: #E3E8EF; }
    .pbar i { display: block; height: 100%; background: #0B5CAD; transition: width .25s ease; }
    /* compact, always-visible selection strip (plain text, not pills) */
    .selbar { background: #F8FBFE; border-bottom: 1px solid #D9E2EC;
              padding: 7px 24px; font-size: 12px; line-height: 1.8; color: #16232E; }
    .selbar .selgrp { color: #0B5CAD; font-weight: 800; }
    .selbar .selrow { display: block; }
    .selbar .selcount { float: right; color: #5B6B7A; font-size: 10.5px; font-weight: 700; letter-spacing: .4px; }
    .selitem { display: inline; white-space: nowrap; border-radius: 4px; padding: 1px 2px; }
    .selitem:hover { background: #EAF2FA; }
    .selitem .selx { display: none; border: 0; background: #B3261E; color: #fff; border-radius: 999px;
                     width: 15px; height: 15px; line-height: 13px; font-size: 10px; cursor: pointer; padding: 0;
                     vertical-align: 1px; margin-left: 2px; }
    .selitem:hover .selx { display: inline-block; }
    .bd { padding: 0; }
    .sec { margin-bottom: 14px; }
    .lbl { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: .06em; color: #5B6B7A; margin-bottom: 6px; }
    textarea, input[type="text"], input[type="search"] { width: 100%; border: 1px solid #C4D0DC; border-radius: 8px; padding: 8px 10px; font-size: 13px; color: #16232E; background: #fff; }
    textarea:focus-visible, input:focus-visible, .chip:focus-visible, .pbtn:focus-visible, .seg button:focus-visible, .btn:focus-visible, select.res:focus-visible, summary:focus-visible { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    .chips { display: flex; flex-wrap: wrap; gap: 6px; }
    .chip { display: inline-flex; align-items: center; border: 1px solid #C4D0DC; background: #F4F8FB; color: #16232E; border-radius: 999px;
            padding: 6px 12px; font-size: 12.5px; min-height: 28px; cursor: pointer; }
    .chip:hover { border-color: #0B5CAD; }
    .chip.on { background: #EAF2FA; border-color: #0B5CAD; color: #16232E; }
    .chip.on::before { content: "✓ "; font-weight: 800; white-space: pre; }
    .chip.q { background: transparent; border-style: dashed; color: #35506B; }
    .chip.q:hover { border-color: #0B5CAD; color: #0B5CAD; }
    .chip.q { padding: 3px 8px; font-size: 11px; min-height: 22px; }
    /* il quesito che porta un pacchetto di esami: bordo pieno; acceso, come un profilo */
    .chip.q.pk { border-style: solid; border-color: #9DBFDE; color: #16232E; font-weight: 600; }
    .chip.q.pk.on { background: #EAF2FA; border-color: #0B5CAD; color: #16232E; }
    .qrow { display: flex; gap: 8px; align-items: flex-start; }
    .qrow input { flex: 1 1 52%; min-width: 0; }
    .qchips { flex: 1 1 48%; display: flex; flex-wrap: wrap; gap: 4px; align-content: flex-start; }
    .chip.preset { background: #EAF2FA; border-color: #9DBFDE; font-weight: 600; padding: 5px 11px; font-size: 11.5px; min-height: 26px; }
    /* dense two-column exam grid: many exams, little space, still tappable */
    .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(190px, 1fr)); gap: 4px 5px; }
    .opt { display: flex; align-items: center; gap: 6px; border: 1px solid #E3E8EF; background: #fff; color: #16232E;
           border-radius: 7px; padding: 5px 7px; font-size: 11.5px; line-height: 1.2; cursor: pointer; text-align: left;
           min-height: 27px; overflow: hidden; }
    .opt:hover { border-color: #0B5CAD; background: #F4F8FB; }
    .opt .box { flex: 0 0 13px; width: 13px; height: 13px; border: 1.5px solid #9DBFDE; border-radius: 3px;
                display: inline-grid; place-items: center; font-size: 9px; font-weight: 800; color: transparent; }
    .opt.on { background: #EAF2FA; border-color: #0B5CAD; color: #16232E; font-weight: 600; }
    .opt.on .box { background: #0B5CAD; border-color: #0B5CAD; color: #fff; }
    .opt .nm { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .grouphdr { grid-column: 1 / -1; font-size: 11px; font-weight: 600; letter-spacing: .06em; color: #5B6B7A;
                margin: 5px 0 0; text-transform: uppercase; }
    .chip.preset.on { background: #EAF2FA; border-color: #0B5CAD; color: #16232E; }
    .gchips { grid-column: 1 / -1; display: flex; flex-wrap: wrap; gap: 4px; margin: 1px 0; }
    .qrx { grid-column: 1 / -1; min-width: 0; }
    .chip.cart { background: #EDF7F0; border-color: #BCE0C9; color: #124F31; cursor: default; }
    .chip.ghosted { background: #F4F8FB; border-color: #E3E8EF; color: #5B6B7A; cursor: default; }
    .chip.nel { background: #EDF7F0; border-color: #BCE0C9; color: #124F31; cursor: default; }
    .chip.manca { background: #FBEBEA; border-color: #E9BAB6; color: #7c1a14; cursor: default; font-weight: 600; }
    .chip.controlla { background: #FFF7E6; border-color: #F0D49A; color: #8a4b03; cursor: default; font-weight: 600; }
    .btn { display: block; width: 100%; border: 0; border-radius: 10px; padding: 12px; font-size: 14px; font-weight: 700; cursor: pointer; text-align: center; }
    .btn + .btn { margin-top: 7px; }
    .btnrow { display: flex; gap: 7px; }
    .btnrow .btn { flex: 1 1 auto; min-width: 0; padding: 11px 8px; font-size: 13px; margin: 0;
                   white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .btnrow .btn.confirm { flex: 0 1 auto; }
    .btn.primary { background: #0B5CAD; color: #fff; }
    .btn.primary:hover { background: #094a8c; }
    .btn.confirm { background: #FFF7E6; color: #8a4b03; border: 1px solid #E5C588; }
    .btn.confirm:hover { background: #ffefd0; }
    .btn.ghost { background: #F4F8FB; color: #16232E; border: 1px solid #C4D0DC; }
    .btn.ghost:hover { border-color: #0B5CAD; }
    .btn.stop { background: #B3261E; color: #fff; }
    .btn.stop:hover { background: #941e18; }
    .btn:disabled { background: #EDF1F5; color: #93A3B3; border: 1px solid #E3E8EF; cursor: default; opacity: 1; }
    .idline { font-size: 11.5px; color: #5B6B7A; margin: 0 0 7px; text-align: center; }
    .idline b { color: #16232E; }
    .problem { font-size: 11.5px; color: #7a4b03; background: #FFF7E6; border: 1px solid #E5C588; border-radius: 8px; padding: 7px 9px; margin-bottom: 7px; }
    .hint { font-size: 11.5px; color: #5B6B7A; margin-top: 7px; }
    .steps { display: flex; flex-direction: column; gap: 6px; }
    .step { display: flex; align-items: baseline; gap: 8px; padding: 8px 9px; border-radius: 8px; background: #F4F8FB; }
    .step .ic { flex: 0 0 16px; text-align: center; font-size: 12px; display: inline-block; }
    .step.ok { background: #EDF7F0; } .step.ok .ic { color: #177245; }
    .step.running { background: #EAF2FA; outline: 1px solid #9DBFDE; }
    .step.running .ic { animation: psaSpin 1.1s linear infinite; }
    .step.fail { background: #FBEBEA; } .step.fail .ic { color: #B3261E; font-weight: 800; }
    .step.skipped { opacity: .55; }
    .step small { color: #5B6B7A; margin-left: auto; text-align: right; }
    .banner { border-radius: 10px; padding: 10px 12px; margin-bottom: 10px; font-size: 12.5px; }
    .banner b { display: block; font-size: 13px; margin-bottom: 3px; }
    .banner.err { background: #FBEBEA; color: #7c1a14; border: 1px solid #E9BAB6; }
    .banner.ok { background: #EDF7F0; color: #124F31; border: 1px solid #BCE0C9; }
    .banner.warn { background: #FFF7E6; color: #7a4b03; border: 1px solid #E5C588; }
    .ac { position: relative; margin-top: 8px; }
    .ac input { width: 100%; }
    .acdrop { position: absolute; left: 0; right: 0; top: calc(100% + 4px); z-index: 5; background: #fff;
              border: 1px solid #C4D0DC; border-radius: 10px; box-shadow: 0 10px 24px rgba(9,42,74,.18);
              max-height: 260px; overflow: auto; padding: 4px; }
    .acitem { display: flex; align-items: center; gap: 8px; width: 100%; text-align: left; border: 0; background: transparent;
              border-radius: 6px; padding: 6px 8px; font-size: 12px; cursor: pointer; color: #16232E; }
    .acitem:hover { background: #EAF2FA; }
    .acitem.on { color: #177245; font-weight: 600; }
    .acitem.on::after { content: "✓"; margin-left: auto; }
    .acnm { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .actag { flex: 0 0 auto; margin-left: auto; font-size: 9.5px; font-weight: 800; letter-spacing: .4px; color: #5B6B7A;
             background: #F4F8FB; border: 1px solid #E3E8EF; border-radius: 5px; padding: 1px 5px; }
    .acitem.on .actag { margin-left: 0; }
    .acempty { padding: 8px; font-size: 12px; color: #8296A9; }
    .list { border: 1px solid #D9E2EC; border-radius: 10px; max-height: 320px; overflow: auto; margin-top: 6px; }
    .list label { display: flex; gap: 8px; padding: 9px 10px; font-size: 12px; cursor: pointer; align-items: baseline; border-bottom: 1px solid #EEF2F6; }
    .list label:hover { background: #F4F8FB; }
    .list input[type="checkbox"] { accent-color: #0B5CAD; }
    .log { font: 11px/1.5 ui-monospace, Menlo, Consolas, monospace; font-variant-numeric: tabular-nums; color: #35506B; background: #F8FAFC;
           border: 1px solid #E3E8EF; border-radius: 8px; padding: 8px; max-height: 130px; overflow: auto; white-space: pre-wrap; word-break: break-word; }
    details.reg summary { cursor: pointer; font-size: 11.5px; color: #5B6B7A; margin: 8px 0 6px; }
    details.reflab > summary { cursor: pointer; }
    /* l'angolo per ridimensionare: in basso a destra, come in ogni finestra, e
       come lì senza disegno (il bordo tondo lo tagliava): lo dice il cursore */
    .rsz { position: absolute; right: 0; bottom: 0; width: 16px; height: 16px; cursor: nwse-resize; z-index: 7; touch-action: none; }
    .commit { position: sticky; bottom: -1px; margin: 0 -24px -14px; padding: 10px 24px 14px; background: #fff;
              border-top: 1px solid #EEF2F6; box-shadow: 0 -10px 14px -12px rgba(9,42,74,.25); }
    .rlist { display: flex; flex-direction: column; gap: 4px; max-height: 320px; overflow: auto; }
    .rrow { display: flex; align-items: center; gap: 8px; border: 1px solid #E3E8EF; background: #fff; border-radius: 8px;
            padding: 7px 9px; font-size: 12px; cursor: pointer; text-align: left; width: 100%; color: #16232E; }
    .rrow:hover { border-color: #0B5CAD; background: #F4F8FB; }
    .prow { display: flex; flex-direction: column; gap: 1px; align-items: flex-start; width: 100%; text-align: left;
            border: 1px solid #E3E8EF; background: #fff; border-radius: 8px; padding: 6px 9px; cursor: pointer; color: #16232E; }
    .prow:hover { border-color: #0B5CAD; background: #F4F8FB; }
    .prow.hot { border-color: #9DBFDE; background: #EAF2FA; }
    .pline1 { font-size: 12px; font-variant-numeric: tabular-nums; }
    .pline1 small { color: #5B6B7A; font-size: 10.5px; }
    .pline2 { font-size: 10.5px; color: #5B6B7A; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 100%; }

    .rdot { flex: 0 0 7px; width: 7px; height: 7px; border-radius: 50%; border: 1.5px solid #C4D0DC; background: transparent; }
    .rdot.saved { background: #177245; border-color: #177245; }
    .rdot.open { background: #9DBFDE; border-color: #9DBFDE; }
    .rdot.busy { background: #E5A83B; border-color: #E5A83B; animation: psaPulse 1s infinite; }
    .rdot.err { background: #B3261E; border-color: #B3261E; }
    .rrow.saved { background: #F6FBF8; border-color: #BCE0C9; }
    .mini { float: right; border: 1px solid #C4D0DC; background: #fff; color: #0B5CAD; border-radius: 6px;
            padding: 1px 7px; font-size: 10.5px; font-weight: 700; cursor: pointer; letter-spacing: 0; text-transform: none; }
    .mini:hover { border-color: #0B5CAD; background: #F4F8FB; }
    .rwhen { flex: 0 0 auto; font-family: ui-monospace, Menlo, Consolas, monospace; font-size: 11px; color: #35506B; font-variant-numeric: tabular-nums; }
    .rsys { flex: 0 0 auto; font-size: 9.5px; font-weight: 800; letter-spacing: .5px; color: #5B6B7A; background: #F4F8FB;
            border: 1px solid #E3E8EF; border-radius: 5px; padding: 1px 5px; }
    .rlab { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    /* Le schermate in UNA fila di pillole, nell'ordine in cui si lavora:
       Richieste, Esiti, EO, Consensi, Dimissioni. La pillola accesa è quella
       dove sei. */
    .seg { display: flex; align-items: flex-end; flex-wrap: wrap; gap: 2px; margin: 0; padding: 0 24px;
           border-bottom: 1px solid #EEF2F6; min-height: 42px; }
    .seg > button { border: 0; border-bottom: 2px solid transparent; background: none; border-radius: 0; margin-bottom: -1px;
                    padding: 12px 10px 10px; font-size: 13px; font-weight: 400; color: #5B6B7A; cursor: pointer; }
    .seg > button:hover { color: #16232E; }
    .seg > button.on { color: #16232E; font-weight: 600; border-bottom-color: #0B5CAD; }
    .segdx { margin-left: auto; align-self: center; display: flex; align-items: center; gap: 6px; padding: 9px 0 3px; }
    /* in Modifica la fila resta com'è (stessa altezza, stesse righe di testo) ma non va mai a capo */
    .seg.modifica { flex-wrap: nowrap; }
    .segtit { flex: 0 1 auto; min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; padding: 12px 0 10px;
              border-bottom: 2px solid transparent; margin-bottom: -1px; font-size: 13px; font-weight: 600; line-height: normal; color: #16232E; }
    .seg .n { margin-left: 5px; font-weight: 600; color: #5B6B7A; font-variant-numeric: tabular-nums; }
    .rgo { flex: 0 0 auto; color: #8296A9; font-size: 12px; }
    .dlist, .mlist { display: flex; flex-direction: column; gap: 4px; }
    .dsep { display: flex; align-items: center; gap: 8px; margin: 8px 2px 3px; font-size: 10.5px;
            color: #5B6B7A; text-transform: uppercase; letter-spacing: .06em; }
    .dsep::after { content: ""; flex: 1 1 auto; height: 1px; background: #E3E8EF; }
    .drow { display: flex; align-items: stretch; gap: 5px; }
    /* Copying is what this list is FOR: the target is the whole row, not a
       13px glyph at its edge. The pencil stays a button of its own. */
    .dcopia { flex: 1 1 auto; display: flex; align-items: center; gap: 8px; min-width: 0; text-align: left;
              border: 1px solid #E3E8EF; border-radius: 9px; background: #fff; cursor: pointer;
              padding: 8px 10px 8px 11px; font: inherit; }
    .dcopia:hover { border-color: #9DBFDE; background: #F4F9FD; }
    .dcopia:focus-visible { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    .dcopia.fatto { border-color: #BCE0C9; background: #EDF7F0; }
    .dcopia.fatto .dico { color: #124F31; }
    .dnome { flex: 1 1 auto; font-size: 12.5px; font-weight: 600; color: #16232E; overflow: hidden;
             white-space: nowrap; text-overflow: ellipsis; }
    .dmeta { flex: 0 0 auto; font-size: 10.5px; color: #5B6B7A; }
    .dico { flex: 0 0 auto; font-size: 13px; color: #6E8398; }
    .dmod { color: #0B5CAD; font-weight: 800; margin-left: 5px; }
    .dmod.agg { color: #A2600A; }
    .dbtn { flex: 0 0 auto; min-width: 38px; border: 1px solid #E3E8EF; border-radius: 9px;
            background: #F8FBFE; color: #35506B; font-size: 13px; cursor: pointer; }
    .dbtn:hover { background: #EAF2FA; border-color: #9DBFDE; color: #0B5CAD; }
    .dbtn:focus-visible { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    /* il testo scelto nella tendina: si vede cosa è finito negli appunti */
    .eotxt { margin-top: 8px; border: 1px solid #E3E8EF; border-left: 3px solid #0B5CAD; border-radius: 8px;
             background: #F8FBFE; padding: 9px 11px; font-size: 12.5px; line-height: 1.55; color: #35506B;
             max-height: 34vh; overflow: auto; white-space: pre-wrap; }
    .eoazione { margin-top: 8px; }
    .dedit { width: 100%; min-height: 46vh; resize: vertical; border: 1px solid #D9E2EC; border-radius: 9px;
             padding: 9px 10px; font: 12.5px/1.5 ui-monospace, SFMono-Regular, Consolas, monospace;
             color: #16232E; background: #fff; }
    .dedit:focus { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    /* a name we were never taught: shown in full, and underlined so it can
       never be mistaken for one of the curated sigle */
    .sttab th.stn.grezza { text-decoration: underline dotted #C08A2E; text-underline-offset: 2px; }
    .avvnomi { display: flex; align-items: center; gap: 8px; font-size: 11.5px; color: #7a4b03;
               background: #FFF7E6; border: 1px solid #E5C588; border-radius: 8px; padding: 5px 9px; margin-bottom: 6px; }
    .avvnomi .avvi { flex: 0 0 auto; width: 16px; height: 16px; border-radius: 50%; background: #E5C588;
                     color: #4d2f02; font-weight: 800; font-size: 11px; text-align: center; line-height: 16px; }
    .avvnomi .avvb { margin-left: auto; border: 0; background: transparent; color: #7a4b03; font: inherit;
                     font-weight: 700; cursor: pointer; text-decoration: underline; }
    .avvlista { white-space: pre-wrap; font-size: 11px; line-height: 1.45; color: #5B6B7A;
                background: #FFFDF7; border: 1px solid #EEDFC0; border-radius: 8px; padding: 6px 9px; margin-bottom: 6px; }
    .archhd { display: flex; align-items: center; gap: 8px; width: 100%; margin-top: 8px; cursor: pointer;
              border: 1px solid #E3E8EF; border-radius: 9px; background: #F8FBFE; padding: 7px 10px;
              font: 600 12px/1 inherit; color: #5B6B7A; }
    .archhd:hover { border-color: #9DBFDE; color: #16232E; }
    .archhd .an { background: #E3E8EF; color: #35506B; border-radius: 999px; padding: 1px 7px; font-size: 10.5px; }
    .archhd .ago { margin-left: auto; color: #8296A9; }
    .alist { display: flex; flex-direction: column; gap: 3px; margin-top: 4px; }
    .arow { display: flex; align-items: center; gap: 8px; padding: 5px 8px 5px 10px;
            border: 1px solid #EDF1F6; border-radius: 8px; background: #fff; }
    .arow .anm { flex: 1 1 auto; font-size: 12px; color: #5B6B7A; overflow: hidden;
                 white-space: nowrap; text-overflow: ellipsis; }
    .arow .ameta { flex: 0 0 auto; font-size: 10.5px; color: #5B6B7A; }
    .abtn { flex: 0 0 auto; border: 1px solid #D9E2EC; background: #F8FBFE; color: #35506B;
            border-radius: 7px; padding: 3px 8px; font: 600 11px/1.4 inherit; cursor: pointer; }
    .abtn:hover { border-color: #9DBFDE; color: #0B5CAD; }
    .abtn.del:hover { border-color: #E9BAB6; background: #FBEBEA; color: #B3261E; }
    .tchip { display: flex; align-items: center; }
    .tchip button { display: inline-flex; align-items: center; gap: 6px; height: 32px; border: 1px solid #E3E8EF; background: #fff; color: #5B6B7A;
                    font: 600 12px/1 inherit; border-radius: 8px; padding: 0 9px; cursor: pointer; font-variant-numeric: tabular-nums; }
    .tchip.off button { border-color: transparent; width: 36px; justify-content: center; padding: 0; }
    .tchip button:hover { background: #F1F4F7; color: #16232E; }
    .tchip .tdot { width: 7px; height: 7px; border-radius: 50%; background: #C62828; }
    .tchip.on button:first-child { border-radius: 7px 0 0 7px; border-right: 0; font-variant-numeric: tabular-nums; }
    .tchip.on button:last-child { border-radius: 0 7px 7px 0; }
    .tchip.on button { color: #16232E; }
    .tnow { display: flex; align-items: center; gap: 10px; background: #EDF7F0; border: 1px solid #BCE0C9;
            border-radius: 10px; padding: 10px 12px; margin-bottom: 8px; }
    .tbig { font: 800 20px/1 inherit; color: #124F31; font-variant-numeric: tabular-nums; }
    .tlab { flex: 1 1 auto; font-size: 12px; color: #35506B; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .tpres { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 6px; }
    .tpre { border: 1px solid #C4D0DC; background: #fff; color: #16232E; border-radius: 999px;
            padding: 7px 12px; font: 600 12px/1 inherit; cursor: pointer; }
    .tpre:hover { border-color: #0B5CAD; color: #0B5CAD; background: #F4F8FB; }
    .tlibero { display: flex; gap: 6px; }
    .tlibero input { flex: 1 1 auto; border: 1px solid #D9E2EC; border-radius: 8px; padding: 7px 9px;
                     font: 12.5px/1.3 inherit; color: #16232E; }
    .tlibero input:focus { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    .ttot { float: right; font-size: 11px; color: #5B6B7A; font-weight: 600; }
    .tlist { display: flex; flex-direction: column; gap: 3px; }
    .trow { display: flex; align-items: center; gap: 8px; padding: 5px 6px 5px 9px; font-size: 11.5px;
            border: 1px solid #EDF1F6; border-radius: 8px; background: #fff; }
    .trow .tt { flex: 1 1 auto; font-weight: 600; color: #16232E; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .trow .tp { flex: 0 1 90px; color: #8296A9; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .trow .td { flex: 0 0 auto; font-weight: 700; color: #0B5CAD; font-variant-numeric: tabular-nums; }
    .trow .to { flex: 0 0 auto; color: #5B6B7A; font-size: 10.5px; font-variant-numeric: tabular-nums; }
    .tdel { border: 0; background: transparent; color: #5B6B7A; cursor: pointer; font-size: 12px; padding: 0 2px; }
    .tdel:hover { color: #B3261E; }
    /* la nota e, accanto, i promemoria del paziente con la loro sveglia */
    .notaw { position: relative; display: flex; align-items: flex-start; gap: 8px; padding: 10px 24px 0; }
    .notacol { position: relative; flex: 1 1 auto; min-width: 0; }
    .nota { display: block; width: 100%; resize: none; overflow: hidden;
            border: 1px solid transparent; border-radius: 8px; background: #F8FBFE;
            padding: 6px 8px; font: 12.5px/1.45 inherit; color: #16232E; }
    .nota::placeholder { color: #9DB0C2; }
    .nota:hover { border-color: #E3E8EF; }
    .nota:focus { outline: 0; border-color: #9DBFDE; background: #fff; }
    .notaok { position: absolute; right: 8px; bottom: 4px; font-size: 10px; color: #177245; }
    .notaok.ko { color: #B3261E; }
    /* PROMEMORIA. La pill: quanto manca in grassetto, poi la cosa da fare.
       Tranquilla oltre la mezz'ora, ambra sotto i 30 minuti, rossa sotto i 10
       e quando è l'ora — solo allora un bagliore lento. */
    .prslot { display: contents; }
    .prom { position: relative; z-index: 1; flex: 0 1 auto; min-width: 0; max-width: 180px; display: inline-flex; align-items: baseline; gap: 5px;
            height: 22px; padding: 0 9px; border: 0; border-radius: 999px; background: #EEF2F6; color: #35506B; cursor: pointer;
            font-size: 12px; line-height: 22px; white-space: nowrap; font-variant-numeric: tabular-nums; }
    .prom b { flex: none; font-weight: 700; }
    .prom .prl { min-width: 0; overflow: hidden; text-overflow: ellipsis; }
    .prom .prpiu { flex: none; font-weight: 600; opacity: .7; }
    .prom:hover { background: #E3E9F0; }
    .prom:focus-visible { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    .prom.amb, .prst.amb { background: #FFF4DB; color: #8A5A00; }
    .prom.amb:hover { background: #FCEBC4; }
    .prom.ros, .prst.ros { background: #FDEBEA; color: #B3261E; animation: prBagliore 2.6s ease-in-out infinite; }
    .prom.ros:hover { background: #FADBD8; }
    @keyframes prBagliore { 0%, 100% { box-shadow: 0 0 0 0 rgba(179,38,30,0); } 50% { box-shadow: 0 0 0 4px rgba(179,38,30,.13); } }
    /* nella Stanza solo il tempo, piccolo, in alto a destra */
    .prst { flex: none; align-self: center; margin-left: 6px; padding: 0 6px; border-radius: 999px; background: #EEF2F6; color: #5B6B7A;
            font-size: 11px; font-weight: 700; line-height: 16px; white-space: nowrap; font-variant-numeric: tabular-nums; }
    .stp1:has(> .prst) .stpn { flex: 1 1 auto; }
    /* la sveglia della nota: tranquilla, all'estremità della barra */
    .prbar { flex: 0 1 auto; min-width: 0; display: flex; align-items: center; gap: 6px; height: 32px; }
    .prbar .prom { max-width: 200px; }
    .prnuovo { flex: none; display: inline-grid; place-items: center; width: 32px; height: 32px; padding: 0; border: 0; border-radius: 8px;
               background: none; color: #8296A9; cursor: pointer; }
    .prnuovo:hover { background: #F1F4F7; color: #16232E; }
    .prnuovo:focus-visible { outline: 2px solid #0B5CAD; outline-offset: -2px; }
    .prbar:has(.prform) .prnuovo { display: none; }
    .prbar .prform { flex: 0 1 240px; min-width: 150px; }
    /* il campo, su una riga: sotto, mentre scrivi, quando sarà */
    .prform { position: relative; z-index: 2; display: block; }
    .prin { display: block; width: 100%; height: 30px; padding: 0 10px; border: 1px solid #9DBFDE; border-radius: 8px; background: #fff;
            font-size: 13px; line-height: 1.3; color: #16232E; }
    .prin::placeholder { color: #9DB0C2; }
    .prin:focus { outline: 0; border-color: #0B5CAD; box-shadow: 0 0 0 3px rgba(11,92,173,.12); }
    .prhint { position: absolute; right: 0; top: calc(100% + 4px); z-index: 3; padding: 2px 8px; border-radius: 6px; background: #fff;
              box-shadow: 0 2px 10px rgba(9,42,74,.16); font-size: 11.5px; line-height: 18px; color: #35506B; white-space: nowrap;
              font-variant-numeric: tabular-nums; pointer-events: none; }
    .prhint:empty { display: none; }
    .prhint.ko { color: #B3261E; }
    /* l'elenco di un paziente: ✓ Fatto, +15 min */
    .prmenu { position: absolute; z-index: 30; width: max-content; min-width: 260px; max-width: min(360px, calc(100vw - 16px)); padding: 4px;
              border: 1px solid #D9E2EC; border-radius: 10px; background: #fff; box-shadow: 0 10px 28px rgba(9,42,74,.16); }
    .prmhd { padding: 6px 8px 4px; font-size: 12px; color: #5B6B7A; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .prmrow { display: flex; align-items: center; gap: 8px; min-height: 38px; padding: 3px 4px 3px 8px; }
    .prmrow + .prmrow { border-top: 1px solid #EEF2F6; }
    .prmrow .prst { margin-left: 0; }
    .prmq { flex: 1 1 auto; min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; font-size: 13px; color: #16232E; }
    .prmq b { font-weight: 600; font-variant-numeric: tabular-nums; }
    .prmb { flex: none; min-height: 28px; border: 1px solid #D9E2EC; border-radius: 6px; background: #fff; padding: 2px 9px; cursor: pointer;
            font-size: 12px; font-weight: 600; color: #16232E; white-space: nowrap; }
    .prmb:hover { border-color: #9DBFDE; }
    .prmb.ok:hover { border-color: #BCE0C9; background: #EDF7F0; color: #177245; }
    .prmb:focus-visible { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    /* sulla pill ridotta, solo quando tocca */
    .pill .prurg { display: inline-flex; align-items: center; gap: 3px; padding: 1px 7px 1px 5px; border-radius: 999px; background: #B3261E;
                   color: #fff; font-size: 11px; font-weight: 700; line-height: 16px; font-variant-numeric: tabular-nums; box-shadow: 0 0 0 1.5px #fff; }
    .pill .prurg svg { width: 12px; height: 12px; }
    @media (prefers-reduced-motion: reduce) { .prom.ros, .prst.ros { animation: none; } }
    .crow { display: flex; align-items: center; gap: 10px; width: 100%; text-align: left; cursor: pointer;
            border: 1px solid #E3E8EF; border-radius: 9px; background: #fff; padding: 10px 11px; font: inherit; }
    .crow:hover { border-color: #9DBFDE; background: #F4F9FD; }
    .crow:focus-visible { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    .cnome { flex: 1 1 auto; font-size: 12.5px; font-weight: 600; color: #16232E; }
    .cgo { flex: 0 0 auto; font-size: 11px; color: #0B5CAD; font-weight: 700; }
    .cpag { flex: 0 0 auto; font-size: 10px; color: #8a4b03; background: #FFF3DB; border-radius: 999px; padding: 1px 7px; font-weight: 700; }
    .linkbtn { border: 0; background: transparent; color: #0B5CAD; font: inherit; font-weight: 700;
               text-decoration: underline; cursor: pointer; padding: 0; }
    .portok { color: #177245; font-weight: 700; }

    /* La tabella scorre dentro la sua cornice, non col pannello: solo così
       l'intestazione (sticky) resta sotto gli occhi con venti analiti. */
    .stwrap { overflow: auto; max-height: 60vh; overscroll-behavior: contain; border: 1px solid #E3E8EF; border-radius: 8px; }
    /* La tabella è larga quanto i suoi numeri, non quanto il pannello: se il
       medico allarga la finestra i valori restano accanto ai nomi invece di
       allontanarsene. Per lo stesso motivo i numeri sono allineati a
       sinistra, incolonnati dalle cifre tabulari. */
    .sttab { border-collapse: collapse; font-size: 11.5px; width: auto; }
    .sttab th, .sttab td { padding: 3px 7px; white-space: nowrap; border-bottom: 1px solid #EDF1F6; }
    .sttab thead th { position: sticky; top: 0; background: #F8FBFE; color: #5B6B7A; font-weight: 600;
                      font-size: 10.5px; text-align: left; border-bottom: 1px solid #D9E2EC; }
    .sttab .sth { display: block; font-size: 9.5px; color: #5B6B7A; font-weight: 500; }
    .sttab th.stn { position: sticky; left: 0; z-index: 1; background: #fff; text-align: left;
                    font-weight: 600; color: #16232E; max-width: 168px; overflow: hidden; text-overflow: ellipsis; }
    .sttab thead th.stn { background: #F8FBFE; z-index: 2; }
    .sttab td { text-align: left; color: #35506B; font-variant-numeric: tabular-nums; }
    .sttab td.fuori { color: #B3261E; font-weight: 800; }
    .sttab td.parz { font-style: italic; }   /* parziale: in corsivo, niente puntini */
    /* Novelty rides a different channel: a tint behind the number. Text
       colour is untouched, so red keeps meaning "out of range". */
    .sttab td.nuovo, .sttab td.agg, .sttab tbody tr:hover td.nuovo, .sttab tbody tr:hover td.agg {
      background: #DCEAF9; box-shadow: inset 0 -2px 0 #0B5CAD; }
    /* I segni del medico: un tocco giallo, due arancio, tre via. Stanno DOPO
       la novità perché il segno vince sullo sfondo azzurro; la riga blu sotto
       il numero (box-shadow) resta e continua a dire «nuovo». */
    .sttab td[data-cella] { cursor: pointer; user-select: none; }   /* due tocchi non devono selezionare il numero */
    /* Il segno è una pastiglia stretta attorno al numero (freccia e segno
       compresi), non tutta la cella: il margine negativo compensa il padding,
       così il numero non si sposta quando la pastiglia compare. */
    .sttab td .val { display: inline-block; border-radius: 999px; padding: 0 5px; margin: 0 -5px; }
    .sttab td .pct { font-weight: 500; color: #5B6B7A; font-style: normal; }
    .sttab td.marca1 .val { background: #FFE58A; }
    .sttab td.marca2 .val { background: #FFC46B; }
    .sttab tbody tr:hover td, .sttab tbody tr:hover th.stn { background: #F4F9FD; }
    /* Sezioni: gli esami stanno dove un medico li cerca, e sempre nello stesso
       posto. L'ordine non dipende più da come il laboratorio ha stampato. */
    .sttab tr.stsez th.stn, .sttab tr.stsez td { background: #EEF4FA; border-bottom: 1px solid #D9E4EF;
      font-size: 9.5px; font-weight: 800; letter-spacing: .07em; text-transform: uppercase; color: #5B6B7A; }
    .sttab tr.stsez th.stn { color: #35506B; padding-top: 7px; padding-bottom: 4px; }
    .sttab tr.stsez td { text-align: left; padding-top: 7px; padding-bottom: 4px; }
    .sttab tr.stsez:hover th.stn, .sttab tr.stsez:hover td { background: #EEF4FA; }
    /* una cella senza valore si deve VEDERE che è vuota, o una riga con due
       soli prelievi sembra una riga piena */
    .sttab td.vuoto { color: #AEBECD; }
    /* L'unità sta ACCANTO al nome, fra parentesi: su un rigo suo raddoppiava
       l'altezza di ogni riga e allontanava i numeri dal nome. */
    .stum { font-size: 9px; color: #5B6B7A; font-weight: 500; letter-spacing: 0; }
    .sttab th.ultima { color: #0B5CAD; }
    .sttab th.ultima::after { content: "ultimo"; display: block; font-size: 8.5px; font-weight: 700;
      letter-spacing: .06em; text-transform: uppercase; color: #9DBFDE; }
    /* il segno di provenienza: piccolo, in alto, mai confondibile con un valore */
    .sttab .prov { font-style: normal; font-size: 9px; vertical-align: super; color: #0B5CAD;
                   font-weight: 800; margin-left: 1px; cursor: help; }
    .reftxt { font-size: 12.5px; line-height: 1.5; color: #16232E; }
    .reftxt .rt { padding: 1px 0; }
    .reftxt .rt:empty { display: none; }
    .newbar { display: flex; align-items: center; gap: 8px; font-size: 11.5px; color: #0B5CAD;
              background: #EAF2FA; border: 1px solid #9DBFDE; border-radius: 8px; padding: 5px 9px; margin-bottom: 6px; }
    .newbar button { margin-left: auto; border: 0; background: transparent; color: #0B5CAD; font: inherit; font-weight: 700; cursor: pointer; }
    .foot { flex: 0 0 auto; padding: 8px 14px 10px; border-top: 1px solid #EEF2F6; display: flex; justify-content: space-between; align-items: center; color: #5B6B7A; font-size: 11px; }
    .footlink { border: 0; background: transparent; color: #0B5CAD; font-size: 11px; cursor: pointer; padding: 0; text-decoration: underline; }
    select.res { width: 100%; border: 1px solid #C4D0DC; border-radius: 8px; padding: 7px 8px; font-size: 12.5px; background: #fff; }
    @keyframes psaSpin { to { transform: rotate(360deg); } }
    @keyframes psaPulse { 0%,100% { opacity: 1; } 50% { opacity: .35; } }
    @keyframes psaDrain { from { width: 100%; } to { width: 0; } }
    @media (prefers-reduced-motion: reduce) { .step.running .ic, .pill .dot { animation: none; } }

    /* ---- Stanza ---- */
    /* nella finestra la mappa riempie tutto il corpo che resta, da bordo a bordo */
    .card.stanza .bdi { height: 100%; display: flex; flex-direction: column; padding: 0; }
    .card.stanza .bdi > .sec { flex: 1 1 auto; display: flex; flex-direction: column; min-height: 0; margin-bottom: 0; }
    .card.stanza .bdi > .banner, .card.stanza .bdi > .reg { flex: none; margin: 10px 14px; }
    .card.stanza .stmap { flex: 1 1 auto; height: auto; }
    /* I Pazienti, in Lista e in Stanza. Due grigi per il testo; l'azzurro solo
       per il paziente di questa pagina, per il fuoco e per l'azione che conta;
       il colore solo per il triage, in una striscia. */
    .t-rosso { --tr: #C62828; } .t-arancione { --tr: #EF6C00; } .t-azzurro { --tr: #1E88E5; }
    .t-verde { --tr: #2E7D32; } .t-bianco { --tr: #B0BEC5; }
    /* le azioni in fondo alla fila delle schede: Lista | Stanza, o in Modifica
       + Letto, + Area, Fine. Mai a capo, e alte uguali in ogni caso */
    .stazioni { display: inline-flex; flex: none; flex-wrap: nowrap; align-items: center; gap: 6px; height: 32px; margin-left: auto; white-space: nowrap; }
    .stazioni .stseg { display: inline-flex; gap: 2px; padding: 2px; border-radius: 8px; background: #EEF2F6; }
    .stazioni .stseg button { border: 0; border-radius: 6px; background: transparent; padding: 4px 12px; cursor: pointer;
                              font-size: 13px; font-weight: 600; line-height: 20px; color: #5B6B7A; white-space: nowrap; }
    .stazioni .stseg button:hover { border: 0; background: transparent; color: #16232E; }
    .stazioni .stseg button.on { background: #fff; color: #16232E; box-shadow: inset 0 0 0 1px #D9E2EC; }
    .stbtn, .stazioni .stbtn { border: 1px solid #D9E2EC; border-radius: 8px; background: #fff; padding: 3px 12px; cursor: pointer;
             font-size: 13px; font-weight: 600; line-height: 20px; color: #16232E; white-space: nowrap; }
    .stbtn:hover, .stazioni .stbtn:hover { border-color: #9DBFDE; background: #fff; color: #16232E; }
    .stbtn.pri, .stazioni .stbtn.pri { background: #0B5CAD; border-color: #0B5CAD; color: #fff; }
    .stbtn.pri:hover, .stazioni .stbtn.pri:hover { background: #094a8c; border-color: #094a8c; color: #fff; }
    .stazioni button:focus-visible, .stbtn:focus-visible, .stctl:focus-visible, .stp:focus-visible, .stname:focus-visible,
    .pzrow:has(.pzapri:focus-visible), .pzric:focus-visible, .pzposto:focus-visible, .pzx:focus-visible, .pzprom:focus-visible, .pzarchhd:focus-visible,
    .pzsvuota:focus-visible, .pzabtn:focus-visible, .stannulla:focus-visible { outline: 2px solid #0B5CAD; outline-offset: 1px; }
    /* quello che dicono tutti e due: da quanto non lo apri, «questa pagina», i segni */
    .stvisto { flex: none; font-size: 12px; color: #5B6B7A; white-space: nowrap; font-variant-numeric: tabular-nums; }
    .stvisto.amb { padding: 0 7px; border-radius: 999px; background: #FFF4DB; color: #8A5A00; }
    .stqui { flex: none; font-size: 12px; font-weight: 600; color: #0B5CAD; white-space: nowrap; }
    .sttag { flex: none; font-size: 11px; font-weight: 600; letter-spacing: .06em; text-transform: uppercase; color: #5B6B7A; white-space: nowrap; }
    .stom { flex: none; margin-right: 5px; font-weight: 400; color: #8A5A00; }
    .stcoda { font-weight: 400; color: #5B6B7A; white-space: nowrap; }
    .stn { margin-left: 6px; font-size: 12px; font-weight: 400; color: #5B6B7A; font-variant-numeric: tabular-nums; letter-spacing: 0; }
    .stsr { position: absolute; width: 1px; height: 1px; overflow: hidden; clip-path: inset(50%); white-space: nowrap; }   /* solo per chi legge con la voce */

    /* LISTA: righe da 44px separate da un filo, niente riquadri. Il nome non si
       taglia mai per primo: prima cede la nota */
    .pzlista { border-top: 1px solid #EEF2F6; container: pzlista / inline-size; }
    .pzlista, .pzarch { max-width: 960px; }
    .pzrow { position: relative; display: flex; align-items: center; gap: 10px; min-height: 44px; padding: 0 6px 0 10px;
             border-bottom: 1px solid #EEF2F6; color: #16232E; }
    /* chi è: il nome (che apre), il promemoria accanto, la nota che cede per prima */
    .pzchi { flex: 1 1 auto; min-width: 0; display: flex; align-items: baseline; gap: 10px; }
    .pzapri { flex: 0 1 auto; min-width: 0; display: flex; align-items: baseline; padding: 0; border: 0; background: none;
              color: inherit; text-align: left; cursor: pointer; }
    .pzapri::after { content: ""; position: absolute; inset: 0; }   /* tutta la riga */
    .pzchi .prom { flex-shrink: 6; min-width: 52px; }
    .pzchi .prform { flex: 1 1 auto; min-width: 140px; max-width: 360px; align-self: center; }
    .pzchi:has(.prform) .prslot, .pzchi:has(.prform) .pznota { display: none; }
    .pzapri:focus-visible { outline: none; }
    .pzrow:has(.pzapri:focus-visible) { outline-offset: -2px; }
    .pzrow:hover { background: #F7F9FB; }
    .pzrow.qui { background: #F4F8FC; box-shadow: inset 3px 0 0 #0B5CAD; }
    .pzrow.prec { opacity: .55; }
    .pztr { flex: none; width: 4px; height: 22px; border-radius: 2px; background: var(--tr, transparent); }
    .pznm { flex: none; max-width: 100%; overflow: hidden; white-space: nowrap; text-overflow: ellipsis;
            font-size: 14px; font-weight: 600; }
    .pznota { flex: 1 1 0; min-width: 0; max-width: 100%; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; font-size: 13px; color: #5B6B7A; }
    /* il posto: sempre largo uguale; il bordo solo sulla riga sotto il mouse */
    .pzposto { position: relative; z-index: 1; flex: 0 0 104px; display: inline-flex; align-items: center; justify-content: space-between;
               min-height: 28px; white-space: nowrap; border: 1px solid transparent; border-radius: 6px; background: none; padding: 2px 8px;
               cursor: pointer; font-size: 12px; color: #5B6B7A; }
    .pzpn { min-width: 0; overflow: hidden; text-overflow: ellipsis; }
    .pzrow:hover .pzposto, .pzrow:focus-within .pzposto { border-color: #E3E8EF; background: #fff; }
    .pzrow .pzposto:hover { border-color: #9DBFDE; color: #16232E; }
    /* Richieste in grigio; azzurro sulla riga sotto il mouse o col fuoco */
    .pzric { position: relative; z-index: 1; flex: none; min-height: 28px; border: 0; border-radius: 6px; background: none; padding: 2px 8px; cursor: pointer;
             font-size: 13px; font-weight: 500; color: #5B6B7A; }
    .pzrow:hover .pzric, .pzrow:focus-within .pzric { color: #0B5CAD; }
    .pzric:hover { background: #EAF2FA; }
    .pzx { position: relative; z-index: 1; flex: none; width: 28px; height: 28px; border: 0; border-radius: 6px; background: none; cursor: pointer;
           font-size: 13px; color: #5B6B7A; opacity: 0; }
    .pzrow:hover .pzx, .pzrow:focus-within .pzx { opacity: 1; }
    .pzx:hover { background: #FDF1F0; color: #B3261E; }
    /* la sveglia, come la ✕: compare passandoci sopra */
    .pzprom { position: relative; z-index: 1; flex: none; display: inline-grid; place-items: center; width: 28px; height: 28px; padding: 0;
              border: 0; border-radius: 6px; background: none; cursor: pointer; color: #5B6B7A; opacity: 0; }
    .pzrow:hover .pzprom, .pzrow:focus-within .pzprom { opacity: 1; }
    .pzprom:hover { background: #EEF2F6; color: #16232E; }
    /* colonna stretta: il nome da solo sulla prima riga, sotto il promemoria e
       la nota; «visto…» e «questa pagina» li dice solo la voce (la riga di
       questa pagina è già azzurra) */
    @container pzlista (max-width: 560px) {
      .pzrow { gap: 6px; }
      .pzchi { flex-wrap: wrap; column-gap: 8px; row-gap: 0; }
      .pzapri, .pzchi .prform { flex-basis: 100%; }
      .pzchi .prform { max-width: none; }
      .pzrow .stvisto, .pzrow .stqui { position: absolute; width: 1px; height: 1px; overflow: hidden; clip-path: inset(50%); }
    }
    .pzvuoto { padding: 16px 10px; font-size: 13px; color: #5B6B7A; }
    .pzarchhd { display: inline-flex; align-items: center; gap: 6px; margin-top: 12px; padding: 6px 4px; border: 0; background: none; cursor: pointer;
                font-size: 13px; font-weight: 600; color: #5B6B7A; }
    .pzarchhd:hover { color: #16232E; }
    .pzarchhd .stn { margin-left: 0; }
    .pzarch { padding-bottom: 8px; }
    .pzarow { display: flex; align-items: center; gap: 10px; min-height: 40px; padding: 0 6px 0 10px; border-bottom: 1px solid #EEF2F6; }
    .pzanm { flex: 1 1 auto; min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; font-size: 13px; color: #5B6B7A; }
    .pzameta { flex: none; font-size: 12px; color: #5B6B7A; }
    .pzabtn { position: relative; flex: none; min-height: 28px; border: 1px solid #D9E2EC; border-radius: 6px; background: #fff; padding: 2px 8px;
              cursor: pointer; font-size: 12px; color: #16232E; }
    .pzabtn:hover { border-color: #9DBFDE; }
    .pzabtn.del:hover { border-color: #E9BAB6; background: #FDF1F0; color: #B3261E; }
    .pzhint { padding: 8px 10px 0; font-size: 12px; color: #5B6B7A; }
    .pzsvuota { margin: 8px 0 0 6px; padding: 6px 4px; border: 0; background: none; cursor: pointer; font-size: 13px; color: #5B6B7A; text-decoration: underline; }
    .pzsvuota:hover { color: #16232E; }

    /* STANZA: a sinistra «Da sistemare», a destra la stanza */
    .stmap { position: relative; display: flex; flex-direction: column; height: 62vh; min-height: 380px; background: #F7F9FB;
             user-select: none; -webkit-user-select: none; -webkit-touch-callout: none; }
    .stcorpo { flex: 1 1 auto; display: flex; min-height: 0; }
    .sttray { flex: 0 1 220px; min-width: 150px; display: flex; flex-direction: column; border-right: 1px solid #E3E8EF;
              background: #fff; transition: background-color .12s; }
    .sttray.over { background: #EAF2FA; }
    .sttrayhd { flex: none; padding: 12px 12px 8px; font-size: 13px; font-weight: 600; color: #16232E; }
    .strow { flex: 1 1 auto; min-height: 0; overflow-y: auto; display: flex; flex-direction: column; gap: 6px; padding: 0 12px 12px; }
    .stnone { font-size: 13px; color: #5B6B7A; }
    /* finestra stretta: «Da sistemare» scende in fondo, su una riga che scorre di lato */
    .stmap { container: stmap / inline-size; }
    @container stmap (max-width: 700px) {
      .stcorpo { flex-direction: column; }
      .stcanvas { order: -1; }
      .sttray { flex: none; height: 96px; min-width: 0; border-right: 0; border-top: 1px solid #E3E8EF; }
      .sttrayhd { padding: 8px 12px 6px; }
      .strow { flex: 1 1 auto; flex-direction: row; align-items: flex-start; overflow-x: auto; overflow-y: hidden; padding: 0 12px 8px; scrollbar-width: thin; }
      .strow .stp { flex: none; max-width: 220px; touch-action: pan-x; }
    }
    /* La pianta: celle tutte uguali (--u), le più grandi che ci stanno, fra 20 e
       44px. Tutto si misura in celle: allargando o stringendo la finestra la
       stanza cresce o cala tutta insieme e niente si sovrappone; se non ci sta
       nemmeno a 20px (un nome non si leggerebbe più), scorre. */
    .stcanvas { position: relative; flex: 1 1 auto; min-width: 0; min-height: 0; overflow: auto; container-type: size;
                display: grid; place-items: center; }
    .stcanvas.dx { --sf: linear-gradient(to left, transparent, #000 40px); }
    .stcanvas.sx { --sf: linear-gradient(to right, transparent, #000 40px); }
    .stcanvas.sx.dx { --sf: linear-gradient(to right, transparent, #000 40px, #000 calc(100% - 40px), transparent); }
    .stcanvas.sx, .stcanvas.dx { -webkit-mask-image: var(--sf); mask-image: var(--sf); }
    .stplan { position: relative; --u: clamp(20px, min(100cqw / var(--cols), 100cqh / var(--rows)), 44px);
              width: calc(var(--cols) * var(--u)); height: calc(var(--rows) * var(--u)); }
    /* in Modifica la pianta intera, coi puntini agli angoli delle celle (e un
       margine per la × degli oggetti sul bordo) */
    .stmap.edit .stcanvas { padding: 12px; }
    .stmap.edit .stplan { background-image: radial-gradient(circle, #C4D0DC 1px, transparent 1.5px);
                          background-size: var(--u) var(--u); background-position: calc(var(--u) / -2) calc(var(--u) / -2); }
    /* ogni oggetto sulle sue celle, con un filo d'aria: due letti vicini non si toccano */
    .stbed, .starea { position: absolute; left: calc(var(--c) * var(--u) + 3px); top: calc(var(--r) * var(--u) + 3px);
                      width: calc(var(--w) * var(--u) - 6px); height: calc(var(--h) * var(--u) - 6px); }
    .sthd { display: flex; align-items: baseline; min-width: 0; }
    .stname { min-width: 0; max-width: 100%; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .stmap.edit .stname { cursor: text; border-radius: 4px; }
    .stmap.edit .stname:hover { background: #EEF2F6; box-shadow: 0 0 0 3px #EEF2F6; color: #16232E; }
    /* il paziente: il nome; sotto, «questa pagina» e la nota */
    .stp { position: relative; display: flex; flex-direction: column; gap: 1px; min-width: 0; max-width: 100%; padding: 6px 10px 6px 14px;
           border: 1px solid #D9E2EC; border-radius: 8px; background: #fff; cursor: grab; touch-action: none; transition: border-color .12s; }
    /* il triage: la stessa striscia dappertutto, dentro il bordo (nel letto la porta il letto) */
    .stp.tri::before, .stbed.tri::before { content: ""; position: absolute; left: 4px; top: 8px; bottom: 8px; width: 4px; border-radius: 2px; background: var(--tr); }
    .stp:hover { border-color: #9DBFDE; }
    .stp.qui { border-color: #0B5CAD; }
    .stp1 { display: flex; align-items: baseline; min-width: 0; }
    .stpn { min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; font-size: 14px; font-weight: 600; line-height: 18px; color: #16232E; }
    .stp2 { display: flex; align-items: baseline; gap: 6px; min-width: 0; line-height: 16px; }
    .stnota { min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; font-size: 13px; color: #5B6B7A; }
    .stp.spento { opacity: .55; }
    .stp.prec { cursor: pointer; }
    .stp.via { opacity: .3; }
    /* quello che si porta: il nome e basta, accanto al puntatore, mai sopra quello che si mira */
    .stghost { position: absolute; left: 0; top: 0; z-index: 20; max-width: 220px; padding: 3px 10px; border: 1px solid #9DBFDE; border-radius: 6px;
               background: #fff; box-shadow: 0 8px 20px rgba(9,42,74,.18); font-size: 13px; font-weight: 600; line-height: 18px; color: #16232E;
               white-space: nowrap; overflow: hidden; text-overflow: ellipsis; pointer-events: none; }
    .stmap.trascino, .stmap.trascino * { cursor: grabbing !important; }
    /* il letto: il suo nome, poi il paziente. Il testo non cambia misura: nel
       letto piccolo sparisce prima la nota, poi tutto tranne il nome del
       paziente (quello del letto resta nel passaggio del mouse). Vuoto, è più quieto. */
    .stbed { z-index: 1; container: stbed / size; border: 1px solid #E3E8EF; border-radius: 10px; background: transparent; transition: border-color .12s; }
    .stbed.occ { border-color: #C4D0DC; background: #fff; }
    .stbed.qui { border-color: #0B5CAD; box-shadow: 0 0 0 1px #0B5CAD; }
    .stbed.over { z-index: 4; outline: 2px dashed #0B5CAD; outline-offset: 3px; }
    .stmap:not(.edit) .stbed.occ { cursor: grab; touch-action: none; }
    .stbedin { position: absolute; inset: 6px 8px 6px 14px; display: flex; flex-direction: column; min-width: 0; overflow: hidden; }
    .stbed .stname { flex: none; font-size: 12px; font-weight: 400; line-height: 16px; color: #5B6B7A; }
    /* nel letto il promemoria sta sulla riga del nome del letto: quella del paziente resta tutta sua */
    .stbedhd { flex: none; display: flex; align-items: center; justify-content: space-between; gap: 4px; min-width: 0; }
    .stbedhd .stname { flex: 0 1 auto; min-width: 0; }
    .stglifo { flex: none; margin: auto; }
    .stbed .stp { flex: 1 1 auto; min-height: 0; gap: 0; padding: 0; border: 0; border-radius: 0; background: none; }
    .stbed .stp2 .stcoda { font-size: 12px; }
    .stbed .stpn { white-space: normal; overflow-wrap: anywhere; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 2; }
    .stbed .stqui, .stbed .sttag { flex: 0 1 auto; min-width: 0; overflow: hidden; text-overflow: ellipsis; }
    .stbed .stnota { flex: 0 1 auto; min-height: 0; white-space: normal; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;
                     font-size: 12px; line-height: 16px; }
    @container stbed (max-height: 94px) { .stbed .stnota { -webkit-line-clamp: 1; } }
    @container stbed (max-height: 70px) { .stbed .stnota { display: none; } }
    @container stbed (max-width: 110px) { .stbed .stnota { display: none; } }
    @container stbed (max-height: 62px) {
      .stmap:not(.edit) .stbed.occ .stname, .stbed .stp2, .stglifo { display: none; }
      .stmap.edit .stbed .stp { display: none; }   /* in Modifica conta il nome del letto */
    }
    .stfuori { position: absolute; left: 50%; bottom: -12px; z-index: 3; transform: translateX(-50%); padding: 2px 9px; border-radius: 999px;
               background: #16232E; color: #fff; font-size: 12px; font-weight: 600; white-space: nowrap; pointer-events: none; }
    /* le aree: senza letto, dentro quanti pazienti servono */
    .starea { display: flex; flex-direction: column; border: 1.5px dashed #C4D0DC; border-radius: 12px; background: rgba(255,255,255,.6);
              transition: border-color .12s, background-color .12s; }
    .starea > .sthd { flex: none; padding: 8px 10px 6px; }
    .starea .stname { font-size: 11px; font-weight: 600; letter-spacing: .06em; text-transform: uppercase; color: #5B6B7A; }
    .starea.over { border-color: #0B5CAD; background: #EAF2FA; }
    .starbody { flex: 1 1 auto; min-height: 0; overflow: auto; display: flex; flex-wrap: wrap; align-content: flex-start; gap: 6px; padding: 0 8px 8px; }
    .starbody .stp { max-width: 240px; }
    /* Modifica: i pazienti si fermano; l'oggetto scelto (o sotto il mouse) mostra la × e, l'area, l'angolo */
    .stmap.edit .stp { opacity: .4; pointer-events: none; }
    .stmap.edit .stbed, .stmap.edit .starea { cursor: move; touch-action: none; }
    .stmap.edit .stbed { background: #F7F9FB; }   /* i puntini non passano dentro il letto */
    .stmap.edit .stbed.occ { background: #fff; }
    .stbed.sel, .starea.sel { outline: 2px solid #9DBFDE; outline-offset: 3px; }
    .stbed.drag, .starea.drag { z-index: 5; background: #fff; box-shadow: 0 10px 24px rgba(9,42,74,.16); }
    /* sopra un altro non ci sta: rosso, e lasciato lì torna dov'era */
    .stbed.bad, .starea.bad { outline: 2px solid #B3261E; outline-offset: 2px; }
    .stctl { position: absolute; z-index: 4; width: 24px; height: 24px; padding: 0; border: 1px solid #D9E2EC; border-radius: 50%;
             background: #fff; cursor: pointer; font-size: 13px; line-height: 22px; text-align: center; color: #16232E;
             opacity: 0; pointer-events: none; transition: opacity .12s; }
    .stctl::before, .pzposto::before, .pzric::before, .pzx::before, .pzprom::before, .pzabtn::before, .stannulla::before { content: ""; position: absolute; inset: -4px; }
    .strsz::before { content: ""; position: absolute; inset: -8px; }
    .stbed:hover > .stctl, .starea:hover > .stctl, .sel > .stctl, .stbed:focus-within > .stctl, .starea:focus-within > .stctl,
    .starea:hover > .strsz, .starea.sel > .strsz { opacity: 1; pointer-events: auto; }
    .stctl:hover { border-color: #9DBFDE; }
    .stx { top: -12px; right: -12px; }
    .stx:hover { border-color: #E9BAB6; background: #FDF1F0; color: #B3261E; }
    .strsz { position: absolute; right: 3px; bottom: 3px; width: 16px; height: 16px; cursor: nwse-resize; touch-action: none; opacity: 0;
             pointer-events: none; transition: opacity .12s;
             background: linear-gradient(135deg, transparent 48%, #C4D0DC 48% 56%, transparent 56% 68%, #C4D0DC 68% 76%, transparent 76%); }
    .strsz:hover { background: linear-gradient(135deg, transparent 48%, #0B5CAD 48% 56%, transparent 56% 68%, #0B5CAD 68% 76%, transparent 76%); }
    .stmap .stnomein { width: 100%; min-width: 56px; height: 24px; padding: 1px 6px; border: 1px solid #9DBFDE; border-radius: 6px;
                       background: #fff; font-size: 13px; color: #16232E; user-select: text; -webkit-user-select: text; }
    .stvuota { position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center;
               gap: 6px; padding: 24px; text-align: center; pointer-events: none; }
    .stvuota svg { margin-bottom: 6px; }
    .stvuota b { font-size: 16px; font-weight: 600; color: #16232E; }
    .stvuota .stbtn { margin-top: 8px; pointer-events: auto; }
    /* «Sposta in…» */
    .stmenu { position: absolute; z-index: 30; min-width: 220px; max-width: 300px; max-height: min(60vh, 420px); overflow-y: auto; padding: 4px;
              border: 1px solid #D9E2EC; border-radius: 10px; background: #fff; box-shadow: 0 10px 28px rgba(9,42,74,.16); }
    .stmenuhd { padding: 6px 10px 4px; font-size: 12px; color: #5B6B7A; }
    .stmi { display: flex; align-items: baseline; gap: 12px; width: 100%; min-height: 32px; padding: 6px 10px; border: 0; border-radius: 6px;
            background: none; cursor: pointer; text-align: left; font-size: 13px; color: #16232E; }
    .stmi span { min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .stmi small { flex: none; margin-left: auto; font-size: 12px; color: #5B6B7A; }
    .stmi:hover, .stmi:focus { outline: none; background: #EEF2F6; }
    .stmi:focus-visible { outline: 2px solid #0B5CAD; outline-offset: -2px; }
    .stmi.cur { cursor: default; color: #5B6B7A; }
    .stmsep { height: 1px; margin: 4px 6px; background: #EEF2F6; }
    /* «Annulla», per 8 secondi */
    .stsnack { position: absolute; left: 50%; bottom: 16px; z-index: 25; transform: translateX(-50%); display: flex; align-items: center; gap: 12px;
               max-width: calc(100% - 32px); padding: 6px 6px 6px 14px; border: 1px solid #D9E2EC; border-radius: 10px; background: #fff;
               box-shadow: 0 6px 18px rgba(9,42,74,.12); font-size: 13px; color: #16232E; pointer-events: none; }
    .stsnack span { min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    .sec > .stsnack { position: sticky; left: auto; bottom: 12px; transform: none; width: max-content; margin: 16px auto 0; }
    @container stmap (max-width: 700px) { .stmap > .stsnack { bottom: 108px; } }
    .stannulla { position: relative; flex: none; min-height: 28px; border: 0; border-radius: 6px; background: none; padding: 2px 10px; cursor: pointer; pointer-events: auto;
                 font-size: 13px; font-weight: 600; color: #0B5CAD; }
    .stannulla:hover { background: #EAF2FA; }
    @media (pointer: coarse) {
      .stazioni { height: 40px; }
      .stazioni .stseg button, .stbtn, .stazioni .stbtn { min-height: 36px; }
      .pzx, .pzprom { opacity: 1; }
      .stctl { width: 32px; height: 32px; line-height: 30px; }
      .stx { top: -16px; right: -16px; }
    }
    @media (prefers-reduced-motion: reduce) { .stmap *, .stazioni *, .pzlista * { transition: none !important; } }
  `;

  const LOGO = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M12 5v14M5 12h14" stroke="#fff" stroke-width="3.2" stroke-linecap="round"/>
  </svg>`;

  // il logo sull'intestazione bianca: stessa croce, fondo blu
  const LOGO_BLU = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <rect x="1" y="1" width="22" height="22" rx="6" fill="#0B5CAD"/>
    <path d="M12 6v12M6 12h12" stroke="#fff" stroke-width="3" stroke-linecap="round"/>
  </svg>`;
  // Icone a tratto, 16px, colore del testo: le emoji cambiano faccia da un
  // computer all'altro (il ▶ diventava un quadratino nero).
  const ico = (d) => `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
  const ICO = {
    indietro: ico('<path d="M10 3 5 8l5 5"/>'),
    riduci: ico('<path d="M3.5 8h9"/>'),
    altro: ico('<circle cx="3.5" cy="8" r=".9" fill="currentColor" stroke="none"/><circle cx="8" cy="8" r=".9" fill="currentColor" stroke="none"/><circle cx="12.5" cy="8" r=".9" fill="currentColor" stroke="none"/>'),
    crono: ico('<circle cx="8" cy="9" r="5"/><path d="M8 9V6.5M6.5 2h3M12 4.5l1-1"/>'),
    ferma: ico('<rect x="4.5" y="4.5" width="7" height="7" rx="1.2" fill="currentColor" stroke="none"/>'),
    // la sveglia dei promemoria (il cronometro è un'altra cosa)
    sveglia: ico('<circle cx="8" cy="9" r="5.2"/><path d="M8 6.6V9l1.7 1.1M2.6 4.3l1.9-1.7M13.4 4.3l-1.9-1.7"/>'),
  };

  const RADIO_SET = [RES.RX, RES.ECO, RES.RMN, RES.TAC];
  function rememberQuesito(q) {
    store.set("lastQ", q);
    store.set("quesiti.ts", Date.now());
    const list = store.get("quesiti", QUESITI_DEFAULT);
    const next = [q, ...list.filter((x) => x.toLowerCase() !== q.toLowerCase())].slice(0, 8);
    store.set("quesiti", next);
  }
  // Quesiti are clinical text: they live at most a shift, and the login page
  // (forgetAll) drops them like every other clinical trace.
  function scadenzaQuesiti() {
    const ts = store.get("quesiti.ts", 0);
    if (ts && Date.now() - ts > PATIENTS_TTL) forgetQuesiti();
  }
  function forgetQuesiti() {
    store.set("lastQ", "");
    store.set("quesiti", QUESITI_DEFAULT);
    store.set("quesiti.ts", 0);
  }
  const hasExt = () => { try { return !!(chrome && chrome.runtime && chrome.runtime.id); } catch { return false; } };
  const ask = (msg) => new Promise((res) => {
    try { chrome.runtime.sendMessage(msg, (r) => { void chrome.runtime.lastError; res(r || { ok: false }); }); }
    catch { res({ ok: false }); }
  });

  function freshReceipt(richiestaId) {
    const r = tabStore.get("receipt.v1", null);
    if (!r || !r.items) return null;
    if (Date.now() - (r.ts || 0) > CONFIRM_FLAG_TTL) return null;
    if (richiestaId && r.richiestaId !== richiestaId) return null;
    return r;
  }

  // La finestra aperta: frazioni dello schermo, così segue il browser quando
  // cambia misura. Di partenza al centro, all'85%. Mai più piccola di così,
  // e un pezzo d'intestazione resta sempre a portata di mano.
  const FINESTRA = { x: 0.075, y: 0.075, w: 0.85, h: 0.85 };
  const AFFIANCA = { x: 0.63, y: 0.02, w: 0.36, h: 0.96 };   // una colonna a destra: il gestionale resta visibile
  const eAffiancata = (w) => !!w && ["x", "y", "w", "h"].every((k) => Math.abs(w[k] - AFFIANCA[k]) < 0.005);
  function geometriaFinestra(win) {
    const g = win && [win.x, win.y, win.w, win.h].every(Number.isFinite) ? win : FINESTRA;
    const vw = window.innerWidth || 1000, vh = window.innerHeight || 800;
    const w = Math.min(1, Math.max(380 / vw, g.w)), h = Math.min(1, Math.max(320 / vh, g.h));
    const x = Math.min(Math.max(g.x, 120 / vw - w), 1 - 120 / vw);
    const y = Math.min(Math.max(g.y, 0), 1 - 44 / vh);
    return { x, y, w, h };
  }

  class Panel {
    constructor(pageType) {
      this.pageType = pageType;
      this.selected = new Map(); // "res:code" -> {res, code, label}
      this.pacchetto = "";       // il quesito-pacchetto attivo («Dispnea»), o ""
      this.pkgDa = new Set();    // gli esami che ha messo LUI (non quelli scelti a mano)
      const saved = tabStore.get("log." + (findEpisodeId(document, location.href) || "x"), null);
      this.logLines = saved && Date.now() - (saved.ts || 0) < 2 * 3600e3 ? saved.lines || [] : [];
      this.runState = null; // null | 'running' | 'done' | 'fail' | 'stopped'
      this.runData = null;
      this.message = null;  // string (inline) or {head, body} (result banner)
      this.stopFn = null;
      this.host = document.createElement("div");
      this.host.id = "psassist-host";
      this.root = this.host.attachShadow({ mode: "open" });
      document.documentElement.appendChild(this.host);
      // Aperto o ridotto, a ogni pagina. Il gestionale ricarica la pagina a
      // ogni clic: se ci è arrivato il medico dal gestionale voleva VEDERE il
      // gestionale, e la finestra all'85% glielo coprirebbe — si parte dalla
      // pill. Se ce l'ha portato il pannello (un paziente scelto qui, la fine
      // di un giro), si parte aperti.
      const daPannello = Date.now() - (Number(tabStore.get("navPannello.v1", 0)) || 0) < 30e3;
      tabStore.set("navPannello.v1", 0);
      this.collapsed = !daPannello;
      this.menuAperto = false;   // il menu «⋯» dell'intestazione
      this.avvisoPill = "";      // una parola sulla pill, per pochi secondi («✓ Copiato · incolla»)
      // Che cosa sta succedendo fuori dalla finestra — conferma, etichette,
      // un errore da finire a mano — detto dalla striscia nell'angolo:
      // {tag, testo, tono: ok|run|warn|err, badge?, paziente?, onTap?, onStop?}
      this.striscia = null;
      this.acq = "";           // catalog search text
      this.esiti = [];                  // risultati + referti, newest first
      this.storico = null;              // the portal's multi-day table, if it is THIS patient's
      this.storicoAltri = "";           // ...or the name it belongs to, when it is not
      this.storicoVia = "dal nome";     // su cosa è stata confermata l'identità
      this.storicoDaConfermare = false; // c'è, ma serve il codice fiscale per dire che è suo
      this.portale = "";                // indirizzo del portale aggiunto dal medico
      this.soloAlterati = false;        // valori: show only what is out of range
      this.nColEsiti = 0;               // colonne della tabella degli Esiti: decide la larghezza
      this.mostraNomi = false;          // the unexpected-name list, open or closed
      this.mostraArch = false;          // l'elenco degli archiviati, aperto o chiuso
      this.rottiTab = new Set();        // prelievi che hanno già fallito: niente ritentativi da soli
      // La finestra aperta e la pill ridotta vivono in due posti diversi: la
      // finestra (frazioni dello schermo, così segue il browser che cambia
      // misura) parte al centro e prende l'85%; la pill resta dove la metti.
      this.win = store.get("win.v1", null);       // {x, y, w, h} in frazioni dello schermo
      this.pillPos = store.get("pillpos.v1", null); // {left, top} in px
      this.runPatient = null;           // patient name PINNED when a run starts
      this.episodeId = findEpisodeId(document, location.href);
      this.view = null;                 // home | richieste | esiti | valori
      this.viewId = null;               // which esito is open in 'valori'
      // The header must always show the patient this page belongs to: follow
      // any <title> change (the EHR sets it to the patient name).
      const titleEl = document.querySelector("title");
      if (titleEl) {
        this._titleObs = new MutationObserver(() => {
          // mai ricostruire una schermata in cui si sta scrivendo
          const scrive = ["nota", "prin"].includes(this.root.activeElement?.id);
          if (this.runState !== "running" && !scrive
              && this.view !== "dimtesto" && this.view !== "dimimport") this.render();
        });
        this._titleObs.observe(titleEl, { childList: true, characterData: true, subtree: true });
      }
      // the portal page is another tab: coming back here is the moment to look
    // for a table read in the meantime
    // (e i promemoria rifanno i conti: in una scheda nascosta il tempo non si aggiorna)
    this._visibile = () => {
      if (document.hidden) return;
      this.promTick();
      if (this.pageType === "patient") this.caricaStorico();
    };
    document.addEventListener("visibilitychange", this._visibile);
    this._unload = (e) => { e.preventDefault(); e.returnValue = ""; };
      this._esc = (e) => {
        if (e.key !== "Escape") return;
        if (this.escLocale && this.escLocale()) return;   // la stanza lo usa per sé (menu, trascinamento)
        // una stampa in corso (Esc la annulla) e il conto alla rovescia della conferma: l'Esc è loro
        if (document.getElementById("psassist-print") || document.getElementById("psassist-confirm")) return;
        // Solo col pannello aperto: da quando il giro va in sottofondo, un Esc
        // dato al gestionale (una tendina, un campo) non deve fermare gli
        // esami. Dalla striscia si ferma col quadratino rosso.
        if (this.runState === "running" && !this.collapsed) return this.stop();
        if (this.collapsed || this.runState) return;
        // Altrimenti Esc riduce la finestra alla pill — ma solo se viene dal
        // pannello (o da nessuna parte: la finestra copre la pagina), e mai
        // da un campo in cui si sta scrivendo: lì Esc è del campo.
        const via = e.composedPath ? e.composedPath() : [];
        const dentro = via.includes(this.host);
        const t = via[0];
        if (!dentro && t && t !== document.body && t !== document.documentElement && t !== document) return;
        if (t && /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName || "")) return;
        e.preventDefault();
        if (this.menuAperto) { this.menuAperto = false; this.render(); return; }
        if (this.stanzaEdit) { this.stanzaEdit = false; this.render(); return; }
        this.riduci();
      };
      window.addEventListener("keydown", this._esc, true);
      // Un clic FUORI dalla finestra (sul gestionale che si vede ai bordi) la
      // riduce alla pill: il clic intanto arriva alla pagina, non si ferma.
      // Dentro la finestra, un clic fuori dal menu «⋯» lo chiude.
      this._fuori = (e) => {
        const via = e.composedPath ? e.composedPath() : [];
        if (via.includes(this.host)) {
          if (this.menuAperto && !via.some((x) => x.classList && x.classList.contains("menuw"))) { this.menuAperto = false; this.render(); }
          return;
        }
        if (this.collapsed || this.runState === "running") return;
        if (via.some((x) => x.id === "psassist-print" || x.id === "psassist-confirm")) return;   // le nostre finestre di stampa e conferma
        this.riduci();
      };
      window.addEventListener("pointerdown", this._fuori, true);
      // il fuoco sopravvive al ridisegno: dopo ogni azione resta dov'era
      this.root.addEventListener("focusin", (e) => { const id = e.target && e.target.id; if (id) this._fuocoId = id; });
      // I promemoria: un tocco sulla pill apre il suo elenco, la sveglia apre
      // il campo. Ogni 30 secondi le pill rifanno i conti, sul posto.
      this.root.addEventListener("click", (e) => this.promClic(e));
      this._promOgni = setInterval(() => this.promTick(), 30e3);
    }

    // ---- cross-page continuity -------------------------------------------
    // The EHR reloads the page at every click (that's the app, not us). To
    // make the panel FEEL persistent, its working state — quesito, selected
    // exams, open sections — is saved per (tab,
    // episode) and restored on the next page of the SAME patient. A page of
    // another episode restores nothing.
    uiKey() { return this.episodeId ? `ui.${this.episodeId}` : null; }
    // the view is per (tab, episode) like the rest of the working state
    refKey() { return "refopen." + (this.episodeId || "x"); }
    risKey(id) { return `ris.${this.episodeId || "x"}.${id}`; }
    // what this draw looked like the last time the doctor actually looked at it
    vistoKey(id) { return `visto.${this.episodeId || "x"}.${id}`; }
    segnaVisto(id, rows) {
      const vals = {};
      for (const r of rows || []) { const k = valKey(r.nome); if (k) vals[k] = String(r.valore); }
      tabStore.set(this.vistoKey(id), { ts: Date.now(), vals });
    }
    // key → "nuovo" (analyte that was not there) | "cambiato" (value moved
    // since the last look). Empty until there IS a previous look: the first
    // read of a draw is the baseline, never a wall of marks.
    novita(id, rows) {
      const out = new Map();
      const seen = tabStore.get(this.vistoKey(id), null);
      if (!seen || !seen.vals) return out;
      for (const r of rows || []) {
        const k = valKey(r.nome);
        if (!k) continue;
        if (!(k in seen.vals)) out.set(k, "nuovo");
        else if (seen.vals[k] !== String(r.valore)) out.set(k, "cambiato");
      }
      return out;
    }
    setView(v, id, nota) {
      // a banner belongs to the screen that raised it: changing screen clears
      // it, unless this navigation is itself carrying the answer
      this.message = nota || null;
      this.view = v; this.viewId = id || null; this.persistUi(); this.render();
      if (v === "esiti") this.caricaStorico();   // letto sul portale intanto? e l'identità è cambiata?
    }
    // Il cronometro si vede da ogni schermata, altrimenti ci si dimentica di
    // fermarlo — ed è l'unica cosa che lo rende utile. Un tocco sul tempo
    // apre la scheda, un tocco su ⏹ lo ferma: fermarlo non deve costare due
    // passaggi.
    chipTempo() {
      const t = tempoInCorso();
      if (!t) return `<span class="tchip off"><button id="tapri" title="Cronometro: misura quanto ti prende un'attività" aria-label="Cronometro">${ICO.crono}</button></span>`;
      return `<span class="tchip on"><button id="tapri" title="${esc(t.titolo)}${t.paz ? " · " + esc(t.paz) : ""} — apri i tempi"><i class="tdot"></i>${esc(mmss(durata(t)))}</button><button id="tstop" title="Ferma il cronometro" aria-label="Ferma il cronometro">${ICO.ferma}</button></span>`;
    }

    // the inline banner: a string is something that went wrong, {ok} is a
    // confirmation. Every view shows it — the panel always answers.
    notaHtml() {
      const m = this.message;
      if (this.runState) return "";
      if (typeof m === "string" && m) return `<div class="banner warn">${esc(m)}</div>`;
      if (m && typeof m.ok === "string") return `<div class="banner ok">${esc(m.ok)}</div>`;
      return "";
    }
    marcaLetto(id) {
      const held = tabStore.get(this.risKey(id), null);
      if (held && held.rows) this.segnaVisto(id, held.rows);
    }
    // Aprire un paziente vuol dire quasi sempre GUARDARE: si atterra sugli
    // Esiti. Ordinare è un tocco più in là (Richieste resta in cima), e chi
    // arriva da una scheda del pannello sceglie già dove andare.
    defaultView() {
      if (this.pageType !== "patient") return "richieste";
      // senza i link per ordinare non è la scheda di un paziente ma la lista
      // del pronto soccorso: lì si mostra l'elenco dei pazienti
      return this.entry && (this.entry.labUrl || this.entry.radioUrl) ? "esiti" : "home";
    }
    persistUi() {
      const k = this.uiKey();
      if (!k) return;
      tabStore.set(k, {
        q: this._q || "",
        qrx: this._qrx || "",
        sel: [...this.selected.values()].map((i) => [i.res, i.code, i.label]),
        acq: this.acq || "",
        eoSel: this.eoSel || "",
        pk: this.pacchetto || "",
        pkDa: [...this.pkgDa],
        ts: Date.now(),
      });
    }
    applyAfterNav() {
      const a = tabStore.get("afterNav.v1", null);
      if (!a || a.ep !== this.episodeId || Date.now() - (a.ts || 0) > 60e3) return;
      tabStore.set("afterNav.v1", null);
      this.view = a.view; this.viewId = null; this.persistUi();
    }

    restoreUi() {
      const k = this.uiKey();
      const s = k ? tabStore.get(k, null) : null;
      if (!s || Date.now() - (s.ts || 0) > 6 * 3600e3) {
        this._q = store.get("lastQ", "") || ""; // keep the last quesito typed
        this._qrx = "";
        this.view = this.defaultView() === "home" ? "home" : (this.view || this.defaultView());
        return;
      }
      this._q = s.q || store.get("lastQ", "") || "";
      this._qrx = s.qrx || "";
      this.eoSel = s.eoSel || "";
      this.selected = new Map((s.sel || []).map(([res, code, label]) => [this.key(res, code), { res, code, label, display: displayLabel(res, code) }]));
      // il gestionale ricarica a ogni click: il pacchetto attivo e gli esami
      // che ha messo restano com'erano
      this.pacchetto = PACCHETTI.some((p) => p.q === s.pk) ? s.pk : "";
      this.pkgDa = new Set(this.pacchetto ? (s.pkDa || []).filter((k) => this.selected.has(k)) : []);
      this.acq = s.acq || "";
      // A page load decides the view, not the stored one: opening a patient
      // lands on Esiti — quello che si va a fare, nove volte su dieci, è
      // guardare — e chi arriva da una scheda del pannello ha già scelto lui
      // dove andare (afterNav decide subito dopo).
      // (The ER worklist stays on the patient list either way.)
      this.view = this.defaultView();
      this.viewId = null;
    }
    clearOrderUi() { // after a successful run the order is placed: start clean
      this._q = "";
      this._qrx = "";
      this.selected.clear();
      this.pacchetto = ""; this.pkgDa.clear();
      this.persistUi();
    }

    // ---- selection ----
    key(res, code) { return `${res}:${code}`; }
    isSel(res, code) { return this.selected.has(this.key(res, code)); }
    toggle(res, code) {
      if (this.acq) this.acFocus = true; // stay in the search box
      const k = this.key(res, code);
      this.pkgDa.delete(k);   // toccato a mano: da qui in poi è tuo, non del pacchetto
      if (this.selected.has(k)) this.selected.delete(k);
      else this.selected.set(k, { res, code, label: examLabel(res, code), display: displayLabel(res, code) });
      this.persistUi();
      this.render();
    }
    togglePreset(p) {
      const items = p.items;
      const allOn = items.every(([r, c]) => this.isSel(r, c));
      for (const [r, c] of items) {
        const k = this.key(r, c);
        this.pkgDa.delete(k);   // toccato a mano: non è più del pacchetto
        if (allOn) this.selected.delete(k);
        else this.selected.set(k, { res: r, code: c, label: examLabel(r, c), display: displayLabel(r, c) });
      }
      this.persistUi();
      this.render();
    }

    // ---- quesito = pacchetto di esami ----
    // Un chip-pacchetto scrive il quesito E spunta il suo pacchetto. Si
    // ricorda quali esami ha messo LUI (pkgDa): cambiando pacchetto, o
    // toccando di nuovo il chip, se ne vanno solo quelli — gli esami che c'erano
    // già (scelti a mano, o di un profilo) restano. Un chip normale scrive solo
    // il quesito, come sempre; se c'era un pacchetto lo lascia andare e i suoi
    // esami restano, ora «a mano».
    pacchettoDi(q) {
      const t = String(q || "").trim().toLowerCase();
      return PACCHETTI.find((p) => p.q.toLowerCase() === t) || null;
    }
    scegliQuesito(q) {
      const p = this.pacchettoDi(q);
      const prima = this.pkgDa;
      let mancano = [];
      if (!p) {
        this._q = q;
        this.pacchetto = ""; this.pkgDa = new Set();
      } else if (this.pacchetto === p.q) {
        // di nuovo il pacchetto attivo: via quesito e pacchetto
        for (const k of prima) this.selected.delete(k);
        this._q = ""; this.pacchetto = ""; this.pkgDa = new Set();
      } else {
        const cat = fullCatalog();
        const nuovo = new Set();
        for (const [r, c] of p.items) {
          const k = this.key(r, c);
          if (!cat[r]?.items?.[c]) { mancano.push(DISPLAY[k] || `esame ${c} (${RES_SHORT[r] || r})`); continue; }
          if (!this.selected.has(k)) {
            this.selected.set(k, { res: r, code: c, label: examLabel(r, c), display: displayLabel(r, c) });
            nuovo.add(k);
          } else if (prima.has(k)) nuovo.add(k);   // lo aveva messo il pacchetto di prima: resta del pacchetto
        }
        for (const k of prima) if (!nuovo.has(k)) this.selected.delete(k);
        this.pacchetto = p.q; this.pkgDa = nuovo; this._q = p.q;
      }
      // quello che manca dal catalogo si dice una volta sola, qui e nel Registro
      if (mancano.length) {
        const nota = `«${p.q}»: non ho aggiunto ${mancano.join(", ")} — ${mancano.length === 1 ? "non è" : "non sono"} nel catalogo di questo computer.`;
        this.log(`${now()}  ${nota}`);
        this.message = this._notaPk = nota;
      } else if (this._notaPk && this.message === this._notaPk) { this.message = null; this._notaPk = ""; }
      this.persistUi();
      this.render();
    }

    log(line) {
      this.logLines.push(line);
      if (this.logLines.length > 200) this.logLines.shift();
      tabStore.set("log." + (this.episodeId || "x"), { ts: Date.now(), lines: this.logLines });
      const el = this.root.querySelector(".log");
      if (el) { el.textContent = this.logLines.join("\n"); el.scrollTop = el.scrollHeight; }
    }

    // La striscia dice a che punto è, due righe: chi (e cosa) sopra, il
    // momento sotto. Con `ms` se ne va da sola, e `poi` dice cosa resta.
    segnala(s, { ms = 0, poi = null } = {}) {
      clearTimeout(this._tStriscia);
      this.striscia = s ? { ...s } : null;
      if (s && ms) {
        const mia = this.striscia;
        this._tStriscia = setTimeout(() => {
          if (this.striscia !== mia) return;
          this.striscia = null;
          poi?.();
          this.render();
        }, ms);
      }
      // a finestra aperta la striscia non si vede: niente ridisegno (si
      // starebbe magari scrivendo in un campo)
      if (this.collapsed) this.render();
    }
    // finito tutto (stampato): la pill torna quella di sempre
    chiudiGiro() {
      if (this.runState !== "done") return;
      this.runState = null; this.runData = null; this.message = null;
    }

    // ---- engine callbacks ----
    beginRun(state, plan) {
      // a chained second richiesta keeps the first one's steps on screen
      if (plan && plan.continuation && this.runData && this.runData.steps) state.steps.unshift(...this.runData.steps);
      this.runState = "running"; this.runData = state; this.stopFn = state.stop;
      clearTimeout(this._tStriscia); this.striscia = null;
      this.carrelloDaAprire = null;
      this.riprova = null; this.consegnaErrore = null;
      this.runRipreso = !!(plan && plan.startPage === "ripresa");
      // Il giro sopravvive al cambio pagina: riprende da dov'era. Si avvisa
      // prima di uscire solo dove riprendere non si può — le catene
      // lab+radiologia, e il bookmarklet, che va ricliccato a mano.
      if (!plan || !plan.riprendibile || !hasExt()) window.addEventListener("beforeunload", this._unload);
      // …e intanto il pannello si fa piccolo: una striscia in un angolo che
      // dice a che punto è, e il gestionale resta tutto tuo. La preferenza del
      // medico NON si tocca (niente store.set): finito il giro torna com'era.
      // Solo per i giri che possono andare in sottofondo: una catena
      // lab+radiologia resta sotto gli occhi, come è sempre stata.
      if (plan && plan.riprendibile) this.collapsed = true;
      this.render();
    }
    renderRun(state) { this.runData = state; this.render(); }
    finished(state, plan) {
      if (plan.hold) { this.runData = state; this.render(); return; } // the chain finishes for us
      window.removeEventListener("beforeunload", this._unload);
      // L'ordine è partito: la prossima pagina riparte pulita. Ma se il giro
      // era di un ALTRO paziente (ripreso mentre guardavi altro), il quesito e
      // gli esami che stai spuntando qui non si toccano.
      if (!plan || !plan.episodeId || plan.episodeId === this.episodeId) this.clearOrderUi();
      this.runState = "done"; this.runData = state;
      const n = state.added.length;
      this.message = {
        head: `✓ ${n} ${n === 1 ? "esame" : "esami"} in carrello, ${n === 1 ? "verificato" : "verificati"}`,
        body: state.quesitoKept ? "Quesito del triage mantenuto." : "",
      };
      // In sottofondo la finestra non si apre mai da sola: dalla spedizione
      // alle etichette parla la striscia, e un tocco la apre con la ricevuta.
      // (Solo la catena lab+radiologia, plan.hold, resta sotto gli occhi.)
      this.cartTag = `✓ ${n} ${n === 1 ? "esame" : "esami"} in carrello`;
      const daConfermare = !!tabStore.get("confirm.v1", null);
      this.segnala({ tag: this.cartTag, tono: daConfermare ? "run" : "ok",
        testo: daConfermare ? "Confermo…" : plan.startPage === "ripresa" ? "Il carrello è pronto: aprilo quando vuoi" : "Apro il carrello…" });
      this.render();
      if (state.finishedListUrl) this.chiudiRichiesta(state.finishedListUrl, plan, state);
    }

    // OGNI navigazione decisa dal programma passa di qui. Se il medico sta
    // scrivendo nel gestionale (cursore in un campo, un campo cambiato, un
    // tasto da meno di 15 secondi) non si va: la pill dice «… · tocca per il
    // carrello» e un tocco ci porta. `prima` scrive il passaggio di consegne
    // per la pagina dopo, nell'istante in cui si parte davvero (se non si
    // riesce a scriverlo, non si parte).
    vaiSeLibero(url, { striscia = null, prima = null, ms = 300 } = {}) {
      const vai = () => { if (prima && prima() === false) return; nav(url); };
      const aspetta = (perche) => {
        this.log(`${now()}  non cambio pagina da solo: ${perche} — un tocco sulla striscia apre il carrello`);
        this.carrelloDaAprire = vai;   // a finestra aperta: il bottone «Apri il carrello»
        const s = striscia || this.striscia || { tag: "", tono: "warn" };
        this.segnala({ ...s, testo: `${s.testo ? s.testo + " · " : ""}tocca per il carrello`, titolo: "tocca per il carrello", onTap: vai, onStop: null });
      };
      const ora = staScrivendo();
      if (ora) { aspetta(ora); return false; }
      setTimeout(() => {
        const poi = staScrivendo();   // nel frattempo ha cominciato a scrivere?
        if (poi) aspetta(poi); else vai();
      }, ms);
      return true;
    }

    // La prova che una richiesta è confermata, quando la cornice non l'ha
    // data: UNA lettura della pagina del paziente — quella che elenca le
    // richieste confermate coi loro fogli da stampare. Mai un invio.
    async provaConferma(rid, ep, plan) {
      // solo l'indirizzo di una pagina da leggere: mai quello di un modulo inviato
      const leggibile = (x) => { try { return !!x && new URL(x).origin === location.origin && !/[?&](ccsForm|Insert|Delete|Update)=/i.test(x); } catch { return false; } };
      const qui = findEpisodeId(document, location.href) === ep && this.pageType === "patient" ? location.href : "";
      const u = [qui, plan?.patientUrl, (tuttiPazienti().find((p) => p.ep === ep) || {}).url].find(leggibile) || "";
      if (!rid || !ep || !u) return null;
      try {
        const { doc, url } = await fetchDoc(u);
        if (classify(doc) === "login" || findEpisodeIdInDoc(doc) !== ep) return null;
        return printModel(doc, url)[rid] ? { doc, url } : null;
      } catch (e) {
        this.log(`${now()}  controllo della conferma non riuscito: ${e?.head || e?.message || e}`);
        return null;
      }
    }

    // Le richieste di questo episodio mandate e mai viste confermate: dopo 2
    // minuti la pill lo dice, ambra, e un tocco apre il loro carrello. Si
    // guarda solo la pagina che il medico ha davanti — al server non si chiede
    // niente — e sul carrello di quella stessa richiesta non si dice (ci sei).
    sorvegliaConferme(appenaAperta = false) {
      clearTimeout(this._tConferme);
      const sua = param(location.href, "RICHIESTA_ID");
      const x = nonConfermateQui().find((r) => r.rid !== sua);
      if (!x) return;
      const manca = x.ts + attesaConferma() - Date.now();
      const occupata = this.runState === "running" || (this.striscia && (this.striscia.tono === "err" || this.striscia.tono === "run" || this.striscia.daStampa));
      if (manca > 0 || occupata) { this._tConferme = setTimeout(() => this.sorvegliaConferme(), Math.max(manca, 0) + (occupata ? 20e3 : 50)); return; }
      let u = "";
      try { u = new URL(x.listUrl).origin === location.origin && !/[?&](Insert|Delete)=/.test(x.listUrl) ? x.listUrl : ""; } catch { u = ""; }
      this.log(`${now()}  la richiesta ${x.rid} delle ${hhmm(x.ts)} non risulta confermata`);
      if (appenaAperta) this.collapsed = true;   // la pagina appena aperta: l'avviso si vede subito
      this.segnala({ tag: "Non confermata", tono: "warn", titolo: "tocca per il carrello",
        testo: `Richiesta ${hhmm(x.ts)} non confermata · tocca per il carrello`,
        onTap: () => (u ? nav(u) : this.apri()) });
    }

    // Ultimo passo: la conferma. Si prova a farla in sottofondo — la pagina
    // del carrello caricata davvero, in una cornice invisibile, col suo
    // bottone premuto davvero. Se il server non si lascia incorniciare, o se
    // un controllo dice di no, si va sulla pagina come si è sempre fatto: lì
    // il medico vede tutto e decide lui. Ogni pagina dopo ci arriva con la
    // striscia (AVVISO), mai con la finestra.
    async chiudiRichiesta(listUrl, plan, state) {
      const daConfermare = !!tabStore.get("confirm.v1", null);
      const tag = this.cartTag || "";
      const ep = plan?.episodeId || this.episodeId;
      const rid = state?.richiestaId || param(listUrl, "RICHIESTA_ID");
      const n = state?.added?.length || 0;
      const chi = this.runPatient || "";
      const consegna = (striscia, testo) => tabStore.set(AVVISO, {
        ts: Date.now(), striscia: { paziente: chi, ...striscia }, ...(testo ? { testo } : {}),
      });
      // da qui la richiesta è da confermare: finché una pagina del paziente
      // non la mostra confermata, la si tiene d'occhio (solo numeri)
      ricordaDaConfermare(rid, ep, listUrl, n);
      if (!daConfermare || DEMO) {
        // Un giro ripreso vuol dire che stavi facendo altro: la pagina non te
        // la porto via. Il carrello è pronto, ci vai col bottone.
        if (plan && plan.startPage === "ripresa") {
          this.message = { head: this.message?.head || "", body: "Il carrello è pronto: aprilo quando vuoi." };
          this.render();
          return;
        }
        // Revisione: si va sul carrello, e lì la Conferma è quella del
        // gestionale (il suo clic arma comunque la stampa delle etichette).
        const str = daConfermare ? { tag, testo: "Confermo…", tono: "run", attesaConferma: true }
          : { tag, testo: "Conferma dal gestionale", tono: "ok" };
        this.vaiSeLibero(listUrl, { ms: 400, striscia: daConfermare ? { tag, testo: "Conferma da fare", tono: "warn" } : str,
          prima: () => { consegna(str); } });
        return;
      }
      this.message = { head: this.message?.head || "", body: "Confermo in sottofondo…" };
      this.render();
      // Se la pagina se ne va mentre la cornice lavora, la conferma automatica
      // muore con lei: non deve ripartire da sola più tardi, su un carrello
      // aperto a mano. Resta il segno qui sopra, e la pill lo dirà.
      const abbandona = () => tabStore.set("confirm.v1", null);
      window.addEventListener("pagehide", abbandona);
      let esito = "rifiutata";
      try { esito = await confermaInCornice(listUrl, { panel: this, episodeId: ep, rid }); }
      catch { esito = "rifiutata"; }
      window.removeEventListener("pagehide", abbandona);
      this.log(`${now()}  conferma in sottofondo: ${esito}`);
      if (esito === "incerta") {
        // Nessuna prova dalla cornice: una lettura della pagina del paziente.
        const prova = await this.provaConferma(rid, ep, plan);
        if (prova) {
          this.log(`${now()}  la pagina del paziente la elenca coi suoi fogli: confermata`);
          let partita = false;
          try { partita = maybeAutoPrint(this, prova.doc, prova.url); } catch { partita = false; }
          esito = partita ? "stampata" : "confermata";
        } else this.log(`${now()}  la pagina del paziente non la elenca: NON confermata`);
      }
      const fine = { n, ts: Date.now() };
      if (esito === "stampata" || esito === "confermata") confermataProvata(rid);
      if (esito === "stampata") {
        // la striscia adesso è della stampa; alla fine resta il resoconto
        this.message = { head: `✓ ${confermatiTesto(fine)}`, body: "Senza passare dal carrello." };
        this.render();
        return;
      }
      if (esito === "confermata") {
        // Confermata, ma i fogli non sono partiti (un'altra stampa in corso):
        // restano armati, e partono dalla sua scheda. Niente si ricarica.
        this.message = { head: `✓ ${confermatiTesto(fine)}`, body: "Le etichette partono dalla sua scheda." };
        this.segnala({ tag: "Confermata", testo: confermatiTesto(fine), tono: "ok" });
        this.render();
        return;
      }
      if (esito === "incerta") {
        // Né la cornice né la pagina del paziente la dicono confermata: per
        // il pannello NON lo è. Mai verde, e mai una seconda conferma da sola:
        // un tocco apre il carrello, e lì decide il medico.
        tabStore.set("confirm.v1", null);
        const str = { tag: "Non confermata", testo: "Controlla il carrello e premi tu Conferma", tono: "warn" };
        this.message = { head: "Conferma non verificata", body: "Il gestionale non mostra questa richiesta fra le confermate: apri il carrello, controlla e premi tu Conferma." };
        this.segnala({ tag: "Non confermata", testo: "tocca per il carrello", titolo: "tocca per il carrello", tono: "warn", paziente: chi,
          onTap: () => { consegna(str); nav(listUrl); } });
        this.render();
        return;
      }
      // Rifiutata (il server non si lascia incorniciare) o sospesa (un
      // controllo ha detto di no): si finisce sulla pagina vera, col motivo.
      const motivo = "Conferma automatica sospesa: controlla il carrello e premi tu Conferma.";
      const sospesa = { tag: "Conferma sospesa", testo: "Controlla il carrello e premi tu Conferma", tono: "warn" };
      const testo = (typeof this.message === "string" && this.message) || motivo;
      if (esito === "sospesa") tabStore.set("confirm.v1", null);
      if (this.runRipreso) {
        // giro ripreso: niente salti di pagina, il carrello si apre col tocco
        tabStore.set("confirm.v1", null);
        const aMano = esito === "rifiutata";
        this.message = { head: this.message?.head || "", body: aMano ? "Conferma da fare a mano: apri il carrello." : testo };
        const dopo = aMano ? { tag, testo: "Conferma dal gestionale", tono: "ok" } : sospesa;
        this.segnala({ tag: aMano ? tag : sospesa.tag, tono: "warn", paziente: chi, titolo: "tocca per il carrello",
          testo: `${aMano ? "Conferma da fare a mano" : "Controlla il carrello"} · tocca per il carrello`,
          onTap: () => { consegna(dopo, aMano ? null : testo); nav(listUrl); } });
        this.render();
        return;
      }
      if (esito === "sospesa") {
        this.vaiSeLibero(listUrl, { ms: 0, striscia: { ...sospesa, testo: "" }, prima: () => { consegna(sospesa, testo); } });
      } else {
        // cornice vietata: la conferma la fa la pagina vera, appena caricata.
        // Se non si può partire adesso, la conferma resta al medico.
        const confermo = { tag, testo: "Confermo…", tono: "run", attesaConferma: true };
        const parte = this.vaiSeLibero(listUrl, { ms: 0, striscia: { tag, testo: "Conferma da fare a mano", tono: "warn" },
          prima: () => { consegna(tabStore.get("confirm.v1", null) ? confermo : { tag, testo: "Conferma dal gestionale", tono: "ok" }); } });
        if (!parte) tabStore.set("confirm.v1", null);
      }
    }
    failed(state, msg, plan) {
      window.removeEventListener("beforeunload", this._unload);
      this.runState = "fail"; this.runData = state; this.message = msg;
      const riprenderà = !!tabStore.get(CORSA, null);
      // La catena lab+radiologia resta sotto gli occhi, com'è sempre stata.
      if (plan && plan.hold) {
        if (this.collapsed && !riprenderà) { this.collapsed = false; store.set("collapsed", false); }
        this.render();
        return;
      }
      // Un giro che riprenderà da solo alla pagina dopo: lo dice la striscia.
      if (riprenderà) {
        this.segnala({ tag: "Giro interrotto", testo: "Riprende alla prossima pagina", tono: "warn", paziente: this.runPatient || "" });
        this.render();
        return;
      }
      // Errore in sottofondo: la finestra NON si apre. La striscia diventa
      // rossa e dice che cosa manca (mai partito) e che cosa è da controllare
      // (mandato, ma non visto in carrello), e la scheda va sul carrello della
      // richiesta — sul laboratorio del primo esame rimasto fuori — con una
      // semplice lettura dell'elenco: niente si manda, niente si conferma. Lì
      // il medico vede gli esami già scelti e aggiunge il resto a mano.
      tabStore.set("confirm.v1", null);
      const mancano = msg.mancano || [], controllare = msg.controllare || [];
      const cosa = [mancano.length ? `Mancano: ${mancano.join(", ")}` : "", controllare.length ? `Da controllare: ${controllare.join(", ")}` : ""]
        .filter(Boolean).join(" · ");
      const striscia = msg.sessione
        ? { tag: "Sessione scaduta", testo: "Rifai l'accesso, poi controlla il carrello", tono: "err", paziente: this.runPatient || "" }
        : { tag: "Errore · completa a mano", testo: cosa || msg.head, tono: "err", paziente: this.runPatient || "" };
      // solo l'elenco semplice, di questo ospedale: niente che inserisca o tolga
      let listUrl = state.lastListUrl;
      try {
        if (new URL(listUrl).origin !== location.origin || /[?&](Insert|Delete)=/.test(listUrl)) listUrl = null;
        // il laboratorio del primo esame rimasto fuori, se la richiesta lo offre
        const res = state.resMancante;
        if (listUrl && res && res !== param(listUrl, "RISORSA_ID") && (param(listUrl, "RISORSE") || "").split(",").includes(res)) {
          const u = new URL(listUrl);
          u.searchParams.set("RISORSA_ID", res);
          listUrl = u.href;
        }
      } catch { listUrl = null; }
      // Mai sul carrello dopo un episodio che non torna o la sessione scaduta
      // (restaQui), né se il giro ripreso ti ha trovato sulla scheda di un
      // altro paziente: quella pagina non te la porto via.
      // (epDiQuesta: la lista del PS non è la pagina di nessun paziente)
      const qui = this.epDiQuesta();
      const vai = !!listUrl && !msg.restaQui && (!this.runRipreso || (!!qui && qui === plan?.episodeId));
      // quello che è in carrello resta da confermare: lo si tiene d'occhio
      if (vai && state.added.length) ricordaDaConfermare(state.richiestaId, plan?.episodeId, listUrl, state.added.length);
      // «↻ Riprova i mancanti»: mai dopo una sessione scaduta, un episodio che
      // non torna o un'altra scheda al lavoro
      this.riprova = msg.restaQui ? null : ricettaRiprova(state, plan);
      const consegna = () => tabStore.set(AVVISO, {
        ts: Date.now(), testo: msg, striscia,
        giro: { stato: "fail", paziente: this.runPatient || "", listUrl,
          steps: (state.steps || []).map(({ label, status, note }) => ({ label, status, note })) },
        ...(this.riprova ? { riprova: this.riprova } : {}),
      });
      // anche «Apri il carrello» porta con sé il resoconto: lì compare «Riprova»
      this.consegnaErrore = listUrl && this.riprova ? consegna : null;
      this.segnala(striscia);
      this.render();
      if (vai) {
        state.lastListUrl = listUrl;   // anche «Apri il carrello» del resoconto porta lì
        this.vaiSeLibero(listUrl, { striscia, prima: consegna });
      }
    }
    stopped(state, msg, plan) {
      window.removeEventListener("beforeunload", this._unload);
      this.runState = "stopped"; this.runData = state; this.message = msg;
      if (plan && plan.hold) {
        if (this.collapsed) { this.collapsed = false; store.set("collapsed", false); }
        this.render();
        return;
      }
      // fermato dal medico: lo dice la striscia, un tocco apre il resoconto
      this.segnala({ tag: "Interrotto", testo: "L'ultimo esame potrebbe essere in carrello: controlla", tono: "warn", paziente: this.runPatient || "" });
      this.render();
    }
    stop() { this.stopFn?.(); }

    // «↻ Riprova i mancanti» si mostra solo dov'è sicuro: sul carrello di
    // QUELLA richiesta (il motore rilegge il carrello dal server: quelli già
    // entrati li ritrova e non li rimanda), o sulla pagina del paziente se la
    // richiesta non era ancora nata. Altrove si apre prima il carrello.
    riprovaQui() {
      const r = this.riprova;
      if (!r || this.runState !== "fail" || !(r.mancanti || []).length) return false;
      if (findEpisodeId(document, location.href) !== r.ep) return false;
      if (r.rid) return this.pageType === "exam" && param(location.href, "RICHIESTA_ID") === r.rid;
      return this.pageType === "patient" && !!(this.entry && (this.entry.labUrl || this.entry.radioUrl));
    }
    riprovaMancanti() {
      const r = this.riprova;
      if (!this.riprovaQui()) return;
      this.dimenticaErrore();
      // senza richiesta: un giro normale, col quesito e gli esami del pannello
      if (!r.rid) { this.view = "richieste"; this.launch(r.autoConfirm); return; }
      const nomi = (l) => l.map((x) => x.display || shortLabel(x.label)).join(", ");
      const fuori = r.controllare || [];
      this.startPlan({
        startPage: "exam", examDoc: document, examUrl: location.href, richiestaId: r.rid,
        autoConfirm: r.autoConfirm, patientName: r.paziente, patientUrl: r.patientUrl,
        // quelli già in carrello si cercano soltanto: mai un secondo invio
        items: [...(r.verdi || []).map((x) => ({ ...x, soloVerifica: true, giaFatto: true })), ...r.mancanti.map((x) => ({ ...x }))],
        daControllare: fuori.map((x) => ({ ...x })),   // fuori dal giro, ma se va storto di nuovo restano in elenco
      });
      this.log(`${now()}  ↻ riprovo i mancanti: ${nomi(r.mancanti)}${
        fuori.length ? ` — non rimando quelli da controllare: ${nomi(fuori)}` : ""}`);
    }
    // Via l'errore: la pill torna quella di sempre, e il passaggio di
    // consegne verso il carrello (e «Riprova») si dimentica.
    dimenticaErrore() {
      this.runState = null; this.runData = null; this.message = null;
      this.carrelloDaAprire = null; this.consegnaErrore = null; this.riprova = null;
      clearTimeout(this._tStriscia); this.striscia = null;
      tabStore.set(AVVISO, null);
    }
    // «Annulla»: si torna alle Richieste col quesito e gli esami scelti,
    // com'erano. La richiesta rimasta a metà non la si sorveglia più: l'hai
    // lasciata tu, e ricordartela fra due minuti vorrebbe dire confermarla
    // accanto a quella che rifai da capo.
    annulla() {
      const u = this.runData?.lastListUrl;
      const rid = this.riprova?.rid || this.runData?.richiestaId || (u ? param(u, "RICHIESTA_ID") : null);
      this.dimenticaErrore();
      if (rid) confermataProvata(rid);
      this.restoreUi();
      // (sulla lista del PS, dove non si ordina, si resta sui Pazienti)
      this.view = this.defaultView() === "home" ? "home" : "richieste"; this.viewId = null;
      this.persistUi();
      this.render();
    }

    // ---- run starters ----
    startPlan(base) {
      if (this.runState === "running") return;
      // Copie: il motore traduce codici e risorse per la sede, e la selezione
      // del medico deve restare la sua (dopo un errore, «Annulla» la ritrova).
      const items = base.items || [...this.selected.values()].map((i) => ({ ...i }));
      if (!items.length) return;
      const episodeId = findEpisodeId(document, location.href);
      if (!episodeId) { // fail-closed: never order on an unidentifiable episode
        this.message = "Episodio non identificabile su questa pagina: usa la pagina nativa.";
        this.render();
        return;
      }
      this.log(`${now()}  ── nuova operazione ──`);
      this.message = null;
      tabStore.set("receipt.v1", null);
      // Pin the patient this run belongs to: the running/result views show
      // THIS name, never whatever the page title becomes later.
      this.runPatient = base.patientName || (document.title || "").trim();
      const plan = { quesito: (this._q || "").trim(), items, episodeId, patientName: this.runPatient, ...base,
        // la pagina che elenca le richieste confermate: serve a provare una conferma
        patientUrl: base.patientUrl || (this.pageType === "patient" ? location.href : "") };
      if ((this._q || "").trim()) rememberQuesito((this._q || "").trim());
      if (plan.legs && plan.legs.length > 1) this.runChain(plan);
      else runPlan(plan, this); // fire and forget; the engine drives the UI via callbacks
    }

    // Lab and radiology cannot share a richiesta, so when both are selected we
    // build them one after the other and then walk the doctor through both
    // confirmations (and one single print flow at the end).
    async runChain(plan) {
      const done = [];
      for (let i = 0; i < plan.legs.length; i++) {
        const leg = plan.legs[i];
        const st = await runPlan({
          ...plan, hold: true, continuation: i > 0,
          entryUrl: leg.entryUrl, items: leg.items, legLabel: leg.label,
          quesito: leg.quesito ?? plan.quesito,
        }, this);
        if (this.runState !== "running" || !st || !st.richiestaId) return; // failed/stopped: stop here
        done.push({
          rid: st.richiestaId, listUrl: st.finishedListUrl || st.lastListUrl, kind: leg.kind,
          carrelli: st.carrelli || {},
          count: st.added.length,
          lastCode: st.added.length ? st.added[st.added.length - 1].code : null,
          lastLabel: st.added.length ? st.added[st.added.length - 1].label : null,
          added: st.added.map((x) => ({ res: x.res, code: x.code, label: x.label, display: x.display || x.label })),
        });
      }
      if (!done.length) return;
      // ogni richiesta della catena resta da confermare finché non lo si vede
      for (const d of done) ricordaDaConfermare(d.rid, plan.episodeId, d.listUrl, d.count);
      window.removeEventListener("beforeunload", this._unload);
      this.clearOrderUi();
      this.runState = "done";
      const total = done.reduce((n, d) => n + d.count, 0);
      this.message = { head: `✓ ${done.length} richieste, ${total} esami verificati`, body: "" };
      // hand the rest of the walk to the pages we are about to land on
      const first = done[0];
      tabStore.set("queue.v1", { episodeId: plan.episodeId, autoConfirm: !!plan.autoConfirm, ts: Date.now(), items: done });
      tabStore.set("receipt.v1", { richiestaId: first.rid, episodeId: plan.episodeId, ts: Date.now(), items: first.added, carrelli: first.carrelli || {} });
      if (plan.autoConfirm && first.lastCode && first.kind !== "radio") {
        tabStore.set("confirm.v1", { richiestaId: first.rid, episodeId: plan.episodeId, lastCode: first.lastCode, lastLabel: first.lastLabel, count: first.count, ts: Date.now() });
      }
      this.render();
      if (first.listUrl) this.vaiSeLibero(first.listUrl, { ms: 900, striscia: { tag: `✓ ${done.length} richieste`, testo: "Conferma dal gestionale", tono: "ok" } });
    }

    // ---- live validation (before anything is sent) ----
    computeProblems() {
      const items = [...this.selected.values()];
      const problems = { go: [], confirm: [] };
      const both = (m) => { problems.go.push(m); problems.confirm.push(m); };
      const wantsRadio = items.some((i) => RADIO_SET.includes(i.res));
      const wantsLab = items.some((i) => !RADIO_SET.includes(i.res));
      const q = (this._q || "").trim(), qrx = (this._qrx || "").trim();
      if (this.pageType === "patient") {
        if ((wantsLab && !q) || (wantsRadio && !q && !qrx)) both("Scrivi il quesito diagnostico prima di creare la richiesta.");
        if (wantsRadio && !wantsLab && !this.entry?.radioUrl) both("Link Richieste Radiologia non trovato su questa pagina.");
        if (wantsLab && !this.entry?.labUrl) both("Link Richieste Laboratorio non trovato su questa pagina.");
      } else if (this.pageType === "crea") {
        const allowed = new Set((param(location.href, "RISORSE") || "").split(",").filter(Boolean));
        if (allowed.size) {
          const cat = fullCatalog();
          const opzioni = [...allowed].map((v) => ({ value: v, label: (cat[v] && cat[v].label) || v }));
          const wrong = items.filter((i) => i.res && !risorsaQui(i, opzioni, cat));
          if (wrong.length) both(`Non ordinabili in questa richiesta: ${wrong.map((i) => i.display || shortLabel(i.label)).join(", ")}.`);
        }
        const form = document.forms.namedItem("RICHIESTACrea");
        const pageQ = (form?.elements?.namedItem("QUESITO_DIAGNOSTICO")?.value || "").trim();
        if (items.length && !pageQ && !q && !(wantsRadio && !wantsLab && qrx)) both("Scrivi il quesito diagnostico (nel pannello o nella pagina).");
      } else if (this.pageType === "exam") {
        const live = examModel(document, location.href);
        if (live.resOptions.length) {
          // lo stesso criterio del motore: un esame che in questa sede sta in
          // un'altra risorsa (per nome, o perché ha lo stesso esame) si ordina
          const cat = fullCatalog();
          const wrong = items.filter((i) => i.res && !risorsaQui(i, live.resOptions, cat));
          if (wrong.length) both(`Non ordinabili in questa richiesta: ${wrong.map((i) => i.display || shortLabel(i.label)).join(", ")}.`);
        }
      }

      return problems;
    }

    // =============================================================== VIEWS
    // Compact always-visible selection strip: plain text grouped by resource
    // ("POC: EMOGAS, EMOCROMO · URGENZE: PCT"), an ✕ appears on hover.
    selbarHtml() {
      if (!this.selected.size) return "";
      if (this.pageType === "patient" && !(this.entry && (this.entry.labUrl || this.entry.radioUrl))) return "";
      const byRes = {};   // per nome corto: Urgenze e centrale sono un gruppo solo
      for (const i of this.selected.values()) (byRes[risorsaCorta(i.res)] = byRes[risorsaCorta(i.res)] || []).push(i);
      const groups = Object.entries(byRes).map(([r, arr]) => {
        const items = arr.map((i) =>
          `<span class="selitem" title="${esc(i.label)}">${esc(i.display || shortLabel(i.label))}<button class="selx" data-unsel="${esc(this.key(i.res, i.code))}" title="Rimuovi" aria-label="Rimuovi ${esc(i.display || shortLabel(i.label))}">✕</button></span>`
        ).join(", ");
        return `<span class="selgrp">${esc(r.toUpperCase())}:</span> ${items}`;
      });
      return `<div class="selbar"><span class="selcount">${this.selected.size} SELEZIONATI</span>${groups.map((g) => `<div class="selrow">${g}</div>`).join("")}</div>`;
    }

    render() {
      const patientName = (document.title || "").trim();
      const ep = findEpisodeId(document, location.href);
      // keep every scroll position across re-renders (chip toggles must not
      // bounce the panel back to the top), sideways too: dopo un paziente
      // portato la mappa, «Da sistemare» e le aree restano dove li hai lasciati
      const scorre = (el) => {
        const a = el.classList.contains("starbody") && el.closest("[data-area]");
        return a ? `[data-area="${CSS.escape(a.getAttribute("data-area"))}"] .starbody` : "." + ["bd", "list", "rlist", "stcanvas", "strow"].find((c) => el.classList.contains(c));
      };
      const keepScroll = [...this.root.querySelectorAll(".bd, .list, .rlist, .stcanvas, .strow, .starbody")]
        .filter((el) => el.scrollTop || el.scrollLeft).map((el) => [scorre(el), el.scrollTop, el.scrollLeft]);
      // un promemoria a metà resta scritto, col cursore dov'era; l'elenco aperto si chiude
      const pin = this.root.querySelector("#prin");
      if (pin && this.root.activeElement === pin) { this._promFuoco = true; this._promSel = [pin.selectionStart, pin.selectionEnd]; }
      this.promChiudiMenu();

      let body;
      if (this.runState === "running") body = this.viewRunning();
      else if (this.runState) body = this.viewResult();
      else if (this.view === "esiti") body = this.viewEsiti();
      else if (this.view === "referto") body = this.viewReferto();
      else if (this.view === "dimissioni") body = this.viewDimissioni();
      else if (this.view === "dimtesto") body = this.viewDimTesto();
      else if (this.view === "dimimport") body = this.viewDimImport();
      else if (this.view === "consensi") body = this.viewConsensi();
      else if (this.view === "eo") body = this.viewEo();
      else if (this.view === "tempi") body = this.viewTempi();
      else if (this.view === "richieste") body = this.viewIdle(patientName, ep);
      else body = this.viewHome(patientName, ep);
      // la stanza è una mappa: prende tutta la finestra che resta
      const inStanza = !this.runState && !["esiti", "referto", "dimissioni", "dimtesto", "dimimport", "consensi", "eo", "tempi", "richieste"].includes(this.view)
        && this.pazVista() === "stanza";

      const running = this.runState === "running";
      // a che punto è, in ESAMI (non in passi): «esame 2 di 6»
      // (si contano quelli già passati: l'ordine in cui vanno non è quello della lista)
      const esami = (this.runData?.steps || []).filter((s) => s.esame);
      const passati = esami.filter((s) => s.status !== "pending" && s.status !== "running").length;
      const badgeEsami = !esami.length ? "" : esami.some((s) => s.status === "running") ? `esame ${passati + 1} di ${esami.length}`
        : passati ? `${passati} di ${esami.length}` : `${esami.length} ${esami.length === 1 ? "esame" : "esami"}`;
      // The panel is titled by the PATIENT it is acting on — collapsed too.
      // Dove un paziente non c'è (la lista del PS) il titolo della pagina è
      // «PRONTO SOCCORSO - LISTA»: quello non va mai dove va un nome.
      const sulPaziente = !!this.epDiQuesta();
      const who = (this.runState && this.runPatient) || (sulPaziente ? patientName : "") || APP;
      // Mentre il giro va avanti il pannello è una striscia: chi, a che punto,
      // e che cosa sta facendo adesso. Il gestionale resta usabile sotto.
      const passo = (this.runData?.steps || []).find((s) => s.status === "running");
      const fase = running
        ? (passo ? `${passo.label}${passo.note ? " · " + passo.note : ""}` : "…")
        : typeof this.message === "string" ? this.message
          : (this.message?.ok || this.message?.head || this.message?.body || "");
      // Sei su un'altra scheda: il giro continua (le richieste portano il loro
      // episodio), ma va detto a chiare lettere di chi sono gli esami.
      const altrove = !!(this.runState && this.runPatient && patientName && this.runPatient !== patientName);
      // la striscia di quello che succede fuori dalla finestra: rossa per un
      // errore, ambra quando tocca a te
      const strWho = (this.striscia && this.striscia.paziente) || who;
      const strTono = !this.striscia ? "" : this.striscia.tono === "err" ? "err" : this.striscia.tono === "warn" ? "warn" : "";
      const chiPill = this.avvisoPill || ((this.runState || sulPaziente) ? who : "Pazienti");
      const pillInner = running
        ? `<span class="dot"></span> <span class="who">${esc(who)}</span>${badgeEsami ? ` <span class="badge">${esc(badgeEsami)}</span>` : ""}`
        : this.selected.size && !this.avvisoPill
          ? `${LOGO} <span class="who">${esc(chiPill)}</span> <span class="badge">${this.selected.size}</span>`
          : `${LOGO} <span class="who">${esc(chiPill)}</span>`;

      // whose data is on screen must be answerable at a glance, always:
      // patient in the title, episode always next to the section name.
      const inHome = !this.runState && this.view === "home";
      const section = this.runState ? "" : { richieste: "Richieste", esiti: "Esiti", referto: "Referto", dimissioni: "Dimissioni", dimtesto: "Dimissioni", dimimport: "Dimissioni", consensi: "Consensi", eo: "EO", tempi: "Tempi" }[this.view] || "";
      // the discharge sheets are templates: no episode belongs in that header
      const inDim = this.view === "dimissioni" || this.view === "dimtesto" || this.view === "dimimport";
      // accanto al nome, l'episodio: di chi sono i dati, sempre a colpo d'occhio
      const sub = sulPaziente && !inHome && !inDim && ep ? `ep. ${esc(ep)}` : "";
      // Il titolo è il paziente, e solo lui: dove non c'è, niente titolo — lo
      // dice la scheda accesa, e sulla lista PS la scheda Pazienti fa anche da ‹.
      // Il ‹ resta sul paziente, e dentro un referto o un foglio di dimissione.
      const indietro = !!section && (sulPaziente || ["referto", "dimtesto", "dimimport"].includes(this.view));
      const titolo = this.runState || (sulPaziente && !inHome) ? who : "";
      // Aperto: una finestra al centro, l'85% dello schermo (o come l'hai
      // lasciata tu). Ridotto: la pill, dove l'hai messa (in alto a destra
      // se non l'hai mai spostata).
      const ridotto = this.collapsed;
      let posStyle;
      if (ridotto) {
        const pp = this.pillPos;
        posStyle = pp && Number.isFinite(pp.left) && Number.isFinite(pp.top)
          ? `left:${Math.max(0, Math.min(window.innerWidth - 80, pp.left))}px;top:${Math.max(0, Math.min(window.innerHeight - 48, pp.top))}px;right:auto;`
          : "";
      } else {
        const g = geometriaFinestra(this.win);
        posStyle = `left:${g.x * 100}vw;top:${g.y * 100}vh;width:${g.w * 100}vw;height:${g.h * 100}vh;right:auto;`;
      }
      // i valori e la stanza si leggono in larghezza; il resto su una colonna comoda

      this.root.innerHTML = `
        <style>${COLORS}</style>
        <div class="wrap${ridotto ? "" : " win"}" style="${posStyle}">
          ${this.collapsed && !running && this.striscia ? `
            <div class="strip">
              <button class="pill run ${esc(strTono)}" id="expand" title="${esc(strWho)} — ${esc(this.striscia.titolo || (this.striscia.onTap ? "tocca per i comandi" : "tocca per aprire il pannello"))}">
                ${this.striscia.tono === "run" ? `<span class="dot"></span>` : `<span class="tick">${this.striscia.tono === "err" || this.striscia.tono === "warn" ? "!" : "✓"}</span>`}
                <span class="col">
                  <span class="l1"><b class="who">${esc(strWho)}</b>${this.striscia.tag ? ` <span class="tag">${esc(this.striscia.tag)}</span>` : ""}${
                    this.striscia.badge ? ` <span class="badge">${esc(this.striscia.badge)}</span>` : ""}</span>
                  <span class="l2">${esc(this.striscia.testo || "")}</span>
                </span>
              </button>
              ${this.striscia.azione ? `<button class="strazione" id="strazione" title="${esc(this.striscia.azione.titolo || "")}">${esc(this.striscia.azione.label)}</button>` : ""}
              ${this.striscia.onStop ? `<button class="stopmini" id="strstop" title="Annulla (Esc)">✕</button>` : ""}
            </div>
          ` : this.collapsed && this.runState ? `
            <div class="strip">
              <button class="pill run ${altrove ? "alt" : this.runState === "fail" ? "err" : this.runState === "stopped" ? "warn" : ""}" id="expand" title="${esc(who)}${
                altrove ? " — stai guardando un'altra scheda" : ""} — tocca per aprire il pannello">
                ${running ? `<span class="dot"></span>` : `<span class="tick">${this.runState === "done" ? "✓" : "!"}</span>`}
                <span class="col">
                  <span class="l1"><b>${esc(who)}</b>${badgeEsami ? ` <span class="badge">${esc(badgeEsami)}</span>` : ""}</span>
                  <span class="l2">${esc(fase || (this.runState === "done" ? "fatto" : ""))}</span>
                </span>
              </button>
              ${running ? `<button class="stopmini" id="stopbtn" title="Interrompi (Esc)">⏹</button>` : ""}
            </div>
          ` : this.collapsed ? `
            <button class="pill" id="expand" title="${esc(who)}${ep ? " · episodio " + esc(ep) : ""} — ${esc(APP)}, trascina per spostare">${pillInner}${this.promUrgente()}</button>
          ` : `
            <div class="card${inStanza ? " stanza" : ""}" role="dialog" aria-label="${esc(APP)}" tabindex="-1">
              <div class="hd" id="draghd" title="Trascina per spostare · doppio clic per rimetterla al centro">
                ${indietro ? `<button class="iconbtn" id="back" title="${
                  this.view === "referto" ? "Torna agli esiti"
                  : this.view === "dimtesto" || this.view === "dimimport" ? "Torna ai fogli di dimissione"
                  : "Tutti i pazienti"}" aria-label="Indietro">${ICO.indietro}</button>` : `<span class="logo">${LOGO_BLU}</span>`}${titolo ? `<b class="who">${esc(titolo)}</b>` : ""}
                ${sub ? `<span class="sub" title="${esc(who)} — episodio ${esc(ep || "?")}">${sub}</span>` : ""}
                <span class="hsp"></span>
                ${this.chipTempo()}
                <span class="menuw">
                  <button class="iconbtn" id="menubtn" title="Altro" aria-label="Altro" aria-haspopup="true" aria-expanded="${this.menuAperto ? "true" : "false"}">${ICO.altro}</button>
                  ${this.menuAperto ? `<div class="menu" role="menu">
                    ${this.win ? `<button role="menuitem" id="wincentra" title="La finestra al centro, all'85% dello schermo">Al centro</button>` : ""}
                    ${eAffiancata(this.win) ? "" : `<button role="menuitem" id="winaffianca" title="Una colonna a destra: il gestionale resta visibile a sinistra">Affianca a destra</button>`}
                    ${inStanza && !this.stanzaEdit ? `<button role="menuitem" id="stmodmenu" title="Disegna la stanza: aggiungi, sposta e rinomina letti e aree">Modifica la stanza</button>` : ""}
                    <hr>
                    <button role="menuitem" id="verbtn" title="Il Registro delle operazioni">${this.showLog ? "Nascondi il registro" : "Registro"}</button>
                    ${(typeof chrome !== "undefined" && chrome.runtime?.id) ? `<button role="menuitem" id="extreload" title="Dopo aver sostituito i file nella cartella dell'estensione, questo la ricarica con la nuova versione">Ricarica estensione</button>` : ""}
                    <div class="mver">${esc(APP)} ${VERSION}</div>
                  </div>` : ""}
                </span>
                <button class="iconbtn" id="collapse" title="Riduci alla pill (Esc)" aria-label="Riduci">${ICO.riduci}</button>
              </div>
              ${running && this.runData?.steps?.length ? `<div class="pbar"><i style="width:${Math.round((this.runData.steps.filter((x) => x.status === "ok").length / this.runData.steps.length) * 100)}%"></i></div>` : ""}
              <div class="cap">
              ${!this.runState && this.pageType === "patient" && !inHome ? this.notaHtmlPaziente() : ""}
              ${!this.runState && inStanza && this.stanzaEdit ? `
                <div class="seg modifica" role="toolbar" aria-label="Modifica la stanza">
                  <b class="segtit">Modifica la stanza</b><span class="segdx">${this.stanzaAzioni()}</span>
                </div>` : !this.runState ? `
                <div class="seg" role="tablist">
                  ${this.pageType === "patient" && this.view !== "home" ? `
                  <button class="${this.view === "richieste" ? "on" : ""}" data-seg="richieste">Richieste</button>
                  <button class="${this.view === "esiti" || this.view === "referto" ? "on" : ""}" data-seg="esiti">Esiti${this.nEsiti() ? ` <span class="n">${this.nEsiti()}</span>` : ""}</button>`
                  : `<button class="${inHome || !section ? "on" : ""}" data-seg="home">Pazienti</button>`}
                  <button class="${this.view === "eo" ? "on" : ""}" data-seg="eo" title="Esame obiettivo da copiare">EO</button>
                  <button class="${this.view === "consensi" ? "on" : ""}" data-seg="consensi">Consensi</button>
                  <button class="${inDim ? "on" : ""}" data-seg="dimissioni">Dimissioni</button>
                  ${(inHome || !section) && this.stanzaAzioni ? `<span class="segdx">${this.stanzaAzioni()}</span>` : ""}
                </div>` : ""}
              ${!this.runState ? this.selbarHtml() : ""}
              </div>
              <div class="bd"><div class="bdi">${this.view === "richieste" ? "" : this.notaHtml()}${this.registroHtml()}${body}</div></div>
              ${this.inPazienti() ? "" : this.stanzaSnack()}
              ${["n", "s", "e", "w", "ne", "nw", "se", "sw"].map((d) => `<div class="rz rz-${d}" data-rz="${d}"></div>`).join("")}
              <div class="rsz" id="rsz" data-rz="se" title="Trascina per ridimensionare · doppio click per la misura di partenza"></div>

            </div>
          `}
        </div>`;
      this.bind();
      for (const [sel, top, left] of keepScroll) {
        const el = this.root.querySelector(sel);
        if (el) { el.scrollTop = top; el.scrollLeft = left; }
      }
      this._bordiStanza?.();   // i bordi sfumati della mappa, sullo scorrimento appena rimesso
      if (this._fuocoId && !this.root.activeElement) {
        const f = this.root.getElementById ? this.root.getElementById(this._fuocoId) : null;
        if (f && !/^(INPUT|TEXTAREA)$/.test(f.tagName)) f.focus({ preventScroll: true });
      }
    }

    // HOME — the patients this shift. Picking one of the OTHERS navigates to
    // their page first: the panel never shows data belonging to a patient
    // other than the page in front of you.
    // La stessa gente in due viste: la Lista (una riga per paziente) e la
    // Stanza (dove sta nella stanza). L'interruttore, e in Modifica i suoi
    // comandi, stanno nella fila delle schede: stanzaAzioni().
    viewHome(patientName) {
      const m = this.pazModello();
      return `<div class="sec">${this.pazVista() === "stanza" ? this.viewStanza(m) : this.viewLista(m, patientName)}</div>`;
    }

    // ================================================================ STANZA
    // La mappa della stanza del PS. Letti (un paziente ciascuno) e aree senza
    // letto (corridoio, attesa: quanti ne servono); a sinistra «Da sistemare»,
    // dove finisce chiunque non abbia un posto — un paziente non sparisce mai.
    // Di norma si spostano i PAZIENTI (trascinando, o «Sposta in…»); con
    // Modifica si disegna la STANZA, di solito una volta sola. Ogni spostamento
    // si annulla per 8 secondi. Tutto resta in questo browser: la stanza in
    // "stanza.v1" (celle intere della PIANTA, così a ogni misura è la stessa),
    // chi-sta-dove in "stanza.posti.v1" — solo episodi, mai nomi.
    pazVista() {
      const v = this._pazVista || store.get("pazVista", "lista");
      return v === "stanza" ? "stanza" : "lista";
    }
    // l'episodio della pagina aperta. La lista del PS non ne ha uno suo: i
    // suoi link portano quello del primo in elenco, che non è «qui».
    epDiQuesta() { return this.episodeId && this.defaultView() !== "home" ? this.episodeId : ""; }
    // Aprire un paziente dal pannello: il suo è già qui, un altro si carica
    // (e la sua pagina si apre sulla schermata scelta).
    apriPaziente(ep, go) {
      if (ep && ep === this.epDiQuesta()) return this.setView(go);
      const p = knownPatients().find((x) => x.ep === ep);
      if (!p || !p.url) return;
      tabStore.set("afterNav.v1", { ep, view: go, ts: Date.now() }); // open there, on their page
      nav(p.url);
    }
    // la schermata dei Pazienti: quella che non è nessun'altra
    inPazienti() {
      return !this.runState && !["esiti", "referto", "dimissioni", "dimtesto", "dimimport", "consensi", "eo", "tempi", "richieste"].includes(this.view);
    }
    // Le azioni dei Pazienti, in fondo alla fila delle schede: Lista | Stanza,
    // e basta. In Modifica, al suo posto, + Letto, + Area e Fine. Si entra in
    // Modifica da «Disegna la stanza» (stanza vuota) o dal menu «⋯».
    stanzaAzioni() {
      if (!this.inPazienti()) return "";
      const vista = this.pazVista();
      if (vista === "stanza" && this.stanzaEdit) {
        return `<span class="stazioni"><button type="button" class="stbtn" id="stpiuletto" title="Aggiungi un letto: un paziente">+ Letto</button><button type="button" class="stbtn" id="stpiuarea" title="Aggiungi un'area senza letti (corridoio, attesa, poltrone): più pazienti">+ Area</button><button type="button" class="stbtn pri" id="stfine" title="La stanza è pronta: si torna a spostare i pazienti (Esc)">Fine</button></span>`;
      }
      const seg = (v, testo, tip) => `<button type="button" class="${vista === v ? "on" : ""}" data-pazvista="${v}" aria-pressed="${vista === v}" title="${tip}">${testo}</button>`;
      return `<span class="stazioni"><span class="stseg" role="group" aria-label="Vista dei pazienti">${
        seg("lista", "Lista", "I pazienti in elenco")}${seg("stanza", "Stanza", "La mappa della stanza: dove sta ogni paziente")}</span></span>`;
    }
    // La stanza com'è salvata, ripulita: celle intere dentro la pianta, niente
    // sopra un altro, nomi corti, niente doppioni. Quello che non torna (anche
    // una stanza salvata in un altro formato) si lascia fuori; una memoria
    // rotta dà una stanza vuota, non un errore.
    stanzaSala() {
      const s = store.get("stanza.v1", null) || {};
      const { cols, rows, lw, lh, aw, ah } = PIANTA;
      const int = (v, min, max) => Number.isInteger(v) && v >= min && v <= max;
      const visti = new Set(), presi = [];
      const buono = (o) => typeof o.id === "string" && /^[\w-]{1,16}$/.test(o.id) && !visti.has(o.id) && visti.add(o.id);
      const posa = (q) => !presi.some((p) => troppoVicini(p, q)) && presi.push(q);
      const nome = (o, d) => String(o.nome ?? "").replace(/\s+/g, " ").trim().slice(0, 24) || d;
      const letti = [], aree = [];
      for (const l of Array.isArray(s.letti) ? s.letti : []) {
        if (letti.length >= 60 || !l || !int(l.c, 0, cols - lw) || !int(l.r, 0, rows - lh) || !buono(l) || !posa({ c: l.c, r: l.r, w: lw, h: lh })) continue;
        letti.push({ id: l.id, c: l.c, r: l.r, nome: nome(l, "Letto") });
      }
      for (const a of Array.isArray(s.aree) ? s.aree : []) {
        if (aree.length >= 30 || !a || !int(a.w, aw, cols) || !int(a.h, ah, rows) || !int(a.c, 0, cols - a.w) || !int(a.r, 0, rows - a.h)
          || !buono(a) || !posa({ c: a.c, r: a.r, w: a.w, h: a.h })) continue;
        aree.push({ id: a.id, c: a.c, r: a.r, w: a.w, h: a.h, nome: nome(a, "Area") });
      }
      return { letti, aree };
    }
    // gli oggetti della stanza come rettangoli di celle
    stanzaRettangoli(sala) {
      return [...sala.letti.map((l) => ({ id: l.id, c: l.c, r: l.r, w: PIANTA.lw, h: PIANTA.lh })),
        ...sala.aree.map((a) => ({ id: a.id, c: a.c, r: a.r, w: a.w, h: a.h }))];
    }
    stanzaScrivi(sala) {
      if (store.set("stanza.v1", sala)) return true;
      this.message = "La stanza NON è stata salvata: la memoria di questo browser è piena o bloccata.";
      this.render();
      return false;
    }
    // Lo stesso paziente (stesso codice fiscale) con due episodi aperti: il
    // più vecchio è l'«episodio precedente» — fuori dalla stanza, in grigio.
    stanzaPrecedenti(pazienti) {
      const perCf = new Map(), out = new Set();
      for (const p of pazienti) if (String(p.pk || "").startsWith("cf:")) perCf.set(p.pk, [...(perCf.get(p.pk) || []), p]);
      const num = (p) => (/^\d+$/.test(p.ep) ? Number(p.ep) : NaN);
      for (const l of perCf.values()) {
        if (l.length < 2) continue;
        l.sort((a, b) => (Number.isNaN(num(a)) || Number.isNaN(num(b)) ? (b.ts || 0) - (a.ts || 0) : num(b) - num(a)));
        for (const p of l.slice(1)) out.add(p.ep);
      }
      return out;
    }
    // Chi sta dove. Un paziente in elenco tiene il suo posto finché non lo
    // sposti, non lo togli dall'elenco o dall'elenco non sparisce: se non lo
    // apri da 12 ore diventa grigio, ma resta dov'è. Un letto tiene un
    // paziente: se i dati ne dicono due, resta il più recente. Il posto di chi
    // non è in elenco (sessione scaduta, archiviato) aspetta un giorno che
    // torni — ma mai su un letto già preso.
    stanzaStato(pazienti, sala, precedenti) {
      const raw = store.get("stanza.posti.v1", {});
      const tutti = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
      const ora = Date.now(), perEp = new Map(pazienti.map((p) => [p.ep, p]));
      const letti = new Set(sala.letti.map((l) => l.id)), aree = new Set(sala.aree.map((a) => a.id));
      const esiste = (v) => v && (v.tipo === "letto" ? letti.has(v.id) : v.tipo === "area" && aree.has(v.id));
      const voci = Object.entries(tutti).filter(([ep]) => /^[\w.-]{1,40}$/.test(ep)).sort((a, b) => (b[1]?.ts || 0) - (a[1]?.ts || 0));
      const posti = {}, perLetto = {}, tieni = {}, preso = {};
      for (const [ep, v] of voci) {   // prima chi è in elenco: sono loro a occupare i letti
        const p = perEp.get(ep);
        if (!p || !esiste(v) || precedenti.has(ep) || (v.tipo === "letto" && perLetto[v.id])) continue;
        if (v.tipo === "letto") perLetto[v.id] = preso[v.id] = ep;
        posti[ep] = tieni[ep] = { tipo: v.tipo, id: v.id, ts: +v.ts || 0 };
      }
      for (const [ep, v] of voci) {   // poi chi non c'è
        if (perEp.has(ep) || !esiste(v) || ora - (+v.ts || 0) > PATIENTS_TTL || (v.tipo === "letto" && preso[v.id])) continue;
        if (v.tipo === "letto") preso[v.id] = ep;
        tieni[ep] = { tipo: v.tipo, id: v.id, ts: +v.ts || 0 };
      }
      if (tutti !== raw || Object.keys(tieni).length !== Object.keys(tutti).length) store.set("stanza.posti.v1", tieni);
      return { posti, perLetto };
    }
    // I nomi. «ROSSI MARIO» → «ROSSI M.»; il cognome si porta dietro le
    // particelle (DE LUCA, DELLA ROSA). Due pazienti attivi con lo stesso
    // cognome: ⚠ e il nome intero. Con lo stesso nome intero: anche le ultime
    // quattro cifre dell'episodio, «· …9001».
    stanzaNomi(pazienti, precedenti) {
      const PART = new Set(["DE", "DI", "DA", "DEL", "DELLA", "DELLE", "DELLO", "DEI", "DEGLI", "DAL", "DALLA", "DALLE", "DALLO",
        "LA", "LO", "LE", "LI", "SAN", "SANTA", "SANTO", "VAN", "VON", "MC", "MAC", "DOS", "DAS", "DU"]);
      const parti = (nome) => {
        const w = String(nome || "").trim().split(/\s+/).filter(Boolean);
        let i = 0;
        while (i < w.length - 2 && PART.has(w[i].toUpperCase())) i++;
        return { cognome: w.slice(0, i + 1).join(" "), nome: w.slice(i + 1).join(" ") };
      };
      const conta = (chiave) => {
        const c = new Map();
        for (const p of pazienti) if (!precedenti.has(p.ep)) { const k = chiave(p); if (k) c.set(k, (c.get(k) || 0) + 1); }
        return c;
      };
      const perCognome = conta((p) => normNome(parti(p.name).cognome)), perNome = conta((p) => normNome(p.name));
      return new Map(pazienti.map((p) => {
        const { cognome, nome } = parti(p.name), vivo = !precedenti.has(p.ep);
        const omonimo = vivo && perCognome.get(normNome(cognome)) > 1;
        const coda = vivo && perNome.get(normNome(p.name)) > 1 ? ` · …${String(p.ep).slice(-4)}` : "";
        const breve = !cognome ? "paziente" : omonimo || !nome ? `${cognome} ${nome}`.trim() : `${cognome} ${nome[0].toUpperCase()}.`;
        return [p.ep, { breve, lungo: p.name || "paziente", coda, omonimo }];
      }));
    }
    // Tutto quello che Lista e Stanza mostrano dei pazienti, calcolato una volta
    pazModello() {
      const pazienti = knownPatients(), sala = this.stanzaSala();
      const precedenti = this.stanzaPrecedenti(pazienti);
      const { posti, perLetto } = this.stanzaStato(pazienti, sala, precedenti);
      const nomi = this.stanzaNomi(pazienti, precedenti);
      const qui = this.epDiQuesta(), ora = Date.now();
      const info = new Map(pazienti.map((p) => [p.ep, {
        p, ...nomi.get(p.ep), nota: notaDi(p, pazienti), qui: p.ep === qui, prec: precedenti.has(p.ep),
        spento: precedenti.has(p.ep) || ora - (p.ts || 0) > 12 * 3600e3, posto: posti[p.ep] || null,
      }]));
      return { pazienti, sala, posti, perLetto, info, qui, prom: promTutti() };
    }
    nomePosto(m, i) {
      const v = i && i.posto;
      return !v ? "" : (v.tipo === "letto" ? m.sala.letti : m.sala.aree).find((o) => o.id === v.id)?.nome || "";
    }
    oraDi(ts) { return (new Date().toDateString() === new Date(ts || 0).toDateString() ? "" : "ieri ") + hhmm(ts); }
    vistoFa(ts) {
      const min = Math.max(0, Math.round((Date.now() - (ts || 0)) / 60000));
      return min < 1 ? "visto adesso" : min < 60 ? `visto ${min} min fa` : `visto ${Math.floor(min / 60)} h fa`;
    }
    // Il passaggio del mouse dice tutto: chi è, quale episodio, quando l'hai
    // aperto, da quando sta dove sta, il triage, la nota.
    pazTitolo(m, i, mappa) {
      const { p } = i, posto = this.nomePosto(m, i);
      return [
        i.lungo + i.coda,
        `episodio ${p.ep} · aperto ${this.oraDi(p.ts)}`,
        posto && `in ${posto} dalle ${this.oraDi(i.posto.ts)}`,
        p.triage && `triage all'apertura: ${p.triage}`,
        i.nota && `Nota: ${i.nota}`,
        i.omonimo && "⚠ stesso cognome di un altro paziente in elenco",
        i.prec && "Episodio precedente: di questo paziente c'è un episodio più recente",
        mappa && (i.prec ? "Un tocco lo apre" : "Un tocco apre gli esiti · trascinalo, o tasto destro: Sposta in…"),
      ].filter(Boolean).join("\n");
    }
    // a destra del nome: «questa pagina», o da quanto non lo apri (in ambra dopo 3 ore)
    pazStato(i) {
      if (i.prec) return `<span class="sttag">episodio precedente</span>`;
      if (i.qui) return `<span class="stqui">questa pagina</span>`;
      return `<span class="stvisto${Date.now() - (i.p.ts || 0) > 3 * 3600e3 ? " amb" : ""}">${this.vistoFa(i.p.ts)}</span>`;
    }
    // LISTA — una riga per paziente: triage, nome, nota, da quanto non lo
    // apri, dove sta nella stanza, Richieste. La ✕ compare passandoci sopra.
    viewLista(m, patientName) {
      const canOrder = !!(this.entry && (this.entry.labUrl || this.entry.radioUrl));
      const conSala = m.sala.letti.length + m.sala.aree.length > 0;
      const lista = [...m.info.values()].sort((a, b) => b.qui - a.qui);   // chi è su questa pagina, per primo
      // Il nome è quello con cui il paziente è stato conosciuto. Il titolo
      // della pagina si usa solo se non ne abbiamo uno: sulla lista PS quel
      // titolo è «PRONTO SOCCORSO - LISTA», e stamparlo dove va il nome del
      // paziente è esattamente ciò che questo programma promette di non fare.
      if (m.qui && canOrder && !m.info.has(m.qui)) {
        lista.unshift({ p: { ep: m.qui, name: patientName, ts: Date.now() }, breve: patientName, lungo: patientName || "paziente",
                        coda: "", omonimo: false, nota: "", qui: true, prec: false, spento: false, posto: null });
      }
      // la riga intera apre il paziente: il bottone del nome la copre tutta, e
      // gli altri comandi stanno sopra — niente bottoni dentro bottoni. Accanto
      // al nome il promemoria più vicino; la sveglia compare passandoci sopra.
      const riga = (i) => {
        const { p } = i, posto = this.nomePosto(m, i), tr = p.triage ? " t-" + p.triage.toLowerCase() : "";
        return `
        <div class="pzrow${i.qui ? " qui" : ""}${i.prec ? " prec" : ""}">
          <i class="pztr${tr}" aria-hidden="true"></i>
          <div class="pzchi">
            <button type="button" class="pzapri" data-go="esiti" data-ep="${esc(p.ep)}" title="${esc(this.pazTitolo(m, i) + "\nUn tocco apre gli esiti")}">
              <span class="pznm">${i.omonimo ? `<b class="stom" aria-label="attenzione, stesso cognome di un altro paziente">⚠</b>` : ""}${esc(i.lungo)}${i.coda ? `<span class="stcoda">${esc(i.coda)}</span>` : ""}</span>${p.triage ? `<span class="stsr">, triage ${esc(p.triage)}</span>` : ""}
            </button>
            <span class="prslot" data-promslot="${esc(p.ep)}">${this.promPill(p.ep, m.prom)}</span>
            <span class="pznota">${esc(i.nota)}</span>
            ${this._promIn?.ep === p.ep && this._promIn.dove === "lista" ? this.promCampo() : ""}
          </div>
          ${this.pazStato(i)}
          ${conSala && !i.prec && m.info.has(p.ep) ? `<button type="button" class="pzposto" data-posto="${esc(p.ep)}" aria-haspopup="menu" title="${posto ? `In ${esc(posto)}: cambia posto` : "Non ha un posto nella stanza: scegline uno"}"><span class="pzpn">${esc(posto || "—")}</span><span aria-hidden="true">&nbsp;▾</span></button>` : ""}
          <button type="button" class="pzric" data-go="richieste" data-ep="${esc(p.ep)}" title="Richieste per ${esc(i.lungo)}">Richieste</button>
          ${i.prec ? "" : `<button type="button" class="pzprom" data-promnuovo="${esc(p.ep)}" data-dove="lista" title="Promemoria: un'ora per fare una cosa (es. 11:30 tropo)" aria-label="Promemoria per ${esc(i.lungo)}">${ICO.sveglia}</button>`}
          ${m.info.has(p.ep) ? `<button type="button" class="pzx" data-parch="${esc(p.ep)}" title="Togli dall'elenco: va negli archiviati (si può annullare). Nel gestionale non cambia niente." aria-label="Togli ${esc(i.lungo)} dall'elenco">✕</button>` : ""}
        </div>`;
      };
      const rigaArch = (p) => `
        <div class="pzarow">
          <span class="pzanm" title="${esc(p.name || "")}">${esc(p.name || "paziente")}</span>
          <span class="pzameta">archiviato ${esc(agoLabel(p.archTs || p.ts))}</span>
          <button type="button" class="pzabtn" data-unarch="${esc(p.ep)}" title="Riportalo fra i pazienti attivi">↩ riporta</button>
          <button type="button" class="pzabtn del" data-del="${esc(p.ep)}" title="Elimina tutto quello che il programma sa di lui">🗑</button>
        </div>`;
      const archiviati = pazientiArchiviati();
      // in fondo, chiusi: gli archiviati e «Svuota l'elenco» (che si annulla)
      const archivio = lista.length || archiviati.length ? `
        <button type="button" class="pzarchhd" id="archtog" aria-expanded="${this.mostraArch ? "true" : "false"}">Archiviati${archiviati.length ? ` <span class="stn">${archiviati.length}</span>` : ""}<span aria-hidden="true">${this.mostraArch ? "▾" : "▸"}</span></button>
        ${this.mostraArch ? `<div class="pzarch">${archiviati.map(rigaArch).join("")}
          <div class="pzhint">${archiviati.length ? "🗑 cancella tutto di quel paziente: scheda clinica, referti tenuti, nota e promemoria. Non si torna indietro." : "Nessun paziente archiviato."}</div>
          <button type="button" class="pzsvuota" id="stsvuota" title="Toglie tutti i pazienti dall'elenco e dalla stanza. Per 8 secondi si può annullare.">Svuota l'elenco</button>
        </div>` : ""}` : "";
      return `
        <div class="pzlista">${lista.map(riga).join("") || `<div class="pzvuoto">Nessun paziente ancora. Apri un paziente: resta qui per il turno.</div>`}</div>
        ${archivio}${this.stanzaSnack()}`;
    }
    // Il paziente nella Stanza: striscia del triage, nome (⚠ se un altro ha
    // lo stesso cognome), e sotto «questa pagina» (o «episodio precedente») e
    // la nota. Da quanto non lo apri lo dice la Lista; qui, dopo 12 ore, il
    // grigio. Nel letto la striscia la porta il letto, il nome sta su una riga
    // e l'episodio che lo distingue scende accanto allo stato: non si taglia mai.
    stanzaChip(m, i, inLetto) {
      const { p } = i, edit = !!this.stanzaEdit;
      const cls = ["stp", i.qui && "qui", i.prec && "prec", i.spento && "spento", !inLetto && p.triage && "tri t-" + p.triage.toLowerCase()].filter(Boolean).join(" ");
      const nota = i.nota ? `<span class="stnota">${esc(i.nota)}</span>` : "";
      const stato = i.prec ? `<span class="sttag">episodio precedente</span>` : i.qui ? `<span class="stqui">questa pagina</span>` : "";
      const sotto = `${i.coda && inLetto ? `<span class="stcoda">${esc(i.coda.replace(/^ · /, ""))}</span>` : ""}${stato}${inLetto ? "" : nota}`;
      return `<div class="${cls}" data-stp="${esc(p.ep)}" role="button" tabindex="${edit ? -1 : 0}"${i.prec ? "" : ' aria-haspopup="menu"'} title="${esc(this.pazTitolo(m, i, true))}" aria-label="${esc(i.lungo + i.coda)}${p.triage ? `, triage ${esc(p.triage)}` : ""}${i.qui ? ", questa pagina" : i.prec ? ", episodio precedente" : ""}">
        <span class="stp1">${i.omonimo ? `<b class="stom" aria-hidden="true">⚠</b>` : ""}<b class="stpn">${esc(i.breve)}${i.coda && !inLetto ? `<span class="stcoda">${esc(i.coda)}</span>` : ""}</b>${inLetto ? "" : this.promMini(p.ep, m.prom)}</span>${
        sotto ? `<span class="stp2">${sotto}</span>` : ""}${inLetto ? nota : ""}</div>`;
    }
    // il letto vuoto: un letto a tratto, appena accennato
    stanzaGlifo(w, cls) {
      const t = 'vector-effect="non-scaling-stroke"';
      return `<svg${cls ? ` class="${cls}"` : ""} width="${w}" height="${Math.round(w * 2 / 3)}" viewBox="0 0 30 20" fill="none" stroke="#C4D0DC" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path ${t} d="M2 3v15M2 14h26v4M2 10h24a2 2 0 0 1 2 2v2"/><rect ${t} x="5" y="6" width="7" height="4" rx="1.5"/></svg>`;
    }
    // il nome di un letto o di un'area; in Modifica un tocco lo rende scrivibile
    stanzaNome(tipo, o) {
      const r = this._stanzaRinomina;
      if (this.stanzaEdit && r && r.tipo === tipo && r.id === o.id) {
        return `<input type="text" class="stnomein" maxlength="24" value="${esc(r.testo)}" spellcheck="false" autocomplete="off" aria-label="Nome ${tipo === "letto" ? "del letto" : "dell'area"}">`;
      }
      return this.stanzaEdit
        ? `<span class="stname" data-stnome="${tipo}" role="button" tabindex="0" title="Tocca per rinominare, trascina per spostare">${esc(o.nome)}</span>`
        : `<span class="stname">${esc(o.nome)}</span>`;
    }
    // In Modifica, sull'oggetto scelto o sotto il mouse: × lo elimina;
    // l'angolo in basso a destra allarga l'area.
    stanzaCtl(tipo, o) {
      const del = `<button type="button" class="stctl stx" data-stdel="${tipo}:${esc(o.id)}" title="Elimina ${tipo === "letto" ? "il letto" : "l'area"} «${esc(o.nome)}»: chi c'era torna in «Da sistemare». Si può annullare." aria-label="Elimina ${esc(o.nome)}">×</button>`;
      return tipo === "letto" ? del : `${del}<span class="strsz" data-strsz="1" title="Trascina per ridimensionare l'area"></span>`;
    }
    viewStanza(m) {
      const { sala, pazienti, info, perLetto, posti } = m;
      const edit = !!this.stanzaEdit;
      const chip = (p) => this.stanzaChip(m, info.get(p.ep));
      // In Modifica la pianta intera, coi puntini: sotto il mouse niente cambia
      // misura. Fuori, solo il pezzo disegnato con una cella di margine: anche
      // una stanza piccola riempie la mappa.
      const rett = this.stanzaRettangoli(sala);
      let c0 = 0, r0 = 0, cols = PIANTA.cols, rows = PIANTA.rows;
      if (!edit && rett.length) {
        c0 = Math.min(...rett.map((q) => q.c)) - 1;
        r0 = Math.min(...rett.map((q) => q.r)) - 1;
        cols = Math.max(...rett.map((q) => q.c + q.w)) + 1 - c0;
        rows = Math.max(...rett.map((q) => q.r + q.h)) + 1 - r0;
      }
      const celle = (c, r, w, h) => `--c:${c - c0};--r:${r - r0};--w:${w};--h:${h}`;
      const letto = (l) => {
        const i = perLetto[l.id] ? info.get(perLetto[l.id]) : null;
        const cls = ["stbed", i && "occ", i?.qui && "qui", i?.p.triage && "tri t-" + i.p.triage.toLowerCase(),
          edit && this._stanzaSel === "letto:" + l.id && "sel"].filter(Boolean).join(" ");
        return `<div class="${cls}" data-letto="${esc(l.id)}" data-drop="letto:${esc(l.id)}"${i ? ` data-occ="${esc(i.breve + i.coda)}" data-occep="${esc(i.p.ep)}"` : ""} role="group"
          aria-label="${esc(l.nome)}: ${i ? esc(i.lungo + i.coda) : "vuoto"}"${edit ? "" : ` title="${esc(l.nome)}${i ? "" : " — trascina qui un paziente"}"`}
          style="${celle(l.c, l.r, PIANTA.lw, PIANTA.lh)}">
          <div class="stbedin">${i ? `<div class="stbedhd">${this.stanzaNome("letto", l)}${this.promMini(i.p.ep, m.prom)}</div>${this.stanzaChip(m, i, true)}`
            : this.stanzaNome("letto", l) + this.stanzaGlifo(28, "stglifo")}</div>
          ${edit ? this.stanzaCtl("letto", l) : ""}
        </div>`;
      };
      const area = (a) => {
        const dentro = pazienti.filter((p) => posti[p.ep]?.tipo === "area" && posti[p.ep].id === a.id)
          .sort((x, y) => posti[x.ep].ts - posti[y.ep].ts);   // in ordine di arrivo: chi c'è non si sposta
        return `<div class="starea${edit && this._stanzaSel === "area:" + a.id ? " sel" : ""}" data-area="${esc(a.id)}" data-drop="area:${esc(a.id)}" role="group" aria-label="${esc(a.nome)}: ${dentro.length} ${dentro.length === 1 ? "paziente" : "pazienti"}"${edit ? "" : ` title="${esc(a.nome)} — trascina qui i pazienti"`}
          style="${celle(a.c, a.r, a.w, a.h)}">
          <div class="sthd">${this.stanzaNome("area", a)}${dentro.length ? `<span class="stn">${dentro.length}</span>` : ""}</div>
          <div class="starbody">${dentro.map(chip).join("")}</div>
          ${edit ? this.stanzaCtl("area", a) : ""}
        </div>`;
      };
      // da sistemare: prima chi è su questa pagina, poi i vivi, in fondo i grigi
      const liberi = pazienti.filter((p) => !posti[p.ep])
        .sort((a, b) => info.get(b.ep).qui - info.get(a.ep).qui || info.get(a.ep).spento - info.get(b.ep).spento);
      const vuota = !rett.length;
      return `
        <div class="stmap${edit ? " edit" : ""}" role="region" aria-label="Mappa della stanza">
          <div class="stcorpo">
            <div class="sttray" data-drop="tray" role="group" aria-label="Da sistemare: ${liberi.length}" title="Da sistemare: chi non ha ancora un posto nella stanza">
              <div class="sttrayhd">Da sistemare${liberi.length ? `<span class="stn">${liberi.length}</span>` : ""}</div>
              <div class="strow">${liberi.map(chip).join("") || `<span class="stnone">${pazienti.length ? "Tutti al loro posto" : "Nessun paziente ancora: chi apri arriva qui"}</span>`}</div>
            </div>
            <div class="stcanvas">
              ${vuota && !edit ? "" : `<div class="stplan" style="--cols:${cols};--rows:${rows}">${sala.letti.map(letto).join("")}${sala.aree.map(area).join("")}</div>`}
              ${!vuota ? "" : edit ? `
              <div class="stvuota"><b>Comincia con + Letto, in alto a destra</b></div>` : `
              <div class="stvuota">
                ${this.stanzaGlifo(60)}
                <b>Disegna la tua stanza una volta</b>
                <button type="button" class="stbtn" id="stdisegna" title="Entra in Modifica: + Letto e + Area, e li porti dove stanno davvero">Disegna la stanza</button>
              </div>`}
            </div>
          </div>
          ${this.stanzaSnack()}
        </div>`;
    }
    // «Annulla» per 8 secondi dopo ogni cosa che si può rimpiangere
    stanzaSnack() {
      const a = this._stanzaAnn;
      if (!a || Date.now() > a.fino) return "";
      return `<div class="stsnack" role="status"><span>${esc(a.testo)}</span><button type="button" class="stannulla" title="Rimetti com'era">Annulla</button></div>`;
    }
    bindStanza() {
      const $ = (s) => this.root.querySelector(s);
      this._bordiStanza = null;   // vale solo per la mappa disegnata adesso
      this.root.querySelectorAll("[data-pazvista]").forEach((b) => b.addEventListener("click", () => {
        this._pazVista = b.getAttribute("data-pazvista");
        store.set("pazVista", this._pazVista);
        this.stanzaEdit = false; this._stanzaRinomina = null; this._stanzaSel = null;
        this.render();
      }));
      // In Modifica si entra da «Disegna la stanza» o dal menu «⋯», e si esce
      // con Fine (o Esc); il fuoco resta dove si continua.
      const modifica = (si) => () => {
        if (!si) this.stanzaSalvaBozza();
        this.stanzaEdit = si; this._stanzaRinomina = null; this._stanzaSel = null; this.menuAperto = false;
        this._stanzaFocus = si ? "#stpiuletto" : '[data-pazvista="stanza"]';
        this.render();
      };
      $("#stdisegna")?.addEventListener("click", modifica(true));
      $("#stmodmenu")?.addEventListener("click", modifica(true));
      $("#stfine")?.addEventListener("click", modifica(false));
      $("#stpiuletto")?.addEventListener("click", () => this.stanzaAggiungi("letto"));
      $("#stpiuarea")?.addEventListener("click", () => this.stanzaAggiungi("area"));
      $(".stannulla")?.addEventListener("click", () => this.stanzaAnnulla());
      // Lista: il posto si cambia dal suo menu; la ✕ archivia (e si annulla)
      this.root.querySelectorAll("[data-posto]").forEach((b) => b.addEventListener("click", (e) => { e.stopPropagation(); this.stanzaMenu(b.getAttribute("data-posto"), b); }));
      this.root.querySelectorAll("[data-parch]").forEach((b) => b.addEventListener("click", (e) => { e.stopPropagation(); this.stanzaArchivia(b.getAttribute("data-parch")); }));
      $("#stsvuota")?.addEventListener("click", () => this.stanzaSvuota());
      const map = $(".stmap");
      if (map) {
        map.addEventListener("pointerdown", (e) => this.stanzaPresa(e, map));
        map.addEventListener("click", (e) => {
          const del = e.target.closest("[data-stdel]");
          if (del) { const [tipo, id] = del.getAttribute("data-stdel").split(":"); this.stanzaElimina(tipo, id); }
        });
        // da tastiera: Invio apre il paziente (o rinomina, in Modifica); Maiusc+F10 o il tasto menu: Sposta in…
        map.addEventListener("keydown", (e) => {
          const chip = e.target.closest?.(".stp[data-stp]"), nome = e.target.closest?.("[data-stnome]");
          if (chip && !this.stanzaEdit && (e.key === "ContextMenu" || (e.shiftKey && e.key === "F10"))) {
            e.preventDefault();
            if (!chip.classList.contains("prec")) this.stanzaMenu(chip.getAttribute("data-stp"), chip);
          } else if (e.key === "Enter" || e.key === " ") {
            if (chip && !this.stanzaEdit) { e.preventDefault(); this.apriPaziente(chip.getAttribute("data-stp"), "esiti"); }
            else if (nome) { e.preventDefault(); this.stanzaRinomina(nome); }
          }
        });
        map.addEventListener("contextmenu", (e) => {
          if (this.stanzaEdit) return;
          const chip = e.target.closest(".stp[data-stp]") || e.target.closest(".stbed.occ")?.querySelector(".stp[data-stp]");
          if (!chip) return;
          e.preventDefault();
          if (!chip.classList.contains("prec")) this.stanzaMenu(chip.getAttribute("data-stp"), chip);
        });
        // stretta, «Da sistemare» è una riga, e la mappa può non starci in
        // larghezza: dove si scorre solo di lato, la rotella scorre di lato
        // (finché c'è strada), e il bordo sfuma dalla parte dove c'è altro
        const diLato = (el) => el?.addEventListener("wheel", (e) => {
          if (el.scrollWidth <= el.clientWidth || el.scrollHeight > el.clientHeight || Math.abs(e.deltaY) <= Math.abs(e.deltaX)) return;
          if (e.deltaY > 0 ? el.scrollLeft + el.clientWidth >= el.scrollWidth - 1 : el.scrollLeft <= 0) return;
          el.scrollLeft += e.deltaY;
          e.preventDefault();
        }, { passive: false });
        diLato(map.querySelector(".strow"));
        const tela = map.querySelector(".stcanvas");
        diLato(tela);
        const bordi = () => {
          tela.classList.toggle("sx", tela.scrollLeft > 1);
          tela.classList.toggle("dx", tela.scrollLeft + tela.clientWidth < tela.scrollWidth - 1);
        };
        // anche subito dopo che render() ha rimesso lo scorrimento di prima
        if (tela) { bordi(); tela.addEventListener("scroll", bordi, { passive: true }); this._bordiStanza = bordi; }
        const inp = map.querySelector(".stnomein");
        if (inp) {
          inp.focus();
          if (this._stanzaRinomina?.seleziona) { inp.select(); this._stanzaRinomina.seleziona = false; }
          else inp.setSelectionRange(inp.value.length, inp.value.length);
          inp.addEventListener("input", () => { if (this._stanzaRinomina) this._stanzaRinomina.testo = inp.value; });
          inp.addEventListener("keydown", (e) => {
            if (e.key === "Enter") { e.preventDefault(); this.stanzaChiudiNome(inp, true, true); }
            else if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); this.stanzaChiudiNome(inp, false, true); }
          });
          inp.addEventListener("blur", () => { if (inp.isConnected) this.stanzaChiudiNome(inp, true); });
        }
      }
      if (this._stanzaFocus) { const f = $(this._stanzaFocus); this._stanzaFocus = null; f?.focus(); }
    }
    // Esc appartiene a chi lo sta usando: il menu «Sposta in…» o un trascinamento
    // (il gestore di Esc della finestra lo chiede prima di ridurre il pannello)
    escLocale() { return !!(this._stanzaPresa || this._stanzaMenu?.menu?.isConnected || this._promMenu?.menu?.isConnected); }
    // Un solo gesto alla volta. Tocco o trascinamento? Sotto i 5px col mouse
    // (10 col dito) è un tocco, per quanto duri; oltre la soglia, un
    // trascinamento. Tenere premuto col dito (mezzo secondo): «Sposta in…».
    // Esc o un annullo del browser lasciano tutto com'era.
    stanzaGesto(e, { inizia, muovi, lascia, tocco, lungo, annulla }) {
      const id = e.pointerId, sx = e.clientX, sy = e.clientY;
      const soglia = e.pointerType === "mouse" ? 5 : 10;
      let mosso = false, partito = false;
      const via = () => {
        clearTimeout(tl);
        window.removeEventListener("pointermove", mm, true);
        window.removeEventListener("pointerup", su, true);
        window.removeEventListener("pointercancel", nulla, true);
        window.removeEventListener("keydown", kd, true);
        this._stanzaPresa = false;
      };
      const nulla = () => { via(); if (partito) annulla?.(); };
      const mm = (ev) => {
        if (ev.pointerId !== id) return;
        if (ev.pointerType === "mouse" && !ev.buttons) return nulla();   // bottone mollato fuori dalla finestra
        const dx = ev.clientX - sx, dy = ev.clientY - sy;
        if (!mosso) {
          if (Math.hypot(dx, dy) < soglia) return;
          mosso = true;
          clearTimeout(tl);
          if (inizia) { partito = true; inizia(); }
        }
        if (partito) muovi(dx, dy, ev);
      };
      const su = (ev) => {
        if (ev.pointerId !== id) return;
        via();
        if (partito) lascia(ev);
        else if (!mosso) tocco?.();
      };
      const kd = (ev) => { if (ev.key === "Escape") { ev.stopPropagation(); nulla(); } };
      const tl = lungo && e.pointerType !== "mouse" ? setTimeout(() => { if (!partito) { via(); lungo(); } }, 500) : 0;
      this._stanzaPresa = true;
      window.addEventListener("pointermove", mm, true);
      window.addEventListener("pointerup", su, true);
      window.addEventListener("pointercancel", nulla, true);
      window.addEventListener("keydown", kd, true);
    }
    stanzaPresa(e, map) {
      if (e.button !== 0 || this._stanzaPresa || e.target.closest("button, input, .stsnack")) return;
      if (!this.stanzaEdit) {
        // un letto occupato si prende tutto: è il suo paziente che si porta
        const chip = e.target.closest(".stp[data-stp]") || e.target.closest(".stbed.occ")?.querySelector(".stp[data-stp]");
        if (!chip) return;
        const ep = chip.getAttribute("data-stp");
        // l'episodio precedente non va nella stanza: un tocco lo apre, e basta
        if (chip.classList.contains("prec")) return this.stanzaGesto(e, { tocco: () => this.apriPaziente(ep, "esiti") });
        return this.stanzaTrascinaPaziente(e, map, chip);
      }
      const obj = e.target.closest("[data-letto], [data-area]");
      this.stanzaSeleziona(obj, map);
      if (obj) this.stanzaTrascinaOggetto(e, map, obj, !!e.target.closest("[data-strsz]"), e.target.closest("[data-stnome]"));
    }
    // in Modifica, l'oggetto toccato per ultimo mostra i suoi comandi
    stanzaSeleziona(obj, map) {
      const k = !obj ? null : obj.hasAttribute("data-letto") ? "letto:" + obj.getAttribute("data-letto") : "area:" + obj.getAttribute("data-area");
      if (k === this._stanzaSel) return;
      this._stanzaSel = k;
      map.querySelectorAll(".sel").forEach((x) => x.classList.remove("sel"));
      obj?.classList.add("sel");
    }
    // il bersaglio sotto il puntatore: un letto, un'area o «Da sistemare»
    stanzaBersaglio(x, y) {
      for (const el of this.root.elementsFromPoint(x, y)) {
        const d = el.closest?.(".stmap [data-drop]");
        if (d) return d;
      }
      return null;
    }
    // Il paziente si porta col suo nome accanto al puntatore (in basso a
    // destra, o dall'altra parte se lì non c'è posto): non copre mai il nome
    // del letto che si mira. Il posto si scrive solo quando lo si lascia.
    // Sopra un letto occupato si legge chi va in «Da sistemare».
    stanzaTrascinaPaziente(e, map, chip) {
      const ep = chip.getAttribute("data-stp");
      let copia = null, sopra = null;
      const segna = (el) => {
        if (el === sopra) return;
        if (sopra) { sopra.classList.remove("over"); sopra.querySelector(".stfuori")?.remove(); }
        sopra = el;
        if (!el) return;
        el.classList.add("over");
        const altro = el.getAttribute("data-occep");
        if (!altro || altro === ep) return;
        el.insertAdjacentHTML("beforeend", `<span class="stfuori">${esc(el.getAttribute("data-occ") || "")} → Da sistemare</span>`);
        // tutta dentro la mappa: se sporge da un lato, si sposta verso l'altro
        const lab = el.lastElementChild, cv = map.querySelector(".stcanvas").getBoundingClientRect(), lr = lab.getBoundingClientRect();
        const dx = Math.max(0, cv.left + 4 - lr.left) - Math.max(0, lr.right - cv.right + 4);
        if (dx) lab.style.marginLeft = dx + "px";
      };
      const pulisci = () => { segna(null); copia?.remove(); chip.classList.remove("via"); map.classList.remove("trascino"); };
      // la copia resta dentro la mappa: fuori non si lascia niente
      const metti = (ev) => {
        const mr = map.getBoundingClientRect(), w = copia.offsetWidth, h = copia.offsetHeight;
        let x = ev.clientX - mr.left + 12, y = ev.clientY - mr.top + 12;
        if (x + w > mr.width) x = ev.clientX - mr.left - 12 - w;
        if (y + h > mr.height) y = ev.clientY - mr.top - 12 - h;
        copia.style.transform = `translate(${Math.max(0, x)}px,${Math.max(0, y)}px)`;
      };
      this.stanzaGesto(e, {
        inizia: () => {
          const i = this.pazModello().info.get(ep);
          copia = document.createElement("div");
          copia.className = "stghost";
          copia.setAttribute("aria-hidden", "true");
          copia.textContent = i ? i.breve + i.coda : chip.querySelector(".stpn")?.textContent || "";
          map.appendChild(copia);
          chip.classList.add("via");
          map.classList.add("trascino");
        },
        muovi: (dx, dy, ev) => {
          metti(ev);
          segna(this.stanzaBersaglio(ev.clientX, ev.clientY));
        },
        lascia: (ev) => {
          const t = this.stanzaBersaglio(ev.clientX, ev.clientY);
          pulisci();
          if (t) this.stanzaSposta(ep, t.getAttribute("data-drop"));
        },
        tocco: () => this.apriPaziente(ep, "esiti"),
        lungo: () => this.stanzaMenu(ep, chip),
        annulla: pulisci,
      });
    }
    // Portare un paziente: sullo stesso posto non succede niente; su un letto
    // occupato il nuovo prende il letto e chi c'era va in «Da sistemare» —
    // niente scambi, che spostano qualcuno dove non l'hai deciso tu. Si annulla.
    stanzaSposta(ep, dove) {
      const [tipo, id] = String(dove || "").split(":");
      const m = this.pazModello(), i = m.info.get(ep);
      if (!i || i.prec || !["tray", "area", "letto"].includes(tipo)) return;
      const da = i.posto;
      if (tipo === "tray" ? !da : da && da.tipo === tipo && da.id === id) return;   // è già lì
      const raw = store.get("stanza.posti.v1", {});
      const posti = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
      const foto = this.stanzaFoto(), nm = (x) => x.breve + x.coda;
      const nomeDi = (t, k) => (t === "letto" ? m.sala.letti : m.sala.aree).find((o) => o.id === k)?.nome || "";
      let testo = `${nm(i)} in ${tipo === "tray" ? "Da sistemare" : nomeDi(tipo, id)}`;
      if (tipo === "tray") delete posti[ep];
      else posti[ep] = { tipo, id, ts: Date.now() };
      if (tipo === "letto") {
        // chiunque altro reclami quel letto (anche chi ora non è in elenco) lo lascia
        for (const [k, v] of Object.entries(posti)) if (k !== ep && v?.tipo === "letto" && v.id === id) delete posti[k];
        const altro = m.perLetto[id];
        if (altro && altro !== ep) testo += ` · ${nm(m.info.get(altro))} da sistemare`;
      }
      if (!store.set("stanza.posti.v1", posti)) { this.message = "Il posto NON è stato salvato: la memoria di questo browser è piena o bloccata."; return this.render(); }
      this.stanzaAnnullabile(testo, foto);
      this.render();
    }
    // la fotografia di prima, per «Annulla» (con l'elenco, anche i promemoria)
    stanzaFoto(conPazienti) {
      return { sala: store.get("stanza.v1", null), posti: store.get("stanza.posti.v1", null), pazienti: conPazienti ? store.get("patients.v1", null) : undefined,
               prom: conPazienti ? store.get(PROM, null) : undefined };
    }
    stanzaAnnullabile(testo, foto) {
      clearTimeout(this._stanzaAnnT);
      this._stanzaAnn = { testo, foto, fino: Date.now() + 8000 };
      this._stanzaAnnT = setTimeout(() => { this._stanzaAnn = null; this.root.querySelector(".stsnack")?.remove(); }, 8000);
    }
    stanzaAnnulla() {
      const a = this._stanzaAnn;
      if (!a) return;
      clearTimeout(this._stanzaAnnT);
      this._stanzaAnn = null;
      if (typeof a.foto === "function") a.foto();   // un passo solo da disfare: il promemoria fatto torna
      else {
        store.set("stanza.v1", a.foto.sala);
        store.set("stanza.posti.v1", a.foto.posti);
        if (a.foto.pazienti !== undefined) store.set("patients.v1", a.foto.pazienti);
        if (a.foto.prom !== undefined) store.set(PROM, a.foto.prom);
      }
      this.render();
    }
    // «Sposta in…»: i letti vuoti, poi quelli occupati (chi c'è va in «Da
    // sistemare»), le aree, «Da sistemare»; in fondo, a parte, «Togli
    // dall'elenco» (come la ✕ della Lista). Col tasto destro, tenendo premuto
    // col dito, con Maiusc+F10 o dal «posto» della Lista. Frecce, Invio, Esc.
    stanzaMenu(ep, anchor) {
      const aperto = this._stanzaMenu;
      if (aperto && aperto.ep === ep && aperto.menu.isConnected) return;
      this.stanzaChiudiMenu();
      const m = this.pazModello(), i = m.info.get(ep), wrap = this.root.querySelector(".wrap");
      if (!i || i.prec || !wrap || !anchor?.isConnected || !(m.sala.letti.length + m.sala.aree.length)) return;   // senza stanza non c'è dove
      const qui = i.posto, attuale = (tipo, id) => !!qui && qui.tipo === tipo && qui.id === id;
      const voce = (dove, testo, det, cur) => `<button type="button" role="menuitem" class="stmi${cur ? " cur" : ""}" data-dove="${esc(dove)}"${cur ? ' aria-disabled="true"' : ""}><span>${esc(testo)}</span><small>${esc(cur ? "qui ora" : det)}</small></button>`;
      const inArea = (a) => Object.values(m.posti).filter((v) => v.tipo === "area" && v.id === a.id).length;
      const gruppi = [
        m.sala.letti.filter((l) => !m.perLetto[l.id]).map((l) => voce("letto:" + l.id, l.nome, "vuoto")),
        m.sala.letti.filter((l) => m.perLetto[l.id]).map((l) => {
          const o = m.info.get(m.perLetto[l.id]);
          return voce("letto:" + l.id, l.nome, "al posto di " + o.breve + o.coda, attuale("letto", l.id));
        }),
        m.sala.aree.map((a) => voce("area:" + a.id, a.nome, inArea(a) ? `${inArea(a)} ${inArea(a) === 1 ? "paziente" : "pazienti"}` : "", attuale("area", a.id))),
        [voce("tray", "Da sistemare", "", !qui)],
        [voce("togli", "Togli dall'elenco", "")],
      ].filter((g) => g.length);
      const titolo = `Sposta ${i.breve + i.coda} in…`;
      wrap.insertAdjacentHTML("beforeend", `<div class="stmenu" role="menu" aria-label="${esc(titolo)}"><div class="stmenuhd" aria-hidden="true">${esc(titolo)}</div>${
        gruppi.map((g) => g.join("")).join('<div class="stmsep" role="separator"></div>')}</div>`);
      const menu = wrap.lastElementChild;
      // sotto chi l'ha aperto; se non c'è posto sotto, sopra; sempre dentro lo schermo
      const wr = wrap.getBoundingClientRect(), ar = anchor.getBoundingClientRect();
      let y = ar.bottom + 4;
      if (y + menu.offsetHeight > innerHeight - 8) y = Math.max(8, ar.top - 4 - menu.offsetHeight);
      menu.style.left = Math.max(8, Math.min(ar.left, innerWidth - menu.offsetWidth - 8)) - wr.left + "px";
      menu.style.top = y - wr.top + "px";
      const voci = () => [...menu.querySelectorAll(".stmi:not([aria-disabled])")];
      menu.addEventListener("click", (e) => {
        const b = e.target.closest(".stmi");
        if (!b || b.hasAttribute("aria-disabled")) return;
        this.stanzaChiudiMenu();
        const dove = b.getAttribute("data-dove");
        if (dove === "togli") return this.stanzaArchivia(ep);
        this._stanzaFocus = anchor.matches("[data-posto]") ? `[data-posto="${CSS.escape(ep)}"]` : `.stmap .stp[data-stp="${CSS.escape(ep)}"]`;
        this.stanzaSposta(ep, dove);
      });
      menu.addEventListener("keydown", (e) => {
        const l = voci(), k = l.indexOf(this.root.activeElement);
        if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); l[(k + (e.key === "ArrowDown" ? 1 : l.length - 1)) % l.length]?.focus(); }
        else if (e.key === "Home" || e.key === "End") { e.preventDefault(); l[e.key === "Home" ? 0 : l.length - 1]?.focus(); }
        else if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); this.stanzaChiudiMenu(true); }
        else if (e.key === "Tab") this.stanzaChiudiMenu();
      });
      const fuori = (e) => { if (!e.composedPath().includes(menu)) this.stanzaChiudiMenu(); };
      window.addEventListener("pointerdown", fuori, true);
      this._stanzaMenu = { menu, anchor, ep, fuori };
      voci()[0]?.focus();
    }
    stanzaChiudiMenu(ritorna) {
      const a = this._stanzaMenu;
      if (!a) return;
      this._stanzaMenu = null;
      window.removeEventListener("pointerdown", a.fuori, true);
      a.menu.remove();
      if (ritorna && a.anchor?.isConnected) a.anchor.focus();
    }
    // togliere dall'elenco e svuotarlo: niente conferme, si annulla
    stanzaArchivia(ep) {
      const p = knownPatients().find((x) => x.ep === ep), foto = this.stanzaFoto(true);
      if (!archiviaPaziente(ep, true)) return;
      this.stanzaAnnullabile(`${p?.name || "Paziente"}: tolto dall'elenco`, foto);
      this.render();
    }
    stanzaSvuota() {
      const foto = this.stanzaFoto(true);
      forgetPatients();
      store.set("stanza.posti.v1", {});   // anche i posti e i promemoria: l'elenco riparte da zero
      store.set(PROM, {});
      this._promIn = null;
      this.mostraArch = false;
      this.stanzaAnnullabile("Elenco svuotato", foto);
      this.render();
    }
    // In Modifica: si spostano letti e aree (o si allarga un'area dall'angolo)
    // di cella in cella, sempre dentro la pianta. Dove finirebbe sopra un
    // altro si fa rosso e, lasciato lì, torna com'era. Un tocco fermo sul nome
    // lo rende scrivibile.
    stanzaTrascinaOggetto(e, map, obj, allarga, nome) {
      const plan = map.querySelector(".stplan");
      const tipo = obj.hasAttribute("data-letto") ? "letto" : "area";
      const id = obj.getAttribute("data-" + tipo);
      const sala = this.stanzaSala(), o = (tipo === "letto" ? sala.letti : sala.aree).find((x) => x.id === id);
      if (!plan || !o) return;
      const { cols, rows, lw, lh, aw, ah } = PIANTA;
      const u = plan.getBoundingClientRect().width / cols;   // in Modifica la pianta è intera
      const altri = this.stanzaRettangoli(sala).filter((x) => x.id !== id);
      const lim = (v, a, b) => Math.max(a, Math.min(b, v));
      const w0 = tipo === "letto" ? lw : o.w, h0 = tipo === "letto" ? lh : o.h;
      let q = { c: o.c, r: o.r, w: w0, h: h0 }, ok = true;
      this.stanzaGesto(e, {
        inizia: () => { obj.classList.add("drag"); map.classList.add("trascino"); },
        muovi: (dx, dy) => {
          const dc = Math.round(dx / u), dr = Math.round(dy / u);
          q = allarga
            ? { c: o.c, r: o.r, w: lim(w0 + dc, aw, cols - o.c), h: lim(h0 + dr, ah, rows - o.r) }
            : { c: lim(o.c + dc, 0, cols - w0), r: lim(o.r + dr, 0, rows - h0), w: w0, h: h0 };
          ok = !altri.some((x) => troppoVicini(x, q));
          for (const k of ["c", "r", "w", "h"]) obj.style.setProperty("--" + k, q[k]);
          obj.classList.toggle("bad", !ok);
        },
        lascia: () => {
          if (!ok || (q.c === o.c && q.r === o.r && q.w === w0 && q.h === h0)) return this.render();
          // si riparte da quella salvata adesso: un nome appena scritto (salvato uscendo dal campo) resta
          const ora = this.stanzaSala(), x = (tipo === "letto" ? ora.letti : ora.aree).find((y) => y.id === id);
          if (!x) return this.render();
          x.c = q.c; x.r = q.r;
          if (tipo === "area") { x.w = q.w; x.h = q.h; }
          if (this.stanzaScrivi(ora)) this.render();
        },
        tocco: () => { if (nome) this.stanzaRinomina(nome); },
        annulla: () => this.render(),
      });
    }
    stanzaRinomina(nomeEl) {
      const obj = nomeEl.closest("[data-letto], [data-area]");
      if (!obj) return;
      const tipo = nomeEl.getAttribute("data-stnome"), id = obj.getAttribute("data-" + tipo);
      const o = (tipo === "letto" ? this.stanzaSala().letti : this.stanzaSala().aree).find((q) => q.id === id);
      if (!o) return;
      this._stanzaRinomina = { tipo, id, testo: o.nome, seleziona: true };
      this._stanzaSel = tipo + ":" + id;
      this.render();
    }
    // Invio o uscire dal campo salvano, Esc lascia il nome di prima.
    stanzaChiudiNome(inp, salva, tasto) {
      const r = this._stanzaRinomina;
      if (!r) return;
      this._stanzaRinomina = null;
      const sala = this.stanzaSala();
      const o = (r.tipo === "letto" ? sala.letti : sala.aree).find((q) => q.id === r.id);
      if (!o) return this.render();
      const nuovo = inp.value.replace(/\s+/g, " ").trim().slice(0, 24);
      if (salva && nuovo && nuovo !== o.nome) {
        o.nome = nuovo;
        if (!this.stanzaScrivi(sala)) return;
      }
      if (tasto) {   // da tastiera: si ridisegna e si resta sul nome
        this.render();
        return [...this.root.querySelectorAll("[data-stnome]")].find((s) => s.closest(`[data-${r.tipo}]`)?.getAttribute(`data-${r.tipo}`) === r.id)?.focus();
      }
      // uscendo col mouse NON si ridisegna: il clic che ha tolto il fuoco deve arrivare
      const t = document.createElement("template");
      t.innerHTML = this.stanzaNome(r.tipo, o);
      if (inp.isConnected) inp.replaceWith(t.content.firstChild);
    }
    // il nome che si stava scrivendo, quando si esce da Modifica senza Invio
    stanzaSalvaBozza() {
      const r = this._stanzaRinomina;
      if (!r) return;
      this._stanzaRinomina = null;
      const nuovo = String(r.testo || "").replace(/\s+/g, " ").trim().slice(0, 24);
      const sala = this.stanzaSala(), o = (r.tipo === "letto" ? sala.letti : sala.aree).find((q) => q.id === r.id);
      if (o && nuovo && nuovo !== o.nome) { o.nome = nuovo; store.set("stanza.v1", sala); }
    }
    // Il primo posto libero per il nuovo arrivato: riga per riga dall'angolo in
    // alto a sinistra, meglio se con una cella d'aria intorno.
    stanzaPostoLibero(sala, w, h) {
      const presi = this.stanzaRettangoli(sala);
      for (const g of [1, 0]) {
        for (let r = 0; r + h <= PIANTA.rows; r++) {
          for (let c = 0; c + w <= PIANTA.cols; c++) if (!presi.some((q) => troppoVicini(q, { c, r, w, h }, g))) return { c, r };
        }
      }
      return null;
    }
    stanzaAggiungi(tipo) {
      const sala = this.stanzaSala();
      const lista = tipo === "letto" ? sala.letti : sala.aree;
      if (lista.length >= (tipo === "letto" ? 60 : 30)) { this.message = tipo === "letto" ? "Al massimo 60 letti." : "Al massimo 30 aree."; return this.render(); }
      // un'area nasce 8 × 5; se non ci sta, piccola quanto può
      const misure = tipo === "letto" ? [[PIANTA.lw, PIANTA.lh]] : [[8, 5], [PIANTA.aw, PIANTA.ah]];
      let p = null, w = 0, h = 0;
      for (const [mw, mh] of misure) if ((p = this.stanzaPostoLibero(sala, mw, mh))) { w = mw; h = mh; break; }
      const piena = "La stanza è piena: togli o sposta qualcosa.";
      if (!p) { this.message = piena; return this.render(); }
      if (this.message === piena) this.message = null;
      let id;
      do id = Math.random().toString(36).slice(2, 8); while (!id || sala.letti.some((o) => o.id === id) || sala.aree.some((o) => o.id === id));
      // il nome segue quello dell'ultimo: dopo «Box 1» viene «Box 2», dopo «B3» «B4»
      const ultimo = /^(.*?)(\d+)$/.exec(lista[lista.length - 1]?.nome || "");
      const base = ultimo ? ultimo[1] : tipo === "letto" ? "Letto " : "Area ";
      const usati = new Set(lista.map((o) => o.nome.toLowerCase()));
      let n = ultimo ? +ultimo[2] + 1 : 1;
      while (usati.has(`${base}${n}`.toLowerCase())) n++;
      const nome = `${base}${n}`.slice(0, 24);
      if (tipo === "letto") sala.letti.push({ id, c: p.c, r: p.r, nome });
      else sala.aree.push({ id, c: p.c, r: p.r, w, h, nome });
      if (!this.stanzaScrivi(sala)) return;
      this._stanzaRinomina = { tipo, id, testo: nome, seleziona: true };   // appena messo, si battezza
      this._stanzaSel = tipo + ":" + id;
      this.render();
    }
    stanzaElimina(tipo, id) {
      const sala = this.stanzaSala();
      const o = (tipo === "letto" ? sala.letti : sala.aree).find((x) => x.id === id);
      if (!o) return;
      const foto = this.stanzaFoto();
      if (tipo === "letto") sala.letti = sala.letti.filter((x) => x.id !== id);
      else sala.aree = sala.aree.filter((x) => x.id !== id);
      if (this._stanzaRinomina?.id === id) this._stanzaRinomina = null;
      if (!this.stanzaScrivi(sala)) return;
      // chi ci stava torna fra i da sistemare (lo farebbe comunque la pulizia: qui si vede subito)
      const posti = store.get("stanza.posti.v1", {}) || {};
      for (const [ep, v] of Object.entries(posti)) if (v?.tipo === tipo && v.id === id) delete posti[ep];
      store.set("stanza.posti.v1", posti);
      this.stanzaAnnullabile(tipo === "letto" ? `Eliminato il letto ${o.nome}` : `Eliminata l'area ${o.nome}`, foto);
      this.render();
    }

    // Il Registro si apre col numero di versione in fondo, che ora c'è su ogni
    // schermata: dopo un banner rosso è lì che si va a vedere cos'è successo,
    // e due ‹ di distanza erano due di troppo.
    registroHtml() {
      if (!this.showLog) return "";
      return `<details class="reg" open><summary>Registro <button class="mini" id="copylog" title="Copia il registro negli appunti (il quesito viene omesso)">⧉ Copia</button></summary><div class="log" aria-live="polite">${esc(this.logLines.join("\n"))}</div></details>`;
    }

    viewIdle(patientName, ep) {
      const cat = fullCatalog();
      // On the ER worklist (no patient open) nothing can be ordered: show no
      // exams at all rather than a picker that would dead-end.
      const canOrder = this.pageType === "exam" || this.pageType === "crea" ||
        (this.pageType === "patient" && !!(this.entry && (this.entry.labUrl || this.entry.radioUrl)));
      if (!canOrder) {
        const extra = this.viewPrint();
        return `${extra}<div class="hint" style="margin:2px 0 0">Apri un paziente per creare richieste.</div>`;
      }
      // i tre pacchetti sempre in testa, poi gli ultimi quesiti usati
      const quesiti = [...PACCHETTI.map((p) => p.q), ...store.get("quesiti", QUESITI_DEFAULT).filter((q) => !this.pacchettoDi(q))].slice(0, 6);
      const canOneClick = this.pageType === "patient" || this.pageType === "crea";

      // Receipt banner: the moment of decision on the landing page must show
      // the full verified accounting, not just what this list happens to show.
      let receiptSec = "";
      let receipt = null;
      let live = null;
      if (this.pageType === "exam") {
        live = examModel(document, location.href);
        receipt = freshReceipt(live.richiestaId);
        if (receipt) {
          const n = receipt.items.length;
          const byRes = {};
          for (const i of receipt.items) (byRes[i.res] = byRes[i.res] || []).push(i);
          receiptSec = `
            <div class="banner ok"><b>✓ ${n} ${n === 1 ? "esame" : "esami"} in carrello, ${n === 1 ? "verificato" : "verificati"}</b></div>
            ${live.confirmButton ? `<button class="btn confirm" id="confirmnow" style="margin-bottom:12px">✓ CONFERMA → stampa</button>` : ""}`;
        }
      }

      const quesitoSec = canOneClick ? `
        <div class="sec">
          <div class="lbl">Quesito diagnostico</div>
          <div class="qrow">
            <input id="q" type="text" placeholder="Es. dolore toracico in atto…" value="${esc(this._q || "")}">
            <div class="qchips">${quesiti.map((q) => {
              const pk = this.pacchettoDi(q);
              if (!pk) return `<button class="chip q" data-q="${esc(q)}">${esc(q)}</button>`;
              const on = this.pacchetto === pk.q;
              return `<button class="chip q pk ${on ? "on" : ""}" data-q="${esc(q)}" aria-pressed="${on}" title="${on ? "Tocca di nuovo per togliere quesito e pacchetto" : "Scrive il quesito e spunta: "}${esc(on ? "" : pk.items.map(([r, c]) => displayLabel(r, c)).join(", "))}">${esc(q)}</button>`;
            }).join("")}</div>
          </div>
        </div>` : "";

      // On the exam page show what is already in the cart on THIS resource,
      // plus (from the receipt) what was verified on other resources.
      let cartSec = "";
      if (this.pageType === "exam" && live) {
        const inCart = live.exams.filter((e) => e.isDel);
        const here = new Set(inCart.map((e) => e.code));
        const elsewhere = receipt ? receipt.items.filter((i) => i.res !== live.res && !here.has(i.code)) : [];
        cartSec = `
          <div class="sec">
            <div class="lbl">Già nel carrello — ${esc(live.res ? risorsaCorta(live.res) : "?")} (${inCart.length})</div>
            <div class="chips">
              ${inCart.map((e) => `<span class="chip cart">${esc(shortLabel(e.label))}</span>`).join("") || `<span class="hint">Ancora nessun esame su questa risorsa.</span>`}
              ${elsewhere.map((i) => `<span class="chip ghosted" title="verificato su ${esc(risorsaCorta(i.res))}">${esc(i.display || shortLabel(i.label))} · ${esc(risorsaCorta(i.res))} ✓</span>`).join("")}
            </div>
          </div>`;
      }

      // Un gruppo per laboratorio, col suo nome corto: dentro, prima i
      // profili rapidi di quel laboratorio, poi gli esami uno per uno. Nel
      // gruppo RX c'è il quesito della radiologia, che non è quello del lab.
      const gruppi = {};
      const gruppo = (r) => (gruppi[RES_SHORT[r] || r] = gruppi[RES_SHORT[r] || r] || { profili: [], esami: [] });
      PRESETS.forEach((p, i) => {
        if (!p.items.every(([r, c]) => cat[r]?.items?.[c])) return;
        const on = p.items.every(([r, c]) => this.isSel(r, c));
        gruppo(p.items[0][0]).profili.push(`<button class="chip preset ${on ? "on" : ""}" data-preset="${i}">${esc(p.name)}</button>`);
      });
      for (const [r, c] of SINGLES) {
        if (!cat[r]?.items?.[c]) continue;
        const on = this.isSel(r, c);
        gruppo(r).esami.push(`<button class="opt ${on ? "on" : ""}" data-res="${esc(r)}" data-code="${esc(c)}" title="${esc(examLabel(r, c))} — ${esc(RES_SHORT[r] || r)}"><span class="box">✓</span><span class="nm">${esc(displayLabel(r, c))}</span></button>`);
      }
      const qrxHtml = canOneClick
        ? `<input id="qrx" class="qrx" type="text" placeholder="Quesito RX — se vuoto, quello sopra" value="${esc(this._qrx || "")}">` : "";
      const singles = Object.entries(gruppi).map(([nome, g]) => `
        <div class="grouphdr">${esc(nome)}</div>
        ${nome === RES_SHORT[RES.RX] ? qrxHtml : ""}
        ${g.profili.length ? `<div class="gchips">${g.profili.join("")}</div>` : ""}
        ${g.esami.join("")}`).join("");

      const n = this.selected.size;
      const nTxt = n === 0 ? "esami" : n === 1 ? "1 esame" : `${n} esami`;
      const twoLegs = this.pageType === "patient" &&
        [...this.selected.values()].some((i) => RADIO_SET.includes(i.res)) &&
        [...this.selected.values()].some((i) => !RADIO_SET.includes(i.res));
      const goLabel = this.pageType === "exam" ? `Aggiungi ${nTxt}`
        : twoLegs ? `Crea 2 richieste · ${nTxt}` : `Crea e aggiungi ${nTxt}`;
      const confirmLabel = `Conferma e stampa`;

      const problems = this.computeProblems();

      const pendingSec = this.pending ? `
        <button class="btn confirm" id="goqueued" style="margin-bottom:12px">→ Conferma ${esc(this.pending.next.kind === "radio" ? "la radiologia" : "il laboratorio")} (${this.pending.next.count})</button>` : "";
      return `
        ${pendingSec}
        ${receiptSec}
        ${quesitoSec}
        ${cartSec}
        <div class="sec">
          <div class="lbl">Esami</div>
          <div class="grid">${singles}</div>
          ${this.viewBrowse(cat)}
        </div>
        ${this.viewPrint()}

        <div class="commit">
          ${this.notaHtml()}
          <div class="idline">Richiesta per <b>${esc(patientName)}</b>${ep ? ` · episodio <b>${esc(ep)}</b>` : ""}</div>
          <div id="problems">${problems.go[0] ? `<div class="problem">${esc(problems.go[0])}</div>` : ""}</div>
          <div class="btnrow">
            <button class="btn primary" id="go" ${n && !problems.go.length ? "" : "disabled"}>${esc(goLabel)}</button>
            <button class="btn confirm" id="goconfirm" title="Come il bottone a sinistra, e in più preme Conferma SUBITO — non si annulla — e avvia la stampa guidata" ${n && !problems.confirm.length ? "" : "disabled"}>${esc(confirmLabel)}</button>
          </div>

        </div>
      `;
    }

    // Patient page: reprint any richiesta's PDFs (labels → label printer,
    // exam list → normal printer) through the sequential wizard.
    viewPrint() {
      if (this.pageType !== "patient") return "";
      const map = printModel(document, location.href);
      const rids = Object.keys(map).sort((a, b) => (printMeta(map, b).ts - printMeta(map, a).ts) || Number(b) - Number(a));
      if (!rids.length) return "";
      const receipt = freshReceipt(null);
      const hot = receipt && map[receipt.richiestaId] ? receipt.richiestaId : null;
      const rows = rids.slice(0, 6).map((rid) => {
        const m = printMeta(map, rid);
        const exams = m.exams.join(", ");
        return `<button class="prow ${rid === hot ? "hot" : ""}" data-print="${esc(rid)}" title="Richiesta ${esc(rid)} — ${esc(printLabelFor(map, rid))}">
          <span class="pline1">🖨 <b>${esc(m.when || "richiesta " + rid)}</b> <small>${esc(printLabelFor(map, rid))}</small></span>
          ${exams ? `<span class="pline2">${esc(exams)}</span>` : ""}
        </button>`;
      }).join("");
      return `
        <div class="sec">
          <div class="lbl">Stampa</div>
          <div class="rlist">${rows}</div>

        </div>`;
    }

    // I referti che gli Esiti mostrano: quelli di laboratorio no — dicono quello
    // che la tabella dei Valori dice già, e in mezzo agli altri facevano
    // perdere l'ECG e la radiologia. Salvare, resettare e contare guardano
    // solo questi.
    refertiMostrati() {
      return this.esiti.filter((e) => e.kind === "referto" && refertoTipo(e) !== "lab");
    }
    // …ma solo dove la tabella dei Valori li può mostrare: c'è una tabella, o
    // c'è da dove leggerla (estensione e portale). Altrimenti — bookmarklet,
    // niente portale — un referto di laboratorio è l'unico posto dove quei
    // valori si vedono: resta, raccolto sotto «Laboratorio (N)». Un esito
    // finale non sparisce mai.
    refertiLab() {
      const tabella = !!(this.storico && this.storico.righe && this.storico.righe.length)
        || this.esiti.some((e) => e.kind === "valori" && ((tabStore.get(this.risKey(e.id), null) || {}).rows || []).length);
      if (tabella || this.conPortale()) return [];
      return this.esiti.filter((e) => e.kind === "referto" && refertoTipo(e) === "lab");
    }
    // Quanti esiti ci sono da guardare: prelievi e referti mostrati.
    nEsiti() {
      return this.esiti.filter((e) => e.kind === "valori").length + this.refertiMostrati().length + this.refertiLab().length;
    }

    // Values are fetched once per accesso and kept for the tab, so reopening
    // is instant; ↻ pulls them again while the lab is still completing.
    // ESITI — one chronological list: values we can read, and reported PDFs.
    // Row = open it (values expand / PDF opens). The 2-line preview under a
    // saved row is its own target: it opens the full values screen.
    // La tabella degli Esiti: i prelievi letti in QUESTA scheda del browser
    // (sempre, anche senza estensione) più la scheda clinica in archivio
    // quando è di questo paziente — il portale, e i prelievi letti altrove.
    // Una tabella sola: per gruppo, una colonna a prelievo, il più recente a
    // sinistra. Non c'è più una riga per richiesta da aprire.
    datiEsiti() {
      let dati = normalizzaStorico(this.storico || null);
      for (const e of this.esiti) {
        if (e.kind !== "valori") continue;
        const v = tabStore.get(this.risKey(e.id), null);
        const t = v && v.rows ? prelievoComeTabella(risMeta(e), v.rows, v.cf || "", v.scartate) : null;
        // la scheda in archivio ha già questi prelievi: la fusione non cambia
        // niente. Se l'archivio manca (o non ha risposto) restano in tabella.
        if (t) dati = fondiStorico(t, dati);
      }
      return dati && dati.righe && dati.righe.length ? dati : null;
    }

    // «↺ Reset»: si dimentica tutto quello che si era letto di questo
    // paziente — i prelievi in questa scheda del browser e la scheda clinica
    // in archivio — e si ricomincia da «⭳ Carica i valori». I segni del
    // medico restano: sono suoi, e ritrovano le stesse celle.
    resetValori() {
      const ep = this.episodeId || "x";
      for (const k of [...tabStore.keys(`ris.${ep}.`), ...tabStore.keys(`visto.${ep}.`)]) tabStore.del(k);
      this.rottiTab.clear();
      if (hasExt()) ask({ t: "delStorico", chiave: this.chiavePaz(), ep: this.episodeId, nome: this.nomePaziente() || "" }).catch(() => {});
      this.storico = null; this.storicoAltri = ""; this.storicoDaConfermare = false;
      this.esiti = esitiModel(document, location.href);   // le righe «già letti» se ne vanno coi loro valori
      this.log(`${now()}  valori azzerati: si rileggono da zero`);
      this.message = { ok: "Valori dimenticati: ⭳ Carica i valori li rilegge da zero." };
      this.render();
    }

    viewEsiti() {
      const open = new Set(tabStore.get(this.refKey(), []));
      const cached = this.refCache || {};
      const busy = this.refBusy || {};
      const prelievi = this.esiti.filter((e) => e.kind === "valori");
      const referti = this.refertiMostrati();
      const lab = this.refertiLab();
      const st = this.datiEsiti();
      this.nColEsiti = st ? st.date.length : 0;
      // con l'estensione e il link dello storico, il portale è una fonte anche
      // quando nel gestionale non c'è niente da leggere (tutto già refertato)
      const conPortale = this.conPortale();
      // la tabella del portale è arrivata: allora non c'è più niente «da leggere»
      const dalPortale = !!(this.storico && (this.storico.periodo || this.storico.paziente?.idMPI));
      if (!prelievi.length && !referti.length && !lab.length && !st && !conPortale) return `<div class="hint">Nessun esito per questo paziente.</div>`;

      // ---- valori: cosa è cambiato dall'ultima lettura, colonna per colonna
      // si parte dalle COLONNE della tabella: ognuna porta l'accesso da cui
      // viene, così due prelievi allo stesso minuto non si rubano i marchi
      const nov = new Map();
      let nNov = 0;
      for (const d of st ? st.date : []) {
        if (!d.id) continue;
        const v = tabStore.get(this.risKey(d.id), null);
        const n = v && v.rows ? this.novita(d.id, v.rows) : null;
        if (n && n.size) { nov.set(chiaveCol(d), n); nNov += n.size; }
      }
      const vivi = prelievi.filter((e) => !e.storico).length;
      const daLeggere = this.daLeggere().length;
      const rotti = prelievi.filter((e) => this.rottiTab.has(e.id));
      // letti, ma senza una data e ora nel gestionale: non possono diventare
      // una colonna, e non devono sparire in silenzio
      const senzaData = prelievi.filter((e) => {
        const v = tabStore.get(this.risKey(e.id), null);
        if (!v || !v.rows || !v.rows.length) return false;
        const t = prelievoComeTabella(risMeta(e), v.rows, "");
        return !!t && t.date[0].ignota;
      });
      const ra = this._refreshAll;
      const t = st ? this.tabellaStorico(st, nov, leggiSegni(this.chiaveNota())) : null;
      const chi = st ? [st.paziente?.cognome, st.paziente?.nome].filter(Boolean).join(" ") : "";
      const sotto = this._sotto;
      const valori = prelievi.length || st || conPortale ? `
        <div class="sec">
          <div class="lbl">Valori${t ? ` (${righeTabella(st.righe).length} esami · ${t.nCol} prelievi)` : ""}
            ${vivi || conPortale ? `<button class="mini" id="risall" ${ra || sotto ? "disabled" : ""} title="Legge i valori dal gestionale, un prelievo alla volta${conPortale ? ", e lo storico del portale in una scheda di sottofondo" : ""}">${
              ra ? `↻ ${ra.done}/${ra.total}…` : sotto ? "↻ storico…" : (conPortale ? !dalPortale : daLeggere === vivi) ? "⭳ Carica i valori" : "↻ Aggiorna"}</button>` : ""}
            ${t ? `<button class="mini" id="storfiltro">${this.soloAlterati ? "tutti" : "solo alterati"}</button>` : ""}
            ${t || prelievi.some((e) => tabStore.get(this.risKey(e.id), null)) ? `<button class="mini" id="valreset" title="Dimentica i valori letti e la scheda in archivio di questo paziente: ⭳ Carica i valori li rilegge da zero">↺ Reset</button>` : ""}
          </div>
          ${nNov ? `<div class="newbar"><span>${nNov} ${nNov === 1 ? "valore nuovo" : "valori nuovi"} dall'ultima lettura</span><button id="letto" type="button">Letto</button></div>` : ""}
          ${sotto ? `<div class="hint">Leggo lo storico del portale in una scheda di sottofondo: si chiude da sola.</div>` : ""}
          ${daLeggere && !ra && !conPortale ? `<div class="hint">${daLeggere} ${daLeggere === 1 ? "prelievo ancora da leggere" : "prelievi ancora da leggere"}: <b>⭳ Carica i valori</b>.</div>` : ""}
          ${conPortale && !dalPortale && !sotto && !ra && !this.notaPortale ? `<div class="hint"><b>⭳ Carica i valori</b> legge lo storico del portale — tutti i prelievi, refertati e no — in una scheda di sottofondo.</div>` : ""}
          ${this.notaPortale && !sotto ? `<div class="hint">Storico del portale non letto: ${esc(this.notaPortale)}. ${
            vivi ? "I prelievi arrivano dalle finestre Risultati." : ""} Si può aprire dal link «Storico Dati Clinici»: si legge da solo.</div>` : ""}
          ${rotti.length ? `<div class="hint">${rotti.length === 1 ? "Un prelievo non si è lasciato leggere" : `${rotti.length} prelievi non si sono lasciati leggere`} (${
            esc(rotti.map((e) => e.when).filter(Boolean).join(", "))}): il Registro dice perché, <b>↻ Aggiorna</b> riprova.</div>` : ""}
          ${senzaData.length ? `<div class="hint">Di ${senzaData.length === 1 ? "un prelievo" : `${senzaData.length} prelievi`} la pagina non dà data e ora, né nel campo nascosto né nella riga: ${
            senzaData.length === 1 ? "è la colonna" : "sono le colonne"} <b>?</b>, in fondo a destra (${
            esc(senzaData.map((e) => shortLabel(e.label)).join(", "))}). I valori ci sono tutti; il Registro dice cosa c'era scritto al posto dell'ora.</div>` : ""}
          ${t ? `${this.avvisoNomi(righeTabella(st.righe), st.scartate)}${t.nRighe ? t.html
            : `<div class="hint">Tutti i valori sono in range: con «solo alterati» non resta niente da mostrare.</div>`}${this.piedeStorico(st, t.legenda)}` : ""}
          ${this.storico && (this.storico.periodo || this.storico.paziente?.idMPI) ? `<div class="hint">Con lo storico del portale, letto per <b>${esc(chi || "—")}</b> · identità confermata <b>${esc(this.storicoVia || "dal nome")}</b>.</div>`
            : this.storicoAltri ? `<div class="hint">In memoria c'è lo storico di <b>${esc(this.storicoAltri)}</b>, non di questo paziente: non lo mostro.</div>`
            : this.storicoDaConfermare ? `<div class="hint">C'è uno storico letto per un paziente con questo nome. Per essere sicuri
              che sia il suo serve il codice fiscale, che sta nella finestra Risultati: <b>⭳ Carica i valori</b> e comparirà.</div>` : ""}
          ${this.htmlPortale()}
        </div>` : "";

      // ---- referti: i documenti, uno per riga, come sempre
      const nSaved = referti.filter((e) => cached[e.id]).length;
      const riga = (e) => {
        const state = cached[e.id] ? "saved" : busy[e.id] === true ? "busy" : typeof busy[e.id] === "string" ? "err" : open.has(e.id) ? "open" : "";
        const why = typeof busy[e.id] === "string" ? busy[e.id] : "";
        const tipo = refertoTipo(e);
        return `<button class="rrow ${esc(state)}" data-esito="${esc(e.id)}" data-kind="referto" title="${esc(e.label)}${why ? " — " + esc(why) : ""}">
            <span class="rdot ${esc(state)}"></span>
            <span class="rwhen">${esc(e.when)}</span>
            <span class="rsys">${esc(e.sistema)}</span>
            <span class="rlab">${esc(shortLabel(e.label))}</span>
            <span class="rgo">${(tipo === "rx" || tipo === "ecg") && busy[e.id] === undefined ? "›" : "Apri referto ↗"}</span>
          </button>`;
      };
      const docs = referti.length ? `
        <div class="sec">
          <div class="lbl">Referti (${referti.length})
            ${hasExt() && nSaved < referti.length ? `<button class="mini" id="refsave"${this._salvaRef ? " disabled" : ""}>${this._salvaRef ? "salvo…" : "Salva referti"}</button>` : ""}
            ${(nSaved || referti.some((e) => open.has(e.id))) ? `<button class="mini" id="refreset">↻ Resetta</button>` : ""}
            ${this.diagnosi ? `<button class="mini" id="refdiag" title="Copia com'è fatto il visualizzatore che non si è lasciato leggere (senza numeri), da mandare a chi fa il pannello">⧉ Copia diagnosi</button>` : ""}
          </div>
          <div class="rlist">${referti.map(riga).join("")}</div>
        </div>` : "";
      // i referti di laboratorio che la tabella non può mostrare: chiusi, ma ci sono
      const docsLab = lab.length ? `
        <details class="sec reflab" id="reflab"${this.labAperto ? " open" : ""}>
          <summary class="lbl" title="Referti del laboratorio: senza la tabella dei Valori, i risultati finali sono qui">Laboratorio (${lab.length})</summary>
          <div class="rlist">${lab.map(riga).join("")}</div>
        </details>` : "";
      return valori + docs + docsLab;
    }

    // L'indirizzo del portale clinico. Stava scritto dentro il programma: se
    // l'ospedale lo cambia, o se è diverso da un presidio all'altro, il
    // pannello non compare di là e da qui non si può capire perché. Ora lo
    // aggiunge il medico, una volta: Chrome chiede il permesso per quel sito
    // e lo script si registra lì.
    htmlPortale() {
      if (!hasExt() || DEMO) return "";   // nel banco non c'è un portale da autorizzare
      // Il permesso lo chiede la pagina delle impostazioni: da qui non si può,
      // perché Chrome vuole un gesto e il gesto non arriva fin là.
      return `<div class="hint">Il pannello non compare sulla pagina dello storico?
        <button class="linkbtn" id="portapri">Aggiungi l'indirizzo del portale</button>${
        this.portale ? ` <span class="portok">✓ ${esc(this.portale)}</span>` : ""}</div>`;
    }

    // The multi-day table: exams down, draws across, newest first. It is read
    // from the portal page, never asked to the server.
    // UNA sola tabella, per il pannello e per il testo copiato: due
    // sorgenti che disegnano «la stessa» tabella finiscono sempre per
    // divergere, e la differenza la scopre il medico.
    tabellaStorico(st, nov = null, segni = {}) {
      const col = st.date.map((d, i) => ({ ...d, i })).reverse();   // il più recente a sinistra
      const righe = righeTabella(st.righe);   // niente doppioni, e «Neu 4.0 (56%)»: una riga, non due
      const ambS = sigleAmbigue(righe);
      const inatteso = (r) => !siglaCurata(r.nome) || ambS.has(chiaveAmbigua(r));
      const simboli = new Map();   // esame → segno, uno per tutta la tabella
      const gruppi = raggruppaStorico(righe)
        .map((g) => ({ ...g, righe: g.righe.filter((r) => !this.soloAlterati || r.valori.some((v) => v.v && v.stato)) }))
        .filter((g) => g.righe.length);

      const rigaEsame = (r) => {
        const p = provenienze(r, simboli);
        const um = (r.valori.find((v) => v && v.um) || {}).um || "";
        const celle = col.map((c) => {
          const v = r.valori[c.i] || { v: "", stato: 0 };
          if (!v.v) return `<td class="vuoto">·</td>`;
          const sg = p.segno(v);
          const daChi = String(v.esame || r.esame || "").trim();
          // la novità (analita nuovo, valore cambiato dall'ultima lettura)
          // viaggia su un canale suo: lo sfondo, mai il colore del testo
          const n = nov && nov.get(chiaveCol(c))?.get(valKey(r.nome));
          const tip = [v.um, v.range, sg && daChi ? "fatto con " + daChi : "",
                       n === "nuovo" ? "nuovo dall'ultima lettura" : n === "cambiato" ? "aggiornato dall'ultima lettura" : ""].filter(Boolean).join(" · ");
          // il segno del medico (un tocco giallo, due arancio) vive sulla
          // cella: «colonna|analita», la stessa identità con cui la tabella
          // fonde i prelievi, così sopravvive a ogni ridisegno
          const cella = chiaveCol(c) + "|" + valKey(r.nome) + (eEga(r.esame) ? "|ega" : "") + (!r.mnem && r.nome === r.esame ? "|#" + (r.pos ?? 0) : "");
          const segno = segni[cella] === 2 ? " marca2" : segni[cella] === 1 ? " marca1" : "";
          return `<td class="${v.stato ? "fuori" : ""}${v.parziale ? " parz" : ""}${n === "nuovo" ? " nuovo" : n === "cambiato" ? " agg" : ""}${segno}" data-cella="${esc(cella)}"${
            tip ? ` title="${esc(tip)}${v.parziale ? " · parziale" : ""}"` : v.parziale ? ` title="parziale"` : ""
          }><span class="val">${esc(v.v)}${v.stato ? (v.stato < 0 ? "↓" : "↑") : ""}${
            sg ? `<i class="prov" title="${esc(daChi ? "fatto con " + daChi + (p.solita ? " — gli altri con " + p.solita : "") : "")}">${esc(sg)}</i>` : ""
          }</span>${v.pct ? `<span class="pct"> (${esc(v.pct)}%)</span>` : ""}</td>`;
        }).join("");
        const etichetta = inatteso(r)
          ? String(r.nome).replace(/\s+/g, " ").trim() + (eEga(r.esame) && ambS.has(chiaveAmbigua(r)) ? " (EGA)" : "")
          : sigla(r.nome);
        return `<tr><th class="stn${inatteso(r) ? " grezza" : ""}" title="${esc(r.nome)}${
          r.esame && r.esame !== r.nome ? " — " + esc(r.esame) : ""}${r.mnem ? " · " + esc(r.mnem) : ""}">${
          esc(etichetta)}${um ? `<span class="stum"> (${esc(um)})</span>` : ""}</th>${celle}</tr>`;
      };

      const corpo = gruppi.map((g) => {
        // niente conteggio dei fuori norma sulla riga di sezione: tanti sono
        // insignificanti, e il numero distrae da quelli che contano
        return `<tr class="stsez"><th class="stn">${esc(g.nome)}</th><td colspan="${col.length}"></td></tr>${g.righe.map(rigaEsame).join("")}`;
      }).join("");

      // In cima a ogni colonna: se il prelievo è di oggi basta l'ora; se è di
      // un altro giorno la data (27/08), con l'ora sotto in piccolo. Si legge
      // per confronto, e «quale giorno» conta solo quando non è questo.
      const d0 = new Date();
      const oggi = `${String(d0.getDate()).padStart(2, "0")}/${String(d0.getMonth() + 1).padStart(2, "0")}/${d0.getFullYear()}`;
      const testa = `<tr><th class="stn">Esame</th>${col.map((c, i) => {
        const diOggi = c.data === oggi;
        const cima = c.ignota ? "?" : diOggi ? c.ora || "oggi" : c.data.slice(0, 5);
        const sotto = c.ignota ? "ora ignota" : diOggi ? "" : c.ora;
        const tip = [c.ignota ? "Il gestionale non dà data e ora per questo prelievo" : c.label, c.titolo].filter(Boolean).join(" · ");
        return `<th class="${i === 0 && !c.ignota ? "ultima" : ""}" title="${esc(tip)}">${esc(cima)}<span class="sth">${esc(sotto)}</span></th>`;
      }).join("")}</tr>`;
      const nRighe = gruppi.reduce((n, g) => n + g.righe.length, 0);
      const legenda = [...simboli].map(([esame, segno]) => ({ segno, esame }));
      return {
        html: `<div class="stwrap"><table class="sttab"><thead>${testa}</thead><tbody>${corpo}</tbody></table></div>`,
        legenda, nRighe, nCol: col.length,
      };
    }

    // La legenda dei segni + la nota sui valori parziali: sotto la tabella,
    // scritta, non solo in un tooltip che su un portatile non si vede.
    piedeStorico(st, legenda) {
      const parz = st.righe.some((r) => r.valori.some((v) => v.parziale));
      return `${legenda.map((l) => `<div class="hint"><b>${esc(l.segno)}</b> fatto con <b>${esc(l.esame)}</b> (sul valore c'è scritto con cosa gli altri)</div>`).join("")}${
        parz ? `<div class="hint"><i>In corsivo</i>: valore ancora <b>parziale</b>, il laboratorio non ha finito.</div>` : ""}
        <div class="hint">Tocca un valore per segnarlo: giallo, poi arancio, poi via.</div>`;
    }

    // The table read on the portal page comes back through the extension. It
    // is shown ONLY if it belongs to the patient on screen: everywhere else
    // in this program the identity is checked before the data is used, and a
    // table of values is the last place to make an exception.
    // Fra le schede in memoria, quella di QUESTO paziente. L'identità la
    // decide il pannello, non il service worker: le regole stanno in un posto
    // solo. Le altre schede non vengono nemmeno chieste.
    async schedaMia() {
      const r = await ask({ t: "getStorico" });
      const indice = (r && r.ok && r.indice) || [];
      if (!indice.length) { this.storicoAltri = ""; return null; }
      const titolo = (document.title || "").trim();
      const mio = this.cfEpisodio();
      const scelta = scegliScheda(indice, mio, titolo, this.episodeId);
      this.storicoVia = scelta && scelta.ep && String(scelta.ep) === String(this.episodeId)
        ? "dal paziente da cui l'hai aperta"
        : scelta && scelta.cf && mio ? "dal codice fiscale" : "dal nome";
      // C'è una scheda con questo nome ma non gliela si può attribuire perché
      // di questo paziente non conosciamo ancora il codice fiscale: lo si
      // dice, invece di far sparire un bottone senza spiegazioni.
      this.storicoDaConfermare = !scelta && !mio
        && indice.some((v) => v.cf && !v.ep && combaciaNome(titolo, v.paziente));

      if (!scelta) {
        const altri = [...new Set(indice.map((v) => [v.paziente?.cognome, v.paziente?.nome].filter(Boolean).join(" "))
          .filter(Boolean))];
        // se la scheda porta QUESTO nome non è «di un altro paziente»: manca
        // solo la prova che sia sua, e quella la si dice diversamente
        this.storicoAltri = this.storicoDaConfermare ? ""
          : altri.length
            ? (altri.length === 1 ? altri[0] : `${altri.length} pazienti (${altri.slice(0, 2).join(", ")}…)`)
            : "un paziente che la pagina non nomina";
        return null;
      }
      const pieno = await ask({ t: "getStorico", chiave: scelta.chiave });
      return pieno && pieno.ok ? pieno.dati : null;
    }

    // E anche il testo di un referto letto: la scheda di un paziente è tutto
    // quello che il programma sa di lui, non solo i numeri.
    async archiviaReferto(e, righe) {
      if (!hasExt() || !righe || !righe.length) return;
      const chiave = this.chiavePaz();
      if (!chiave || chiave === "nome:") return;
      segnaChiave(this.episodeId, chiave);
      const vuota = {
        paziente: { idMPI: "", cognome: "", nome: (document.title || "").trim() },
        cf: this.cfEpisodio() || "", periodo: "", date: [], righe: [], scartate: [], letto: Date.now(),
      };
      await mettiInScheda(chiave, null, (vecchio) => {
        const base = vecchio || vuota;
        const referti = (base.referti || []).filter((r) => r.id !== e.id);
        referti.unshift({ id: e.id, quando: e.when || "", titolo: shortLabel(e.label || ""),
                          sistema: e.sistema || "", testo: righe.slice(0, 200).join("\n").slice(0, 20000) });
        return { ...base, referti: referti.slice(0, 40), letto: Date.now() };
      });
    }

    // Ogni prelievo letto entra anche nella scheda clinica del paziente, così
    // quello che il pannello sa di lui sta in un posto solo: la tabella del
    // portale e le finestre Risultati del gestionale, parziali comprese.
    async archiviaPrelievo(e, rows, cf, scartate) {
      if (!hasExt() || !rows || !rows.length) return;
      const t = prelievoComeTabella(risMeta(e), rows, cf, scartate);
      if (!t) return;
      const chiave = chiaveArchivio(t);
      if (!chiave || chiave === "nome:") return;
      segnaChiave(this.episodeId, chiave);
      await mettiInScheda(chiave, t);
    }

    // Chi è questo paziente, per la nota: il codice fiscale se i prelievi
    // ce l'hanno detto, altrimenti il nome della pagina. Cambia da nome a
    // codice fiscale appena i valori arrivano — e la nota lo segue.
    // Il titolo della pagina è il nome del paziente SOLO dove c'è davvero un
    // paziente: sulla lista del reparto quel titolo è «PRONTO SOCCORSO -
    // LISTA», e prenderlo per un nome è come attribuire una nota, un tempo o
    // una scheda a un paziente che non esiste.
    nomePaziente() {
      const puoOrdinare = !!(this.entry && (this.entry.labUrl || this.entry.radioUrl));
      return this.pageType === "patient" && puoOrdinare ? (document.title || "").trim() : "";
    }

    // La chiave del paziente di questa pagina: una sola, usata dalla nota,
    // dalla scheda clinica e dai referti tenuti — così «elimina questo
    // paziente» sa esattamente cosa togliere.
    chiavePaz() {
      const cf = this.cfEpisodio();
      if (cf) return "cf:" + cf;
      const n = normNome(this.nomePaziente());
      return n ? "nome:" + n : "";
    }
    // La chiave passa da «nome:» a «cf:» nel momento in cui i valori portano
    // il codice fiscale. La nota scritta prima deve SEGUIRE il paziente, non
    // restare indietro (e non riaffiorare su un omonimo): la si sposta.
    chiaveNota() {
      const k = this.chiavePaz();
      if (!k.startsWith("cf:")) return k;
      const vecchia = "nome:" + normNome(this.nomePaziente());
      const tutte = noteTutte();
      if (!tutte[k] && tutte[vecchia] && vecchia !== "nome:") {
        scriviNota(k, tutte[vecchia].t);
        scriviNota(vecchia, "");
        this.log(`${now()}  nota spostata sul codice fiscale del paziente`);
      } else if (tutte[vecchia] && vecchia !== "nome:") {
        scriviNota(vecchia, "");   // già migrata: la copia vecchia non deve restare in giro
      }
      if (vecchia !== "nome:") migraSegni(vecchia, k);
      // «elimina paziente» deve trovare anche questa chiave, con o senza estensione
      segnaChiave(this.episodeId, k);
      return k;
    }
    // La nota, e alla sua destra i promemoria di questo paziente: le pill e
    // una sveglia tranquilla che apre il campo, lì dov'è.
    notaHtmlPaziente() {
      const k = this.chiaveNota();
      if (!k) return "";
      const t = leggiNota(k), ep = this.epDiQuesta();
      return `<div class="notaw">
        <div class="notacol">
          <textarea class="nota" id="nota" rows="2" spellcheck="false"
            placeholder="Nota su questo paziente — si salva mentre scrivi"
            aria-label="Nota su questo paziente">${esc(t)}</textarea>
          <span class="notaok" id="notaok" aria-live="polite"></span>
        </div>
        ${ep ? `<div class="prbar">
          <span class="prslot" data-promslot="${esc(ep)}">${this.promPill(ep)}</span>
          <button type="button" class="prnuovo" data-promnuovo="${esc(ep)}" data-dove="barra" title="Promemoria: un'ora per fare una cosa (es. 11:30 tropo)" aria-label="Promemoria">${ICO.sveglia}</button>
          ${this._promIn?.ep === ep && this._promIn.dove === "barra" ? this.promCampo() : ""}
        </div>` : ""}
      </div>`;
    }

    // ============================================================ PROMEMORIA
    // La pill di un paziente: quanto manca al più vicino, in grassetto, la cosa
    // da fare, e «+1» se ce ne sono altri. Per esteso nel passaggio del mouse.
    promPill(ep, tutti) {
      const l = promDi(ep, tutti);
      if (!l.length) return "";
      const s = this.promStato(l);
      return `<button type="button" class="${s.cls}" data-prom="${esc(ep)}" aria-haspopup="dialog" title="${esc(s.title)}" aria-label="${esc(s.label)}">${s.html}</button>`;
    }
    promStato(l, ora = Date.now()) {
      const p = l[0], b = promBanda(p.t, ora), altri = l.length - 1;
      return {
        cls: "prom" + (b ? " " + b : ""),
        title: `${l.map((x) => promRiga(x, ora)).join("\n")}\nUn tocco: fatto, o 15 minuti in più`,
        label: `Promemoria: ${promRiga(p, ora)}${altri ? ` e ${altri === 1 ? "un altro" : `altri ${altri}`}` : ""}`,
        html: `<b>${esc(promTempo(p.t, ora))}</b><span class="prl">${esc(p.testo)}</span>${altri ? `<span class="prpiu">+${altri}</span>` : ""}`,
      };
    }
    // nella Stanza: solo il tempo, piccolo
    promMini(ep, tutti) {
      const l = promDi(ep, tutti);
      if (!l.length) return "";
      const ora = Date.now(), b = promBanda(l[0].t, ora);
      return `<span class="prst${b ? " " + b : ""}" data-promt="${esc(ep)}" title="${esc(l.map((x) => promRiga(x, ora)).join("\n"))}">${esc(promTempo(l[0].t, ora))}</span>`;
    }
    // Sulla pill ridotta, e solo quando tocca: il promemoria più urgente fra
    // i pazienti in elenco, a 10 minuti o meno, o già passato. Nient'altro.
    promUrgente(ora = Date.now()) {
      const tutti = promTutti();
      if (!Object.keys(tutti).length) return "";
      const arch = new Set(pazientiArchiviati().map((p) => p.ep)), nomi = new Map(tuttiPazienti().map((p) => [p.ep, p.name]));
      const urgenti = Object.entries(tutti).filter(([ep]) => !arch.has(ep))
        .flatMap(([ep, l]) => l.map((p) => ({ ...p, ep }))).filter((p) => promBanda(p.t, ora) === "ros").sort((a, b) => a.t - b.t);
      if (!urgenti.length) return "";
      const chi = (p) => `${nomi.get(p.ep) || (p.ep === this.epDiQuesta() && this.nomePaziente()) || "episodio " + p.ep} · ${p.testo}`;
      return `<span class="prurg" title="${esc(urgenti.map(chi).join("\n"))}">${ICO.sveglia}${esc(promTempo(urgenti[0].t, ora))}</span>`;
    }
    // Ogni 30 secondi le pill dei promemoria rifanno i conti SUL POSTO: niente
    // ridisegno, così non si ruba il fuoco e non si disturba chi scrive.
    promTick() {
      const ora = Date.now(), tutti = promTutti();
      for (const ep of new Set([...this.root.querySelectorAll("[data-promslot]")].map((s) => s.getAttribute("data-promslot")))) this.promMetti(ep, tutti, ora);
      for (const el of this.root.querySelectorAll("[data-promt]")) {
        const l = promDi(el.getAttribute("data-promt"), tutti);
        if (!l.length) { el.remove(); continue; }
        const b = promBanda(l[0].t, ora);
        el.className = "prst" + (b ? " " + b : "");
        el.textContent = promTempo(l[0].t, ora);
        el.title = l.map((x) => promRiga(x, ora)).join("\n");
      }
      for (const el of this.root.querySelectorAll(".prmenu .prst[data-pt]")) {
        const t = +el.getAttribute("data-pt"), b = promBanda(t, ora);
        el.className = "prst" + (b ? " " + b : "");
        el.textContent = promTempo(t, ora);
      }
      const pill = this.root.querySelector("#expand.pill:not(.run)");
      if (pill) {
        const prima = pill.querySelector(".prurg"), ora2 = this.promUrgente(ora);
        if (prima) prima.outerHTML = ora2;
        else if (ora2) pill.insertAdjacentHTML("beforeend", ora2);
      }
      const pin = this.root.querySelector("#prin");
      if (pin && !this._promIn?.err) this.promSuggerisci(pin);
    }
    // la pill di un paziente rifatta sul posto: l'elemento resta lo stesso
    promMetti(ep, tutti = promTutti(), ora = Date.now()) {
      const l = promDi(ep, tutti);
      for (const slot of this.root.querySelectorAll(`[data-promslot="${CSS.escape(ep)}"]`)) {
        const pill = slot.querySelector(".prom");
        if (!l.length) { if (pill !== this.root.activeElement) slot.textContent = ""; continue; }
        if (!pill) { slot.innerHTML = this.promPill(ep, tutti); continue; }
        const s = this.promStato(l, ora);
        pill.className = s.cls; pill.title = s.title; pill.setAttribute("aria-label", s.label); pill.innerHTML = s.html;
      }
    }
    promClic(e) {
      const pill = e.target.closest?.("[data-prom]");
      if (pill) {
        const aperto = this._promMenu?.anchor === pill && this._promMenu.menu.isConnected;
        return aperto ? this.promChiudiMenu(true) : this.promMenu(pill.getAttribute("data-prom"), pill);
      }
      const sveglia = e.target.closest?.("[data-promnuovo]");
      if (sveglia) this.promApri(sveglia.getAttribute("data-promnuovo"), sveglia.getAttribute("data-dove"), sveglia);
    }
    // Il campo si apre lì dove si è toccata la sveglia, senza ridisegnare: la
    // riga della Lista (al posto della nota) o la barra della nota.
    promCampo() {
      const b = this._promIn || {};
      return `<span class="prform"><input type="text" class="prin" id="prin" value="${esc(b.testo || "")}" maxlength="80" spellcheck="false" autocomplete="off"
        placeholder="es. 11:30 tropo · tra 2h ECG" aria-label="Promemoria: un orario e cosa fare" aria-describedby="prhint"><span class="prhint${b.err ? " ko" : ""}" id="prhint" aria-live="polite">${esc(b.err || "")}</span></span>`;
    }
    promApri(ep, dove, sveglia) {
      const b = this._promIn;
      if (b && b.ep === ep && b.dove === dove && this.root.querySelector("#prin")) return this.promChiudi(true);   // di nuovo la sveglia: si chiude
      this.root.querySelector(".prform")?.remove();
      const box = dove === "barra" ? sveglia.closest(".prbar") : sveglia.closest(".pzrow")?.querySelector(".pzchi");
      if (!box) return;
      this._promIn = { ep, dove, testo: "", err: "" };
      box.insertAdjacentHTML("beforeend", this.promCampo());
      this._promFuoco = true;
      this.promLega();
    }
    // gli ascoltatori del campo (aperto ora, o ridisegnato mentre era aperto)
    promLega() {
      const inp = this.root.querySelector("#prin");
      if (!inp || inp._legato) return;
      inp._legato = true;
      if (this._promFuoco) {
        this._promFuoco = false;
        inp.focus({ preventScroll: true });
        const [a, z] = this._promSel || [inp.value.length, inp.value.length];
        inp.setSelectionRange(a, z);
        this._promSel = null;
      }
      this.promSuggerisci(inp);
      inp.addEventListener("input", () => {
        if (this._promIn) { this._promIn.testo = inp.value; this._promIn.err = ""; }
        this.promSuggerisci(inp);
      });
      inp.addEventListener("keydown", (e) => {
        if (e.key === "Enter") { e.preventDefault(); this.promSalva(inp, true); }
        else if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); this.promChiudi(true); }
      });
      // uscendo col mouse NON si ridisegna: il clic che ha tolto il fuoco deve
      // arrivare. Se c'è un orario si salva, come la nota; senza, il campo resta.
      inp.addEventListener("blur", (e) => {
        if (!inp.isConnected || !this._promIn || !document.hasFocus()) return;   // un'altra finestra non è un'uscita dal campo
        if (e.relatedTarget?.closest?.("[data-promnuovo]")?.getAttribute("data-promnuovo") === this._promIn.ep) return;   // la sveglia: la chiude lei
        this.promSalva(inp, false);
      });
    }
    // sotto il campo, mentre si scrive: quando sarà
    promSuggerisci(inp) {
      const h = inp.parentElement?.querySelector(".prhint");
      if (!h) return;
      const b = this._promIn;
      if (b?.err) { h.textContent = b.err; h.classList.add("ko"); return; }
      const p = inp.value.trim() ? leggiPromemoria(inp.value, Date.now()) : null;
      h.classList.remove("ko");
      h.textContent = p ? promRiga({ t: p.t, testo: "" }, Date.now()) : "";
    }
    promSalva(inp, tasto) {
      const b = this._promIn;
      if (!b) return;
      if (!inp.value.trim()) return this.promChiudi(tasto);
      const p = leggiPromemoria(inp.value, Date.now());
      const errore = !p ? "Scrivi un orario: 11:30, o tra 2h"
        : promDi(b.ep).length >= PROM_MAX ? `Al massimo ${PROM_MAX} promemoria per paziente`
        : !promAggiungi(b.ep, p) ? "Non salvato: la memoria del browser è piena o bloccata" : "";
      if (errore) { b.err = errore; this.promSuggerisci(inp); return; }
      this.promMetti(b.ep);
      this.promChiudi(tasto);
    }
    promChiudi(fuoco) {
      const b = this._promIn;
      this._promIn = null;
      this.root.querySelector(".prform")?.remove();
      if (fuoco && b) this.root.querySelector(`[data-promnuovo="${CSS.escape(b.ep)}"]`)?.focus();
    }
    // L'elenco di un paziente, sotto la sua pill: per ognuno ✓ Fatto (si
    // annulla per 8 secondi) e +15 min. Esc, o un clic fuori, lo chiudono.
    promMenu(ep, anchor) {
      this.promChiudiMenu();
      const l = promDi(ep), wrap = this.root.querySelector(".wrap");
      if (!l.length || !wrap || !anchor?.isConnected) return;
      const ora = Date.now(), p0 = tuttiPazienti().find((x) => x.ep === ep);
      const nome = p0?.name || (ep === this.epDiQuesta() ? this.nomePaziente() : "");
      const riga = (p) => {
        const b = promBanda(p.t, ora);
        return `<div class="prmrow"><span class="prst${b ? " " + b : ""}" data-pt="${p.t}">${esc(promTempo(p.t, ora))}</span>
          <span class="prmq" title="${esc(promRiga(p, ora))}"><b>${esc(promOra(p.t, ora))}</b> ${esc(p.testo)}</span>
          <button type="button" class="prmb ok" data-pfatto="${esc(p.id)}" title="Fatto: lo tolgo (si può annullare)">✓ Fatto</button>
          <button type="button" class="prmb" data-prinvia="${esc(p.id)}" title="Rimanda di 15 minuti">+15 min</button></div>`;
      };
      wrap.insertAdjacentHTML("beforeend", `<div class="prmenu" role="dialog" aria-label="Promemoria${nome ? " di " + esc(nome) : ""}">
        <div class="prmhd">Promemoria${nome ? ` · ${esc(nome)}` : ""}</div>${l.map(riga).join("")}</div>`);
      const menu = wrap.lastElementChild;
      // sotto la pill; se sotto non c'è posto, sopra; sempre dentro lo schermo
      const wr = wrap.getBoundingClientRect(), ar = anchor.getBoundingClientRect();
      let y = ar.bottom + 6;
      if (y + menu.offsetHeight > innerHeight - 8) y = Math.max(8, ar.top - 6 - menu.offsetHeight);
      menu.style.left = Math.max(8, Math.min(ar.left, innerWidth - menu.offsetWidth - 8)) - wr.left + "px";
      menu.style.top = y - wr.top + "px";
      menu.addEventListener("click", (e) => {
        const f = e.target.closest("[data-pfatto]"), r = e.target.closest("[data-prinvia]");
        if (f) this.promFatto(ep, f.getAttribute("data-pfatto"));
        else if (r) { promRinvia(ep, r.getAttribute("data-prinvia")); this.promDopo(ep); }
      });
      menu.addEventListener("keydown", (e) => { if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); this.promChiudiMenu(true); } });
      // col Tab fuori dall'elenco si chiude (verso la sua pill no: la pill lo chiude da sé)
      menu.addEventListener("focusout", (e) => { if (e.relatedTarget && !menu.contains(e.relatedTarget) && e.relatedTarget !== anchor) this.promChiudiMenu(); });
      const fuori = (e) => { const via = e.composedPath(); if (!via.includes(menu) && !via.includes(anchor)) this.promChiudiMenu(); };
      window.addEventListener("pointerdown", fuori, true);
      this._promMenu = { menu, anchor, ep, fuori };
      menu.querySelector("button")?.focus({ preventScroll: true });
    }
    promChiudiMenu(ritorna) {
      const a = this._promMenu;
      if (!a) return;
      this._promMenu = null;
      window.removeEventListener("pointerdown", a.fuori, true);
      a.menu.remove();
      if (ritorna && a.anchor?.isConnected) a.anchor.focus();
    }
    // ✓ Fatto: via, e «Annulla» per 8 secondi
    promFatto(ep, id) {
      const p = promTogli(ep, id);
      if (p) this.stanzaAnnullabile(`Fatto: ${p.testo}`, () => promRimetti(ep, p));
      this.promDopo(ep);
    }
    // dopo ✓ o +15 si ridisegna; l'elenco resta aperto finché c'è qualcosa
    promDopo(ep) {
      this.promChiudiMenu();
      this.render();
      const a = this.root.querySelector(`[data-prom="${CSS.escape(ep)}"]`);
      if (a && promDi(ep).length) this.promMenu(ep, a);
      else this.root.querySelector(`[data-promnuovo="${CSS.escape(ep)}"]`)?.focus();
    }

    // l'impronta del codice fiscale di QUESTO episodio, presa dai prelievi
    // che il pannello ha già letto: nessuna richiesta in più
    cfEpisodio() {
      for (const k of tabStore.keys(`ris.${this.episodeId || "x"}.`)) {
        const v = tabStore.get(k, null);
        if (v && v.cf) return v.cf;
      }
      return "";
    }

    // Il link «Storico Dati Clinici» di QUESTA pagina, come ce l'ha il
    // gestionale: mai un indirizzo costruito.
    linkStorico() {
      const a = document.querySelector('a[href*="MODALITA=CLINICA"]');
      if (!a) return "";
      try { const u = new URL(a.href, location.href); return u.origin === location.origin ? u.href : ""; } catch { return ""; }
    }
    // «⭳ Carica i valori» apre anche lo storico del portale, in una scheda di
    // sottofondo che si chiude da sola: la stessa pagina che si apre col link,
    // letta come sempre. Se non arriva, lo si dice — e il link a mano resta.
    async storicoInSottofondo() {
      if (!hasExt() || DEMO || this._sotto || !this.episodeId || !this.nomePaziente()) return;
      const url = this.linkStorico();
      if (!url) { this.log(`${now()}  portale: su questa pagina non c'è il link «Storico Dati Clinici»`); return; }
      this._sotto = { t0: Date.now() };
      this.render();
      let s = { esito: "" };
      try {
        const r = await ask({ t: "apriStoricoSotto", url, ep: this.episodeId, nome: this.nomePaziente() });
        if (!r || !r.ok) { s = { esito: "rifiutato", why: r && r.why }; return; }
        // la tabella si scorre a passi (il portale disegna solo le colonne in
        // vista): con tanti prelievi ci vuole un po'
        while (Date.now() - this._sotto.t0 < 60000) {
          await sleep(800);
          s = await ask({ t: "esitoSotto", tabId: r.tabId });
          if (!s || !s.ok || (s.esito !== "attesa" && s.esito !== "lettura")) break;
        }
      } finally {
        this._sotto = null;
        // ancora «in lettura» allo scadere: quello che è arrivato è arrivato
        if (s && s.esito === "lettura") s = { ...s, esito: "letto" };
        if (s && s.esito === "letto") {
          this.log(`${now()}  storico del portale letto in sottofondo: ${s.esami} esami · ${s.prelievi} prelievi`);
          this.notaPortale = "";
          await this.caricaStorico();
        } else {
          const perche = {
            login: "il portale chiede di entrare", tempo: "la tabella non è comparsa in 30 secondi",
            altrove: "il portale si è aperto a un indirizzo che l'estensione non conosce (aggiungi l'indirizzo del portale)",
            nonportale: "il link dello storico non ha aperto il portale",
            altro: "il portale ha aperto un altro paziente: non lo attribuisco", chiusa: "la scheda del portale è stata chiusa",
            rifiutato: (s && s.why) || "non aperto",
          }[s && s.esito] || "nessuna risposta";
          this.log(`${now()}  storico del portale in sottofondo: ${perche}`);
          this.notaPortale = perche;
        }
        this.render();
      }
      return !!(s && s.esito === "letto");
    }

    // «⭳ Carica i valori». Lo storico del portale ha TUTTI i valori del
    // laboratorio, refertati e no: basta quello, una pagina sola. Le finestre
    // Risultati — una richiesta per prelievo — si leggono solo se il portale
    // non si può leggere: senza estensione, senza link, o se non ha risposto.
    async caricaValori() {
      if (!this.conPortale()) return this.reloadTuttiValori();
      const letto = await this.storicoInSottofondo();
      if (!letto) {
        this.log(`${now()}  leggo i prelievi dalle finestre Risultati, uno alla volta`);
        return this.reloadTuttiValori();
      }
    }
    conPortale() { return hasExt() && !DEMO && !!this.nomePaziente() && !!this.linkStorico(); }

    async caricaStorico() {
      if (this.pageType !== "patient" || !hasExt()) return;
      const prima = (this.storico?.letto || 0) + "|" + this.storicoAltri;
      // schedaMia() ha già deciso l'identità: qui non si ricontrolla, o la
      // regola finirebbe scritta in due posti e prima o poi in due modi
      const dati = await this.schedaMia();
      // rifiutare è giusto, rifiutare in silenzio no: il medico quella tabella
      // l'ha letta un minuto prima e deve sapere perché non è qui
      this.storico = dati && dati.righe ? dati : null;
      if (this.storico) this.storicoAltri = "";
      // si ridisegna solo se è cambiato qualcosa, e mai sopra una schermata in
      // cui si sta scrivendo: tornare su questa scheda non deve costare il cursore
      if ((this.storico?.letto || 0) + "|" + this.storicoAltri === prima) return;
      if (this.view === "dimtesto" || this.view === "dimimport") return;
      if (this.root.activeElement && this.root.activeElement.id === "nota") return;
      this.render();
    }

    async refreshRefCache() {
      const ids = this.refertiMostrati().map((e) => e.id);
      if (!hasExt() || !ids.length) return;
      const r = await ask({ t: "listRef", ep: this.episodeId, ids });
      if (r && r.ok) { this.refCache = r.cached || {}; this.render(); }
    }

    async saveAllReferti() {
      if (!hasExt() || this._salvaRef) return;   // due clic non sono due salvataggi
      this._salvaRef = true;
      try {
      this.refBusy = this.refBusy || {};
      const todo = this.refertiMostrati().filter((e) => !(this.refCache || {})[e.id]);
      for (const e of todo) this.refBusy[e.id] = true;
      this.render();
      for (const e of todo) {
        // Prima dal pannello, con lo stesso lettore delle etichette (sa
        // replicare un visualizzatore); se non basta, dal service worker. Il
        // perché di un fallimento va nel Registro, e la pagina del
        // visualizzatore resta pronta da copiare come diagnosi.
        let res = null;
        const motivi = [];
        try {
          if (nelPortale(e)) { const x = new StopError("Il referto si apre nel portale", "come gli altri di questo sistema"); x.portale = true; throw x; }
          const r = await fetchPdf(e.url, {});
          res = await ask({ t: "cacheRef", id: e.id, ep: this.episodeId, pk: this.chiavePaz(), data: bufB64(await r.blob.arrayBuffer()), size: r.blob.size });
          if (!(res && res.ok)) motivi.push(`memoria: ${(res && res.why) || "non riuscito"}`);
        } catch (err) {
          if (err && err.portale) {
            // sta nel portale: si legge dalla sua scheda, come al tocco
            segnaPortale(e);
            try { await this.refertoDalPortale(e); res = { ok: true, size: this.refCache?.[e.id] || 1 }; }
            catch (err2) { err = err2; res = null; }
          }
          if (!(res && res.ok)) motivi.push(`${err?.head || err?.message || err}${err?.body ? ` — ${err.body}` : ""}${err?.diag ? ` [${err.diag}]` : ""}`);
          if (!(res && res.ok) && !(err && (err.portale || /portale/i.test(err.head || "")))) {
            res = await ask({ t: "cacheRef", id: e.id, url: e.url, ep: this.episodeId, pk: this.chiavePaz() });
            if (!(res && res.ok)) motivi.push(`service worker: ${(res && res.why) || "non riuscito"}`);
          }
          if (!(res && res.ok)) this.diagnosi = { cosa: `referto ${shortLabel(e.label)} (${e.sistema || "?"})`, url: e.url, html: (err && err.html) || "", diag: motivi.join(" · "), quando: now() };
        }
        if (res && res.ok) {
          this.refCache = { ...(this.refCache || {}), [e.id]: res.size || 1 };
          this.refBusy[e.id] = false;
        } else {
          this.refBusy[e.id] = motivi.join(" · ") || "non riuscito";
          this.log(`${now()}  referto non salvato (${shortLabel(e.label)}): ${this.refBusy[e.id]}`);
        }
        this.render();
      }
      } finally {
        // senza il finally una sola eccezione spegneva «Salva referti» per
        // tutta la vita della scheda, e i pallini restavano a girare
        this._salvaRef = false;
        this.render();
      }
    }

    txtKey(id) { return `reftxt.${this.episodeId || "x"}.${id}`; }

    // Il referto sta nel portale (ECG, radiologia): si apre col link del
    // gestionale — lo stesso clic del medico — in una scheda DIETRO. Là la
    // pagina lo scarica e lo mostra da sé, e lo script del portale ne passa
    // una copia; la scheda si chiude. Nessuna richiesta nostra.
    async refertoDalPortale(e) {
      const r = await ask({ t: "apriRefertoSotto", url: e.url, id: e.id, ep: this.episodeId, pk: this.chiavePaz() });
      if (!r || !r.ok) throw new StopError("Portale non aperto", (r && r.why) || "estensione non raggiungibile");
      this.log(`${now()}  ${shortLabel(e.label)}: lo apro nel portale, in una scheda dietro`);
      const fine = Date.now() + 45e3;
      let s = null;
      while (Date.now() < fine) {
        await sleep(900);
        s = await ask({ t: "esitoSotto", tabId: r.tabId });
        if (!s || !s.ok || (s.esito !== "attesa" && s.esito !== "lettura")) break;
      }
      if (!s || !s.ok || s.esito !== "letto") {
        const perche = {
          login: "il portale chiede di entrare: aprilo una volta e fai l'accesso",
          tempo: "il portale non l'ha mostrato in tempo", attesa: "il portale non l'ha mostrato in tempo",
          nonportale: "il link non ha portato al portale (sessione del gestionale?)",
          nonTrovato: "il portale l'ha aperto, ma il PDF non si vede da qui",
          chiusa: "la scheda del portale è stata chiusa", altrove: "la scheda del portale è andata altrove",
        }[s && s.esito] || (s && s.esito) || "nessuna risposta dall'estensione";
        const x = new StopError("Referto non letto dal portale", perche);
        if (s && s.diag) x.diag = s.diag;
        throw x;
      }
      const g = await ask({ t: "getRef", id: e.id, ep: this.episodeId });
      if (!(g && g.ok && g.data)) throw new StopError("Referto letto ma non ritrovato", "riprova");
      this.refCache = { ...(this.refCache || {}), [e.id]: Math.round(g.data.length * 3 / 4) || 1 };
      return Uint8Array.from(atob(g.data), (c) => c.charCodeAt(0)).buffer;
    }

    // Radiology and ECG reports become TEXT inside the panel: their PDFs carry
    // a real font map, so the words can be recovered exactly. Everything else
    // stays a document to open. The PDF itself is never shown here — the ↗
    // button is always one tap away.
    async apriTesto(id) {
      const e = this.esiti.find((x) => x.id === id);
      if (!e) return;
      if (!tabStore.get(this.txtKey(id), null)) {
        this.refBusy = { ...(this.refBusy || {}), [id]: true };
        this.render();
        try {
          let buf;
          // già salvato (pallino verde): si legge la copia, senza chiedere niente a nessuno
          if (hasExt() && (this.refCache || {})[id]) {
            const g = await ask({ t: "getRef", id, ep: this.episodeId });
            if (g && g.ok && g.data) buf = Uint8Array.from(atob(g.data), (c) => c.charCodeAt(0)).buffer;
          }
          // un sistema che si è già visto stare nel portale (ECG, RIS) ci va
          // diretto: chiedere di nuovo il link al gestionale solo per scoprire
          // che rimanda là sarebbe una richiesta in più a ogni tocco
          if (!buf && nelPortale(e)) buf = await this.refertoDalPortale(e);
          if (!buf) try {
            buf = await (await fetchPdf(e.url, {})).blob.arrayBuffer();
          } catch (err) {
            if (err?.name === "AbortError" || !hasExt()) throw err;
            if (err && err.portale) {
              // il referto sta nel portale: lo si legge dalla scheda del portale
              segnaPortale(e);
              buf = await this.refertoDalPortale(e);
            } else {
              // Dal pannello no: ci prova il service worker. Se neanche lui, il
              // perché dei due tentativi resta sul pallino e nella diagnosi.
              const r = await ask({ t: "cacheRef", id, url: e.url, ep: this.episodeId, pk: this.chiavePaz() });
              const g = r && r.ok ? await ask({ t: "getRef", id, ep: this.episodeId }) : null;
              if (!(g && g.ok && g.data)) {
                err.diag = `${err.diag ? `${err.diag} · ` : ""}service worker: ${(r && r.why) || "non riuscito"}`;
                throw err;
              }
              buf = Uint8Array.from(atob(g.data), (c) => c.charCodeAt(0)).buffer;
              this.refCache = { ...(this.refCache || {}), [id]: r.size || 1 };
            }
          }
          const blob = { size: buf.byteLength };
          const letto = await testoPdf(buf);
          const righe = letto.righe;
          // Il PDF c'è: si tiene in ogni caso, anche se il testo non esce.
          if (hasExt() && !(this.refCache || {})[id]) {
            const res = await ask({ t: "cacheRef", id, ep: this.episodeId, pk: this.chiavePaz(), data: bufB64(buf), size: blob.size });
            if (res && res.ok) this.refCache = { ...(this.refCache || {}), [id]: res.size || 1 };
          }
          this.refBusy[id] = false;
          if (righe.length) {
            tabStore.set(this.txtKey(id), { ts: Date.now(), righe });
            this.archiviaReferto(e, righe);
            this.log(`${now()}  ${shortLabel(e.label)}: testo letto (${righe.length} righe, ${letto.lettore}${letto.motivo ? `; ${letto.motivo}` : ""})`);
          } else {
            // I referti sono PDF di testo, mai immagini: se il testo non esce
            // lo sbaglio è del lettore. Si apre il PDF, e la diagnosi dice
            // com'è fatto (la struttura, mai il contenuto) per correggerlo.
            const diag = `${letto.motivo ? `${letto.motivo} · ` : ""}${pdfDiag(buf)}`;
            this.diagnosi = { cosa: `referto ${shortLabel(e.label)} (${e.sistema || "?"})`, url: e.url, html: "", diag, quando: now() };
            this.log(`${now()}  ${shortLabel(e.label)}: testo non letto — si apre il PDF (⧉ Copia diagnosi) [${diag}]`);
            this.render();
            return this.openReferto(id);
          }
        } catch (err) {
          // Non letto: si dice perché (sul pallino e nel Registro) e il
          // documento si apre lo stesso, con lo stesso clic — non al secondo.
          this.refBusy[id] = `${(err && (err.head || err.message)) || "non letto"}${err && err.body ? ` — ${err.body}` : ""}${err && err.diag ? ` [${err.diag}]` : ""}`;
          this.diagnosi = { cosa: `referto ${shortLabel(e.label)} (${e.sistema || "?"})`, url: e.url, html: (err && err.html) || "", diag: this.refBusy[id], quando: now() };
          this.log(`${now()}  ${shortLabel(e.label)}: referto non letto (${this.refBusy[id]})`);
          this.render();
          return this.openReferto(id);
        }
        this.render();
      }
      if (tabStore.get(this.txtKey(id), null)) this.setView("referto", id);
    }

    // The list shows only WHAT, never the text: at discharge the doctor knows
    // which sheet he wants, and reading it here would only cost him a scroll.
    viewDimissioni() {
      const tutte = dimissioni();
      const chiavi = Object.keys(tutte);
      // I fogli rivisti stanno in cima, gli altri sotto una riga che lo dice:
      // così si vede a colpo d'occhio dove si è già messo mano.
      let stacco = false;
      const righe = chiavi.map((k) => {
        const d = tutte[k];
        let sep = "";
        if (!d.rivisto && !stacco && chiavi.some((x) => tutte[x].rivisto)) {
          stacco = true;
          sep = `<div class="dsep"><span>non ancora rivisti</span></div>`;
        }
        const n = d.testo.split("\n").filter((r) => r.trim()).length;
        const segno = d.aggiornato
          ? `<span class="dmod agg" title="L'originale è cambiato dopo la tua modifica">⟳</span>`
          : d.modificato ? `<span class="dmod" title="Testo modificato da te">•</span>` : "";
        return `${sep}
        <div class="drow">
          <button class="dcopia" data-dcopy="${esc(k)}" title="Copia negli appunti il foglio «${esc(d.nome)}»"
                  aria-label="Copia il foglio ${esc(d.nome)}">
            <span class="dnome">${esc(d.nome)}${segno}</span>
            <span class="dmeta">${n} righe</span><span class="dico">⧉</span>
          </button>
          <button class="dbtn" data-dedit="${esc(k)}" title="Modifica il testo di «${esc(d.nome)}»"
                  aria-label="Modifica il foglio ${esc(d.nome)}">✎</button>
        </div>`;
      }).join("");
      // le deleghe per il ritiro si danno a chi va a casa: stanno qui, in cima
      const ritiro = CONSENSI.filter((c) => c.gruppo === "ritiro");
      return `
        ${ritiro.length ? `
        <div class="sec">
          <div class="lbl">Moduli per il ritiro (${ritiro.length})</div>
          <div class="mlist">${ritiro.map((c) => this.rigaModulo(c)).join("")}</div>
        </div>` : ""}
        <div class="sec">
          <div class="lbl">Fogli di dimissione (${chiavi.length})
            <button class="mini" id="dimexport" title="Salva i tuoi testi in un file JSON">⬇ JSON</button>
            <button class="mini" id="dimimport" title="Rimetti i testi di un JSON esportato">⤒ Importa</button>
          </div>
          <div class="dlist">${righe}</div>
          <div class="hint">Clic sulla riga per copiare il foglio, ✎ per modificarlo una volta per tutte. Le modifiche restano su questo computer.</div>
        </div>`;
    }

    // The editor keeps a draft in tabStore at every keystroke: the EHR retitles
    // the page (which re-renders the panel) and reloads it under the doctor's
    // hands, and a rewritten sheet must never die to something he did not do.
    dimDraftKey(k) { return "dimdraft." + k; }
    viewDimTesto() {
      const k = this.viewId;
      const d = dimissioni()[k];
      if (!d) return `<div class="hint">Testo non disponibile.</div>`;
      const bozza = tabStore.get(this.dimDraftKey(k), null);
      const testo = bozza && typeof bozza.testo === "string" ? bozza.testo : d.testo;
      return `
        <div class="sec">
          <div class="lbl">${esc(d.nome)}
            <button class="mini" id="dimcopy" title="Copia questo testo senza salvarlo">⧉ Copia</button>
            <button class="mini" id="dimsave" title="Tieni questo testo per le prossime dimissioni">✓ Salva</button>
            ${d.modificato ? `<button class="mini" id="dimreset" title="${d.mio ? "Elimina questo foglio" : "Butta le tue modifiche e riprendi l'originale"}">${d.mio ? "✕ Elimina" : "↺ Originale"}</button>` : ""}
          </div>
          ${d.aggiornato ? `<div class="banner warn">L'originale di questo foglio è stato aggiornato dopo la tua modifica: con ↺ Originale prendi la versione nuova.</div>` : ""}
          ${testo !== d.testo ? `<div class="banner ok">Bozza non salvata, ripresa da dove l'avevi lasciata.</div>` : ""}
          <textarea class="dedit" id="dimarea" spellcheck="false" aria-label="Testo del foglio ${esc(d.nome)}">${esc(testo)}</textarea>
          <div class="hint">Salva tiene questo testo per le prossime volte. Per un foglio su misura per QUESTO paziente, modifica e usa ⧉ Copia senza salvare: qui non vanno dati del paziente.</div>
        </div>`;
    }

    // Un tocco apre il modulo e la finestra di stampa. I PDF sono dentro
    // l'estensione: nessuna richiesta al server, funziona anche offline.
    // Fine turno: una pagina HTML da guardare o stampare, raggruppata per
    // paziente, coi totali per attività. Come per l'editor dei fogli, si apre
    // anche in una scheda: un download che il browser rifiuta non deve
    // lasciare le mani vuote.
    esportaTempi() {
      const chiusi = tempi().filter((t) => t.fine).sort((a, b) => a.inizio - b.inizio);
      if (!chiusi.length) return;
      const perPaz = new Map(), perTit = new Map();
      for (const t of chiusi) {
        const k = t.paz || "(senza paziente)";
        if (!perPaz.has(k)) perPaz.set(k, []);
        perPaz.get(k).push(t);
        perTit.set(t.titolo, (perTit.get(t.titolo) || 0) + durata(t));
      }
      const tot = chiusi.reduce((n, t) => n + durata(t), 0);
      const riga = (t) => `<tr><td>${esc(t.titolo)}</td><td class="n">${esc(mmss(durata(t)))}</td><td class="n">${esc(oraDi(t.inizio))}</td><td class="n">${esc(oraDi(t.fine))}</td></tr>`;
      const html = `<!doctype html><html lang="it"><head><meta charset="utf-8">
<title>Tempi ${esc(giornoDi(chiusi[0].inizio))}</title><style>
  body{font:14px/1.5 -apple-system,"Segoe UI",Roboto,Arial,sans-serif;color:#151E27;background:#fff;margin:0;padding:28px 22px 60px}
  h1{font-size:22px;margin:0 0 4px} .sub{color:#5D6E7E;font-size:13px;margin-bottom:22px}
  h2{font-size:15px;margin:22px 0 6px;padding-bottom:4px;border-bottom:1px solid #DBE3EA;display:flex;justify-content:space-between}
  table{border-collapse:collapse;width:100%;max-width:760px} td,th{padding:4px 8px;border-bottom:1px solid #EDF1F6;text-align:left}
  th{font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:#8397A8}
  .n{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap} .tot{font-weight:700}
  @media print{body{padding:0}}
</style></head><body>
<h1>Tempi — ${esc(giornoDi(chiusi[0].inizio))}</h1>
<p class="sub">${chiusi.length} attività · totale <b>${esc(mmss(tot))}</b> · dalle ${esc(oraDi(chiusi[0].inizio))} alle ${esc(oraDi(chiusi[chiusi.length - 1].fine))}</p>
<h2>Per attività</h2>
<table><tbody>${[...perTit.entries()].sort((a, b) => b[1] - a[1])
  .map(([k, v]) => `<tr><td>${esc(k)}</td><td class="n tot">${esc(mmss(v))}</td><td class="n">${Math.round((v / tot) * 100)}%</td></tr>`).join("")}</tbody></table>
${[...perPaz.entries()].map(([paz, l]) => `<h2><span>${esc(paz)}</span><span class="tot">${esc(mmss(l.reduce((n, t) => n + durata(t), 0)))}</span></h2>
<table><thead><tr><th>Attività</th><th class="n">Durata</th><th class="n">Inizio</th><th class="n">Fine</th></tr></thead>
<tbody>${l.map(riga).join("")}</tbody></table>`).join("")}
</body></html>`;
      // UN solo Blob: prima se ne creavano due per lo stesso testo e il secondo
      // non veniva mai liberato, quindi restava in memoria per tutta la scheda
      const u = URL.createObjectURL(new Blob([html], { type: "text/html" }));
      let file = false;
      try {
        const a = document.createElement("a");
        a.href = u; a.download = `tempi-${new Date(chiusi[0].inizio).toISOString().slice(0, 10)}.html`;
        document.documentElement.appendChild(a); a.click(); a.remove();
        file = true;
      } catch { /* la scheda qui sotto resta */ }
      openTab(u, "_blank");
      setTimeout(() => URL.revokeObjectURL(u), 60000);
      this.message = { ok: file ? "Tempi esportati: file nei download, e aperti in una scheda." : "Tempi aperti in una scheda: da lì Ctrl+S o Ctrl+P." };
      this.render();
    }

    viewTempi() {
      const t = tempoInCorso();
      const chiusi = tempi().filter((x) => x.fine).sort((a, b) => b.inizio - a.inizio);
      const chi = this.nomePaziente();
      const preset = TITOLI.map((x) => `<button class="tpre" data-avvia="${esc(x)}">${esc(x)}</button>`).join("");
      const tot = chiusi.reduce((n, x) => n + durata(x), 0);
      const righe = chiusi.slice(0, 40).map((x) => `
        <div class="trow">
          <span class="tt">${esc(x.titolo)}</span>
          <span class="tp">${esc(x.paz || "—")}</span>
          <span class="td">${esc(mmss(durata(x)))}</span>
          <span class="to">${esc(oraDi(x.inizio))}–${esc(oraDi(x.fine))}</span>
          <button class="tdel" data-scorda="${esc(x.id)}" title="Togli questa riga">✕</button>
        </div>`).join("");
      return `
        <div class="sec">
          ${t ? `
            <div class="tnow">
              <span class="tbig">${esc(mmss(durata(t)))}</span>
              <span class="tlab">${esc(t.titolo)}${t.paz ? ` · ${esc(t.paz)}` : ""}</span>
              <button class="btn primary" id="tstop2">⏹ Ferma</button>
            </div>` : `
            <div class="lbl">Cosa stai facendo${chi ? ` · ${esc(chi)}` : ""}</div>
            <div class="tpres">${preset}</div>
            <div class="tlibero">
              <input id="tlib" placeholder="…oppure scrivilo" maxlength="60" aria-label="Attività">
              <button class="mini" id="tavvia">▶ Avvia</button>
            </div>`}
          <div class="lbl">Registrati (${chiusi.length})${chiusi.length ? `<button class="mini" id="texp">⬇ Esporta</button><span class="ttot">totale ${esc(mmss(tot))}</span>` : ""}</div>
          <div class="tlist">${righe || `<div class="hint">Ancora niente. Avvia un cronometro qui sopra.</div>`}</div>
          <div class="hint">Non si salvano i secondi passati, si salva l'istante di inizio: ricaricare
            la pagina o riavviare il browser non cambia il conto. Restano una settimana, su questo computer.</div>
        </div>`;
    }

    // EO — un tocco copia l'esame obiettivo generale. Sotto, una tendina con
    // le aggiunte per caso: sceglierne una la copia subito, e la lascia
    // scritta qui perché si veda cosa è finito negli appunti.
    viewEo() {
      const voci = eoVoci();
      const base = voci.base;
      const sel = voci[this.eoSel] ? this.eoSel : "";
      const scelta = sel ? voci[sel] : null;
      const opz = (gruppo, etichetta) => {
        const l = Object.entries(voci).filter(([, v]) => v.gruppo === gruppo);
        if (!l.length) return "";
        return `<optgroup label="${esc(etichetta)}">${l.map(([k, v]) =>
          `<option value="${esc(k)}"${k === sel ? " selected" : ""}>${esc(v.nome)}</option>`).join("")}</optgroup>`;
      };
      if (!base && !Object.keys(voci).length) return `<div class="hint">Modelli di EO non disponibili in questa versione.</div>`;
      return `
        <div class="sec">
          <div class="lbl">Esame obiettivo</div>
          ${base ? `
            <div class="drow">
              <button class="dcopia" data-eocopy="base" title="Copia negli appunti l'esame obiettivo generale"
                      aria-label="Copia l'esame obiettivo generale">
                <span class="dnome">${esc(base.nome)}</span>
                <span class="dmeta">${esc(base.meta)}</span><span class="dico">⧉</span>
              </button>
            </div>` : ""}
          <div class="lbl">Aggiungi per caso</div>
          <select class="res" id="eocaso" aria-label="Aggiunta di esame obiettivo da copiare">
            <option value="">Scegli: si copia da sé…</option>
            ${opz("casi", "Casi")}
            ${opz("frasi", "Frasi pronte")}
          </select>
          <div class="drow eoazione" ${scelta ? "" : "hidden"}>
            <button class="dcopia" data-eocopy="${esc(sel)}" id="eoricopia" title="Copia di nuovo questo testo">
              <span class="dnome">Copia di nuovo</span><span class="dico">⧉</span>
            </button>
          </div>
          <div class="eotxt" id="eotxt" ${scelta ? "" : "hidden"}>${esc(scelta ? scelta.testo : "")}</div>
          <div class="hint">Prima l'EO generale, poi l'aggiunta del caso: due incollate. I testi restano
            uguali per tutti i pazienti — quello che riguarda questo paziente si scrive in cartella.</div>
        </div>`;
    }

    // Un modulo in elenco: un tocco lo apre e parte la stampa. Lo stesso per i
    // consensi e per i moduli della dimissione.
    rigaModulo(c) {
      return `<button class="crow" data-cons="${esc(c.k)}" title="${esc(c.esteso)}">
          <span class="cnome">${esc(c.nome)}</span>
          ${c.pagine > 1 ? `<span class="cpag" title="Esce così tanta carta">${esc(String(c.pagine))} pagine</span>` : ""}
          <span class="cgo">🖨 apri e stampa</span>
        </button>`;
    }
    notaModuli() {
      return hasExt() || DEMO
        ? "I moduli sono dentro l'estensione: si aprono anche se il gestionale è lento o giù, e nessuna richiesta esce dal computer."
        : "Servono i moduli dell'estensione: con il preferito (bookmarklet) questa sezione non ha i PDF.";
    }

    // Solo i consensi da firmare. Le deleghe per il ritiro (esami, referto RX,
    // cartella e CD) si danno al paziente quando va a casa: stanno nella
    // schermata Dimissioni, dove servono.
    viewConsensi() {
      const consensi = CONSENSI.filter((c) => !c.gruppo);
      return `
        <div class="sec">
          <div class="lbl">Moduli di consenso (${consensi.length})</div>
          <div class="dlist">${consensi.map((c) => this.rigaModulo(c)).join("")}</div>
          <div class="hint">${esc(this.notaModuli())}</div>
        </div>`;
    }

    // Import is a paste screen, not a window.prompt: a 20 KB JSON in a
    // one-line browser dialog cannot be read, checked or corrected.
    viewDimImport() {
      return `
        <div class="sec">
          <div class="lbl">Importa i fogli
            <button class="mini" id="dimimpok">⤒ Importa</button>
          </div>
          <textarea class="dedit" id="dimimparea" spellcheck="false"
                    placeholder="Incolla qui il JSON esportato con ⬇ JSON" aria-label="JSON dei fogli di dimissione"></textarea>
          <div class="hint">Entrano solo i testi diversi dagli originali: gli altri restano come sono.</div>
        </div>`;
    }

    viewReferto() {
      const e = this.esiti.find((x) => x.id === this.viewId);
      if (!e) return `<div class="hint">Referto non disponibile.</div>`;
      const t = tabStore.get(this.txtKey(e.id), null);
      const righe = (t && t.righe) || [];
      return `
        <div class="sec">
          <div class="lbl">${esc(e.when)} · ${esc(shortLabel(e.label))}
            <button class="mini" id="copytxt">⧉ Copia</button><button class="mini" id="apripdf">↗ PDF</button></div>
          <div class="reftxt">${righe.map((r) => `<div class="rt">${esc(r)}</div>`).join("") || `<div class="hint">Nessun testo.</div>`}</div>
        </div>`;
    }

    async openReferto(id) {
      const r = this.esiti.find((x) => x.id === id);
      if (!r) return;
      if ((this.refCache || {})[id] && hasExt()) {          // saved copy → instant, no server
        const got = await ask({ t: "getRef", id, ep: this.episodeId });
        if (got && got.ok && got.data) {
          const bin = atob(got.data);
          const arr = new Uint8Array(bin.length);
          for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
          const url = URL.createObjectURL(new Blob([arr], { type: "application/pdf" }));
          openTab(url, "_blank");
          setTimeout(() => URL.revokeObjectURL(url), 60000);
          return;
        }
      }
      const name = "psaRef_" + String(id).replace(/\W/g, ""); // else its own tab, reused on re-click
      const w = openTab("", name);
      if (!w) { this.message = "Consenti i popup per aprire i referti."; this.render(); return; }
      let blank = true;
      try { blank = !w.location.href || w.location.href === "about:blank"; } catch { blank = false; }
      if (blank) w.location.href = r.url;
      try { w.focus(); } catch { /* ignore */ }
      const open = new Set(tabStore.get(this.refKey(), []));
      open.add(id);
      tabStore.set(this.refKey(), [...open]);
      this.render();
      // Qui prima si rileggeva il PDF per tenerne una copia: una seconda
      // richiesta per un documento che è già sullo schermo del medico. Per
      // tenerne una copia c'è «⬇ Salva referti», che è una cosa che si chiede.
    }

    async resetReferti() {
      for (const id of tabStore.get(this.refKey(), [])) {
        try { openTab("", "psaRef_" + String(id).replace(/\W/g, ""))?.close(); } catch { /* ignore */ }
      }
      tabStore.set(this.refKey(), []);
      if (hasExt()) await ask({ t: "clearRef" });
      this.refCache = {}; this.refBusy = {};
      this.render();
    }

    // Copy the log for reporting. The quesito is the only clinical text that
    // can end up in it, so it is masked out before leaving the page.
    async copyLog() {
      const head = [`PS Assist ${VERSION} · pagina ${this.pageType}`, `${navigator.userAgent}`, `${new Date().toLocaleString("it-IT")}`, ""].join("\n");
      const text = head + this.logLines.join("\n").replace(/(quesito[^:]*:\s*)"[^"]*"/gi, '$1"…"');
      const ok = await copiaTesto(text);
      const b = this.root.querySelector("#copylog");
      segnaCopia(b, ok);
    }

    // full values of one accesso, inside the panel
    // Two things the doctor must never discover by himself: a name this
    // program does not know (its abbreviation would be a guess) and a row it
    // refused to read. Both are declared, with the names, and nothing is
    // hidden — the values are all on screen anyway.
    avvisoNomi(rows, scartate) {
      const inattesi = nomiInattesi(rows);
      const amb = sigleAmbigue(rows);
      const doppi = (rows || []).filter((r) => r.nome && amb.has(chiaveAmbigua(r))).map((r) => r.nome).filter((n, i, a) => a.indexOf(n) === i);
      const persi = (scartate || []).filter((x) => x && x.nome);
      // due nomi che si abbrevierebbero uguale sono GIÀ scritti per esteso in
      // tabella: non meritano un avviso a ogni emocromo, solo l'elenco «quali»
      if (!inattesi.length && !persi.length) return "";
      const pezzi = [];
      if (inattesi.length) pezzi.push(`${inattesi.length} ${inattesi.length === 1 ? "nome non in elenco" : "nomi non in elenco"}: scritti per esteso`);
      if (persi.length) pezzi.push(`${persi.length} ${persi.length === 1 ? "riga non letta" : "righe non lette"}`);
      const elenco = [
        inattesi.length ? "Non in elenco: " + inattesi.join(", ") : "",
        doppi.length ? "Stessa abbreviazione: " + doppi.join(", ") : "",
        persi.length ? "Non lette: " + persi.map((x) => `${x.nome} = ${x.valore}`).join(" · ") : "",
      ].filter(Boolean).join("\n");
      return `<div class="avvnomi" title="${esc(elenco)}">
          <span class="avvi">!</span><span>${esc(pezzi.join(" · "))}</span>
          <button class="avvb" id="avvnomi" type="button">${this.mostraNomi ? "nascondi" : "quali"}</button>
        </div>${this.mostraNomi ? `<div class="avvlista">${esc(elenco)}</div>` : ""}`;
    }

    async openEsito(id) {
      const e = this.esiti.find((x) => x.id === id);
      const tipo = e ? refertoTipo(e) : "altro";
      // a report whose text we could not read must never trap the doctor:
      // it falls back to opening the document
      if ((tipo === "rx" || tipo === "ecg") && this.refBusy?.[id] === undefined) return this.apriTesto(id);
      return this.openReferto(id);
    }

    // One tap re-reads EVERY open draw, paced one request at a time: the manual
    // rehearsal of a future automatic refresh — same read, same honesty (an
    // empty or dead page never replaces values already held). Reported draws
    // (storico) are skipped: their page no longer answers.
    async reloadTuttiValori() {
      if (this._refreshAll) return;
      const targets = this.esiti.filter((e) => e.kind === "valori" && !e.storico);
      if (!targets.length) return;
      this._refreshAll = { done: 0, total: targets.length };
      this.refBusy = this.refBusy || {};
      for (const e of targets) this.refBusy[e.id] = true;
      this.render();
      let cambiati = 0;
      try {
      for (const e of targets) {
        const key = this.risKey(e.id);
        const prima = JSON.stringify((tabStore.get(key, null) || {}).rows || []);
        try {
          const mai = !tabStore.get(this.vistoKey(e.id), null);
          const rows = await this.leggiPrelievo(e, { baseline: mai });
          this.rottiTab.delete(e.id);
          if (rows && JSON.stringify(rows) !== prima) cambiati++;
          // una riga nel Registro per prelievo: quando la tabella non torna,
          // qui si vede cosa è stato letto e cosa non ha una data per entrarci
          const inTabella = rows && rows.length ? prelievoComeTabella(risMeta(e), rows, "") : null;
          this.log(`${now()}  ${e.when || "senza data"} · ${shortLabel(e.label)}: ${rows ? rows.length : 0} valori${
            inTabella ? ` → colonna ${inTabella.date[0].ignota ? "«?» (il gestionale non dà data e ora)" : inTabella.date[0].label}` : ""}`);
        } catch (err) {
          this.rottiTab.add(e.id);   // lo dice la schermata, non solo il Registro
          this.log(`${now()}  ${shortLabel(e.label)}: valori non aggiornati (${err?.head || err?.message || err})`);
        }
        this.refBusy[e.id] = false;
        this._refreshAll.done++;
        this.render();
        await sleep(PACE_MS).catch(() => {});
      }
      } finally {
        // come per «Salva referti»: senza il finally «↻ Aggiorna» resta
        // disabilitato per sempre alla prima eccezione
        this._refreshAll = null;
        for (const e of targets) this.refBusy[e.id] = false;
      }
      const letti = targets.filter((e) => !this.rottiTab.has(e.id)).length;
      this.log(`${now()}  letti ${letti} prelievi su ${targets.length}${cambiati ? `, ${cambiati} con valori nuovi` : ", nessun valore nuovo"}`);
      this.render();
    }

    // Values ready before he asks: the 2-line preview is the point of Esiti.
    // UNA lettura di un prelievo, usata da tutti: aprirlo, rileggerlo,
    // ↻ Aggiorna, e il precarico. Prima erano quattro copie della stessa
    // sequenza con quattro politiche d'errore diverse — ed è da lì che
    // veniva un prelievo rotto riletto a ogni ricarico di pagina.
    async leggiPrelievo(e, { baseline = false } = {}) {
      const key = this.risKey(e.id);
      const { doc } = await fetchDoc(e.url, {});
      const { rows, scartate } = parseRisultati(doc);
      const cf = cfImpronta(doc);
      // una finestra che non risponde più non cancella quello che sapevamo
      if (!rows.length && (tabStore.get(key, null) || {}).rows?.length) {
        this.log(`${now()}  la finestra Risultati non risponde più: tengo i valori già letti`);
        return null;
      }
      tabStore.set(key, { ts: Date.now(), rows, scartate, cf, meta: risMeta(e) });
      // in scheda PRIMA di rileggerla, o la riga «Storico» negli Esiti
      // comparirebbe solo alla prossima visita. Un archivio che fallisce non
      // è un prelievo non letto: i valori sono già qui sopra.
      await this.archiviaPrelievo(e, rows, cf, scartate).catch((err) => this.log(`${now()}  prelievo non archiviato (${err?.message || err})`));
      if (baseline) this.segnaVisto(e.id, rows);   // prima lettura: è il riferimento
      // coi valori arriva il codice fiscale: adesso la scheda clinica del
      // portale si può attribuire (o escludere) con certezza — e il prelievo
      // appena letto è già dentro
      this.caricaStorico();
      return rows;
    }

    // Aprire un paziente NON legge niente. I valori si leggono quando li
    // chiedi: aprendo un prelievo, o col bottone «Carica i valori» che li
    // prende tutti, uno alla volta. Un clic su un paziente non è una
    // richiesta di leggere il laboratorio.
    daLeggere() {
      return this.esiti.filter((x) => x.kind === "valori"
        && !tabStore.get(this.risKey(x.id), null) && !this.rottiTab.has(x.id));
    }

    // Le risorse di QUESTA sede, lette dalla pagina: i link «Richieste
    // Laboratorio/Radiologia» (paziente), l'indirizzo (nuova richiesta), la
    // tendina (esami). Vuoto = non si sa, e allora si mostra tutto.
    risorseQui() {
      const ids = new Set();
      const da = (u) => (param(u || "", "RISORSE") || "").split(",").filter(Boolean).forEach((x) => ids.add(x));
      if (this.pageType === "patient") { da(this.entry?.labUrl); da(this.entry?.radioUrl); }
      else da(location.href);
      if (this.pageType === "exam") examModel(document, location.href).resOptions.forEach((o) => ids.add(o.value));
      return ids;
    }

    viewBrowse(cat) {
      const q = (this.acq || "").trim().toUpperCase();
      let drop = "";
      if (q.length >= 2) {
        // I nomi che si dicono in reparto non sono quelli del laboratorio:
        // «PCR» è «PROTEINA C REATTIVA», che scrivendo PCR non si trovava —
        // e restava solo la PCR POC.
        const alias = ALIAS_RICERCA[q] || [];
        // solo le risorse di questa sede: senza, ogni esame compariva due
        // volte, una per sede, con un codice che qui non vale
        // (se di questa sede il catalogo non conosce ancora niente, si mostra
        // tutto: meglio un doppione che una ricerca vuota)
        const noti = [...this.risorseQui()].filter((r) => cat[r]);
        const qui = new Set(noti);
        const hits = [];
        for (const [res, v] of Object.entries(cat)) {
          if (qui.size && !qui.has(res)) continue;
          for (const [code, label] of Object.entries(v.items || {})) {
            const L = label.toUpperCase();
            const perAlias = alias.some((x) => L.startsWith(x));
            if (perAlias || L.includes(q)) hits.push({ res, code, label, perAlias, poc: ePoc(label) || ePoc(v.label) });
          }
        }
        // prima il nome che il medico intendeva, e fra quelli il laboratorio
        // prima del POC; poi chi comincia con quello che ha scritto
        const rango = (h) => (h.perAlias ? 0 : 1) * 10 + (h.poc ? 1 : 0);
        hits.sort((a, b) => rango(a) - rango(b)
          || a.label.toUpperCase().indexOf(q) - b.label.toUpperCase().indexOf(q)
          || ordineRisorsa(a.res, cat) - ordineRisorsa(b.res, cat)
          || a.label.localeCompare(b.label));
        drop = `<div class="acdrop">${
          hits.slice(0, 12).map((h) => `<button class="acitem ${this.isSel(h.res, h.code) ? "on" : ""}" data-res="${esc(h.res)}" data-code="${esc(h.code)}" title="${esc(h.label)}">
            <span class="acnm">${esc(h.label)}</span><span class="actag">${esc(risorsaCorta(h.res, cat))}</span></button>`).join("")
          || `<div class="acempty">Nessun esame trovato</div>`}</div>`;
      }
      return `<div class="ac"><input id="acq" type="search" autocomplete="off" placeholder="altri esami…" value="${esc(this.acq || "")}">${drop}</div>`;
    }

    viewRunning() {
      const steps = this.runData?.steps || [];
      const total = steps.length;
      const doneN = steps.filter((s) => s.status === "ok").length;
      const stepHtml = steps.map((s) => `
        <div class="step ${esc(s.status === "pending" ? "" : s.status)}">
          <span class="ic">${s.status === "ok" ? "✓" : s.status === "running" ? "⟳" : s.status === "fail" ? "✕" : s.status === "skipped" ? "–" : "·"}</span>
          <span>${esc(s.label)}</span><small>${esc(s.note || "")}</small>
        </div>`).join("");
      const qui = (document.title || "").trim();
      return `
        ${this.runPatient ? `<div class="idline" style="margin-top:0">Operazione per <b>${esc(this.runPatient)}</b></div>` : ""}
        ${this.runPatient && qui && qui !== this.runPatient ? `<div class="banner warn">Stai guardando <b>${esc(qui)}</b>: questi esami sono di <b>${esc(this.runPatient)}</b> e vanno alla sua richiesta.</div>` : ""}
        <div class="sec"><div class="lbl">In corso — passo ${Math.min(doneN + 1, total)} di ${total}</div><div class="steps">${stepHtml}</div></div>
        <details class="reg" open><summary>Registro <button class="mini" id="copylog" title="Copia il registro negli appunti (il quesito viene omesso)">⧉ Copia</button></summary><div class="log" aria-live="polite">${esc(this.logLines.join("\n"))}</div></details>
        <div class="commit">
          <button class="btn stop" id="stopbtn">INTERROMPI (Esc)</button>
  
        </div>
      `;
    }

    viewResult() {
      const ok = this.runState === "done";
      const cls = ok ? "ok" : this.runState === "stopped" ? "warn" : "err";
      const m = this.message || {};
      const head = typeof m === "string" ? "" : m.head;
      const bodyTxt = typeof m === "string" ? m : m.body;
      const steps = (this.runData?.steps || []).map((s) => `
        <div class="step ${esc(s.status === "pending" ? "" : s.status)}">
          <span class="ic">${s.status === "ok" ? "✓" : s.status === "fail" ? "✕" : s.status === "skipped" ? "–" : "·"}</span>
          <span>${esc(s.label)}</span><small>${esc(s.note || "")}</small>
        </div>`).join("");
      const listUrl = this.runData?.finishedListUrl || this.runData?.lastListUrl;
      // già sul carrello di quella richiesta (ci ha portato l'errore): niente bottone per andarci
      const giaQui = !!listUrl && this.pageType === "exam" && param(listUrl, "RICHIESTA_ID") === param(location.href, "RICHIESTA_ID");
      // dopo un errore: rifare i mancanti si può solo dov'è sicuro (riprovaQui)
      const riprova = this.riprovaQui() ? this.riprova.mancanti.length : 0;
      // un errore si annulla; un giro che riprenderà da solo no (lì resta «Torna al pannello»)
      const annulla = this.runState === "fail" && !tabStore.get(CORSA, null);
      // Fermato a metà: che cosa c'è già in carrello e che cosa va aggiunto a
      // mano dal gestionale — l'elenco che serve per finire.
      const nel = (typeof m === "object" && m.nel) || [], mancano = (typeof m === "object" && m.mancano) || [];
      const controllare = (typeof m === "object" && m.controllare) || [];
      const liste = !ok && (nel.length || mancano.length || controllare.length) ? `
        <div class="sec"><div class="lbl">Nel carrello (${nel.length})</div><div class="chips">${
          nel.map((x) => `<span class="chip nel">${esc(x)}</span>`).join("") || `<span class="hint">nessuno</span>`}</div></div>
        ${controllare.length ? `<div class="sec"><div class="lbl">Da controllare nel carrello (${controllare.length})</div><div class="chips">${
          controllare.map((x) => `<span class="chip controlla">${esc(x)}</span>`).join("")}</div>
          <div class="hint">${riprova ? "Mandati, ma non visti in carrello: «Riprova» non li rimanda — guardali nel carrello prima."
            : "Mandati, ma non visti in carrello: guarda se ci sono prima di aggiungerli — mai due volte."}</div></div>` : ""}
        <div class="sec"><div class="lbl">Da aggiungere a mano (${mancano.length})</div><div class="chips">${
          mancano.map((x) => `<span class="chip manca">${esc(x)}</span>`).join("") || `<span class="hint">nessuno</span>`}</div></div>` : "";
      return `
        ${this.runPatient ? `<div class="idline" style="margin-top:0">Operazione per <b>${esc(this.runPatient)}</b></div>` : ""}
        <div class="banner ${cls}">${head ? `<b>${esc(head)}</b>` : ""}${esc(bodyTxt || "")}</div>
        ${liste}
        <div class="sec"><div class="steps">${steps}</div></div>
        <details class="reg" open><summary>Registro <button class="mini" id="copylog" title="Copia il registro negli appunti (il quesito viene omesso)">⧉ Copia</button></summary><div class="log" aria-live="polite">${esc(this.logLines.join("\n"))}</div></details>
        <div class="commit">
          ${riprova ? `<button class="btn primary" id="riprova" title="${this.riprova.rid
            ? "Manda solo gli esami mai partiti, in questa stessa richiesta: quelli già in carrello non si rimandano"
            : "Nessuna richiesta era nata: rifà il giro da capo, con gli stessi esami"}">↻ Riprova i mancanti (${riprova})</button>`
            : (listUrl || this.carrelloDaAprire) && !giaQui && (!ok || this.runRipreso || this.carrelloDaAprire) ? `<button class="btn primary" id="openlist">${
            ok ? "Apri il carrello" : "Apri il carrello e controlla"}</button>` : ""}
          ${annulla ? `<button class="btn ghost" id="annulla" title="Lascia questo giro: torni alle Richieste col quesito e gli esami scelti">Annulla</button>`
            : `<button class="btn ghost" id="reset">Torna al pannello</button>`}
        </div>
      `;
    }

    // Ridurre alla pill e riaprire. Ridurre chiude anche il menu e la
    // Modifica della stanza; il fuoco va sulla pill (e al riaprire sul titolo),
    // così la tastiera non finisce nel gestionale coperto.
    riduci() {
      if (this.collapsed) return;
      this.collapsed = true; this.menuAperto = false; this.stanzaEdit = false;
      store.set("collapsed", true);
      this.render();
      this.root.querySelector("#expand")?.focus({ preventScroll: true });
    }
    apri() {
      this.collapsed = false; this.avvisoPill = "";
      // aperta la finestra, la striscia ha detto quello che doveva
      if (this.striscia && !this.striscia.onTap) { clearTimeout(this._tStriscia); this.striscia = null; }
      store.set("collapsed", false);
      this.render();
      this.root.querySelector(".card")?.focus({ preventScroll: true });   // la tastiera nel pannello, non nel gestionale coperto
    }
    // Copiato un testo da incollare nel gestionale (EO, dimissioni, referto):
    // la finestra si toglie di mezzo da sola, la pill dice che è pronto.
    dopoCopia(ok) {
      if (!ok || this.collapsed || this.runState) return;
      setTimeout(() => {
        if (this.collapsed || this.runState) return;
        this.avvisoPill = "✓ Copiato · incolla";
        this.riduci();
        setTimeout(() => { if (this.avvisoPill) { this.avvisoPill = ""; if (this.collapsed) this.render(); } }, 5000);
      }, 650);
    }

    // Trascinare: la pill (ridotta) si sposta dove vuoi e resta lì; la
    // finestra (aperta) si sposta intera dall'intestazione. Un clic vero
    // sulla pill la apre comunque; il doppio clic sull'intestazione rimette
    // la finestra al centro.
    attachDrag(el) {
      el.addEventListener("pointerdown", (e) => {
        if (e.button !== 0 || e.target.closest(".iconbtn, .tchip, .menuw, button:not(#expand), input, a, [data-rz]")) return;
        try { el.setPointerCapture(e.pointerId); } catch { /* niente */ }
        const wrap = this.root.querySelector(".wrap");
        const r = wrap.getBoundingClientRect();
        const sx = e.clientX, sy = e.clientY, ox = r.left, oy = r.top;
        const finestra = wrap.classList.contains("win");
        let moved = false;
        const mm = (ev) => {
          if (!ev.buttons) return up();   // il bottone è stato lasciato fuori dalla finestra
          if (!moved && Math.abs(ev.clientX - sx) + Math.abs(ev.clientY - sy) < 5) return;
          moved = true;
          const vw = window.innerWidth, vh = window.innerHeight;
          if (finestra) {
            const g = geometriaFinestra(this.win);
            this.win = geometriaFinestra({ ...g, x: (ox + ev.clientX - sx) / vw, y: (oy + ev.clientY - sy) / vh });
            wrap.style.left = this.win.x * 100 + "vw";
            wrap.style.top = this.win.y * 100 + "vh";
          } else {
            this.pillPos = {
              left: Math.max(0, Math.min(vw - 80, ox + ev.clientX - sx)),
              top: Math.max(0, Math.min(vh - 48, oy + ev.clientY - sy)),
            };
            wrap.style.left = this.pillPos.left + "px";
            wrap.style.top = this.pillPos.top + "px";
            wrap.style.right = "auto";
          }
        };
        const up = () => {
          window.removeEventListener("pointermove", mm, true);
          window.removeEventListener("pointerup", up, true);
          window.removeEventListener("pointercancel", up, true);
          if (moved) {
            if (finestra) store.set("win.v1", this.win); else store.set("pillpos.v1", this.pillPos);
            this._justDragged = true;
            setTimeout(() => { this._justDragged = false; }, 0);
          }
        };
        window.addEventListener("pointermove", mm, true);
        window.addEventListener("pointerup", up, true);
        window.addEventListener("pointercancel", up, true);
      });
    }

    // Ridimensionare da ogni bordo e da ogni angolo, come una finestra vera.
    attachResize(el) {
      el.addEventListener("pointerdown", (e) => {
        if (e.button !== 0) return;
        e.preventDefault(); e.stopPropagation();
        const d = el.getAttribute("data-rz") || "se";
        try { el.setPointerCapture(e.pointerId); } catch { /* niente */ }
        const wrap = this.root.querySelector(".wrap");
        const r = wrap.getBoundingClientRect();
        const sx = e.clientX, sy = e.clientY;
        const mm = (ev) => {
          if (!ev.buttons) return up();
          const vw = window.innerWidth, vh = window.innerHeight;
          const dx = ev.clientX - sx, dy = ev.clientY - sy;
          let { left, top, width, height } = r;
          if (d.includes("e")) width = r.width + dx;
          if (d.includes("s")) height = r.height + dy;
          if (d.includes("w")) { width = r.width - dx; left = r.left + dx; }
          if (d.includes("n")) { height = r.height - dy; top = r.top + dy; }
          // mai più piccola del minimo: il bordo che si tira si ferma lì
          if (width < 380) { if (d.includes("w")) left -= 380 - width; width = 380; }
          if (height < 320) { if (d.includes("n")) top -= 320 - height; height = 320; }
          this.win = geometriaFinestra({ x: left / vw, y: top / vh, w: Math.min(width, vw) / vw, h: Math.min(height, vh) / vh });
          wrap.style.left = this.win.x * 100 + "vw"; wrap.style.top = this.win.y * 100 + "vh";
          wrap.style.width = this.win.w * 100 + "vw"; wrap.style.height = this.win.h * 100 + "vh";
        };
        const up = () => {
          window.removeEventListener("pointermove", mm, true);
          window.removeEventListener("pointerup", up, true);
          window.removeEventListener("pointercancel", up, true);
          store.set("win.v1", this.win);
        };
        window.addEventListener("pointermove", mm, true);
        window.addEventListener("pointerup", up, true);
        window.addEventListener("pointercancel", up, true);
      });
    }

    bind() {
      const $ = (s) => this.root.querySelector(s);
      $("#expand")?.addEventListener("click", () => {
        // aprire la striscia di un giro in corso è un gesto di adesso, non una
        // preferenza: finito il giro il pannello torna com'era
        if (this.runState === "running") { this.collapsed = false; this.render(); return; }
        if (this._justDragged) return; // it was a drag, not a click
        // durante la stampa la striscia porta i suoi comandi, non il pannello
        if (this.striscia && this.striscia.onTap) { this.striscia.onTap(); return; }
        this.apri();
      });
      $("#strstop")?.addEventListener("click", () => this.striscia?.onStop?.());
      $("#strazione")?.addEventListener("click", () => this.striscia?.azione?.fn?.());
      $("#collapse")?.addEventListener("click", () => this.riduci());
      $("#menubtn")?.addEventListener("click", (e) => { e.stopPropagation(); this.menuAperto = !this.menuAperto; this.render(); });
      // due posizioni pronte: al centro (85%), o in colonna a destra col gestionale visibile
      const metti = (g) => { this.win = g; store.set("win.v1", g); this.menuAperto = false; this.render(); };
      $("#wincentra")?.addEventListener("click", () => metti(null));
      $("#winaffianca")?.addEventListener("click", () => metti({ ...AFFIANCA }));
      this.root.querySelectorAll("[data-rz]").forEach((el) => this.attachResize(el));
      // doppio clic sull'angolo o sull'intestazione: di nuovo al centro, all'85%
      const alCentro = (e) => { e.stopPropagation(); this.win = null; store.set("win.v1", null); this.render(); };
      $("#rsz")?.addEventListener("dblclick", alCentro);
      const hd = $("#draghd");
      if (hd) {
        this.attachDrag(hd);
        hd.addEventListener("dblclick", (e) => { if (!e.target.closest("button")) alCentro(e); });
      }
      const pill = $("#expand");
      if (pill) this.attachDrag(pill);
      $("#stopbtn")?.addEventListener("click", () => this.stop());
      $("#reset")?.addEventListener("click", () => { this.runState = null; this.runData = null; this.message = null; this.carrelloDaAprire = null; this.render(); });
      $("#annulla")?.addEventListener("click", () => this.annulla());
      $("#riprova")?.addEventListener("click", () => this.riprovaMancanti());
      $("#openlist")?.addEventListener("click", () => {
        if (this.carrelloDaAprire) return this.carrelloDaAprire();   // la navigazione rimandata, col suo passaggio di consegne
        const u = this.runData?.finishedListUrl || this.runData?.lastListUrl;
        if (!u) return;
        if (this.runState === "fail") this.consegnaErrore?.();   // il resoconto (e «Riprova») viaggia col carrello
        nav(u);
      });

      $("#back")?.addEventListener("click", () => this.setView(
        this.view === "referto" ? "esiti"
        : this.view === "dimtesto" || this.view === "dimimport" ? "dimissioni"
        : "home"));
      this.root.querySelectorAll("[data-seg]").forEach((b) => b.addEventListener("click", () => this.setView(b.getAttribute("data-seg"))));
      $("#archtog")?.addEventListener("click", () => { this.mostraArch = !this.mostraArch; this.render(); });
      this.root.querySelectorAll("[data-unarch]").forEach((b) => b.addEventListener("click", () => {
        archiviaPaziente(b.getAttribute("data-unarch"), false);
        this.render();
      }));
      this.root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => {
        // un tasto che cancella davvero chiede una volta, e non di nascosto
        if (b.dataset.sicuro !== "1") {
          b.dataset.sicuro = "1"; b.textContent = "cancello?";
          setTimeout(() => { if (b.isConnected && b.dataset.sicuro === "1") { b.dataset.sicuro = ""; b.textContent = "🗑"; } }, 4000);
          return;
        }
        const ep = b.getAttribute("data-del");
        const p = pazientiArchiviati().find((x) => x.ep === ep);
        eliminaPaziente(ep, p?.pk || "", p?.name || "");
        this.message = { ok: `Eliminato tutto di ${p?.name || "quel paziente"}.` };
        this.render();
      }));
      $("#verbtn")?.addEventListener("click", () => { this.showLog = !this.showLog; this.menuAperto = false; this.render(); });
      $("#risall")?.addEventListener("click", () => this.caricaValori());
      // «Letto»: da qui in poi le novità si contano da adesso, per tutti i prelievi
      $("#letto")?.addEventListener("click", () => {
        for (const e of this.esiti) if (e.kind === "valori") this.marcaLetto(e.id);
        this.render();
      });
      $("#apripdf")?.addEventListener("click", () => { if (this.viewId) this.openReferto(this.viewId); });
      $("#portapri")?.addEventListener("click", async () => {
        const r = await ask({ t: "apriImpostazioni" }).catch(() => null);
        this.message = r && r.ok
          ? { ok: "Si è aperta la pagina delle impostazioni: incolla lì l'indirizzo del portale." }
          : "Non riesco ad aprire le impostazioni: aprile da chrome://extensions → PS Assist → Dettagli → Opzioni.";
        this.render();
      });
      // un tocco su un valore lo segna (giallo → arancio → niente): si cambia
      // la cella sul posto, senza ridisegnare, così la tabella non scatta
      const tabella = this.root.querySelector(".sttab");
      if (tabella) tabella.addEventListener("click", (ev) => {
        const td = ev.target?.closest?.("td[data-cella]");
        if (!td) return;
        const stato = (td.classList.contains("marca2") ? 2 : td.classList.contains("marca1") ? 1 : 0) + 1;
        const prossimo = stato > 2 ? 0 : stato;
        if (!scriviSegno(this.chiaveNota(), td.getAttribute("data-cella"), prossimo)) {
          // un salvataggio rifiutato si dice, non si finge
          this.message = "Il browser non ha accettato il segno: memoria piena o bloccata.";
          this.render();
          return;
        }
        td.classList.remove("marca1", "marca2");
        if (prossimo) td.classList.add("marca" + prossimo);
      });
      const filtra = () => { this.soloAlterati = !this.soloAlterati; this.render(); };
      $("#storfiltro")?.addEventListener("click", filtra);
      $("#avvnomi")?.addEventListener("click", () => { this.mostraNomi = !this.mostraNomi; this.render(); });
      $("#valreset")?.addEventListener("click", () => this.resetValori());
      $("#refdiag")?.addEventListener("click", async () => {
        const b = this.root.querySelector("#refdiag");
        segnaCopia(b, await copiaTesto(diagnosiTesto(this.diagnosi)));
      });
      this.root.querySelectorAll("[data-dcopy]").forEach((b) => b.addEventListener("click", async () => {
        const d = dimissioni()[b.getAttribute("data-dcopy")];
        if (!d) return;
        const ico = b.querySelector(".dico");
        let ok = false;
        ok = await copiaTesto(d.testo);
        this.dopoCopia(ok);
        b.classList.toggle("fatto", ok);
        if (ico) ico.textContent = ok ? "✓ copiato" : "✗ non riuscito";
        setTimeout(() => {
          if (!b.isConnected) return;
          b.classList.remove("fatto");
          if (ico) ico.textContent = "⧉";
        }, 1800);
      }));
      // EO: la riga copia, la tendina copia scegliendo. In tutti e due i casi
      // il testo scelto resta scritto sotto, così si vede cosa si è preso.
      const eoFatto = (b, ok) => {
        const ico = b.querySelector(".dico");
        b.classList.toggle("fatto", ok);
        if (ico) ico.textContent = ok ? "✓ copiato" : "✗ non riuscito";
        setTimeout(() => {
          if (!b.isConnected) return;
          b.classList.remove("fatto");
          if (ico) ico.textContent = "⧉";
        }, 1800);
      };
      this.root.querySelectorAll("[data-eocopy]").forEach((b) => b.addEventListener("click", async () => {
        const v = eoVoci()[b.getAttribute("data-eocopy")];
        if (!v) return;
        const ok = await copiaTesto(v.testo);
        eoFatto(b, ok);
        this.dopoCopia(ok);
      }));
      $("#eocaso")?.addEventListener("change", async (ev) => {
        const k = ev.target.value;
        this.eoSel = k || "";
        const v = eoVoci()[k];
        const txt = this.root.querySelector("#eotxt");
        const riga = this.root.querySelector(".eoazione");
        const btn = this.root.querySelector("#eoricopia");
        if (txt) { txt.textContent = v ? v.testo : ""; txt.hidden = !v; }
        if (riga) riga.hidden = !v;
        if (btn) btn.setAttribute("data-eocopy", k || "");
        if (!v) return;
        this.persistUi();
        if (btn) { const ok = await copiaTesto(v.testo); eoFatto(btn, ok); this.dopoCopia(ok); }
      });
      this.root.querySelectorAll("[data-dedit]").forEach((b) => b.addEventListener("click", () => this.setView("dimtesto", b.getAttribute("data-dedit"))));
      // every keystroke goes into the tab's draft: a re-render, a page change
      // or a mis-click can no longer throw away a rewritten sheet
      const area = this.root.querySelector("#dimarea");
      if (area) area.addEventListener("input", () => tabStore.set(this.dimDraftKey(this.viewId), { ts: Date.now(), testo: area.value }));
      $("#dimcopy")?.addEventListener("click", async () => {
        const b = this.root.querySelector("#dimcopy");
        let ok = false;
        ok = await copiaTesto(area ? area.value : "");
        segnaCopia(b, ok);
        this.dopoCopia(ok);
      });
      $("#dimsave")?.addEventListener("click", () => {
        const d = dimissioni()[this.viewId];
        if (!area || !d) return;
        if (!area.value.trim()) { this.message = "Il testo è vuoto: non lo salvo."; this.render(); return; }
        const scritto = salvaDimissione(this.viewId, d.nome, area.value);
        tabStore.set(this.dimDraftKey(this.viewId), null);
        this.log(`${now()}  foglio di dimissione «${d.nome}» aggiornato`);
        // never say "saved" when the browser refused to write it
        this.setView("dimissioni", null, scritto
          ? { ok: `«${d.nome}» salvato: sarà questo il testo copiato d'ora in poi.` }
          : `«${d.nome}» NON salvato: la memoria di questo browser è piena o bloccata.`);
      });
      $("#dimreset")?.addEventListener("click", (ev) => {
        const b = ev.currentTarget;
        const d = dimissioni()[this.viewId] || {};
        const etichetta = b.textContent;
        // one tap must not be able to destroy a text the doctor wrote
        if (b.dataset.sicuro !== "1") {
          b.dataset.sicuro = "1";
          b.textContent = d.mio ? "Elimino?" : "Confermi?";
          setTimeout(() => { if (b.isConnected && b.dataset.sicuro === "1") { b.dataset.sicuro = ""; b.textContent = etichetta; } }, 4000);
          return;
        }
        const nome = d.nome || this.viewId;
        const scritto = ripristinaDimissione(this.viewId);
        tabStore.set(this.dimDraftKey(this.viewId), null);
        this.setView("dimissioni", null, scritto
          ? { ok: `«${nome}» riportato al testo originale.` }
          : `«${nome}» non ripristinato: la memoria di questo browser è bloccata.`);
      });
      $("#dimexport")?.addEventListener("click", async () => {
        const tutte = dimissioni();
        const mie = store.get(dimKey, {});
        const dati = {};
        for (const [k, v] of Object.entries(tutte)) {
          dati[k] = { nome: v.nome, testo: v.testo };
          // carry the fingerprint of the original this version was forked from,
          // so a re-import keeps knowing when the original moves
          if (mie[k] && mie[k].base) dati[k].base = mie[k].base;
        }
        const testo = JSON.stringify({ app: APP, versione: VERSION, salvato: new Date().toISOString(), dimissioni: dati }, null, 1);
        // the file where downloads are allowed, the clipboard everywhere else:
        // the doctor must end up with the text in his hands either way
        let file = false, appunti = false;
        try {
          const url = URL.createObjectURL(new Blob([testo], { type: "application/json" }));
          const a2 = document.createElement("a");
          a2.href = url; a2.download = "dimissioni.json";
          document.documentElement.appendChild(a2); a2.click(); a2.remove();
          setTimeout(() => URL.revokeObjectURL(url), 20000);
          file = true;
        } catch { /* clipboard below */ }
        appunti = await copiaTesto(testo);
        const b = this.root.querySelector("#dimexport");
        if (b) {
          b.textContent = file && appunti ? "✓ file + appunti" : file ? "✓ dimissioni.json" : appunti ? "✓ negli appunti" : "✗ non riuscito";
          setTimeout(() => { if (b.isConnected) b.textContent = "⬇ JSON"; }, 2500);
        }
      });
      const nota = this.root.querySelector("#nota");
      if (nota) {
        const cresci = () => {
          nota.style.height = "auto";
          nota.style.height = Math.min(nota.scrollHeight, 160) + "px";
        };
        cresci();
        let attesa = null;
        nota.addEventListener("input", () => {
          cresci();
          clearTimeout(attesa);
          attesa = setTimeout(() => {
            const ok = scriviNota(this.chiaveNota(), nota.value);
            const spia = this.root.querySelector("#notaok");
            if (spia) {
              spia.textContent = ok ? "salvata" : "NON salvata";
              spia.classList.toggle("ko", !ok);
              setTimeout(() => { if (spia.isConnected) spia.textContent = ""; }, 1400);
            }
          }, 500);
        });
        // uscire dal campo salva subito: non si perde una riga per un clic
        nota.addEventListener("blur", () => { clearTimeout(attesa); scriviNota(this.chiaveNota(), nota.value); });
      }
      $("#tapri")?.addEventListener("click", () => this.setView("tempi"));
      const ferma = () => { fermaTempo(); this.render(); };
      $("#tstop")?.addEventListener("click", ferma);
      $("#tstop2")?.addEventListener("click", ferma);
      const avvia = (titolo) => {
        if (!String(titolo || "").trim()) return;
        avviaTempo(titolo, this.nomePaziente(), this.episodeId);
        this.setView("tempi");
      };
      this.root.querySelectorAll("[data-avvia]").forEach((b) =>
        b.addEventListener("click", () => avvia(b.getAttribute("data-avvia"))));
      $("#tavvia")?.addEventListener("click", () => avvia(this.root.querySelector("#tlib")?.value));
      $("#tlib")?.addEventListener("keydown", (e) => { if (e.key === "Enter") avvia(e.target.value); });
      this.root.querySelectorAll("[data-scorda]").forEach((b) =>
        b.addEventListener("click", () => { scordaTempo(b.getAttribute("data-scorda")); this.render(); }));
      $("#texp")?.addEventListener("click", () => this.esportaTempi());
      this.root.querySelectorAll("[data-cons]").forEach((b) => b.addEventListener("click", () => {
        const c = CONSENSI.find((x) => x.k === b.getAttribute("data-cons"));
        const url = c && urlConsenso(c);
        if (!url) { this.message = "I moduli ci sono solo con l'estensione."; this.render(); return; }
        this.log(`${now()}  modulo «${c.nome}» aperto per la stampa`);
        openPrintWizard([{ name: c.nome, printer: "stampante normale", url, diretto: true }],
          { title: c.nome, panel: this });
      }));
      $("#dimimport")?.addEventListener("click", () => this.setView("dimimport"));
      $("#dimimpok")?.addEventListener("click", () => {
        const ta = this.root.querySelector("#dimimparea");
        const testo = (ta && ta.value || "").trim();
        if (!testo) { this.message = "Incolla prima il JSON esportato."; this.render(); return; }
        let dims = null;
        try {
          const dati = JSON.parse(testo);
          dims = dati && dati.dimissioni && typeof dati.dimissioni === "object" ? dati.dimissioni : dati;
        } catch (e) {
          this.message = `JSON non valido: ${e.message}`; this.render(); return;
        }
        if (!dims || typeof dims !== "object") { this.message = "Questo file non contiene fogli di dimissione."; this.render(); return; }
        const mie = store.get(dimKey, {});
        let n = 0, uguali = 0, saltati = 0;
        for (const [k, v] of Object.entries(dims)) {
          if (k === "__proto__" || k === "constructor" || k === "prototype") continue;
          if (!dimValido(v) || v.testo.length > 40000 || k.length > 80) { saltati++; continue; }
          const orig = DIMISSIONI[k];
          // a text identical to the shipped one is NOT a change: importing it
          // as an override would freeze that sheet at today's wording forever
          if (orig && v.testo.trim() === orig.testo.trim()) { delete mie[k]; uguali++; continue; }
          if (!(k in mie) && Object.keys(mie).length >= 40) { saltati++; continue; }
          mie[k] = {
            nome: String(v.nome || (orig && orig.nome) || k).slice(0, 80),
            testo: v.testo,
            base: typeof v.base === "string" && v.base ? v.base : (orig ? impronta(orig.testo) : ""),
          };
          n++;
        }
        if (!n && !uguali) { this.message = "Nessun testo valido in questo JSON."; this.render(); return; }
        const scritto = store.set(dimKey, mie);
        this.log(`${now()}  importati ${n} fogli di dimissione`);
        const coda = [uguali ? `${uguali} già uguali all'originale` : "", saltati ? `${saltati} ignorati` : ""].filter(Boolean).join(", ");
        this.setView("dimissioni", null, scritto
          ? { ok: `${n === 1 ? "Importato 1 foglio" : `Importati ${n} fogli`}${coda ? ` (${coda})` : ""}.` }
          : "Import NON salvato: la memoria di questo browser è piena o bloccata.");
      });
      $("#copytxt")?.addEventListener("click", async () => {
        const t = tabStore.get(this.txtKey(this.viewId), null);
        if (!t || !t.righe) return;
        let ok = false;
        ok = await copiaTesto(t.righe.join("\n"));
        const b = this.root.querySelector("#copytxt");
        segnaCopia(b, ok);
        this.dopoCopia(ok);
      });
      this.root.querySelectorAll("[data-go]").forEach((b) => b.addEventListener("click", (ev) => {
        ev.stopPropagation();   // Richieste sits inside the card, which is itself a [data-go]
        this.apriPaziente(b.getAttribute("data-ep"), b.getAttribute("data-go"));
      }));
      $("#goqueued")?.addEventListener("click", () => { if (this.pending) goToQueued(this.pending); });
      $("#confirmnow")?.addEventListener("click", () => {
        // native click → server confirm → print handoff (armed at boot)
        const live = examModel(document, location.href);
        live.confirmButton?.click();
      });
      $("#extreload")?.addEventListener("click", () => {
        try { chrome.runtime.sendMessage("psassist-reload"); } catch { /* not the extension build */ }
      });
      const qEl = $("#q");
      qEl?.addEventListener("input", () => { this._q = qEl.value; this.persistUi(); this.refreshCommit(); });
      const qrxEl = $("#qrx");
      qrxEl?.addEventListener("input", () => { this._qrx = qrxEl.value; this.persistUi(); this.refreshCommit(); });
      this.root.querySelectorAll("[data-q]").forEach((b) => b.addEventListener("click", () => {
        const q = b.getAttribute("data-q");
        // un pacchetto (o un pacchetto da lasciare) cambia anche gli esami: si ridisegna
        if (this.pacchettoDi(q) || this.pacchetto) { this.scegliQuesito(q); this.root.querySelector("#q")?.focus(); return; }
        qEl.value = q; this._q = qEl.value; this.persistUi(); this.refreshCommit(); qEl.focus();
      }));
      this.root.querySelectorAll("[data-preset]").forEach((b) => b.addEventListener("click", () => this.togglePreset(PRESETS[+b.getAttribute("data-preset")])));
      this.root.querySelectorAll(".chip[data-code], .opt[data-code]").forEach((b) => b.addEventListener("click", () => this.toggle(b.getAttribute("data-res"), b.getAttribute("data-code"))));
      this.root.querySelectorAll(".acitem[data-code]").forEach((b) => b.addEventListener("click", () => {
        this.toggle(b.getAttribute("data-res"), b.getAttribute("data-code"));
      }));
      this.root.querySelectorAll("[data-unsel]").forEach((b) => b.addEventListener("click", () => { this.selected.delete(b.getAttribute("data-unsel")); this.persistUi(); this.render(); }));
      const ac = $("#acq");
      if (ac) {
        ac.addEventListener("input", () => { this.acq = ac.value; this.acFocus = true; this.render(); });
        ac.addEventListener("keydown", (e) => {
          if (e.key === "Enter") {
            const first = this.root.querySelector(".acitem[data-code]");
            if (first) { e.preventDefault(); this.toggle(first.getAttribute("data-res"), first.getAttribute("data-code")); }
          } else if (e.key === "Escape") { e.stopPropagation(); this.acq = ""; this.render(); }
        });
        if (this.acFocus) { ac.focus(); ac.setSelectionRange(ac.value.length, ac.value.length); }
      }
      $("#go")?.addEventListener("click", () => this.launch(false));
      $("#goconfirm")?.addEventListener("click", () => this.launch(true));
      this.root.querySelectorAll("[data-print]").forEach((b) => b.addEventListener("click", () => {
        const rid = b.getAttribute("data-print");
        const jobs = printJobsFor(printModel(document, location.href), rid);
        if (jobs.length) openPrintWizard(jobs, { panel: this, title: `Richiesta ${rid}.` });
      }));
      this.root.querySelectorAll("[data-esito]").forEach((b) => b.addEventListener("click", () =>
        this.openEsito(b.getAttribute("data-esito"))));
      $("#refreset")?.addEventListener("click", () => this.resetReferti());
      $("#reflab")?.addEventListener("toggle", (e) => { this.labAperto = e.target.open; });
      $("#refsave")?.addEventListener("click", () => this.saveAllReferti());
      $("#copylog")?.addEventListener("click", (e) => { e.preventDefault(); this.copyLog(); });
      this.bindStanza();
      this.promLega();   // il campo di un promemoria rimasto aperto
    }

    // Patch only the commit zone while the doctor types (a full re-render
    // would steal the textarea focus at every keystroke).
    refreshCommit() {
      const problems = this.computeProblems();
      const go = this.root.querySelector("#go");
      const goc = this.root.querySelector("#goconfirm");
      const n = this.selected.size;
      if (go) go.disabled = !n || !!problems.go.length;
      if (goc) goc.disabled = !n || !!problems.confirm.length;
      const box = this.root.querySelector("#problems");
      if (box) box.innerHTML = problems.go[0] ? `<div class="problem">${esc(problems.go[0])}</div>` : "";
    }

    launch(autoConfirm) {
      // Belt over the live validation braces: recompute and refuse loudly.
      const problems = this.computeProblems();
      const blocking = autoConfirm ? problems.confirm : problems.go;
      if (blocking.length) { this.message = blocking[0]; this.render(); return; }
      const items = [...this.selected.values()].map((i) => ({ ...i }));   // copie (vedi startPlan)
      if (!items.length) return;

      const base = { autoConfirm };
      if (this.pageType === "patient") {
        const lab = items.filter((i) => !RADIO_SET.includes(i.res));
        const radio = items.filter((i) => RADIO_SET.includes(i.res));
        const legs = [];
        // ognuna col suo quesito: la radiologia ha il suo, se è scritto
        const q = (this._q || "").trim(), qrx = (this._qrx || "").trim() || q;
        if (lab.length) legs.push({ kind: "lab", label: "laboratorio", items: lab, entryUrl: this.entry?.labUrl, quesito: q });
        if (radio.length) legs.push({ kind: "radio", label: "radiologia", items: radio, entryUrl: this.entry?.radioUrl, quesito: qrx });
        if (legs.some((l) => !l.entryUrl)) { this.message = "Link di apertura richiesta non trovato su questa pagina."; this.render(); return; }
        base.startPage = "patient";
        base.legs = legs;
        base.entryUrl = legs[0].entryUrl;
        base.items = legs[0].items;
        base.quesito = legs[0].quesito;
      } else if (this.pageType === "crea") {
        const form = document.forms.namedItem("RICHIESTACrea");
        if (!form) { this.message = "Form della richiesta non trovato."; this.render(); return; }
        base.startPage = "crea";
        // una richiesta di radiologia prende il quesito RX, se è scritto
        if (items.every((i) => RADIO_SET.includes(i.res)) && (this._qrx || "").trim()) base.quesito = this._qrx.trim();
        base.creaForm = form;
        base.creaUrl = location.href;
      } else {
        base.startPage = "exam";
        base.examDoc = document;
        base.examUrl = location.href;
      }
      this.startPlan(base);
    }
  }

  // ------------------------------------------------ richieste da confermare
  // Una richiesta mandata e non ancora confermata non deve sparire dalla
  // memoria di nessuno. Prima della conferma in sottofondo (e alla fine di un
  // giro in revisione) se ne annotano SOLO i numeri — richiesta, episodio,
  // indirizzo del carrello, ora, quanti esami: mai un nome — e ogni pagina di
  // quell'episodio guarda: se fra le richieste con i fogli da stampare la sua
  // non c'è ancora dopo 2 minuti, la pill lo dice. Al server non si chiede
  // niente per questo: si guarda la pagina che il medico ha aperto. Vista
  // confermata, la si dimentica; dopo 12 ore, anche.
  const DA_CONFERMARE = "daConfermare.v1";
  const DA_CONFERMARE_TTL = 12 * 3600e3;
  const attesaConferma = () => Number(store.get("attesaConferma.ms", 0)) || 120e3;   // i test la accorciano
  function daConfermare() {
    const l = store.get(DA_CONFERMARE, []);
    return (Array.isArray(l) ? l : []).filter((x) => x && x.rid && x.ep && Date.now() - (x.ts || 0) < DA_CONFERMARE_TTL);
  }
  function ricordaDaConfermare(rid, ep, listUrl, n) {
    if (!rid || !ep || DEMO) return;
    const l = daConfermare().filter((x) => x.rid !== String(rid));
    l.push({ rid: String(rid), ep: String(ep), listUrl: listUrl || "", ts: Date.now(), n: n || 0 });
    store.set(DA_CONFERMARE, l.slice(-20));
  }
  function confermataProvata(rid) {
    const l = daConfermare();
    if (l.some((x) => x.rid === String(rid))) store.set(DA_CONFERMARE, l.filter((x) => x.rid !== String(rid)));
  }
  // quelle di questo episodio ancora senza prova, la più vecchia per prima;
  // quelle che questa pagina dimostra confermate si dimenticano qui
  function nonConfermateQui(doc = document, url = location.href) {
    const ep = findEpisodeId(doc, url);
    const tutte = daConfermare();
    if (!ep || !tutte.length) return [];
    const stampabili = printModel(doc, url);
    const restano = tutte.filter((x) => !(x.ep === ep && stampabili[x.rid]));
    if (restano.length !== (store.get(DA_CONFERMARE, []) || []).length) store.set(DA_CONFERMARE, restano);
    return restano.filter((x) => x.ep === ep).sort((a, b) => a.ts - b.ts);
  }

  // ------------------------------------------------ native-confirm handoff
  // La conferma senza guardare la pagina.
  //
  // La pagina del carrello viene caricata DAVVERO — stessa sessione, stesso
  // modulo, stesso bottone — solo dentro una cornice invisibile invece che
  // davanti agli occhi. Il clic è quello vero sul bottone del gestionale, e i
  // byte che partono sono gli stessi: la codifica del modulo la fa il browser,
  // non noi. Cambia solo che il medico non deve stare a guardare il LIS.
  //
  // La cornice gira SENZA script (`allow-forms allow-same-origin`, mai
  // `allow-scripts` né `allow-top-navigation`): così il codice della pagina non
  // può portarsi via la scheda del medico, e non serve — l'invio di un modulo
  // lo fa il browser. Se il server vieta di essere incorniciato, il documento
  // non è leggibile: ce ne accorgiamo e si torna a fare come prima.
  //
  // Fallisce sempre CHIUSA: qualunque intoppo lascia la conferma al medico.
  // E «confermata» si dice solo con una PROVA: una pagina dello stesso
  // episodio che elenca i fogli da stampare di questa richiesta. Un errore del
  // server, il carrello di nuovo, il tempo scaduto — tutto il resto è
  // «incerta», e incerta non è mai verde.
  const FRAME_MS = 25000;
  function confermaInCornice(listUrl, { panel, episodeId, rid }) {
    return new Promise((resolve) => {
      const f = document.createElement("iframe");
      f.setAttribute("sandbox", "allow-forms allow-same-origin");
      f.setAttribute("aria-hidden", "true");
      f.style.cssText = "position:fixed;left:-10000px;top:0;width:1024px;height:768px;border:0;visibility:hidden";
      let fatto = false, fase = "carico";
      const chiudi = (esito) => {
        if (fatto) return;
        fatto = true;
        clearTimeout(tid);
        try { f.remove(); } catch { /* già via */ }
        resolve(esito);
      };
      const tid = setTimeout(() => chiudi(fase === "carico" ? "rifiutata" : "incerta"), FRAME_MS);

      f.addEventListener("load", () => {
        let doc = null, url = "";
        try { doc = f.contentDocument; url = f.contentWindow.location.href; } catch { doc = null; }
        // Una cornice appena inserita emette un `load` per la sua pagina vuota,
        // prima ancora di caricare la nostra: quello non è il carrello.
        if (url === "about:blank" || url === "") return;
        // Non leggibile: prima del clic vuol dire che il server non si lascia
        // incorniciare (è la strada di prima, e si prende quella); dopo il
        // clic, che non si può sapere com'è andata.
        if (!doc || !doc.documentElement) return chiudi(fase === "carico" ? "rifiutata" : "incerta");

        if (fase === "carico") {
          fase = "confermo";
          let cliccato = false;
          try { cliccato = maybeAutoConfirm(panel, doc, url); }
          catch (e) { panel?.log(`${now()}  conferma in sottofondo interrotta: ${e?.message || e}`); }
          // Nessun clic vuol dire che un controllo ha detto di no: la pagina
          // va mostrata al medico, che decide lui.
          if (!cliccato) return chiudi("sospesa");
          panel?.render();
          return;
        }
        // Seconda pagina: quella dopo la conferma. È la prova solo se è di
        // questo episodio e porta i fogli di QUESTA richiesta — e allora i
        // fogli si prendono da lì.
        const suo = findEpisodeIdInDoc(doc);
        if (!rid || !suo || suo !== episodeId || !printModel(doc, url)[rid]) {
          panel?.log(`${now()}  dopo la conferma: "${snippet(doc).slice(0, 80)}" — nessuna prova che sia confermata`);
          return chiudi("incerta");
        }
        let stampata = false;
        try { stampata = maybeAutoPrint(panel, doc, url); } catch { stampata = false; }
        chiudi(stampata ? "stampata" : "confermata");
      });
      f.addEventListener("error", () => chiudi(fase === "carico" ? "rifiutata" : "incerta"));
      document.documentElement.appendChild(f);
      f.src = listUrl;
    });
  }

  // Il giro che la navigazione ha interrotto: riprende da dov'era, su
  // qualunque pagina del gestionale il medico sia finito. Quello che era IN
  // VOLO si cerca in carrello e non si rimanda mai — l'unica cosa che la
  // pagina morendo si porta via è la RISPOSTA, non l'ordine.
  function riprendiCorsa(panel) {
    const c = tabStore.get(CORSA, null);
    if (!c) return false;
    const daFare = (c.involo ? 1 : 0) + (c.restanti || []).length;   // roba ancora aperta: i soli «fatti» non bastano
    const scaduta = Date.now() - (c.ts || 0) > CORSA_TTL;
    const troppe = (c.riprese || 0) >= CORSA_MAX;
    if (scaduta || troppe || !c.listUrl || !c.ep || !daFare) {
      tabStore.set(CORSA, null);
      if (daFare && (scaduta || troppe)) {
        panel.message = `Il giro su ${c.paziente || "questo paziente"} era rimasto a metà da troppo tempo: apri il carrello e controlla.`;
        panel.render();
      }
      return false;
    }
    if (!presidioLibero(c.rid, null)) {
      // Qualcuno ci sta già lavorando: quasi sempre questa stessa scheda
      // duplicata, che si è portata dietro l'appunto. Non si manda niente e non
      // si butta via niente: se fra poco quel presidio scade, la pagina dopo
      // riprende. (Cambiando pagina il presidio si molla subito, quindi questo
      // non scatta per una navigazione normale.)
      panel.log(`${now()}  un'altra scheda sta già mandando gli esami di questa richiesta: da qui, niente`);
      panel.message = "Un'altra scheda sta finendo questo giro di esami: da qui non mando niente.";
      panel.render();
      return false;
    }
    const items = [];
    // Quello che era già in carrello prima dell'interruzione rientra nel giro:
    // si ricontrolla (mai si rimanda) così la ricevuta finale parla della
    // richiesta intera, non solo del pezzo dopo la navigazione.
    for (const f of c.fatti || []) items.push({ ...f, soloVerifica: true, giaFatto: true });
    if (c.involo) items.push({ ...c.involo, soloVerifica: true });
    for (const r of c.restanti || []) items.push({ ...r });
    panel.runPatient = c.paziente || "";
    // Il conto delle riprese si scrive PRIMA di ripartire: se anche questa
    // ripresa muore subito, il tetto vale lo stesso e non si ricomincia in
    // eterno a ogni ricaricamento.
    tabStore.set(CORSA, { ...c, ts: Date.now(), riprese: (c.riprese || 0) + 1 });
    panel.log(`${now()}  ── riprendo il giro dopo il cambio pagina: ${items.length} da sistemare ──`);
    runPlan({
      startPage: "ripresa", listUrl: c.listUrl, items,
      episodeId: c.ep, autoConfirm: !!c.autoConfirm, quesito: c.quesito || "",
      patientName: c.paziente || "", riprese: (c.riprese || 0) + 1,
    }, panel);
    return true;
  }

  // Un giro rimasto a metà che NESSUNO riprenderà (scheda chiusa, browser
  // caduto, sessione scaduta): l'appunto vive nella scheda e se n'è andato con
  // lei, ma il segno condiviso no. Lo si dice, una volta, e lo si toglie.
  function avvisaGiroAbbandonato(panel) {
    const a = store.get(APERTA, null);
    if (!a || !a.quanti) return false;
    const eta = Date.now() - (a.ts || 0);
    if (eta > APERTA_TTL) { store.set(APERTA, null); return false; }
    // fresco = c'è una scheda che ci sta ancora lavorando: non è abbandonato
    if (eta < 60e3 || tabStore.get(CORSA, null)) return false;
    store.set(APERTA, null);
    panel.message = `Un giro di esami su ${a.paziente || "un paziente"} è rimasto a metà: ${
      a.quanti === 1 ? "1 esame non è stato mandato" : `${a.quanti} esami non sono stati mandati`}. Apri la sua richiesta e controlla.`;
    panel.collapsed = false;   // un avviso chiuso nella pill non lo legge nessuno
    panel.render();
    return true;
  }

  function maybeAutoConfirm(panel, doc = document, url = location.href) {
    const flag = tabStore.get("confirm.v1", null);
    if (!flag) return false;
    const clear = () => { tabStore.set("confirm.v1", null); return false; };
    if (Date.now() - (flag.ts || 0) > CONFIRM_FLAG_TTL) return clear();

    const model = examModel(doc, url);
    const ep = findEpisodeId(doc, url);
    if (!model.form || !model.richiestaId) return false; // not an exam page
    // The flag is tab-scoped, so a mismatching richiesta here is stale: drop it.
    if (model.richiestaId !== flag.richiestaId || (flag.episodeId && ep && ep !== flag.episodeId)) return clear();
    if (!model.inCart(flag.lastCode)) return clear(); // right richiesta, wrong cart → abort the auto-confirm
    // Anti wrong-exam check also at the last gate before an irreversible act.
    if (flag.lastLabel) {
      const liveRow = model.exams.find((e) => e.code === flag.lastCode && e.isDel);
      const norm = (s) => (s || "").replace(/\s+/g, " ").trim().toUpperCase();
      if (!liveRow || norm(liveRow.label) !== norm(flag.lastLabel)) return clear();
    }
    if (!model.confirmButton) return clear();
    clear(); // consume immediately: a reload must never re-trigger the countdown

    const inCart = model.exams.filter((e) => e.isDel);
    const cartPreview = inCart.slice(0, 5).map((e) => shortLabel(e.label));
    if (inCart.length > 5) cartPreview.push(`+${inCart.length - 5} altri`);
    // The native Conferma submits the WHOLE richiesta, not this run's
    // additions. This page shows only the CURRENT resource's cart rows, so the
    // honest comparison is per-resource against the receipt: a row in the cart
    // that this run did not add (a leftover from an earlier attempt) means the
    // click would confirm more than the banner says — refuse, human decides.
    const receipt = tabStore.get("receipt.v1", null);
    // Senza ricevuta non si può dire «nel carrello c'è solo quello che ho
    // aggiunto io» — e la Conferma nativa invia la richiesta INTERA. Non
    // poter controllare non è come aver controllato: si ferma, e preme il
    // medico. (Prima di questa riga il controllo veniva semplicemente
    // saltato e la conferma partiva lo stesso.)
    if (!receipt || receipt.richiestaId !== model.richiestaId || !Array.isArray(receipt.items)) {
      clear();
      if (panel) {
        panel.message = "Conferma automatica sospesa: non risulta cosa è stato aggiunto in questa corsa. La Conferma invia la richiesta intera — controlla il carrello e premila tu sulla pagina.";
        panel.log(`${now()}  auto-conferma sospesa: ricevuta assente o di un'altra richiesta`);
        panel.render();
      }
      return false;
    }
    {
      // Questa pagina mostra il carrello di UNA risorsa sola, ma la Conferma
      // invia la richiesta intera. Quindi si controlla risorsa per risorsa:
      // quella davanti agli occhi dal vivo, le altre col carrello che il run
      // ha visto quando le ha visitate. Una riga che non abbiamo aggiunto,
      // su qualunque risorsa, sospende: decide una persona.
      const perRes = new Map();
      for (const i of receipt.items) {
        const r = String(i.res);
        perRes.set(r, (perRes.get(r) || new Set()).add(String(i.code)));
      }
      const carrelli = receipt.carrelli || {};
      const guai = [];
      let vistiQui = 0;
      for (const [res, attesi] of perRes) {
        const visti = res === model.res
          ? inCart.map((e) => String(e.code))
          : (Array.isArray(carrelli[res]) ? carrelli[res].map(String) : null);
        if (res === model.res) vistiQui = visti.length;
        if (!visti) { guai.push(`${risorsaCorta(res)}: carrello non visto`); continue; }
        const estranei = visti.filter((c) => !attesi.has(c));
        if (estranei.length || visti.length !== attesi.size) {
          guai.push(`${risorsaCorta(res)}: ${visti.length} nel carrello, ${attesi.size} aggiunti${estranei.length ? ` (estranei ${estranei.join(", ")})` : ""}`);
        }
      }
      if (guai.length) {
        if (panel) {
          panel.message = `Conferma automatica sospesa: ${guai.join("; ")}. La Conferma invia la richiesta intera — controlla il carrello e premila tu sulla pagina.`;
          panel.log(`${now()}  auto-conferma sospesa (${vistiQui} esami su questa risorsa): ${guai.join("; ")}`);
          panel.render();
        }
        return false;
      }
    }

    // The doctor already chose "+ Conferma": that click was the decision, and
    // every gate above has passed (episode, richiesta, last exam present under
    // its right name, cart identical to the receipt for this resource).
    // Confirm now — a countdown here was dead time, not safety.
    panel?.log(`${now()}  conferma automatica: ${flag.count} ${flag.count === 1 ? "esame" : "esami"} · ${cartPreview.join(" · ")} · click nativo su Conferma`);
    // Quando la pagina non è quella davanti agli occhi, la stampa va armata
    // qui: il gancio sul bottone vive solo sulla pagina vera.
    if (doc !== document) {
      const prec = tabStore.get("print.v1", null);
      const fresco = prec && prec.episodeId === (ep || "") && Date.now() - (prec.ts || 0) < PRINT_FLAG_TTL;
      tabStore.set("print.v1", { ids: [...new Set([...(fresco ? prec.ids || [] : []), model.richiestaId])], episodeId: ep || "", ts: Date.now(),
        n: { ...(fresco ? prec.n || {} : {}), [model.richiestaId]: receipt.items.length } });
      const q = tabStore.get("queue.v1", null);
      if (q && q.items) {
        const restano = q.items.filter((it) => it.rid !== model.richiestaId);
        tabStore.set("queue.v1", restano.length ? { ...q, items: restano, ts: Date.now() } : null);
      }
    }
    model.confirmButton.click(); // native click → server confirm → label print flow
    return true;
  }

  // ============================================================ PDF → TESTO
  // Radiology and ECG reports are PDFs whose text can be recovered: the fonts
  // carry their own ToUnicode map, so glyph codes can be translated exactly
  // instead of guessed. (Laboratory reports cannot: they are drawn one glyph
  // at a time with a subset font and no map — those stay documents to open.)
  async function estraiTestoPdf(bytes) {
    // NB: TextDecoder("latin1") is windows-1252 in the browser and rewrites
    // bytes 0x80-0x9F — which corrupts every compressed stream. One byte, one
    // code unit, by hand.
    const byteStr = (u8) => {
      let out = "";
      for (let i = 0; i < u8.length; i += 0x8000) out += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
      return out;
    };
    const lat = byteStr(bytes instanceof ArrayBuffer ? new Uint8Array(bytes) : bytes);
    const objs = new Map();
    for (const m of lat.matchAll(/(\d+)\s+\d+\s+obj\b([\s\S]*?)endobj/g)) objs.set(Number(m[1]), m[2]);
    if (!objs.size) return [];

    // The browser only decompresses asynchronously, so the whole extraction is
    // async: zlib-wrapped first (what PDFs use), raw deflate as a fallback.
    const inflate = async (grezzo) => {
      const buf = new Uint8Array(grezzo.length);
      for (let i = 0; i < grezzo.length; i++) buf[i] = grezzo.charCodeAt(i) & 0xff;
      for (const modo of ["deflate", "deflate-raw"]) {
        try {
          const ds = new DecompressionStream(modo);
          const out = new Response(new Blob([buf]).stream().pipeThrough(ds));
          return new TextDecoder("latin1").decode(await out.arrayBuffer());
        } catch { /* try the next mode */ }
      }
      return null;
    };
    const streamOf = async (body) => {
      const i = body.indexOf("stream");
      if (i < 0) return null;
      let a = i + 6;
      if (body[a] === "\r") a++;
      if (body[a] === "\n") a++;
      const e = body.lastIndexOf("endstream");
      if (e < 0 || e <= a) return null;
      // exact length when the dictionary states it (a trailing newline would
      // make the decompressor reject the whole stream), else trim it by hand
      const len = /\/Length\s+(\d+)/.exec(body.slice(0, i));
      const grezzo = len && a + Number(len[1]) <= e
        ? body.slice(a, a + Number(len[1]))
        : body.slice(a, e).replace(/\r?\n$/, "");
      if (!/\/FlateDecode/.test(body.slice(0, i))) return grezzo;
      return await inflate(grezzo);
    };

    const hexToStr = (h) => {
      let out = "";
      for (let i = 0; i + 3 < h.length + 1; i += 4) out += String.fromCharCode(parseInt(h.slice(i, i + 4), 16));
      return out;
    };
    const parseCMap = (txt) => {
      const map = new Map();
      const cs = /begincodespacerange([\s\S]*?)endcodespacerange/.exec(txt);
      const primo = cs && /<([0-9A-Fa-f]{2,})>/.exec(cs[1]);
      map.byteLen = primo ? Math.max(1, Math.floor(primo[1].length / 2)) : 1;
      for (const b of txt.matchAll(/beginbfchar([\s\S]*?)endbfchar/g)) {
        for (const m of b[1].matchAll(/<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>/g)) map.set(parseInt(m[1], 16), hexToStr(m[2]));
      }
      for (const b of txt.matchAll(/beginbfrange([\s\S]*?)endbfrange/g)) {
        for (const m of b[1].matchAll(/<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>/g)) {
          const lo = parseInt(m[1], 16), hi = parseInt(m[2], 16), dst = parseInt(m[3], 16);
          for (let c = lo; c <= hi && c - lo < 4096; c++) map.set(c, String.fromCharCode(dst + (c - lo)));
        }
      }
      return map;
    };
    const cmapDiOggetto = new Map();
    for (const [num, body] of objs) {
      const tu = /\/ToUnicode\s+(\d+)\s+0\s+R/.exec(body);
      if (!tu) continue;
      const src = objs.get(Number(tu[1]));
      const txt = src && await streamOf(src);
      if (txt) cmapDiOggetto.set(num, parseCMap(txt));
    }
    const fonts = new Map();
    for (const [, body] of objs) {
      for (const m of body.matchAll(/\/(F\d+)\s+(\d+)\s+0\s+R/g)) {
        const cm = cmapDiOggetto.get(Number(m[2]));
        if (cm) fonts.set(m[1], cm);
      }
    }

    let content = "";
    for (const [, body] of objs) {
      if (!/\/Type\s*\/Page[^s]/.test(body)) continue;
      const c = /\/Contents\s+(\d+)\s+0\s+R/.exec(body);
      if (c && objs.has(Number(c[1]))) content += ((await streamOf(objs.get(Number(c[1])))) || "") + "\n";
    }
    if (!content.trim()) {
      let best = "";
      for (const [, body] of objs) {
        const t = (await streamOf(body)) || "";
        if ((t.match(/T[jJ]/g) || []).length > (best.match(/T[jJ]/g) || []).length) best = t;
      }
      content = best;
    }
    if (!content.trim()) return [];

    let cm = null, x = 0, y = 0;
    const items = [];
    const unesc = (t) => t.replace(/\\([nrtbf()\\])/g, (m, c) => ({ n: "\n", r: "\r", t: "\t", b: "\b", f: "\f" }[c] || c))
      .replace(/\\([0-7]{1,3})/g, (m, o) => String.fromCharCode(parseInt(o, 8)));
    const decode = (t) => {
      if (!cm) return t;
      const n = cm.byteLen || 1;
      let out = "";
      for (let i = 0; i < t.length; i += n) {
        let code = 0;
        for (let k = 0; k < n && i + k < t.length; k++) code = (code << 8) | (t.charCodeAt(i + k) & 0xff);
        const u = cm.get(code);
        out += u !== undefined ? u : (n === 1 ? t[i] : "");
      }
      return out;
    };
    // strings come either literal — (testo) — or hexadecimal — <00520041>
    const daHex = (h) => {
      const pulito = h.replace(/[^0-9A-Fa-f]/g, "");
      let out = "";
      for (let i = 0; i + 1 < pulito.length; i += 2) out += String.fromCharCode(parseInt(pulito.slice(i, i + 2), 16));
      return out;
    };
    // BT resets the text matrix: without this the Td offsets of every block
    // pile up and the lines come out in the wrong order.
    const re = /\bBT\b|\/(F\d+)[^\S\n]+[\d.]+\s+Tf|([\d.-]+)\s+([\d.-]+)\s+T[dD]|([\d.-]+\s+){4}([\d.-]+)\s+([\d.-]+)\s+Tm|\((?:\\.|[^()\\])*\)\s*Tj|<[0-9A-Fa-f\s]*>\s*Tj|\[[\s\S]*?\]\s*TJ/g;
    for (const m of content.matchAll(re)) {
      const t = m[0];
      if (t === "BT") { x = 0; y = 0; continue; }
      // cambiare font azzera la mappa: un font senza ToUnicode va letto
      // grezzo, non con la tabella di un altro font (i caratteri cambierebbero)
      if (t.startsWith("/F")) { const nf = t.slice(1).split(/\s/)[0]; cm = fonts.has(nf) ? fonts.get(nf) : null; continue; }
      if (/Tm$/.test(t)) { const n = t.trim().split(/\s+/); x = parseFloat(n[4]); y = parseFloat(n[5]); continue; }
      if (/T[dD]$/.test(t)) { const n = t.trim().split(/\s+/); x += parseFloat(n[0]); y += parseFloat(n[1]); continue; }
      if (/Tj$/.test(t)) {
        const grezzo = t.trim().startsWith("<")
          ? daHex(t.slice(t.indexOf("<") + 1, t.lastIndexOf(">")))
          : unesc(t.slice(t.indexOf("(") + 1, t.lastIndexOf(")")));
        items.push({ x, y, s: decode(grezzo) });
        continue;
      }
      let s2 = "";
      for (const p of t.matchAll(/\((?:\\.|[^()\\])*\)|<[0-9A-Fa-f\s]*>/g)) {
        s2 += decode(p[0][0] === "<" ? daHex(p[0].slice(1, -1)) : unesc(p[0].slice(1, -1)));
      }
      items.push({ x, y, s: s2 });
    }
    if (!items.length) return [];

    // rebuild lines from the coordinates: same y is the same line
    items.sort((a, b) => (Math.abs(a.y - b.y) > 2 ? b.y - a.y : a.x - b.x));
    const righe = [];
    let cur = null;
    for (const it of items) {
      if (!it.s) continue;
      if (!cur || Math.abs(cur.y - it.y) > 2) { cur = { y: it.y, parts: [] }; righe.push(cur); }
      cur.parts.push(it);
    }
    return righe.map((l) => {
      const passi = [];
      for (let i = 1; i < l.parts.length; i++) {
        const dx = l.parts[i].x - l.parts[i - 1].x, n = Math.max(1, l.parts[i - 1].s.length);
        if (dx > 0) passi.push(dx / n);
      }
      passi.sort((a, b) => a - b);
      const unita = passi.length ? passi[Math.floor(passi.length / 2)] : 6;
      let out = "", prev = null;
      for (const p of l.parts) {
        if (prev) {
          const dx = p.x - prev.x;
          if (dx > unita * Math.max(1, prev.s.length) * 0.7 && !/\s$/.test(out) && !/^\s/.test(p.s)) out += " ";
        }
        out += p.s; prev = p;
      }
      return out.replace(/\s+/g, " ").trim();
    }).filter(Boolean);
  }

  // pdf.js (Mozilla) è il lettore vero: cifratura, oggetti compressi, font
  // con nomi qualsiasi, testo dentro i moduli — tutto quello che il lettore
  // qui sopra non sa. Sta dentro l'estensione e si carica nella scheda solo
  // la prima volta che serve (il service worker lo mette nel mondo isolato
  // del pannello, mai nella pagina). Senza estensione resta il lettore di casa.
  let pdfjsInArrivo = null;
  function pdfjsPronto() {
    if (globalThis.pdfjsLib?.getDocument && globalThis.pdfjsWorker?.WorkerMessageHandler) return Promise.resolve(globalThis.pdfjsLib);
    if (!hasExt()) return Promise.resolve(null);
    return pdfjsInArrivo = pdfjsInArrivo || ask({ t: "pdfjs" }).then((r) => {
      const lib = r && r.ok && globalThis.pdfjsLib?.getDocument ? globalThis.pdfjsLib : null;
      if (!lib) pdfjsInArrivo = null;   // si riprova al prossimo referto
      return lib;
    });
  }

  // Pezzi di testo con la loro posizione → righe: stessa linea di base, stessa
  // riga; dentro la riga da sinistra a destra, con uno spazio dove c'è un buco.
  function righeDaPezzi(pezzi) {
    const righe = [];
    for (const p of pezzi.filter((q) => q.s).sort((a, b) => b.y - a.y)) {
      const r = righe[righe.length - 1];
      if (r && Math.abs(r.y - p.y) <= Math.max(2, Math.min(r.h, p.h) * 0.4)) r.parti.push(p);
      else righe.push({ y: p.y, h: p.h, parti: [p] });
    }
    return righe.map((r) => {
      let out = "", prev = null;
      for (const p of r.parti.sort((a, b) => a.x - b.x)) {
        if (prev && !/\s$/.test(out) && !/^\s/.test(p.s) && p.x - (prev.x + prev.w) > Math.max(prev.h, p.h) * 0.2) out += " ";
        out += p.s; prev = p;
      }
      return out.replace(/\s+/g, " ").trim();
    }).filter(Boolean);
  }

  async function testoPdfjs(lib, bytes) {
    // una COPIA: pdf.js si prende il buffer che gli si passa, e questo serve
    // ancora intero per tenere il PDF
    const doc = await lib.getDocument({
      data: new Uint8Array(bytes).slice(), isEvalSupported: false, disableFontFace: true,
      useSystemFonts: false, useWorkerFetch: false, disableAutoFetch: true, disableStream: true, verbosity: 0,
    }).promise;
    try {
      const righe = [];
      for (let n = 1; n <= doc.numPages; n++) {
        const { items } = await (await doc.getPage(n)).getTextContent();
        righe.push(...righeDaPezzi(items.map((it) => {
          const t = it.transform || [1, 0, 0, 1, 0, 0];
          return { x: t[4], y: t[5], w: it.width || 0, h: Math.hypot(t[2], t[3]) || it.height || 10, s: it.str || "" };
        })));
      }
      return righe;
    } finally { Promise.resolve(doc.destroy()).catch(() => {}); }
  }

  // Il testo di un referto: pdf.js se c'è, il lettore di casa se no (o se
  // pdf.js non ne cava niente). Dice anche chi l'ha letto, o perché nessuno.
  async function testoPdf(bytes) {
    let motivo = "";
    const lib = await pdfjsPronto().catch(() => null);
    if (lib) {
      try {
        const righe = await testoPdfjs(lib, bytes);
        if (righe.length) return { righe, lettore: "pdf.js" };
        motivo = "pdf.js: nessun testo";
      } catch (e) { motivo = `pdf.js: ${(e && (e.name || "errore"))}${e && e.message ? ` ${String(e.message).slice(0, 80)}` : ""}`; }
    } else if (hasExt()) motivo = "pdf.js non caricato";
    const righe = await estraiTestoPdf(bytes).catch(() => []);
    return { righe, lettore: "lettore di casa", motivo };
  }

  // Com'è fatto un PDF, senza una parola di quello che c'è scritto: versione,
  // cifratura, oggetti compressi, font e codifiche, filtri, immagini, chi l'ha
  // prodotto. È quello che serve per capire perché il testo non esce.
  function pdfDiag(bytes) {
    try {
      const u8 = bytes instanceof ArrayBuffer ? new Uint8Array(bytes) : bytes;
      let t = "";
      for (let i = 0; i < u8.length; i += 0x8000) t += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
      const conta = (re) => (t.match(re) || []).length;
      const tipi = (re) => [...new Set([...t.matchAll(re)].map((m) => m[1]))].slice(0, 6).join(",") || "—";
      const enc = /\/Encrypt\s+(\d+)\s+\d+\s+R/.exec(t);
      const encObj = enc ? (new RegExp(`\\b${enc[1]}\\s+\\d+\\s+obj([\\s\\S]{0,400}?)endobj`).exec(t) || [])[1] || "" : "";
      const vr = encObj ? `V${(/\/V\s+(\d)/.exec(encObj) || [])[1] || "?"}/R${(/\/R\s+(\d)/.exec(encObj) || [])[1] || "?"}${/\/AESV[23]/.test(encObj) ? " AES" : ""}` : "";
      const leggibile = (re) => { const m = re.exec(t); return m && /^[\x20-\x7E]{2,60}$/.test(m[1]) ? m[1] : ""; };
      const prod = leggibile(/\/Producer\s*\(([^)]{2,60})\)/);   // il programma, non l'autore
      return [
        `PDF ${(/%PDF-(\d\.\d)/.exec(t) || [])[1] || "?"} ${Math.round(u8.length / 1024)}KB`,
        enc ? `cifrato ${vr}` : "non cifrato",
        `ObjStm ${conta(/\/Type\s*\/ObjStm/g)}`,
        `pagine ${conta(/\/Type\s*\/Page(?!s)/g) || "?"}`,
        `font ${tipi(/\/Subtype\s*\/(Type0|TrueType|Type1|Type3|MMType1)\b/g)}`,
        `encoding ${tipi(/\/Encoding\s*\/([A-Za-z0-9-]+)/g)}`,
        `ToUnicode ${conta(/\/ToUnicode\b/g)}`,
        `filtri ${tipi(/\/Filter\s*\[?\s*\/([A-Za-z0-9]+)/g)}`,
        `immagini ${conta(/\/Subtype\s*\/Image\b/g)}`,
        `moduli ${conta(/\/Subtype\s*\/Form\b/g)}`,
        prod ? `prodotto da «${prod}»` : "",
      ].filter(Boolean).join(" · ");
    } catch (e) { return `diagnosi PDF non riuscita (${e && e.message})`; }
  }

  // ============================================================ PRINT WIZARD
  // Sequential printing of the richiesta PDFs: labels first (label printer),
  // then the exam list (normal printer). True silent printing with per-job
  // printer selection is not possible from a web page on Windows, so this is
  // the most automatic legal flow. Chrome's dialog remembers recent
  // destinations, so switching printer is one click.
  // Mentre un PDF arriva non c'è niente davanti: a che punto è lo dice la pill
  // — o, senza pannello (o col pannello aperto), un riquadrino nell'angolo.
  // Arrivato il PDF compare la scheda di sempre: il PDF in anteprima e la
  // stampante su cui va. È il controllo di un'occhiata, e dice quale
  // stampante scegliere. Da quella cornice, visibile, si apre subito il
  // dialogo di stampa; chiuso il dialogo si passa da soli al documento dopo,
  // e la scheda si toglie finché quello non arriva.
  let wizardOpen = false;
  const cosaStampo = (job) => /^etichett/i.test(job.name) ? "le etichette"
    : /^lista esami/i.test(job.name) ? "la lista esami"
    : /^prenotazione/i.test(job.name) ? "la prenotazione RX"
    : `«${job.name}»`;

  // «6 esami confermati 14:32»: il resoconto che resta sulla pill
  const confermatiTesto = (fine) => `${fine.n ? `${fine.n} ${fine.n === 1 ? "esame confermato" : "esami confermati"}` : "Richiesta confermata"} ${hhmm(fine.ts || Date.now())}`;
  function openPrintWizard(jobs, opzioni = {}) {
    const { title = "", onClose, panel = null, tag = "Stampa", fine = null } = opzioni;
    let ultimaDiag = null;   // l'ultimo visualizzatore non catturato, per «⧉ Diagnosi»
    if (wizardOpen || !jobs.length) return;
    wizardOpen = true;

    const wrap = document.createElement("div");
    wrap.id = "psassist-print";
    const root = wrap.attachShadow({ mode: "open" });
    document.documentElement.appendChild(wrap);

    let i = 0;
    let attempts = 0;
    let blobUrl = null;
    let timer = null;
    let gen = 0;               // il caricamento in corso: uno saltato non deve stampare al posto del dopo
    // Chiudere (✕, Esc) deve fermare davvero la caccia al PDF: senza questo il
    // medico annullava, la catena continuava a chiedere al server, e una
    // seconda stampa poteva partire mentre la prima era ancora in giro.
    // Anche «Avanti» ferma quella del documento che si salta.
    let ctlDoc = null;
    let cur = null;            // il documento in anteprima: { f, printed, apertoIl, avanzato }
    let tuttiChiesti = true;   // ogni documento ha avuto la sua stampa
    let chiuso = false;
    let staccaStampa = () => {};   // toglie l'ascolto del dialogo di stampa del documento in corso

    const CSS = `${COLORS}
      .ps[hidden], .back[hidden], .pw[hidden] { display: none; }
      /* mentre il PDF arriva, senza pill: un riquadrino nell'angolo */
      .ps { position: fixed; top: 10px; right: 10px; z-index: 2147483647; display: flex; align-items: center; gap: 8px;
            max-width: min(380px, 82vw); background: #0B5CAD; color: #fff; border-radius: 12px; padding: 7px 8px 7px 11px;
            font-size: 12px; box-shadow: 0 4px 14px rgba(9,42,74,.22); cursor: pointer; }
      .ps .dot { width: 8px; height: 8px; border-radius: 50%; background: #7FD1A8; flex: none; animation: psaPulse 1.2s ease-in-out infinite; }
      .ps .pst { min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .ps .psx { border: 0; background: rgba(255,255,255,.18); color: #fff; border-radius: 999px; width: 24px; height: 24px; cursor: pointer; flex: none; }
      /* arrivato il PDF: la scheda al centro, il PDF in anteprima */
      .back { position: fixed; inset: 0; background: rgba(9,42,74,.45); z-index: 2147483646; }
      .pw { position: fixed; top: 4vh; left: 50%; transform: translateX(-50%); z-index: 2147483647;
            width: min(720px, 94vw); background: #fff; border-radius: 16px; overflow: hidden;
            box-shadow: 0 18px 48px rgba(9,42,74,.4); font-size: 13.5px; color: #16232E;
            display: flex; flex-direction: column; max-height: 92vh; }
      .pwhd { display: flex; align-items: center; flex-wrap: wrap; gap: 6px 10px; padding: 12px 16px; background: #0B5CAD; color: #fff; }
      .pwhd b { font-size: 14.5px; }
      .pwhd .pwtit { font-size: 12px; opacity: .85; }
      .pwhd .dest { margin-left: auto; background: #FFF7E6; color: #8a4b03; border-radius: 999px; padding: 4px 12px; font-weight: 700; font-size: 12.5px; }
      .pwbody { flex: 1; min-height: 320px; background: #E8EEF4; }
      .pwbody iframe { width: 100%; height: 56vh; border: 0; display: block; background: #fff; }
      .pwmsg { padding: 40px 20px; text-align: center; color: #5B6B7A; }
      .pwft { padding: 12px 16px; display: flex; gap: 8px; align-items: center; border-top: 1px solid #E3E8EF; flex-wrap: wrap; }
      .pwbtn { border: 0; border-radius: 10px; padding: 11px 16px; font-weight: 700; font-size: 13.5px; cursor: pointer; }
      .pwbtn:disabled { opacity: .45; cursor: default; }
      .pwbtn.next { background: #177245; color: #fff; }
      .pwbtn.next:hover { background: #125c37; }
      .pwbtn.re { background: #0B5CAD; color: #fff; }
      .pwbtn.re:hover:enabled { background: #094a8c; }
      .pwbtn.ghost { background: #F4F8FB; color: #16232E; border: 1px solid #C4D0DC; }
      .pwbtn.exit { background: transparent; color: #B3261E; border: 1px solid #E9BAB6; margin-left: auto; }
      /* quando la cattura non riesce, l'unica strada che funziona si vede */
      .pwbtn.grande { font-size: 15px; padding: 13px 22px; box-shadow: 0 3px 12px rgba(11,92,173,.35); }
      .pwhint { width: 100%; font-size: 11.5px; color: #5B6B7A; }
      .pwerr { margin: 12px 16px 0; background: #FBEBEA; border: 1px solid #E9BAB6; color: #7c1a14; border-radius: 10px; padding: 10px 12px; font-size: 12.5px; }
    `;
    root.innerHTML = `<style>${CSS}</style><div class="ps" role="status" hidden></div><div class="back" hidden></div>
      <div class="pw" role="dialog" aria-label="Stampa documenti" hidden><div class="pwhd"></div><div class="pwguaio"></div><div class="pwbody"></div><div class="pwft"></div></div>`;
    const ps = root.querySelector(".ps"), back = root.querySelector(".back"), pw = root.querySelector(".pw");
    const testa = pw.querySelector(".pwhd"), guaio = pw.querySelector(".pwguaio"), corpo = pw.querySelector(".pwbody"), piede = pw.querySelector(".pwft");

    const conto = () => (jobs.length > 1 ? `${Math.min(i + 1, jobs.length)}/${jobs.length}` : "");
    // La scheda (col velo) si vede o no. Il riquadrino serve solo senza pill,
    // e solo quando la scheda non c'è.
    const vedi = (si) => {
      pw.hidden = back.hidden = !si;
      if (!(panel && panel.collapsed)) ps.hidden = si;
    };
    // A che punto è: nella pill se il pannello è ridotto, altrimenti nel
    // riquadrino. Un tocco lì mostra la scheda; ✕ (o Esc) annulla.
    const stato = (testo, tono = "run") => {
      wrap.dataset.testo = testo;
      if (panel && panel.collapsed) {
        ps.hidden = true;
        panel.segnala({ tag, badge: conto(), testo, tono, daStampa: true, onTap: () => vedi(true), onStop: () => chiudi(false) });
        return;
      }
      ps.hidden = !pw.hidden;
      ps.innerHTML = `<span class="dot"></span><span class="pst"><b>${esc(tag)}${conto() ? " " + esc(conto()) : ""}</b> · ${esc(testo)}</span><button class="psx" title="Annulla la stampa (Esc)" aria-label="Annulla la stampa">✕</button>`;
      ps.querySelector(".psx").onclick = (e) => { e.stopPropagation(); chiudi(false); };
      ps.onclick = () => vedi(true);
    };
    const nota = (html) => { const h = piede.querySelector(".pwhint"); if (h) h.innerHTML = html; };
    // nel banco di prova il dialogo non c'è: si dice, e si va avanti a mano
    const scegli = () => (DEMO ? "Banco di prova: niente dialogo di stampa. Il documento è qui sopra; «→ Avanti» passa al prossimo."
      : `Scegli <b>${esc(jobs[i].printer)}</b> nel dialogo di stampa.`);

    // Testata e comandi della scheda: quale documento, su quale stampante, e
    // i bottoni di sempre. Un verbo per pulsante, un'icona per verbo (prima ce
    // n'erano cinque, e «Avanti» e «Salta» facevano la stessa cosa). Il corpo
    // — l'anteprima — non si tocca: rimettere la cornice la ricaricherebbe.
    const comandi = ({ err = "", viewer = false } = {}) => {
      const job = jobs[i];
      const nextLbl = i + 1 < jobs.length ? `→ Avanti (${i + 2} di ${jobs.length})` : "✓ Fine";
      testa.innerHTML = `<b>Stampa ${i + 1} di ${jobs.length} — ${esc(job.name)}</b>${title ? `<span class="pwtit">${esc(title)}</span>` : ""}<span class="dest">→ ${esc(job.printer)}</span>`;
      guaio.innerHTML = err ? `<div class="pwerr">${esc(err)}</div>` : "";
      piede.innerHTML = `
        ${viewer
          ? `<button class="pwbtn re grande" id="pwtab" title="Apre il documento in una scheda: da lì Ctrl+P">↗&nbsp; Apri e stampa</button>`
          : `<button class="pwbtn re" id="pwre" title="Riapre la finestra di stampa del browser" ${cur ? "" : "disabled"}>🖨&nbsp; Stampa</button>`}
        <button class="pwbtn next" id="pwnext" title="${i + 1 < jobs.length ? "Passa al documento successivo" : "Chiude: hai stampato tutto"}">${nextLbl}</button>
        ${viewer ? "" : `<button class="pwbtn ghost" id="pwtab" title="Se la stampa non parte, aprilo in una scheda">↗&nbsp; Scheda</button>`}
        ${viewer && ultimaDiag ? `<button class="pwbtn ghost" id="pwdiag" title="Copia com'è fatto il visualizzatore (senza numeri), da mandare a chi fa il pannello">⧉&nbsp; Diagnosi</button>` : ""}
        <button class="pwbtn exit" id="pwexit" title="Chiude senza stampare il resto (Esc)">✕&nbsp; Chiudi</button>
        <div class="pwhint">${viewer
          ? `Questo documento non si lascia stampare da qui: <b>↗ Apri e stampa</b>, poi Ctrl+P → <b>${esc(job.printer)}</b>, e qui «→ Avanti».`
          : err ? "" : scegli()}</div>`;
      piede.querySelector("#pwre")?.addEventListener("click", () => { if (cur && cur.f.isConnected) stampa(cur); });
      piede.querySelector("#pwnext").onclick = advance;
      piede.querySelector("#pwexit").onclick = () => chiudi(false);
      piede.querySelector("#pwtab").onclick = () => openTab(job.url, "_blank"); // user-activated → not popup-blocked
      piede.querySelector("#pwdiag")?.addEventListener("click", async () => {
        const b = piede.querySelector("#pwdiag");
        segnaCopia(b, await copiaTesto(diagnosiTesto(ultimaDiag)));
      });
    };

    const chiudi = (finito) => {
      if (chiuso) return;
      chiuso = true;
      wizardOpen = false;
      ctlDoc?.abort();
      staccaStampa();
      clearTimeout(timer);
      if (blobUrl) URL.revokeObjectURL(blobUrl);
      window.removeEventListener("keydown", onKey, true);
      wrap.remove();
      if (panel) {
        const tutto = finito && tuttiChiesti;
        if (fine) {
          // Una richiesta confermata: la pill ne resta il resoconto finché non
          // fai altro — quanti esami, a che ora — e se i fogli non sono usciti
          // tutti (annullato, saltato, non scaricato), «Ristampa» li rifà.
          panel.segnala({ tag: tutto ? "Stampato" : "Stampa non finita", testo: confermatiTesto(fine), tono: "ok",
            azione: tutto ? null : { label: "Ristampa", titolo: "Stampa di nuovo etichette e lista esami", fn: () => openPrintWizard(jobs, opzioni) } });
        } else if (finito && panel.collapsed) {
          // una stampa chiesta a mano: la pill lo dice per qualche secondo
          panel.segnala({ tag, testo: tuttiChiesti ? "✓ Stampato" : "✓ Stampa finita", tono: "ok" }, { ms: 4000, poi: () => panel.chiudiGiro() });
        } else if (panel.striscia && panel.striscia.daStampa) panel.segnala(null);
      }
      onClose?.();
    };
    const onKey = (e) => { if (e.key === "Escape") { e.stopPropagation(); chiudi(false); } };
    window.addEventListener("keydown", onKey, true);

    // Il dialogo non si è aperto (o si è chiuso all'istante: stampa non
    // disponibile su quel PC): non si salta niente, «🖨 Stampa» lo riapre.
    const nonParte = () => {
      wrap.dataset.stato = "mano";
      nota(`La finestra di stampa non si è aperta? <b>🖨 Stampa</b> la riapre — scegli <b>${esc(jobs[i].printer)}</b>.`);
      stato("Stampa: serve un tuo clic", "warn");
    };
    // La stampa del documento in anteprima: il dialogo del browser, dalla sua
    // cornice (nel banco di prova non c'è: la scheda lo dice già).
    const stampa = (c) => {
      c.printed = true;
      c.apertoIl = Date.now();
      attempts++;
      wrap.dataset.printAttempts = String(attempts);
      if (DEMO) { wrap.dataset.stato = "mano"; return; }
      wrap.dataset.stato = "stampo";
      nota(scegli());
      stato(`Stampo ${cosaStampo(jobs[i])}`);
      try { c.f.contentWindow.print(); }
      catch { nonParte(); }
    };

    const advance = () => {
      clearTimeout(timer);
      staccaStampa();
      if (!cur || !cur.printed) tuttiChiesti = false;
      cur = null;
      ctlDoc?.abort();
      if (blobUrl) { URL.revokeObjectURL(blobUrl); blobUrl = null; }
      i++;
      if (i >= jobs.length) return chiudi(true);
      load();
    };

    const load = async () => {
      const mio = ++gen;
      const job = jobs[i];
      cur = null;
      ctlDoc = new AbortController();
      const segnale = ctlDoc.signal;
      // quello che si sta stampando, leggibile da fuori (il banco di prova e i test)
      wrap.dataset.doc = `Stampa ${i + 1} di ${jobs.length} — ${job.name}`;
      wrap.dataset.printer = job.printer;
      wrap.dataset.stato = "carico";
      // Mentre arriva il PDF, niente davanti: la scheda si toglie (via anche
      // l'anteprima di prima) e la si vede solo chiedendola con un tocco.
      vedi(false);
      corpo.innerHTML = `<div class="pwmsg">Carico il PDF…</div>`;
      comandi();
      stato(`Aspetto ${cosaStampo(job)}…`);
      try {
        // un modulo di consenso è un file dell'estensione, non una pagina del
        // gestionale: si prende così com'è, senza la catena same-origin
        const { blob, via } = job.diretto
          ? { blob: await (await fetch(job.url, { signal: segnale })).blob(), via: "estensione" }
          : await fetchPdf(job.url, { signal: segnale });
        if (mio !== gen || chiuso) return;
        panel?.log(`${now()}  ${job.name}: PDF ottenuto${via ? " via " + via : ""}`);
        blobUrl = URL.createObjectURL(blob);
        const f = document.createElement("iframe");
        f.title = `Anteprima — ${job.name}`;
        const c = cur = { f, printed: false, apertoIl: 0, avanzato: false };
        // Chiuso il dialogo di stampa si passa al documento dopo da soli: è
        // quello che il medico farebbe premendo «→ Avanti», e con
        // l'etichettatrice davanti non ha una mano libera. Il browser non dice
        // se ha stampato o annullato — dice solo che il dialogo si è chiuso —
        // quindi si va avanti in tutt'e due i casi, una volta sola per
        // documento. Un dialogo che si chiude PRIMA di essersi aperto davvero
        // (stampa non disponibile) non fa saltare niente: lo dice la scheda.
        const dopoStampa = () => {
          if (c.avanzato || cur !== c || !f.isConnected || !c.printed) return;
          if (Date.now() - c.apertoIl < 500) { nonParte(); return; }
          c.avanzato = true;
          staccaStampa();
          panel?.log(`${now()}  ${job.name}: finestra di stampa chiusa, passo al documento dopo`);
          clearTimeout(timer);
          timer = setTimeout(advance, 300);
        };
        staccaStampa();   // resti del documento precedente
        window.addEventListener("afterprint", dopoStampa);
        staccaStampa = () => {
          window.removeEventListener("afterprint", dopoStampa);
          try { f.contentWindow?.removeEventListener("afterprint", dopoStampa); } catch { /* cornice già andata */ }
        };
        // il cronometro va SEMPRE dentro `timer`, e la stampa parte solo se
        // quella cornice è ancora quella in anteprima: «Avanti» ne lasciava
        // uno orfano, che stampava il documento dopo al posto di questo
        const once = () => { if (!c.printed && cur === c && f.isConnected) stampa(c); };
        f.addEventListener("load", () => {
          try { f.contentWindow?.addEventListener("afterprint", dopoStampa); } catch { /* cornice già andata */ }
          clearTimeout(timer); timer = setTimeout(once, 350);
        });
        timer = setTimeout(once, 1500); // headless/viewer-less fallback
        f.src = blobUrl;      // prima di inserirla: un solo «load», quello del PDF
        corpo.replaceChildren(f);
        comandi();            // «🖨 Stampa» adesso ha un documento
        wrap.dataset.stato = "pronto";
        vedi(true);
        stato(`Stampo ${cosaStampo(job)}`);
      } catch (e) {
        if (e?.name === "AbortError" || mio !== gen || chiuso) return;
        // This endpoint is a viewer we can't safely turn into a Blob. Don't
        // auto-open (a popup after the async fetch is blocked for lack of user
        // activation) — offer a big button the doctor clicks, which carries
        // activation and always opens the tab. The sequence still advances.
        // Non tutto quello che fallisce è «un visualizzatore»: una sessione
        // scaduta, un HTTP 500 o una risposta fuori dall'ospedale finivano
        // sotto quella scritta, e «Apri e stampa» apriva la pagina di login.
        const suo = e instanceof ViewerError;
        if (suo && e.html) {
          ultimaDiag = { cosa: `stampa ${job.name}`, url: job.url, html: e.html, diag: e.diag, quando: now() };
          if (panel) panel.diagnosi = ultimaDiag;
        }
        panel?.log(`${now()}  ${job.name}: PDF non catturato — ${suo ? `visualizzatore${e.diag ? " [" + e.diag + "]" : ""}` : `${e?.head || e?.message || e}`}`);
        corpo.innerHTML = suo
          ? `<div class="pwmsg">Premi <b>↗ Apri e stampa</b> qui sotto, poi <b>Ctrl+P → ${esc(job.printer)}</b>,<br>torna qui e premi «→ Avanti».</div>`
          : `<div class="pwmsg">Questo documento non è stato scaricato. Risolvi il problema qui sopra e riprova la stampa dal pannello.</div>`;
        comandi({
          viewer: suo,
          err: suo ? `Questo documento non si lascia catturare (è un visualizzatore).${e?.diag ? " [" + e.diag + "]" : ""}`
            : `${e?.head || "Non riuscito"}${e?.body ? " — " + e.body : ""}`,
        });
        wrap.dataset.stato = "mano";
        vedi(true);
        stato(suo ? "Apri e stampa: serve un tuo clic" : "Documento non scaricato", "warn");
      }
    };

    load();
  }

  // Post-confirm print handoff: armed when the native Conferma button is
  // clicked (both by the doctor and by the auto-confirm countdown), consumed
  // by the first subsequent page that lists this richiesta's print links —
  // the post-confirm page if it has them, otherwise the patient page.
  function armPrintOnConfirm(model, episodeId) {
    if (!model.form || !model.richiestaId) return;
    const arm = () => {
      const q = tabStore.get("queue.v1", null);
      if (q && q.items) { // this richiesta is done: drop it from the walk
        const left = q.items.filter((it) => it.rid !== model.richiestaId);
        tabStore.set("queue.v1", left.length ? { ...q, items: left, ts: Date.now() } : null);
      }
      const prev = tabStore.get("print.v1", null);
      const fresco = prev && prev.episodeId === episodeId && Date.now() - (prev.ts || 0) < PRINT_FLAG_TTL;
      const ids = [...new Set([...(fresco ? prev.ids || [] : []), model.richiestaId])]; // lab + radiology land in ONE flow
      // quanti esami: lo sa la ricevuta di questa richiesta; senza, il conto non si inventa
      const rc = tabStore.get("receipt.v1", null);
      const n = { ...(fresco ? prev.n || {} : {}) };
      if (rc && rc.richiestaId === model.richiestaId && Array.isArray(rc.items)) n[model.richiestaId] = rc.items.length;
      tabStore.set("print.v1", { ids, episodeId, ts: Date.now(), n });
    };
    for (const name of ["Update", "Update1"]) {
      const b = model.form.elements.namedItem(name);
      if (b && (b.type || "").toLowerCase() === "submit") b.addEventListener("click", arm, true);
    }
  }

  // After confirming one richiesta of a lab+radiology pair, the server drops us
  // on the patient page: carry on to the one still to confirm.
  function nextQueued(episodeId) {
    const q = tabStore.get("queue.v1", null);
    if (!q || !q.items || !q.items.length) return null;
    if (Date.now() - (q.ts || 0) > QUEUE_TTL) { tabStore.set("queue.v1", null); return null; }
    if (!episodeId || (q.episodeId && q.episodeId !== episodeId)) return null; // fail closed
    return { q, next: q.items[0] };
  }

  function goToQueued(entry, vai = nav) {
    const { q, next } = entry;
    tabStore.set("receipt.v1", { richiestaId: next.rid, episodeId: q.episodeId, ts: Date.now(), items: next.added || [], carrelli: next.carrelli || {} });
    if (q.autoConfirm && next.lastCode && next.kind !== "radio") {
      tabStore.set("confirm.v1", { richiestaId: next.rid, episodeId: q.episodeId, lastCode: next.lastCode, lastLabel: next.lastLabel, count: next.count, ts: Date.now() });
    }
    tabStore.set("queue.v1", { ...q, items: q.items.map((it, i) => (i ? it : { ...it, nav: true })), ts: Date.now() });
    vai(next.listUrl);
  }

  function maybeAutoPrint(panel, doc = document, url = location.href) {
    const flag = tabStore.get("print.v1", null);
    if (!flag) return false;
    // never print for an episode other than the page in front of the user
    const here = findEpisodeId(doc, url);
    if (!here || (flag.episodeId && flag.episodeId !== here)) return false;
    if (Date.now() - (flag.ts || 0) > PRINT_FLAG_TTL) { tabStore.set("print.v1", null); return false; }
    const map = printModel(doc, url);
    const ids = (flag.ids || [flag.richiestaId]).filter((id) => map[id]);
    if (!ids.length) return false; // this page doesn't list them yet — keep waiting
    // group by printer ACROSS the confirmed richieste: labels, then lists,
    // then radiology bookings — one uninterrupted flow
    const all = ids.map((id) => printJobsFor(map, id));
    const jobs = [
      ...all.flatMap((j) => j.filter((x) => x.printer === "etichettatrice")),
      ...all.flatMap((j) => j.filter((x) => x.printer !== "etichettatrice")),
    ];
    ids.forEach(confermataProvata);   // in pagina coi suoi fogli: confermata, non c'è più da sorvegliarla
    if (!jobs.length) return false;
    if (wizardOpen) return false;   // keep the flag: these jobs must not vanish behind another wizard
    tabStore.set("print.v1", null);
    // il resoconto che resta sulla pill: quanti esami, e quando
    const conti = ids.map((id) => (flag.n || {})[id]);
    const fine = { n: conti.every((x) => x > 0) ? conti.reduce((a, b) => a + b, 0) : 0, ts: flag.ts || Date.now() };
    openPrintWizard(jobs, { panel, tag: "Confermata", fine, title: ids.length > 1 ? `${ids.length} richieste appena confermate.` : "Richiesta appena confermata." });
    return true;
  }

  // ==================================================================== BOOT
  // The extension runs on two applications: SA4PSO, and the clinical portal
  // where the multi-day table lives. Everything below the storico reader is
  // written for SA4PSO's markup and must never be applied to the other one —
  // its login page carries a password field, and mistaking it for SA4PSO's
  // would wipe the shift's saved documents.
  const SA4PSO = location.hostname === "smarthealth.multimedica.it" || !!DEMO;
  function voceTabella(doc) {
    const el = [...doc.querySelectorAll('button, a, [role="tab"], [role="button"], li, span')]
      .find((x) => x.childElementCount <= 2 && /^tabella$/i.test((x.textContent || "").trim()));
    return el ? el.closest('button, a, [role="tab"], [role="button"], [onclick]') || el : null;
  }

  function boot() {
    if (document.getElementById("psassist-host")) return;
    // The portal's multi-day table: here the panel does not order anything and
    // does not ask the server anything. It reads the table already on screen
    // and hands it to the patient's page. Nothing else.
    if (haStorico(document)) { bootStorico(); return; }
    if (!SA4PSO) {
      // Una scheda che il pannello ha aperto per un REFERTO: qui non c'è
      // nessuna tabella da aspettare, si aspetta il PDF (vedi sotto).
      let perReferto = false;
      const chi = hasExt() ? ask({ t: "chiAprivo" }).catch(() => null) : Promise.resolve(null);
      chi.then((r) => { if (r && r.ok && r.sotto && r.cosa === "referto") { perReferto = true; leggiRefertoPortale(); } });
      // The portal is a single-page application: it paints the table AFTER
      // this script has run, and reaching it is an in-app route change that
      // never re-injects us. Probing once would mean never reading anything.
      let atteso = null;
      const occhio = new MutationObserver(() => {
        clearTimeout(atteso);
        atteso = setTimeout(() => {
          if (document.getElementById("psassist-host")) return;
          if (haStorico(document)) { occhio.disconnect(); clearTimeout(muto); bootStorico(); }
        }, 120);
      });
      occhio.observe(document.documentElement, { childList: true, subtree: true });
      // Se dopo un po' la tabella non c'è, non si resta muti: «non si vede
      // niente» è indistinguibile da «l'estensione non gira su questa pagina»,
      // e senza saperlo non si sa nemmeno cosa raccontarmi. La striscia dice
      // che il programma c'è e cosa gli manca. Sparisce da sola.
      const muto = setTimeout(async () => {
        if (document.getElementById("psassist-host") || haStorico(document)) return;
        // La scheda che il pannello ha aperto in sottofondo («⭳ Carica i
        // valori»): nessuno la guarda, quindi niente striscia. Se il portale
        // chiede di entrare lo si dice al pannello; se la tabella sta dietro la
        // voce «Tabella», la si apre — un clic nell'interfaccia del portale,
        // come farebbe il medico, e UNA volta sola.
        let mia = false;
        const r0 = await chi;
        if (perReferto || (r0 && r0.ok && r0.sotto && r0.cosa === "referto")) return;
        mia = !!(r0 && r0.ok && r0.sotto);
        if (mia) {
          let cliccato = false;
          for (let giro = 0; giro < 8 && !document.getElementById("psassist-host") && !haStorico(document); giro++) {
            if (document.querySelector('input[type="password"]')) { ask({ t: "sottoLogin" }).catch(() => {}); return; }
            const voce = !cliccato && voceTabella(document);
            if (voce) { voce.click(); cliccato = true; }
            await sleep(1500);
          }
          return;
        }
        const h = document.createElement("div");
        h.id = "psassist-attesa";
        const r = h.attachShadow({ mode: "open" });
        r.innerHTML = `<style>:host{all:initial}
          .b{position:fixed;left:12px;bottom:12px;z-index:2147483647;display:flex;align-items:center;gap:10px;
             max-width:min(520px,92vw);font:12.5px/1.4 -apple-system,"Segoe UI",Roboto,Arial,sans-serif;
             background:#6B7A88;color:#fff;border-radius:10px;padding:8px 10px 8px 12px;box-shadow:0 6px 22px rgba(11,44,80,.28)}
          button{border:1px solid rgba(255,255,255,.5);background:transparent;color:#fff;border-radius:7px;
                 padding:4px 9px;font:inherit;font-weight:600;cursor:pointer}
          button:hover{background:rgba(255,255,255,.14)}</style>
          <div class="b" role="status"><span><b>PS Assist</b> è attivo, ma qui non c'è nessuna tabella:
          apri <b>Tabella</b> nello storico dati clinici.</span><button id="via">✕</button></div>`;
        r.getElementById("via").addEventListener("click", () => h.remove());
        document.documentElement.appendChild(h);
        setTimeout(() => h.remove(), 15000);
      }, 1500);
      return;
    }
    scadenzaQuesiti();
    const pageType = classify(document);
    if (pageType === "login") {
      // La sessione è caduta. forgetAll() porta via anche l'appunto del giro:
      // se c'era qualcosa da mandare va detto QUI, prima di cancellare, perché
      // dopo il nuovo accesso non ne resterebbe traccia. Senza nomi: questa
      // pagina la può avere davanti chiunque.
      const c = tabStore.get(CORSA, null);
      const restavano = c ? (c.restanti || []).length + (c.involo ? 1 : 0) : 0;
      forgetAll();
      if (restavano) {
        const d = document.createElement("div");
        d.id = "psassist-avviso-login";
        d.style.cssText = "position:fixed;left:12px;bottom:12px;z-index:2147483647;max-width:min(520px,92vw);background:#B3261E;color:#fff;border-radius:10px;padding:10px 12px;font:13px/1.45 -apple-system,'Segoe UI',Roboto,Arial,sans-serif;box-shadow:0 6px 20px rgba(9,42,74,.35)";
        d.textContent = `PS Assist: la sessione è scaduta mentre mandava gli esami — ${restavano === 1 ? "1 esame non è partito" : restavano + " esami non sono partiti"}. Rientra e controlla il carrello dell'ultima richiesta.`;
        document.documentElement.appendChild(d);
      }
      return;
    }
    if (pageType === "other") {
      // e.g. the post-confirm label page: no panel, but a pending print
      // handoff starts here when the page lists the richiesta's print links.
      nonConfermateQui();   // le richieste che questa pagina mostra confermate non vanno più sorvegliate
      maybeAutoPrint(null);
      return;
    }
    const panel = new Panel(pageType);
    if (pageType === "patient") {
      panel.entry = patientModel(document, location.href);
      panel.esiti = esitiModel(document, location.href);
      // Se una riga di prelievo non si lascia leggere, il Registro lo dice
      // subito e con le sue parole: senza questo, un prelievo che non diventa
      // una colonna è indistinguibile da un prelievo che non esiste. Quando
      // sono tutte a posto non si scrive niente: la pagina si ricarica a ogni
      // click, e un Registro pieno di righe uguali non lo legge nessuno.
      const dp = diagPrelievi(document, location.href);
      const male = dp.filter((r) => !r.ok);
      if (male.length) {
        panel.log(`${now()}  ${male.length} righe di prelievo su ${dp.length} non si lasciano leggere:\n${
          dp.map((r) => `    ${r.ok ? "ok" : "✗ "} ${r.testo}`).join("\n")}`);
      }
    }
    panel.restoreUi(); // same tab + same episode → quesito/selezione/vista tornano come prima
    // Quello che è stato deciso in sottofondo si dice sulla pagina dove il
    // medico atterra — che può essere il carrello, non solo quella del paziente.
    // Con la striscia si atterra come pill (un giro in sottofondo non apre mai
    // la finestra da solo); un errore porta con sé il resoconto, che si apre
    // con un tocco.
    const av = tabStore.get(AVVISO, null);
    if (av) {
      tabStore.set(AVVISO, null);
      if (Date.now() - (av.ts || 0) < CONFIRM_FLAG_TTL) {
        if (av.testo) panel.message = av.testo;
        if (av.giro) {
          panel.runState = av.giro.stato || "fail";
          panel.runPatient = av.giro.paziente || "";
          panel.runData = { steps: Array.isArray(av.giro.steps) ? av.giro.steps : [], added: [],
            lastListUrl: av.giro.listUrl || null, finishedListUrl: null };
          if (av.riprova && Array.isArray(av.riprova.mancanti)) panel.riprova = av.riprova;
        }
        if (av.striscia) { panel.collapsed = true; panel.striscia = av.striscia; }
        else panel.collapsed = false;
      }
    }
    panel.render();
    // Un giro rimasto a metà viene prima di tutto: ha esami ancora da mandare,
    // e riprende da qualunque pagina del gestionale — anche da quella di un
    // altro paziente, perché le richieste portano il loro episodio con sé.
    const ripresa = riprendiCorsa(panel);
    if (!ripresa) avvisaGiroAbbandonato(panel);
    osservaScrittura();
    if (!ripresa) panel.sorvegliaConferme(true);
    if (pageType === "patient") {
      // this patient is now one the panel knows (name + episode + page only)
      // only a page that can actually order is a patient: the ER worklist
      // classifies the same way but its episode belongs to someone in the list
      if (panel.entry && (panel.entry.labUrl || panel.entry.radioUrl)) {
        rememberPatient(panel.episodeId, (document.title || "").trim(), location.href, triageDi(document));
        // Il portale clinico si apre da QUESTO link, sulla pagina di QUESTO
        // paziente: quel clic è l'identità, ed è esatta. Si annota qui, prima
        // che la scheda si apra, così di là la tabella sa di chi è senza
        // confrontare nomi e senza chiedere niente al server.
        document.addEventListener("click", (ev) => {
          const a = ev.target?.closest?.('a[href*="MODALITA=CLINICA"]');
          if (!a || !hasExt()) return;
          ask({ t: "apreStorico", ep: panel.episodeId || "", nome: panel.nomePaziente() || "" }).catch(() => {});
        }, true);
      }
      if (hasExt()) ask({ t: "portale" }).then((r) => {
        if (r && r.ok && r.origine) { panel.portale = r.origine; panel.render(); }
      }).catch(() => {});
      panel.applyAfterNav();
      const pending = nextQueued(findEpisodeId(document, location.href));
      panel.pending = pending; // a richiesta of this run still needs confirming
      // Il bottone che porta a termine la richiesta rimasta a metà (la
      // radiologia dopo il laboratorio) sta nelle Richieste: finché qualcosa
      // è in sospeso si atterra lì, non sugli Esiti.
      if (pending && panel.view === "esiti") panel.view = "richieste";
      panel.render();
      panel.refreshRefCache();
      panel.caricaStorico();
      if (ripresa) return;   // il giro ripreso arriva da sé a conferma e stampa
      if (pending) {
        // auto-continue once per richiesta; afterwards it is a button, so an
        // abandoned confirmation can never turn into a navigation loop
        if (pending.q.autoConfirm && !pending.next.nav) {
          goToQueued(pending, (u) => panel.vaiSeLibero(u, { ms: 0, striscia: { tag: "Richiesta da confermare", testo: "Conferma dal gestionale", tono: "warn" } }));
          return;
        }
      } else {
        // nothing left to confirm → print everything at once
        maybeAutoPrint(panel);
      }
    } else {
      panel.render();
    }
    if (pageType === "exam") {
      const model = examModel(document, location.href);
      learnFrom(model);
      panel.render(); // pick up anything just learned
      armPrintOnConfirm(model, findEpisodeId(document, location.href)); // native Conferma → print handoff
      if (!ripresa) {   // prima si finisce di mandare gli esami
        const cliccato = maybeAutoConfirm(panel);
        // si aspettava la conferma e un controllo ha detto di no: tocca al medico
        if (!cliccato && panel.striscia && panel.striscia.attesaConferma) {
          panel.segnala({ tag: "Conferma sospesa", testo: "Controlla il carrello e premi tu Conferma", tono: "warn", paziente: panel.striscia.paziente || "" });
        }
      }
    }
    if (pageType === "crea") {
      // Mirror a quesito the server (triage) already filled in, so the panel
      // never suggests overwriting it.
      const pageQ = document.forms.namedItem("RICHIESTACrea")?.elements?.namedItem("QUESITO_DIAGNOSTICO");
      if (pageQ && pageQ.value.trim()) { panel._q = pageQ.value; panel.render(); }
    }
  }

  // ---------------------------------------------------- portale clinico
  // A strip at the bottom of the portal page: what was read, for whom, and a
  // way to read it again after moving the columns. No panel, no ordering.
  // Una scheda del portale aperta dal pannello per leggere un REFERTO (ECG,
  // radiologia). Il PDF lo ha in mano la pagina — l'ha scaricato lei, per
  // mostrarlo — e portale-pdf.js, che sta nel suo mondo, ne passa una copia:
  // qui la si porta al service worker, che la tiene e chiude la scheda. Se il
  // portale chiede di entrare lo si dice; se il PDF non arriva, si manda com'è
  // fatta la pagina (mai il contenuto), per capire perché.
  function leggiRefertoPortale() {
    let fatto = false;
    let sguardo = null;   // i conti di portale-pdf.js: se risponde, e cosa ha visto
    const consegna = (buf, via) => {
      if (fatto || !buf || !(buf.byteLength > 8)) return;
      fatto = true;
      ask({ t: "refertoSotto", data: bufB64(buf), size: buf.byteLength, via }).catch(() => {});
    };
    window.addEventListener("message", (ev) => {
      const d = ev.data;
      if (ev.origin !== location.origin || !d || typeof d !== "object") return;
      if (d.psassistPdfPronto === 1) {
        const v = sguardo || { blob: 0, rete: 0, pdf: 0 };
        sguardo = { blob: Math.max(v.blob, d.blob || 0), rete: Math.max(v.rete, d.rete || 0), pdf: Math.max(v.pdf, d.pdf || 0) };
      }
      if (d.psassistPdf === 1) consegna(d.buf, d.via || "");
    });
    // a tutti i frame di questa origine: «sei una scheda del pannello» e
    // «ripeti quelli già visti» (lo script del portale parte prima di noi)
    const chiedi = () => {
      const tutti = [window];
      for (let i = 0; i < window.frames.length; i++) tutti.push(window.frames[i]);
      for (const w of tutti) { try { w.postMessage({ psassistSotto: 1, psassistPdfChiedi: 1 }, location.origin); } catch { /* altra origine */ } }
    };
    // …e la pagina stessa: un PDF dentro un frame, un embed o un object come blob:
    const nellaPagina = async () => {
      for (const el of document.querySelectorAll("iframe[src], embed[src], object[data]")) {
        const src = el.getAttribute("src") || el.getAttribute("data") || "";
        if (!/^blob:/i.test(src)) continue;
        try {
          const b = await (await fetch(src)).arrayBuffer();
          if (b.byteLength > 8 && String.fromCharCode(...new Uint8Array(b, 0, 5)) === "%PDF-") return consegna(b, "pagina");
        } catch { /* revocato, o d'altra origine */ }
      }
    };
    (async () => {
      for (let giro = 0; giro < 25 && !fatto; giro++) {
        if (document.querySelector('input[type="password"]')) { ask({ t: "sottoLogin" }).catch(() => {}); return; }
        chiedi();
        await nellaPagina();
        await sleep(1000);
      }
      if (!fatto) ask({ t: "refertoSottoDiag", diag: diagPortale(sguardo) }).catch(() => {});
    })();
  }
  // Com'è fatta la pagina del portale, senza niente del paziente: il percorso
  // (numeri tolti), i frame e cosa mostrano, e cosa ha visto portale-pdf.js.
  function diagPortale(sguardo) {
    const senzaId = (x) => String(x || "").replace(/[?#].*$/, "").replace(/\d{2,}/g, "#").slice(0, 80);
    const hash = String(location.hash || "").replace(/[?].*$/, "").replace(/\d+/g, "#").slice(0, 60);
    const frame = [...document.querySelectorAll("iframe, embed, object")].slice(0, 6).map((el) => {
      const src = el.getAttribute("src") || el.getAttribute("data") || "";
      const tipo = el.getAttribute("type") ? `[${el.getAttribute("type")}]` : "";
      return `${el.tagName.toLowerCase()}${tipo} ${/^blob:/i.test(src) ? "blob:" : src ? senzaId(src) : "(vuoto)"}`;
    });
    return [
      `portale ${senzaId(location.pathname)}${hash ? " " + hash : ""}`,
      sguardo ? `sguardo sì (blob ${sguardo.blob} · rete ${sguardo.rete} · pdf ${sguardo.pdf})` : "sguardo NO (portale-pdf.js non risponde)",
      `frame: ${frame.length ? frame.join(", ") : "nessuno"}`,
      `canvas ${document.querySelectorAll("canvas").length}`,
      `textLayer ${document.querySelectorAll(".textLayer").length}`,
      `script ${document.scripts.length}`,
    ].join(" · ");
  }

  function bootStorico() {
    document.getElementById("psassist-attesa")?.remove();
    let unito = null;
    let chiAprivo;   // undefined = non ancora chiesto, null = non lo sappiamo
    const host = document.createElement("div");
    host.id = "psassist-host";
    const root = host.attachShadow({ mode: "open" });
    document.documentElement.appendChild(host);

    const disegna = (stato) => {
      root.innerHTML = `
        <style>
          :host { all: initial; }
          .bar { position: fixed; left: 12px; bottom: 12px; z-index: 2147483647;
                 display: flex; align-items: center; gap: 10px; max-width: min(560px, 92vw);
                 font: 12.5px/1.4 -apple-system, "Segoe UI", Roboto, Arial, sans-serif;
                 background: #0B5CAD; color: #fff; border-radius: 10px; padding: 8px 10px 8px 12px;
                 box-shadow: 0 6px 22px rgba(11,44,80,.28); }
          .bar.ko { background: #6B7A88; }
          b { font-weight: 700; }
          .who { opacity: .85; }
          button { border: 1px solid rgba(255,255,255,.5); background: transparent; color: #fff;
                   border-radius: 7px; padding: 4px 9px; font: inherit; font-weight: 600; cursor: pointer; }
          button:hover { background: rgba(255,255,255,.14); }
          button:focus-visible { outline: 2px solid #fff; outline-offset: 1px; }
        </style>
        <div class="bar ${stato.ok ? "" : "ko"}" role="status">
          <span>${stato.html || esc(stato.testo || "")}</span>
          <button id="rileggi" title="Dopo aver spostato le colonne o cambiato il periodo">↻ Rileggi</button>
        </div>`;
      root.getElementById("rileggi").addEventListener("click", leggi);
    };

    const leggi = async () => {
      const letto = leggiStorico(document);
      if (!letto) { disegna({ ok: false, testo: "Nessuna tabella da leggere in questa pagina." }); return; }
      // Da quale paziente il medico è arrivato qui: l'ha aperto lui, dalla sua
      // pagina. È l'identità più solida che ci sia, e non costa una richiesta.
      // Si richiede a OGNI lettura: la scheda del portale resta aperta, e nel
      // frattempo il medico può aver cliccato «Storico» da un altro paziente.
      if (hasExt()) {
        chiAprivo = null;
        try { const r = await ask({ t: "chiAprivo" }); if (r && r.ok) chiAprivo = r; } catch { /* si va avanti */ }
      }
      // …ma vale solo se di là c'è LO STESSO nome: il portale cambia paziente
      // senza ricaricare la pagina, e la tabella di un altro non deve portarsi
      // dietro l'episodio da cui si era partiti.
      const dalClic = !!(chiAprivo && chiAprivo.ep && combaciaNome(chiAprivo.nome, letto.paziente));
      if (dalClic) { letto.ep = chiAprivo.ep; letto.nomeSa4 = chiAprivo.nome || ""; }
      unito = unisciStorico(unito, letto);
      const valori = unito.righe.reduce((n, r) => n + r.valori.filter((v) => v.v).length, 0);
      const chi = [unito.paziente.cognome, unito.paziente.nome].filter(Boolean).join(" ");
      const quanti = `<b>${esc(String(unito.righe.length))} esami · ${esc(String(unito.date.length))} prelievi</b> letti (${esc(String(valori))} valori)`;
      // l'unico testo con del markup dentro: passa da `html`, e ogni pezzo che
      // viene dalla pagina del portale è scappato qui, uno per uno
      const nonSuo = chiAprivo && chiAprivo.ep && !dalClic
        ? ` · non è ${esc(chiAprivo.nome || "il paziente")}, da cui l'hai aperta: si attribuirà col codice fiscale (⭳ Carica i valori)` : "";
      const detto = (nuovo, n) => `${quanti} <span class="who">— ${esc(chi)}${nuovo ? ", nuovo" : ""}${n > 1 ? ` · ${esc(String(n))} pazienti in memoria` : ""}${nonSuo}</span>. Torna sul paziente: sono in Esiti.`;
      if (!hasExt()) {
        disegna({ ok: false, testo: `Letti ${unito.righe.length} esami, ma serve l'estensione per portarli sul paziente.` });
        return;
      }
      // una scheda per paziente: se non c'era, la crea
      mettiInScheda(chiaveArchivio(unito), unito).then((r) => {
        disegna(r && r.ok ? { ok: true, html: detto(r.nuovo, r.pazienti || 1) }
          : { ok: false, testo: "Letto, ma l'estensione non li ha ricevuti: apri il paziente e riprova." });
      });
    };

    // the table redraws when the period changes or the columns are scrolled
    let attesa = null;
    const osserva = document.querySelector(".clinical-data-table__freeze-panel");
    if (osserva) {
      new MutationObserver(() => { clearTimeout(attesa); attesa = setTimeout(leggi, 400); })
        .observe(osserva, { childList: true, subtree: true });
    }
    // Il portale disegna solo le colonne IN VISTA: il medico scorre la tabella e
    // i prelievi compaiono. Nella scheda che il pannello ha aperto in sottofondo
    // non scorre nessuno — e si leggevano solo i primi quattro. Lì la tabella la
    // si scorre qui, a passi, da un capo all'altro: lo stesso gesto del medico,
    // nessuna richiesta nostra. Ogni passo che disegna colonne nuove le aggiunge
    // a quelle già lette (unisciStorico somma, non sostituisce).
    const scorriTutto = async () => {
      const sc = document.querySelector(".clinical-data-table__freeze-container-right");
      if (!sc || sc.scrollWidth <= sc.clientWidth + 4) return;
      const vai = async (x) => {
        sc.scrollLeft = x;
        sc.dispatchEvent(new Event("scroll"));   // in una scheda nascosta il browser non lo manda da sé
        await sleep(700);
        await leggi();
      };
      const passo = Math.max(60, Math.floor(sc.clientWidth * 0.7));
      for (let x = 0; x < sc.scrollWidth; x += passo) await vai(x);
      await vai(sc.scrollWidth);
    };
    leggi().then(() => { if (chiAprivo && chiAprivo.sotto) scorriTutto().catch(() => {}); });
  }

  boot();
})();
