﻿# PS Assist — stampa automatica: l'aiutante che Chrome (o Edge) avvia per UNA
# domanda dell'estensione, e che esce appena ha risposto. In Windows non resta
# acceso niente: nessun processo fisso, nessuna icona.
#
# Il protocollo è quello dei «native messaging host» di Chrome: su stdin 4 byte
# (la lunghezza, little-endian) e un JSON in UTF-8; la risposta allo stesso modo
# su stdout. Cinque domande, nient'altro:
#   {t:"ping"}                                  → la versione
#   {t:"stampanti"}                             → le stampanti installate e la predefinita
#   {t:"stampa", pdf, stampante, tipo, ruota}   → quel PDF su QUELLA stampante, senza dialogo
#   {t:"chi", avviata?}                         → che versione c'è in %LOCALAPPDATA%\PSAssist\estensione
#   {t:"aggiorna", zip, versione}               → «Aggiorna app»: lo zip (scaricato da Chrome)
#                                                 al posto di quella cartella, la vecchia in
#                                                 estensione.prima, e i file di questa cartella
# e per la stampa un esito, detto onestamente:
#   ok:true,  esito "stampato"     il foglio è uscito dalla coda di Windows
#   ok:true,  esito "mandato"      è nella coda di Windows, e lì è rimasto
#   ok:false, esito "fallito"      non è uscito niente (stampante spenta o sparita, PDF rotto…)
#   ok:false, esito "sconosciuto"  può essere uscito (SumatraPDF non ha finito, la stampante
#                                  si è fermata mentre stampava)
# Tutto entro 35 secondi dall'avvio (l'estensione ne aspetta 90). Non usa la
# rete, non esegue altro che SumatraPDF.exe di questa cartella, e annota solo in
# %LOCALAPPDATA%\PSAssist\stampa.log (mai il contenuto, mai nomi).
# Scrive solo in %LOCALAPPDATA%\PSAssist (estensione, estensione.prima, stampa,
# il registro) e in %TEMP% (psassist-*, tolti sempre, anche quando va storto).

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'   # stdout è di Chrome: niente barre, niente testo
$INIZIO = Get-Date
$VERSIONE = '3'
$MAX_MESSAGGIO = 40MB    # il PDF (o lo zip di «Aggiorna app») in base64 e poco altro
$MAX_PDF = 25MB
$TETTO_S = 35            # tutto il lavoro di una stampa; con l'avvio di PowerShell, sotto i 40
# dopo SumatraPDF, quanto si guarda la coda di Windows: un'etichettatrice di
# rete ci mette di più, e «stampato» deve essere l'esito di tutti i giorni
$CODA_S = @{ etichette = 10; a4 = 4 }
$SUMATRA = Join-Path $PSScriptRoot 'SumatraPDF.exe'
$base = $env:LOCALAPPDATA
if (-not $base) { $base = [IO.Path]::GetTempPath() }
$LOG = Join-Path (Join-Path $base 'PSAssist') 'stampa.log'
$TEMP = [IO.Path]::GetTempPath()
$partito = $false        # SumatraPDF è partito: da qui in poi un guaio non è più «non è uscito niente»

function Annota([string]$riga) {
  try {
    $dir = Split-Path $LOG
    if (-not (Test-Path -LiteralPath $dir)) { $null = New-Item -ItemType Directory -Path $dir }
    if ((Test-Path -LiteralPath $LOG) -and (Get-Item -LiteralPath $LOG).Length -gt 256KB) { Move-Item -LiteralPath $LOG "$LOG.1" -Force }
    Add-Content -LiteralPath $LOG -Value ('{0:yyyy-MM-dd HH:mm:ss}  {1}' -f (Get-Date), $riga) -Encoding UTF8
  } catch { }   # un registro che non si scrive non ferma la stampa
}

# Un esito che non è «stampato»: il motivo per il medico, e che cosa vuol dire.
function Esito([string]$esito, [string]$why) {
  $e = New-Object Exception $why
  $e.Data['esito'] = $esito
  throw $e
}

# Esattamente n byte: stdin arriva a pezzi.
function Leggi([IO.Stream]$s, [int]$n) {
  $buf = New-Object byte[] $n
  $letti = 0
  while ($letti -lt $n) {
    $k = $s.Read($buf, $letti, $n - $letti)
    if ($k -le 0) { throw 'messaggio troncato' }
    $letti += $k
  }
  , $buf
}

function Rispondi($obj) {
  $b = [Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Compress -Depth 3))
  $out = [Console]::OpenStandardOutput()
  $out.Write([BitConverter]::GetBytes([int32]$b.Length), 0, 4)
  $out.Write($b, 0, $b.Length)
  $out.Flush()
}

# Le stampanti di questo utente, con la predefinita di Windows. Solo per la
# pagina delle impostazioni: per stampare se ne guarda una sola (Pronta).
function Stampanti {
  $tutte = @()
  try { $tutte = @(Get-CimInstance -ClassName Win32_Printer -OperationTimeoutSec 20 | ForEach-Object { [pscustomobject]@{ nome = [string]$_.Name; predefinita = [bool]$_.Default } }) } catch { }
  if (-not $tutte.Count) {
    try { $tutte = @(Get-Printer | ForEach-Object { [pscustomobject]@{ nome = [string]$_.Name; predefinita = $false } }) } catch { }
  }
  $tutte | Select-Object -First 100   # la risposta a Chrome non può superare 1 MB
}

# La stampante di questo foglio: c'è, col nome esatto che le dà Windows, ed è
# accesa? Se c'è lo dice lo spooler (InstalledPrinters, niente WMI); se è
# accesa, una domanda a Windows per QUELLA stampante — mai l'elenco intero,
# che con le code di un server di stampa costava secondi a ogni foglio.
function Pronta([string]$nome) {
  # un nome con le virgolette, o che finisce con «\», romperebbe la riga di comando di SumatraPDF
  if (-not $nome -or $nome.Contains('"') -or $nome.EndsWith('\')) { Esito 'fallito' ('il nome della stampante «{0}» non si può usare: scegline un''altra nelle impostazioni' -f $nome) }
  $tutte = $null
  try {
    Add-Type -AssemblyName System.Drawing
    $tipo = 'System.Drawing.Printing.PrinterSettings' -as [type]
    if ($tipo) { $tutte = @($tipo::InstalledPrinters) }
  } catch { }
  if ($tutte) {
    $vero = $tutte | Where-Object { $_ -eq $nome } | Select-Object -First 1
    if (-not $vero) { Esito 'fallito' ('la stampante «{0}» non c''è su questo PC' -f $nome) }
    $nome = [string]$vero
  }
  $wql = $nome.Replace('\', '\\').Replace("'", "\'")
  try { $p = @(Get-CimInstance -ClassName Win32_Printer -Filter "Name='$wql'" -OperationTimeoutSec 5) | Select-Object -First 1 }
  catch { return $nome }   # Windows non risponde: una stampante spenta la dice la coda, dopo
  if (-not $p) {
    if ($tutte) { return $nome }
    Esito 'fallito' ('la stampante «{0}» non c''è su questo PC' -f $nome)
  }
  if ($p.WorkOffline -or $p.PrinterStatus -eq 7) { Esito 'fallito' ('la stampante «{0}» risulta spenta o offline' -f $nome) }
  $nome
}

# La misura della prima pagina (la prima MediaBox del file), per il registro e
# per la pagina di prova: dice se l'etichetta è più larga che alta. Nessun contenuto.
function Misura([byte[]]$byte) {
  $testa = [Text.Encoding]::ASCII.GetString($byte, 0, [Math]::Min($byte.Length, 256KB))
  $m = [regex]::Match($testa, '/MediaBox\s*\[\s*(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s*\]')
  if (-not $m.Success) { return $null }
  $v = 1..4 | ForEach-Object { [double]::Parse($m.Groups[$_].Value, [Globalization.CultureInfo]::InvariantCulture) }
  , @([math]::Round($v[2] - $v[0]), [math]::Round($v[3] - $v[1]))
}

# Il foglio è nella coda di Windows (SumatraPDF lo chiama col percorso del
# file). Uscito dalla coda: stampato. Fermo in errore, offline o in pausa: lo si
# toglie, e non è uscito niente — a meno che stesse già stampando: un pezzo
# può essere uscito, o restare nella memoria della stampante e uscire dopo
# (sconosciuto: mai un secondo foglio da solo). Ancora lì quando il tempo
# finisce: mandato, e basta.
function Coda([string]$nome, [string]$file, [datetime]$fino) {
  $chiave = [IO.Path]::GetFileNameWithoutExtension($file)
  do {
    try { $miei = @(Get-PrintJob -PrinterName $nome | Where-Object { [string]$_.DocumentName -like "*$chiave*" }) }
    catch { return 'mandato' }   # la coda non si lascia leggere: di più non si sa
    if (-not @($miei | Where-Object { [string]$_.JobStatus -notmatch 'Printed|Complete' }).Count) { return 'stampato' }
    if ($miei | Where-Object { [string]$_.JobStatus -match 'Error|Offline|Paused' }) {
      $tolto = $true
      foreach ($j in $miei) { try { Remove-PrintJob -InputObject $j } catch { $tolto = $false } }
      if ($miei | Where-Object { [string]$_.JobStatus -match 'Printing' -or $_.PagesPrinted -gt 0 }) {
        Esito 'sconosciuto' ('la stampante «{0}» si è fermata mentre stampava: il foglio può essere uscito, o uscire quando riparte' -f $nome)
      }
      if ($tolto) { Esito 'fallito' ('la stampante «{0}» risulta spenta o offline: il foglio è stato tolto dalla coda' -f $nome) }
      Esito 'sconosciuto' ('la stampante «{0}» risulta spenta o offline, e il foglio non si toglie dalla coda: può uscire quando torna accesa' -f $nome)
    }
    Start-Sleep -Milliseconds 500
  } while ((Get-Date) -lt $fino)
  'mandato'
}

function Stampa($d, [string]$pdf64) {
  if ($d.tipo -ne 'etichette' -and $d.tipo -ne 'a4') { Esito 'fallito' 'tipo di foglio sconosciuto' }
  try { $byte = [Convert]::FromBase64String($pdf64) } catch { Esito 'fallito' 'il PDF non è leggibile' }
  if ($byte.Length -gt $MAX_PDF) { Esito 'fallito' 'il PDF è troppo grande' }
  if ($byte.Length -lt 5 -or [Text.Encoding]::ASCII.GetString($byte, 0, 5) -ne '%PDF-') { Esito 'fallito' 'non è un PDF' }
  $nome = Pronta ([string]$d.stampante)
  if (-not (Test-Path -LiteralPath $SUMATRA)) { Esito 'fallito' 'manca SumatraPDF.exe nella cartella della stampa automatica: rilancia installa.cmd' }
  # Le etichette alla loro misura vera; il resto adattato al foglio. SumatraPDF
  # gira di 90° ogni pagina più larga che alta: con i driver delle
  # etichettatrici (Zebra, TSC, Citizen) l'etichetta uscirebbe di traverso, e
  # per loro la rotazione è spenta («ruota: no», dalle impostazioni).
  $opzioni = if ($d.tipo -ne 'etichette') { 'fit' } elseif ($d.ruota -eq 'no') { 'noscale,disable-auto-rotation' } else { 'noscale' }
  $file = Join-Path $TEMP ('psassist-{0}.pdf' -f [guid]::NewGuid().ToString('N'))
  [IO.File]::WriteAllBytes($file, $byte)
  try {
    $coda = $CODA_S[[string]$d.tipo]
    $attesa = [math]::Max(5, [math]::Floor($TETTO_S - $coda - ((Get-Date) - $INIZIO).TotalSeconds))
    $si = New-Object Diagnostics.ProcessStartInfo
    $si.FileName = $SUMATRA
    $si.Arguments = '-print-to "{0}" -print-settings "{1}" -silent "{2}"' -f $nome, $opzioni, $file
    $si.UseShellExecute = $false
    $si.CreateNoWindow = $true
    # stdin e stdout sono il filo con Chrome: SumatraPDF ha i suoi
    $si.RedirectStandardInput = $true
    $si.RedirectStandardOutput = $true
    $si.RedirectStandardError = $true
    $p = [Diagnostics.Process]::Start($si)   # (bloccato da una regola: non è partito, non è uscito niente)
    $script:partito = $true
    $null = $p.StandardOutput.ReadToEndAsync()
    $null = $p.StandardError.ReadToEndAsync()
    if (-not $p.WaitForExit($attesa * 1000)) {
      try { $p.Kill() } catch { }
      Esito 'sconosciuto' ('SumatraPDF non ha finito in {0} secondi: il foglio può essere uscito lo stesso' -f $attesa)
    }
    # SumatraPDF 3.6.1 esce col numero dei file che non ha stampato: 1, qui.
    # Un foglio che non riesce a stampare lo toglie dalla coda: non è uscito niente.
    if ($p.ExitCode -ne 0) { Esito 'fallito' ('SumatraPDF non è riuscito a stampare il foglio{0}' -f $(if ($p.ExitCode -ne 1) { " (codice $($p.ExitCode))" } else { '' })) }
    $esito = Coda $nome $file ((Get-Date).AddSeconds($coda))
  } finally {
    Remove-Item -LiteralPath $file -Force -ErrorAction SilentlyContinue
  }
  [pscustomobject]@{ esito = $esito; stampante = $nome; pagina = (Misura $byte); opzioni = $opzioni }
}

# ---- «Aggiorna app» -----------------------------------------------------------
# Lo zip l'ha scaricato l'estensione (la rete di Chrome): qui niente rete. Si
# apre in %TEMP%, si controlla (extension\manifest.json, stessa chiave della
# cartella installata, la versione detta, più nuova), la cartella installata
# diventa estensione.prima (una copia sola: ripristina.cmd la rimette) e la
# nuova va al suo posto, con installata.json. Poi i file di questa cartella
# (host.cmd no: cmd.exe lo sta leggendo adesso, una riga alla volta) e
# SumatraPDF, solo se è un altro e ha l'impronta che il nuovo installa.ps1 aspetta.
function Versione([string]$v) { $x = $null; if ([version]::TryParse($v, [ref]$x)) { $x } else { [version]'0.0' } }
function Manifest([string]$dir) { Get-Content -LiteralPath (Join-Path $dir 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json }
$CASA = Split-Path $LOG
$EST = Join-Path $CASA 'estensione'

function Aggiorna($d, [string]$zip64) {
  if (-not (Test-Path -LiteralPath (Join-Path $EST 'manifest.json'))) { throw ('l''estensione non è installata in {0}: rilancia installa.cmd' -f $EST) }
  try { $byte = [Convert]::FromBase64String($zip64) } catch { throw 'lo zip non è leggibile' }
  if ($byte.Length -lt 4 -or $byte[0] -ne 0x50 -or $byte[1] -ne 0x4B) { throw 'non è uno zip' }
  $prima = Join-Path $CASA 'estensione.prima'
  $g = [guid]::NewGuid().ToString('N')
  $zip = Join-Path $TEMP "psassist-agg-$g.zip"
  $tmp = Join-Path $TEMP "psassist-agg-$g"
  try {
    [IO.File]::WriteAllBytes($zip, $byte)
    Expand-Archive -LiteralPath $zip -DestinationPath $tmp
    $nuova = Join-Path $tmp 'extension'
    if (-not (Test-Path -LiteralPath (Join-Path $nuova 'manifest.json'))) { throw 'nello zip manca extension\manifest.json' }
    $n = Manifest $nuova
    $o = Manifest $EST
    if ([string]$n.key -ne [string]$o.key) { throw 'lo zip non è di PS Assist (la chiave è diversa)' }
    if ([string]$n.version -ne [string]$d.versione) { throw ('lo zip è la {0}, non la {1}' -f $n.version, $d.versione) }
    if ((Versione $n.version) -le (Versione $o.version)) { throw ('la {0} non è più nuova della {1}' -f $n.version, $o.version) }
    if (Test-Path -LiteralPath $prima) { Remove-Item -LiteralPath $prima -Recurse -Force }
    # una cartella in uso non si rinomina: allora la si copia, e la nuova va sopra
    $rinominata = $true
    try { Rename-Item -LiteralPath $EST -NewName 'estensione.prima' }
    catch { $rinominata = $false; Copy-Item -LiteralPath $EST -Destination $prima -Recurse }
    try {
      if ($rinominata) { $null = New-Item -ItemType Directory -Path $EST }
      Get-ChildItem -LiteralPath $nuova | Copy-Item -Destination $EST -Recurse -Force
      Copy-Item -LiteralPath (Join-Path $prima 'installata.json') -Destination $EST -Force
    } catch {
      # a metà: torna quella di prima
      if ($rinominata) { Remove-Item -LiteralPath $EST -Recurse -Force -ErrorAction SilentlyContinue; Rename-Item -LiteralPath $prima -NewName 'estensione' }
      else { Get-ChildItem -LiteralPath $prima | Copy-Item -Destination $EST -Recurse -Force -ErrorAction SilentlyContinue }
      throw
    }
    # l'aiutante stesso: un intoppo qui non disfa l'estensione, già al suo posto
    try {
      $dove = Join-Path $CASA 'stampa'
      $sz = Join-Path $tmp 'stampa'
      foreach ($f in 'host.ps1', 'installa.ps1', 'disinstalla.cmd', 'ripristina.cmd') {
        if (Test-Path -LiteralPath (Join-Path $sz $f)) { Copy-Item -LiteralPath (Join-Path $sz $f) -Destination $dove -Force }
      }
      $atteso = [regex]::Match([IO.File]::ReadAllText((Join-Path $sz 'installa.ps1')), '\$EXE_SHA256 = ''([0-9A-F]{64})''').Groups[1].Value
      $exe = Join-Path $sz 'SumatraPDF.exe'
      $qui = Join-Path $dove 'SumatraPDF.exe'
      if ($atteso -and (Test-Path -LiteralPath $exe) -and (Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash -eq $atteso -and
          -not ((Test-Path -LiteralPath $qui) -and (Get-FileHash -LiteralPath $qui -Algorithm SHA256).Hash -eq $atteso)) {
        Copy-Item -LiteralPath $exe -Destination $qui -Force
      }
    } catch { Annota ('aggiorna: i file della stampa non si rinnovano - {0}' -f $_.Exception.Message) }
  } finally {
    Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
  }
  [string]$n.version
}

$d = $null
try {
  # I fogli di una stampa interrotta (il PC spento a metà, la sessione chiusa)
  # non restano nella cartella temporanea: a ogni avvio via quelli di più di 10 minuti.
  Get-ChildItem -LiteralPath $TEMP -Filter 'psassist-*.pdf' -ErrorAction SilentlyContinue |
    Where-Object { $_.LastWriteTime -lt (Get-Date).AddMinutes(-10) } |
    Remove-Item -Force -ErrorAction SilentlyContinue
  # (e quelli di un aggiornamento fermato a metà: Chrome chiude l'aiutante, il finally non arriva)
  Get-ChildItem -LiteralPath $TEMP -Filter 'psassist-agg-*' -ErrorAction SilentlyContinue |
    Where-Object { $_.LastWriteTime -lt (Get-Date).AddMinutes(-10) } |
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
  $in = [Console]::OpenStandardInput()
  $n = [BitConverter]::ToInt32((Leggi $in 4), 0)
  if ($n -le 0 -or $n -gt $MAX_MESSAGGIO) { throw 'messaggio di lunghezza impossibile' }
  $testo = [Text.Encoding]::UTF8.GetString((Leggi $in $n))
  # Il PDF, o lo zip (base64: mai virgolette dentro), si stacca prima di leggere
  # il JSON: il resto è piccolo, e ConvertFrom-Json non deve masticare megabyte.
  $pdf64 = ''
  $m = [regex]::Match($testo, '"(?:pdf|zip)"\s*:\s*"([A-Za-z0-9+/=]*)"')
  if ($m.Success) {
    $pdf64 = $m.Groups[1].Value
    $testo = $testo.Remove($m.Groups[1].Index, $m.Groups[1].Length)
  }
  $d = $testo | ConvertFrom-Json
  switch ([string]$d.t) {
    'ping' { Rispondi @{ ok = $true; versione = $VERSIONE } }
    'stampanti' {
      $tutte = @(Stampanti)
      $pred = $tutte | Where-Object { $_.predefinita } | Select-Object -First 1
      Rispondi @{ ok = $true; stampanti = @($tutte | ForEach-Object { $_.nome }); predefinita = [string]$pred.nome }
    }
    'stampa' {
      $r = Stampa $d $pdf64
      $mm = if ($r.pagina) { '{0}x{1} mm' -f [math]::Round($r.pagina[0] * 25.4 / 72), [math]::Round($r.pagina[1] * 25.4 / 72) } else { 'misura ?' }
      Annota ('stampa {0} -> {1}: {2} ({3} KB, {4:0.0} s, {5}, {6})' -f $d.tipo, $r.stampante, $r.esito, [math]::Round($pdf64.Length * 3 / 4 / 1KB), ((Get-Date) - $INIZIO).TotalSeconds, $mm, $r.opzioni)
      Rispondi @{ ok = $true; esito = $r.esito; stampante = $r.stampante; pagina = $r.pagina }
    }
    'chi' {
      $v = ''
      try { $v = [string](Manifest $EST).version } catch { }   # non installata lì
      if ($d.avviata) { Annota ('estensione avviata: {0}' -f [string]$d.avviata) }
      Rispondi @{ ok = $true; versione = $VERSIONE; estensione = $v; cartella = $EST }
    }
    'aggiorna' {
      $v = Aggiorna $d $pdf64
      Annota ('aggiorna -> {0} ({1} KB, {2:0.0} s)' -f $v, [math]::Round($pdf64.Length * 3 / 4 / 1KB), ((Get-Date) - $INIZIO).TotalSeconds)
      Rispondi @{ ok = $true; versione = $v }
    }
    default { throw 'domanda sconosciuta' }
  }
} catch {
  $why = [string]$_.Exception.Message
  # un guaio non previsto dopo la partenza di SumatraPDF: il foglio può essere uscito
  $esito = [string]$_.Exception.Data['esito']
  if (-not $esito) { $esito = if ($partito) { 'sconosciuto' } else { 'fallito' } }
  Annota ('{0} {1}: {2} - {3}' -f $(if ($d) { $d.t } else { '?' }), $(if ($d) { $d.tipo } else { '' }), $esito, $why)
  Rispondi @{ ok = $false; esito = $esito; why = $why }
}
